// "The Shepherd's Boy". The boy's plan is a root Situation holding the
// cried-wolf trick aimed at company and excitement; the first cry is the
// planned one by the narrator's Corresponds. The two trick cries
// happen, help comes twice, then the wolf actually comes out and worries
// the flock while the third, louder cry gets a claim Situation of its
// own (the wolf is present). The wolf's presence holds from its coming
// out on; before that no wolf was present — a NoInstance over a Virtual
// wolf pattern whose window ends at the coming out; after the third cry
// no help came — a NoInstance over a Virtual help pattern; the villagers
// believing the boy was again deceiving them is the belief Situation
// that caused the not-coming.
import {
  TimeAnchor,
  Situation,
  Wolf,
  Entity,
  Present,
  InOrderTo,
  Get,
  CryOut,
  ComeToHelp,
  ComeOut,
  Worry,
  Plans,
  Believes,
  Deceives,
  Causes,
  NoInstance,
  Corresponds,
  In,
  At,
  Within,
  Assert,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import {
  entity,
  Virtualize,
  Occurred,
  Did,
  PatternEvent,
  StartsWithin,
  Chain,
  Bounds,
} from "../helpers.mjs";

export function BuildStory(input, story) {
  const boy = entity(story, "the boy");
  const flock = entity(story, "his flock");
  const villagers = entity(story, "the villagers");
  const forest = entity(story, "the forest");
  const wolf = new Wolf(story);
  wolf.name = "the wolf";
  input.push(boy, flock, villagers, forest, wolf);

  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  input.push(storyStart, storyEnd);

  // The plan: cry wolf to get a little company and some excitement. A
  // root Situation (§12): it holds only what the boy plans.
  const plan = new Situation();
  input.push(plan);
  const company = entity(plan, "a little company");
  const excitement = entity(plan, "some excitement");
  input.push(company, excitement);
  const getBoth = new Get(plan);
  getBoth.theme = [company, excitement];
  input.push(getBoth);
  Did(input, getBoth, boy);
  const cryPlan = new CryOut(plan);
  cryPlan.call = "Wolf, Wolf";
  input.push(cryPlan);
  Did(input, cryPlan, boy);
  const aimed = new InOrderTo(plan);
  aimed.action = cryPlan;
  aimed.goal = getBoth;
  Assert(input, aimed);

  // The third cry's own claim, a root Situation. Its content is about
  // the moment of the cry, so the time is written out (§12.1) against
  // the story's own anchor, once that anchor exists below.
  const claim3 = new Situation();
  input.push(claim3);

  const cry1 = new CryOut(story);
  cry1.call = "Wolf, Wolf";
  const help1 = new ComeToHelp(story);
  help1.theme = boy;
  const cry2 = new CryOut(story);
  cry2.call = "Wolf, Wolf";
  const help2 = new ComeToHelp(story);
  help2.theme = boy;
  const comeOut = new ComeOut(story);
  comeOut.from = forest;
  const worry = new Worry(story);
  worry.theme = flock;
  const cry3 = new CryOut(story);
  cry3.call = "Wolf, Wolf";
  cry3.content = claim3;
  const happened = [
    [cry1, boy], [help1, villagers], [cry2, boy], [help2, villagers],
    [comeOut, wolf], [worry, wolf], [cry3, boy],
  ];
  for (const [event, actor] of happened) Occurred(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, cry1, cry3, storyEnd);

  const claimed = new Present(claim3);
  claimed.subject = wolf;
  input.push(claimed);
  const claimedAtCry = new At(claim3);
  claimedAtCry.proposition = claimed;
  claimedAtCry.anchor = Start(cry3);
  Assert(input, claimedAtCry);

  // The first cry is the planned trick: the narrator's correspondence.
  const planned = new Corresponds(story);
  planned.left = cryPlan;
  planned.right = cry1;
  input.push(planned);

  const plans = new Plans(story);
  plans.planner = boy;
  plans.content = plan;
  Assert(input, plans);

  // The wolf was present from its coming out on.
  const presentHeld = new Present(story);
  presentHeld.subject = wolf;
  input.push(presentHeld);
  const fromComing = new In(story);
  fromComing.proposition = presentHeld;
  fromComing.duration = Duration(Start(comeOut), storyEnd);
  Assert(input, fromComing);

  // …and before that there was no wolf at any moment: negated existence
  // over a Virtual wolf present at a Virtual moment within the window
  // (§14.4), not an In over the window, which would only exclude a wolf
  // present at every point of it.
  const anyWolf = new Wolf(story);
  input.push(anyWolf);
  Virtualize(input, anyWolf);
  const someMoment = new TimeAnchor(story);
  input.push(someMoment);
  Virtualize(input, someMoment);
  const inWindow = new Within(story);
  inWindow.anchor = someMoment;
  inWindow.duration = Duration(storyStart, Start(comeOut));
  input.push(inWindow);
  const wolfThere = new Present(story);
  wolfThere.subject = anyWolf;
  input.push(wolfThere);
  const thereThen = new At(story);
  thereThen.proposition = wolfThere;
  thereThen.anchor = someMoment;
  input.push(thereThen);
  const noWolf = new NoInstance(story);
  noWolf.of = anyWolf;
  Assert(input, noWolf);

  // The third time nobody came: negated existence over a Virtual help
  // starting within the window from the third cry on.
  const anyHelp = new ComeToHelp(story);
  anyHelp.theme = boy;
  PatternEvent(input, anyHelp);
  StartsWithin(input, anyHelp, Duration(Start(cry3), storyEnd));
  const noneCame = new NoInstance(story);
  noneCame.of = anyHelp;
  Assert(input, noneCame);

  // The villagers, fooled twice, believed the boy was again deceiving
  // them; that believing is why nobody came. A root belief Situation.
  const belief3 = new Situation();
  input.push(belief3);
  const again = new Deceives(belief3);
  again.deceiver = boy;
  again.victim = villagers;
  input.push(again);
  Assert(input, again);
  const believedFooled = new Believes(story);
  believedFooled.believer = villagers;
  believedFooled.content = belief3;
  Assert(input, believedFooled);
  const whyNone = new Causes(story);
  whyNone.cause = believedFooled;
  whyNone.effect = noneCame;
  Assert(input, whyNone);

  return {
    root: story,
    storyStart,
    storyEnd,
    boy,
    villagers,
    wolf,
    cry1,
    cry2,
    cry3,
    comeOut,
    plan,
    claimedAtCry,
    noneCame,
    believedFooled,
  };
}
