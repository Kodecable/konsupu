// Five questions over the Shepherd's-Boy cognition. The ordinal question
// uses the kept Nth selector and reads the plan through an Among over an
// InOrderTo description (the plan's cry corresponds to the story's first
// cry by the narrator's Corresponds); the two negative Validity
// questions ride on the NoInstance patterns; the truth question judges
// the claim's own proposition in the story (§12.2) — the claim states
// its time, so no re-anchoring is needed.
import {
  Wolf,
  Present,
  CryOut,
  ComeToHelp,
  InOrderTo,
  Causes,
  Nth,
  Validity,
  Among,
  At,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import { Virtualize, PatternEvent, StartsWithin } from "../helpers.mjs";

function among(input, situated, node, situation) {
  const declaration = new Among(situated);
  declaration.node = node;
  declaration.situation = situation;
  input.push(declaration);
  return declaration;
}

function validity(input, situated, proposition, answer) {
  const verdict = new Validity(situated);
  verdict.proposition = proposition;
  verdict.variable = answer;
  input.push(verdict);
  return verdict;
}

export const Questions = [
  {
    text: "Why did the boy first cry \"Wolf\"?",
    intent: "OK: the planned Get of company and excitement — the plan's InOrderTo whose action corresponds to the first matching cry",
    build(input, world, answer) {
      const cryPat = new CryOut(world.root);
      cryPat.call = "Wolf, Wolf";
      input.push(cryPat);
      Virtualize(input, cryPat);
      const first = new Nth(world.root);
      first.pattern = cryPat;
      first.index = 1;
      input.push(first);
      const why = new InOrderTo(world.root);
      why.action = first;
      why.goal = answer;
      input.push(why);
      among(input, world.root, why, world.plan);
    },
  },
  {
    text: "Was there a wolf when the boy cried \"Wolf\" the second time?",
    intent: "no (OK, false): the second cry's start lies before the coming out, inside the NoInstance's window",
    build(input, world, answer) {
      const anyWolf = new Wolf(world.root);
      input.push(anyWolf);
      Virtualize(input, anyWolf);
      const there = new Present(world.root);
      there.subject = anyWolf;
      input.push(there);
      const atCry2 = new At(world.root);
      atCry2.proposition = there;
      atCry2.anchor = Start(world.cry2);
      input.push(atCry2);
      validity(input, world.root, atCry2, answer);
    },
  },
  {
    text: "Why did nobody come to help the boy the third time?",
    intent: "OK: the villagers' believing he was again deceiving them — the holding Causes of the not-coming",
    build(input, world, answer) {
      const why = new Causes(world.root);
      why.cause = answer;
      why.effect = world.noneCame;
      input.push(why);
      among(input, world.root, why, world.root);
    },
  },
  {
    text: "Was the boy telling the truth when he cried \"Wolf\" the third time?",
    intent: "yes (OK, true): the claim's At(Present(wolf), Start(cry3)) is derivable in the story — the wolf is present from the coming out on, which precedes the third cry",
    build(input, world, answer) {
      validity(input, world.root, world.claimedAtCry, answer);
    },
  },
  {
    text: "Did any villager come to help the boy the third time?",
    intent: "no (OK, false): the asked pattern (a help starting from the third cry on) falls under the NoInstance",
    build(input, world, answer) {
      const anyHelp = new ComeToHelp(world.root);
      anyHelp.theme = world.boy;
      PatternEvent(input, anyHelp);
      const window = StartsWithin(input, anyHelp, Duration(Start(world.cry3), world.storyEnd));
      validity(input, world.root, window, answer);
    },
  },
];
