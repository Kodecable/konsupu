// Five questions over the Nurse-and-the-Wolf cognition. The addressee
// question binds the story's unique Say whose Agent is the nurse; the
// hope question goes through an Among into the wolf's expectation
// context itself; the throwing question is an existence Validity over a
// Virtual throwing by the nurse starting within the window, whose "no"
// the Only carries; the promise question is an existence Validity that
// stays Unknown (only the wolf himself later calls it a promise); the
// call-for-help question is the positive control, a Validity over the
// canonical occurrence of the story's calling.
import {
  Say,
  Eat,
  Throw,
  Occurs,
  Entity,
  Promise,
  Validity,
  In,
  Among,
  Start,
  EventDuration,
  Duration,
} from "../../space/Interface/Commons.js";
import { Virtualize, AgentOf, PatternEvent, StartsWithin } from "../helpers.mjs";

function among(input, situated, node, situation) {
  const declaration = new Among(situated);
  declaration.node = node;
  declaration.situation = situation;
  input.push(declaration);
  return declaration;
}

function validity(input, situated, proposition, answer) {
  const verdict = new Validity(situated);
  verdict.proposition = proposition;
  verdict.variable = answer;
  input.push(verdict);
  return verdict;
}

export const Questions = [
  {
    text: "Who was the nurse speaking to when she mentioned the wolf?",
    intent: "OK: the child — the unique Say whose Agent is the nurse, its to field read off the bound node",
    // The wolf-mentioning is carried by the threat content being the
    // Say's content; constraining "the saying whose content mentions the
    // wolf" would need matching into the content Situation, which a
    // construction trial does not need (the story has one Say).
    build(input, world, answer) {
      const d = new Say(world.root);
      d.to = answer;
      input.push(d);
      among(input, world.root, d, world.root);
      const agent = AgentOf(input, d, world.nurse);
      among(input, world.root, agent, world.root);
    },
  },
  {
    text: "What did the wolf hope to eat?",
    intent: "OK: the child — the expectation context's own Eat event",
    // An Among straight into the root expectation Situation: its unique
    // Eat completes the description. Reading a context needs no HoldsIn.
    build(input, world, answer) {
      const e = new Eat(world.root);
      e.theme = answer;
      input.push(e);
      among(input, world.root, e, world.wolfThought);
    },
  },
  {
    text: "When the child began to cry, did the nurse throw it to the wolf?",
    intent: "no (OK, false): the asked pattern (a throwing by the nurse starting from the cry on) falls under the Only's head, and the throwing is none of the listed deeds",
    build(input, world, answer) {
      const t = new Throw(world.root);
      t.theme = world.child;
      t.to = world.wolf;
      PatternEvent(input, t);
      AgentOf(input, t, world.nurse);
      const window = StartsWithin(input, t, Duration(Start(world.cry), world.storyEnd));
      // Validity has no head; the pattern is the connected component of
      // the named proposition (§6.4, §8.4).
      validity(input, world.root, window, answer);
    },
  },
  {
    text: "Did anyone promise the wolf the child?",
    intent: "Unknown: the threat is a Conditional, not a Promise; nothing held promises and nothing excludes one",
    // The promised deed is a Virtual description, not a plain Throw: a
    // plain Node here would introduce a throwing into the story.
    build(input, world, answer) {
      const who = new Entity(world.root);
      input.push(who);
      Virtualize(input, who);
      const giveChild = new Throw(world.root);
      giveChild.theme = world.child;
      giveChild.to = world.wolf;
      input.push(giveChild);
      Virtualize(input, giveChild);
      const promised = new Promise(world.root);
      promised.actor = who;
      promised.deed = giveChild;
      input.push(promised);
      validity(input, world.root, promised, answer);
    },
  },
  {
    text: "Did the nurse call for help?",
    intent: "yes (OK, true): the story asserts the canonical occurrence of the calling",
    // The canonical occurrence (§13.1), not a bare Occurs, which would
    // ask whether the calling goes on at every point of AllTime.
    build(input, world, answer) {
      const happened = new Occurs(world.root);
      happened.event = world.callForHelp;
      input.push(happened);
      const during = new In(world.root);
      during.proposition = happened;
      during.duration = EventDuration(world.callForHelp);
      input.push(during);
      validity(input, world.root, during, answer);
    },
  },
];
