// "The Nurse and the Wolf". The threat is a root speech-content
// Situation holding a Conditional — for every crying there is a throwing
// by the nurse; the wolf's expectation is a root belief Situation of its
// own (the child will cry; he will eat the child), and his waiting is
// motivated by that believing. When the child
// does cry, all the nurse did from the cry on was shut the window and
// call for help — an Only over a Virtual deed pattern with the window as
// its constraint, from which "she did not throw the child" follows.
import {
  TimeAnchor,
  Situation,
  Conditional,
  And,
  Cry,
  Throw,
  Say,
  Crouch,
  Wait,
  ComeForward,
  Shut,
  CallForHelp,
  RushOut,
  GallopAway,
  Eat,
  Believes,
  Motivates,
  Only,
  Deed,
  Assert,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import {
  entity,
  Occurred,
  AgentOf,
  PatternEvent,
  StartsWithin,
  Chain,
  Bounds,
} from "../helpers.mjs";

export function BuildStory(input, story) {
  const nurse = entity(story, "the nurse");
  const child = entity(story, "the child");
  const wolf = entity(story, "the wolf");
  const house = entity(story, "the house");
  const window = entity(story, "the window");
  const dogs = entity(story, "the dogs of the house");
  input.push(nurse, child, wolf, house, window, dogs);

  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  input.push(storyStart, storyEnd);

  // "If you make that noise again I will throw you to the Wolf." The
  // threat is a root Situation (§12). For every crying (forall) there is
  // a throwing by the nurse (exists); both are Virtual pattern events
  // with their canonical occurrence constraint (§13.1), and the
  // quantifiers list every Virtual node of the Conditional (§11.2).
  const threat = new Situation();
  input.push(threat);
  const noise = new Cry(threat);
  noise.theme = child;
  const noiseAgain = PatternEvent(input, noise);
  const throwChild = new Throw(threat);
  throwChild.theme = child;
  throwChild.to = wolf;
  const thrown = PatternEvent(input, throwChild);
  const byNurse = AgentOf(input, throwChild, nurse);
  const consequence = new And(threat);
  consequence.propositions = [thrown, byNurse];
  input.push(consequence);
  const warning = new Conditional(threat);
  warning.forall = [noise];
  warning.exists = [throwChild];
  warning.antecedent = noiseAgain;
  warning.consequence = consequence;
  Assert(input, warning);

  const say = new Say(story);
  say.to = child;
  say.content = threat;
  say.text = "Be quiet now…";
  const crouch = new Crouch(story);
  crouch.place = house;
  const wait = new Wait(story);
  wait.place = house;

  // The wolf's own expectation: the child is sure to cry soon, and the
  // morsel he expects to eat is the child. A root Situation (§12): it
  // holds only what the wolf expects.
  const wolfThought = new Situation();
  input.push(wolfThought);
  const crySoon = new Cry(wolfThought);
  crySoon.theme = child;
  Occurred(input, crySoon);
  const eat = new Eat(wolfThought);
  eat.theme = child;
  Occurred(input, eat, wolf);
  const expects = new Believes(story);
  expects.believer = wolf;
  expects.content = wolfThought;
  Assert(input, expects);

  const cry = new Cry(story);
  cry.theme = child;
  const comeForward = new ComeForward(story);
  comeForward.place = window;
  const shutWindow = new Shut(story);
  shutWindow.theme = window;
  const callForHelp = new CallForHelp(story);
  const rushOut = new RushOut(story);
  rushOut.theme = dogs;
  const gallopAway = new GallopAway(story);
  const happened = [
    [say, nurse], [crouch, wolf], [wait, wolf], [cry, undefined],
    [comeForward, wolf], [shutWindow, nurse], [callForHelp, nurse],
    [rushOut, dogs], [gallopAway, wolf],
  ];
  for (const [event, actor] of happened) Occurred(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, say, gallopAway, storyEnd);

  // "So he crouched down … and waited": his own expecting drove it.
  const so = new Motivates(story);
  so.driver = expects;
  so.action = wait;
  Assert(input, so);

  // "But all the Nurse did was to shut down the window and call for
  // help" — from the cry on. The pattern head is a Virtual deed whose
  // Agent is the nurse; "from the cry on" is a moment-of constraint on
  // its start (§14.4), not an In over its occurrence, which would only
  // cover deeds going on at every point of the window.
  const deed = new Deed(story);
  PatternEvent(input, deed);
  AgentOf(input, deed, nurse);
  StartsWithin(input, deed, Duration(Start(cry), storyEnd));
  const allSheDid = new Only(story);
  allSheDid.of = deed;
  allSheDid.among = [shutWindow, callForHelp];
  Assert(input, allSheDid);

  return {
    root: story,
    storyStart,
    storyEnd,
    nurse,
    child,
    wolf,
    say,
    threat,
    wolfThought,
    cry,
    shutWindow,
    callForHelp,
    allSheDid,
  };
}
