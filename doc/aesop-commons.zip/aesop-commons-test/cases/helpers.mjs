// Fixture helpers shared by the story builders: the canonical occurrence
// write, agency, pattern events, the narration chain, story-boundary
// anchors, and the Virtualize shorthand. These are construction sugar over
// the vocabulary — the canonical occurrence write in particular is pure
// boilerplate the spec demands for every happened event (§13.1), which is
// one of the trial's observations.
import {
  Entity,
  Virtual,
  Occurs,
  Agent,
  In,
  Within,
  Next,
  Before,
  Assert,
  Start,
  End,
  EventDuration,
  Situation,
  Variable,
  Query,
} from "../space/Interface/Commons.js";

export function entity(situation, name) {
  const value = new Entity(situation);
  value.name = name;
  return value;
}

// A Virtual declaration over `node`, pushed next to it.
export function Virtualize(input, node) {
  const declaration = new Virtual(node.situated);
  declaration.node = node;
  input.push(declaration);
  return declaration;
}

// An unasserted Agent(action, actor). Asserted in a story it states who
// acted; left unasserted it is a pattern constraint or a question
// description (§13.2).
export function AgentOf(input, event, actor) {
  const agent = new Agent(event.situated);
  agent.action = event;
  agent.actor = actor;
  input.push(agent);
  return agent;
}

// The asserted agency of a story event.
export function Did(input, event, actor) {
  return Assert(input, AgentOf(input, event, actor));
}

// §13.1 canonical occurrence: the event, its start and end anchors, and
// the asserted In(Occurs(e), duration(e)). A bare asserted Occurs(e)
// would mean the event's Duration is AllTime and clash with the anchors.
// An actor, when given, is asserted as an independent Agent.
export function Occurred(input, event, actor) {
  input.push(event, Start(event), End(event));
  const occurs = new Occurs(event.situated);
  occurs.event = event;
  input.push(occurs);
  const during = new In(event.situated);
  during.proposition = occurs;
  during.duration = EventDuration(event);
  Assert(input, during);
  if (actor !== undefined) Did(input, event, actor);
  return during;
}

// A Virtual pattern event: the event and its anchors are Virtual (an
// anchor of a non-instance is no instance either, and §6.4 requires a
// plain Node referencing a Virtual one to be Virtual itself), plus the
// unasserted canonical occurrence constraint In(Occurs(e), duration(e)).
// A bare Occurs(e) in a pattern would demand e be happening at every
// point of AllTime (§13.1).
export function PatternEvent(input, event) {
  input.push(event);
  Virtualize(input, event);
  const start = Start(event);
  const end = End(event);
  input.push(start, end);
  Virtualize(input, start);
  Virtualize(input, end);
  const occurs = new Occurs(event.situated);
  occurs.event = event;
  input.push(occurs);
  const during = new In(event.situated);
  during.proposition = occurs;
  during.duration = EventDuration(event);
  input.push(during);
  return during;
}

// "Happened at some moment of `duration`": the event's start lies within
// it (§14.4). Not In(Occurs(e), duration), which would demand e be
// happening at every point of the duration.
export function StartsWithin(input, event, duration) {
  const within = new Within(event.situated);
  within.anchor = Start(event);
  within.duration = duration;
  input.push(within);
  return within;
}

// Narrative adjacency between consecutive events; Before is the derived
// transitive closure (§9 domain rule), never enumerated by hand.
export function Chain(input, events) {
  for (let index = 0; index + 1 < events.length; index += 1) {
    const link = new Next(events[index].situated);
    link.earlier = events[index];
    link.later = events[index + 1];
    Assert(input, link);
  }
}

// What makes two free anchors the story's bounds: they bracket the whole
// narration (§14.2 — the anchors carry no built-in "story start/end"
// meaning, so the input states the bracketing itself).
export function Bounds(input, storyStart, first, last, storyEnd) {
  const open = new Before(storyStart.situated);
  open.earlier = storyStart;
  open.later = Start(first);
  Assert(input, open);
  const close = new Before(storyEnd.situated);
  close.earlier = End(last);
  close.later = storyEnd;
  Assert(input, close);
}

// One Input per question, the flat §7.2 layout: the story root Situation
// holds the fable facts, then the question cognition — Among-bound
// descriptions, Validity declarations, the answer Variable, the Query —
// sits in the same Situation. Context Situations (beliefs, speech, plans)
// are separate roots (§12): a child Situation would inherit the
// narrator's cognition. A fresh graph per question; nothing is shared.
// The phase2 three-layer dialogue machinery (Asks, re-export Query,
// Reply, Imperative) is runtime plumbing, not Commons semantics, and is
// out of scope here.
export function BuildCase(question, buildStory) {
  const input = [];
  const story = new Situation();
  input.push(story);
  const world = buildStory(input, story);
  const answer = new Variable(story);
  input.push(answer);
  question.build(input, world, answer);
  input.push(new Query(story, [answer]));
  return input;
}
