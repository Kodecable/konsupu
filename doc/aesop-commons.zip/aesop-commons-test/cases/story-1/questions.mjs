// Four questions over the Crow-and-the-Pitcher cognition, in the flat
// single-Situation question form: the question cognition lives beside
// the story facts. A question's constraint is always an explicit
// declaration — an Among over a description (§6.2), whose node may be an
// event or a proposition — never an unasserted proposition left to be
// read as a condition by its position (principle 2). `intent` records
// the expected resolution by hand; there is no solver in this trial.
import {
  Drop,
  Next,
  Causes,
  LocatedAt,
  In,
  Among,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import { AgentOf } from "../helpers.mjs";

function among(input, situated, node, situation) {
  const declaration = new Among(situated);
  declaration.node = node;
  declaration.situation = situation;
  input.push(declaration);
  return declaration;
}

export const Questions = [
  {
    text: "Who dropped a pebble into the pitcher?",
    intent: "OK: the crow — Among binds the theme-pinned drop, then the Agent of that drop binds the answer",
    // The theme is pinned on purpose: the story has three drops into the
    // pitcher, and per §6.2 several Among candidates make the dependent
    // answer Ambiguous even when every candidate's agent is the same —
    // the translation must be as definite as the question is. Agency is
    // an independent Agent (§13.2), so "who" is an Among over an Agent
    // description whose actor is the answer.
    build(input, world, answer) {
      const d = new Drop(world.root);
      d.theme = world.pebble;
      d.destination = world.pitcher;
      input.push(d);
      among(input, world.root, d, world.root);
      const agent = AgentOf(input, d, answer);
      among(input, world.root, agent, world.root);
    },
  },
  {
    text: "What happened after the crow put its beak into the pitcher?",
    intent: "OK: the TryToDrink event — the unique holding Next whose earlier side is putBeak",
    // §6.2: an Among over a proposition picks among the propositions that
    // hold in the Situation.
    build(input, world, answer) {
      const sequel = new Next(world.root);
      sequel.earlier = world.putBeak;
      sequel.later = answer;
      input.push(sequel);
      among(input, world.root, sequel, world.root);
    },
  },
  {
    text: "Why did the water mount up?",
    intent: "OK: the dropping Series — the holding Causes whose effect is the rise",
    build(input, world, answer) {
      const why = new Causes(world.root);
      why.cause = answer;
      why.effect = world.waterRise;
      input.push(why);
      among(input, world.root, why, world.root);
    },
  },
  {
    text: "Where did the pebble end up after the crow dropped it?",
    intent: "OK: the pitcher — the state held from the bound drop's start on",
    // "Ended up somewhere after the drop" is the state holding from the
    // drop's start anchor: ResultsIn is gone (§14.12), its temporal half is
    // an In over Duration(Start(d), storyEnd). The Among over that In
    // picks among what holds — derivable propositions included.
    build(input, world, answer) {
      const d = new Drop(world.root);
      d.theme = world.pebble;
      d.destination = world.pitcher;
      input.push(d);
      input.push(Start(d));
      among(input, world.root, d, world.root);
      const ended = new LocatedAt(world.root);
      ended.entity = world.pebble;
      ended.place = answer;
      input.push(ended);
      const since = new In(world.root);
      since.proposition = ended;
      since.duration = Duration(Start(d), world.storyEnd);
      input.push(since);
      among(input, world.root, since, world.root);
    },
  },
];
