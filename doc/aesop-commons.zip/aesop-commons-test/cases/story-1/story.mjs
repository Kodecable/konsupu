// "The Crow and the Pitcher" under the Commons rework prototype. The
// narration is a chain of occurred events; every happened event gets the
// canonical In(Occurs(e), duration(e)) write; changeable states are
// intervals bounded by anchors (thirst from the story start until the
// drinking; the inability to get at the water from putting the beak in
// until the few more pebbles; quenched and able-again are explicit Not
// over the following interval, since nothing ends a state by default);
// the droppings as one Series cause the rise, the rise enables and
// causes the drinking, the drinking saves the life; the pebble's resting
// place holds from the first drop on.
import {
  TimeAnchor,
  Situation,
  Thirsty,
  LocatedAt,
  Unable,
  Causes,
  Enables,
  InOrderTo,
  Goal,
  Not,
  In,
  GetAt,
  Series,
  ComeUpon,
  Put,
  TryToDrink,
  ThinkUp,
  Drop,
  Rise,
  Quench,
  Save,
  Assert,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import { entity, Virtualize, Occurred, Chain, Bounds } from "../helpers.mjs";

export function BuildStory(input, story) {
  const crow = entity(story, "the crow");
  const pitcher = entity(story, "the pitcher");
  const water = entity(story, "the water");
  const pebble = entity(story, "a pebble");
  const otherPebbles = entity(story, "the other pebbles");
  const morePebbles = entity(story, "a few more pebbles");
  const beak = entity(story, "its beak");
  const thirst = entity(story, "its thirst");
  const life = entity(story, "its life");
  input.push(
    crow, pitcher, water, pebble, otherPebbles, morePebbles, beak, thirst, life,
  );

  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  input.push(storyStart, storyEnd);

  const comeUpon = new ComeUpon(story);
  comeUpon.theme = pitcher;
  const putBeak = new Put(story);
  putBeak.theme = beak;
  putBeak.destination = pitcher;
  const tryDrink = new TryToDrink(story);
  tryDrink.theme = water;
  const think = new ThinkUp(story);
  const dropFirst = new Drop(story);
  dropFirst.theme = pebble;
  dropFirst.destination = pitcher;
  const dropOthers = new Drop(story);
  dropOthers.theme = otherPebbles;
  dropOthers.destination = pitcher;
  const waterRise = new Rise(story);
  waterRise.theme = water;
  const castMore = new Drop(story);
  castMore.theme = morePebbles;
  castMore.destination = pitcher;
  const drink = new Quench(story);
  drink.theme = thirst;
  const saveLife = new Save(story);
  saveLife.theme = life;
  // Agency is an independent Agent proposition (§13.2); the rise has no
  // agent.
  const happened = [
    comeUpon, putBeak, tryDrink, think, dropFirst, dropOthers,
    waterRise, castMore, drink, saveLife,
  ];
  for (const event of happened) {
    Occurred(input, event, event === waterRise ? undefined : crow);
  }
  Chain(input, happened);
  Bounds(input, storyStart, comeUpon, saveLife, storyEnd);

  // Half-dead with thirst: from the story start until the drinking;
  // quenched from the drinking on (explicit, no default inertia).
  const thirsty = new Thirsty(story);
  thirsty.subject = crow;
  input.push(thirsty);
  const thirstHeld = new In(story);
  thirstHeld.proposition = thirsty;
  thirstHeld.duration = Duration(storyStart, Start(drink));
  Assert(input, thirstHeld);
  const notThirsty = new Not(story);
  notThirsty.proposition = thirsty;
  input.push(notThirsty);
  const thirstGone = new In(story);
  thirstGone.proposition = notThirsty;
  thirstGone.duration = Duration(Start(drink), storyEnd);
  Assert(input, thirstGone);

  // Could not reach the water, found when the beak went in, ended only
  // after the few more pebbles ("after casting in a few more pebbles he
  // was able to"). The deed is a Virtual description of getting at the
  // water, not the trying that occurred.
  const gettingAt = new GetAt(story);
  gettingAt.theme = water;
  input.push(gettingAt);
  Virtualize(input, gettingAt);
  const unable = new Unable(story);
  unable.actor = crow;
  unable.deed = gettingAt;
  input.push(unable);
  const unableHeld = new In(story);
  unableHeld.proposition = unable;
  unableHeld.duration = Duration(Start(putBeak), Start(castMore));
  Assert(input, unableHeld);
  const notUnable = new Not(story);
  notUnable.proposition = unable;
  input.push(notUnable);
  const ableAgain = new In(story);
  ableAgain.proposition = notUnable;
  ableAgain.duration = Duration(Start(castMore), storyEnd);
  Assert(input, ableAgain);

  // The droppings together, one after another, made the water rise; the
  // risen water enabled and caused the drinking; the drinking saved the
  // crow's life; the droppings aimed at the rise; the goal was drinking.
  const dropping = new Series(story);
  dropping.parts = [dropFirst, dropOthers];
  Occurred(input, dropping);
  const riseFromDrops = new Causes(story);
  riseFromDrops.cause = dropping;
  riseFromDrops.effect = waterRise;
  Assert(input, riseFromDrops);
  const riseLetDrink = new Causes(story);
  riseLetDrink.cause = waterRise;
  riseLetDrink.effect = drink;
  Assert(input, riseLetDrink);
  const drinkSaved = new Causes(story);
  drinkSaved.cause = drink;
  drinkSaved.effect = saveLife;
  Assert(input, drinkSaved);
  const riseAble = new Enables(story);
  riseAble.enabler = waterRise;
  riseAble.enabled = drink;
  Assert(input, riseAble);
  const dropAimed = new InOrderTo(story);
  dropAimed.action = dropping;
  dropAimed.goal = waterRise;
  Assert(input, dropAimed);
  const goal = new Goal(story);
  goal.actor = crow;
  goal.objective = drink;
  Assert(input, goal);

  // Where the pebble ended up: at the pitcher, from the first drop on.
  const pebbleRests = new LocatedAt(story);
  pebbleRests.entity = pebble;
  pebbleRests.place = pitcher;
  input.push(pebbleRests);
  const restsHeld = new In(story);
  restsHeld.proposition = pebbleRests;
  restsHeld.duration = Duration(Start(dropFirst), storyEnd);
  Assert(input, restsHeld);

  return {
    root: story,
    storyStart,
    storyEnd,
    crow,
    pitcher,
    water,
    pebble,
    putBeak,
    tryDrink,
    dropFirst,
    dropping,
    waterRise,
    drink,
  };
}
