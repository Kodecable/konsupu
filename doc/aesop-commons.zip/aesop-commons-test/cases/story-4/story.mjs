// "The Dog and the Shadow". The belief is a root Situation of its own
// (§12): it holds only what the dog takes to be there — another dog
// carrying another piece of meat — and never mentions the shadow, which
// the dog does not believe in. That the other dog is in fact the shadow
// is the narrator's correspondence, a Corresponds declared in the story
// (§6.3). The dog's goal is an unoccurred Get event in the story whose
// theme is the belief-local meat — a plain Node, so referencing it
// across Situations is legal, and an Event object existing never means
// it happened.
import {
  TimeAnchor,
  Situation,
  LocatedAt,
  Corresponds,
  Believes,
  Goal,
  InOrderTo,
  In,
  Get,
  Carry,
  Cross,
  See,
  SnapAt,
  Fall,
  Assert,
  Start,
  Duration,
} from "../../space/Interface/Commons.js";
import { entity, Occurred, Did, Chain, Bounds } from "../helpers.mjs";

export function BuildStory(input, story) {
  const dog = entity(story, "the dog");
  const meat = entity(story, "the piece of meat");
  const plank = entity(story, "the plank");
  const water = entity(story, "the water beneath");
  const shadow = entity(story, "his own shadow reflected in the water");
  input.push(dog, meat, plank, water, shadow);

  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  input.push(storyStart, storyEnd);

  const getMeat = new Get(story);
  getMeat.theme = meat;
  const carryHome = new Carry(story);
  carryHome.theme = meat;
  const cross = new Cross(story);
  cross.theme = plank;
  cross.place = water;
  const see = new See(story);
  see.theme = shadow;
  see.place = water;
  const snapAt = new SnapAt(story);
  snapAt.theme = shadow;
  const fall = new Fall(story);
  fall.theme = meat;
  fall.destination = water;
  const happened = [getMeat, carryHome, cross, see, snapAt, fall];
  for (const event of happened) {
    Occurred(input, event, event === fall ? undefined : dog);
  }
  Chain(input, happened);
  Bounds(input, storyStart, getMeat, fall, storyEnd);

  // The meat ended up in the water and was never seen more.
  const inWater = new LocatedAt(story);
  inWater.entity = meat;
  inWater.place = water;
  input.push(inWater);
  const sank = new In(story);
  sank.proposition = inWater;
  sank.duration = Duration(Start(fall), storyEnd);
  Assert(input, sank);

  // The belief: another dog carrying another piece of meat. A root
  // Situation, so it inherits nothing the narrator holds.
  const belief = new Situation();
  input.push(belief);
  const otherDog = entity(belief, "another dog");
  const otherMeat = entity(belief, "another piece of meat");
  input.push(otherDog, otherMeat);
  const carries = new Carry(belief);
  carries.theme = otherMeat;
  Occurred(input, carries, otherDog);
  // What the dog took for another dog is in fact his shadow: the
  // narrator's correspondence, declared in the story.
  const really = new Corresponds(story);
  really.left = otherDog;
  really.right = shadow;
  input.push(really);
  const believes = new Believes(story);
  believes.believer = dog;
  believes.content = belief;
  Assert(input, believes);

  // He made up his mind to have that also: a goal whose object is an
  // unoccurred Get in the story over the belief-local meat, and the snap
  // was in order to it.
  const haveThat = new Get(story);
  haveThat.theme = otherMeat;
  input.push(haveThat);
  Did(input, haveThat, dog);
  const goal = new Goal(story);
  goal.actor = dog;
  goal.objective = haveThat;
  Assert(input, goal);
  const snapAimed = new InOrderTo(story);
  snapAimed.action = snapAt;
  snapAimed.goal = haveThat;
  Assert(input, snapAimed);

  return {
    root: story,
    storyStart,
    storyEnd,
    dog,
    meat,
    water,
    shadow,
    snapAt,
    belief,
    otherDog,
    otherMeat,
    haveThat,
  };
}
