// Five questions over the Dog-and-the-Shadow cognition. "What did the dog
// think his shadow was" asks the narrator's correspondence: a Corresponds
// with a Variable side is solved for the corresponding value (§6.3), so
// the answer is the belief's own object without the belief ever
// mentioning the shadow. The wh-questions read the world through Among
// declarations (§6.2); the two Validity questions land in Unknown,
// matching phase2's "not established": the world derives neither the
// getting (the goal event never occurred) nor any Not of it, and nobody's
// deception is asserted or excluded.
import {
  Corresponds,
  See,
  InOrderTo,
  Occurs,
  In,
  Entity,
  Deceives,
  Validity,
  Among,
  EventDuration,
  Start,
  End,
} from "../../space/Interface/Commons.js";
import { Virtualize } from "../helpers.mjs";

function among(input, situated, node, situation) {
  const declaration = new Among(situated);
  declaration.node = node;
  declaration.situation = situation;
  input.push(declaration);
  return declaration;
}

export const Questions = [
  {
    text: "What did the dog think his shadow was?",
    intent: "OK: the other dog — the belief object the story's Corresponds pairs with the shadow",
    build(input, world, answer) {
      const asked = new Corresponds(world.root);
      asked.left = answer;
      asked.right = world.shadow;
      input.push(asked);
    },
  },
  {
    text: "What did the dog really see in the water?",
    intent: "OK: his own shadow — the story's unique See in the water",
    build(input, world, answer) {
      const d = new See(world.root);
      d.place = world.water;
      d.theme = answer;
      input.push(d);
      among(input, world.root, d, world.root);
    },
  },
  {
    text: "Why did the dog snap at the shadow?",
    intent: "OK: the Get of the other piece of meat — the holding InOrderTo of the snap",
    build(input, world, answer) {
      const why = new InOrderTo(world.root);
      why.action = world.snapAt;
      why.goal = answer;
      input.push(why);
      among(input, world.root, why, world.root);
    },
  },
  {
    text: "Did the dog get the other piece of meat?",
    intent: "Unknown: the getting is a goal event that never occurred; no Not of it either (open world)",
    // Validity over the canonical occurrence of the specific would-be
    // event (§13.1): a bare Occurs would ask whether it happens at every
    // point of AllTime.
    build(input, world, answer) {
      input.push(Start(world.haveThat), End(world.haveThat));
      const happened = new Occurs(world.root);
      happened.event = world.haveThat;
      input.push(happened);
      const during = new In(world.root);
      during.proposition = happened;
      during.duration = EventDuration(world.haveThat);
      input.push(during);
      const verdict = new Validity(world.root);
      verdict.proposition = during;
      verdict.variable = answer;
      input.push(verdict);
    },
  },
  {
    text: "Did anyone deceive the dog?",
    intent: "Unknown: no Deceives is held or excluded; mistaken belief does not entail deception",
    build(input, world, answer) {
      const who = new Entity(world.root);
      input.push(who);
      Virtualize(input, who);
      const deceived = new Deceives(world.root);
      deceived.deceiver = who;
      deceived.victim = world.dog;
      input.push(deceived);
      const verdict = new Validity(world.root);
      verdict.proposition = deceived;
      verdict.variable = answer;
      input.push(verdict);
    },
  },
];
