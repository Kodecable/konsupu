// Trial story-world vocabulary for the aesop-commons-test cases, kept to
// what the four chosen stories need. Agency is an independent
// proposition, Agent(action, actor), never a field of the event: the
// spec's principle 9 promotes a relation that is discussed through Node
// relations ("who did it", patterns over the doer) out of the field.
import {
  Brand,
  Final,
  SituatedNode,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Final concrete class factories: every class owns a global BRAND, its
// constructor closes it, and its references are its data members.
function finalClass(Base, brandKey, comment) {
  const Cls = class extends Base {
    static BRAND = Brand(brandKey);
    constructor(...args) {
      Final(Cls, new.target);
      super(...args);
    }
    ReportReferences(visit) {
      report.call(this, visit);
    }
  };
  return Cls;
}

function eventClass(brandKey) {
  return finalClass(Action, brandKey);
}

// An open concrete class: instantiable and extendable (kind subclasses
// below extend it), unlike the closed finalClass products.
function openClass(Base, brandKey) {
  return class extends Base {
    static BRAND = Brand(brandKey);
    constructor(...args) {
      super(...args);
    }
    ReportReferences(visit) {
      report.call(this, visit);
    }
  };
}

// A discourse individual; `name` is surface text only, never matched.
// Open: natural-kind subclasses (Wolf) extend it, the §3 inheritance
// that replaces phase2's Kind marker.
export const Entity = openClass(SituatedNode, "aesop:Entity:v1");

// A wolf individual: "was there a wolf" quantifies over this subclass.
export const Wolf = finalClass(Entity, "aesop:Wolf:v1");

// Events: referable happenings whose occurrence is a separate asserted
// proposition (Occurs). Action adds only agentivity; who acted is the
// separate Agent proposition below.
export class Event extends SituatedNode {
  static BRAND = Brand("aesop:Event:v1");
  constructor(situated) {
    if (new.target === Event) throw new TypeError("Event is abstract");
    super(situated);
  }
}

export class Action extends Event {
  static BRAND = Brand("aesop:Action:v1");
  constructor(situated) {
    if (new.target === Action) throw new TypeError("Action is abstract");
    super(situated);
  }
}

// Open generic deed: patterns like "everything the nurse then did" need
// an instantiable class at the least specific level (phase2's open Get).
export const Deed = class extends Action {
  static BRAND = Brand("aesop:Deed:v1");
  constructor(situated) {
    // Open: deliberately not closed, patterns and story deeds both
    // instantiate it.
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
};

// Several events as one happening, in narration order ("little by
// little"): field parts. An Event, not an Action: no single agent.
export const Series = finalClass(Event, "aesop:Series:v1");

// --- story-1 events ------------------------------------------------------
export const ComeUpon = eventClass("aesop:ComeUpon:v1"); // theme
export const Put = eventClass("aesop:Put:v1"); // theme, destination
export const TryToDrink = eventClass("aesop:TryToDrink:v1"); // theme
export const ThinkUp = eventClass("aesop:ThinkUp:v1"); // (a thought came)
export const Drop = eventClass("aesop:Drop:v1"); // theme, destination
export const Rise = finalClass(Event, "aesop:Rise:v1"); // theme, no agent
export const Quench = eventClass("aesop:Quench:v1"); // theme (thirst)
export const Save = eventClass("aesop:Save:v1"); // theme (life)
export const GetAt = eventClass("aesop:GetAt:v1"); // theme (Unable pattern head)

// --- story-4 events ------------------------------------------------------
export const Get = eventClass("aesop:Get:v1"); // theme
export const Carry = eventClass("aesop:Carry:v1"); // theme
export const Cross = eventClass("aesop:Cross:v1"); // theme, place
export const See = eventClass("aesop:See:v1"); // theme, place
export const SnapAt = eventClass("aesop:SnapAt:v1"); // theme
export const Fall = finalClass(Event, "aesop:Fall:v1"); // theme, destination

// --- story-8 events ------------------------------------------------------
// Speaking as an action: fields to, content (a Situation), text.
export const Say = eventClass("aesop:Say:v1");
export const Crouch = eventClass("aesop:Crouch:v1"); // place
export const Wait = eventClass("aesop:Wait:v1"); // place
export const Cry = finalClass(Event, "aesop:Cry:v1"); // theme (the child)
export const ComeForward = eventClass("aesop:ComeForward:v1"); // place
export const Shut = eventClass("aesop:Shut:v1"); // theme (the window)
export const CallForHelp = eventClass("aesop:CallForHelp:v1");
export const RushOut = eventClass("aesop:RushOut:v1"); // theme (the dogs)
export const GallopAway = eventClass("aesop:GallopAway:v1");
export const Throw = eventClass("aesop:Throw:v1"); // theme, to
export const Eat = eventClass("aesop:Eat:v1"); // theme

// --- story-10 events -----------------------------------------------------
// Crying out: fields call (the shouted words) and content (a Situation
// holding what the cry claims, when the story gives one).
export const CryOut = eventClass("aesop:CryOut:v1");
export const ComeToHelp = eventClass("aesop:ComeToHelp:v1"); // theme
export const ComeOut = eventClass("aesop:ComeOut:v1"); // from
export const Worry = eventClass("aesop:Worry:v1"); // theme (the flock)

// --- propositions --------------------------------------------------------
// Occurrence: an Event object existing never means it happened.
export const Occurs = finalClass(Proposition, "aesop:Occurs:v1"); // field event

// Agency (spec §13.2): `actor` performed `action`. Independent of the
// event so questions and patterns can relate doer and deed as Nodes.
export const Agent = finalClass(Proposition, "aesop:Agent:v1"); // action, actor

// Changeable states and relations; time comes from At/In, never from a
// hidden field of these classes.
export const LocatedAt = finalClass(Proposition, "aesop:LocatedAt:v1"); // entity, place
export const Present = finalClass(Proposition, "aesop:Present:v1"); // subject
export const Thirsty = finalClass(Proposition, "aesop:Thirsty:v1"); // subject

// Inability: the deed is a pattern-accepting field (§6.4), so the Unable
// may be asserted while the deed stays a Virtual description.
export const Unable = class extends Proposition {
  static BRAND = Brand("aesop:Unable:v1");
  static PATTERN = ["deed"];
  constructor(situated) {
    Final(Unable, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
};

export const Next = finalClass(Proposition, "aesop:Next:v1"); // earlier, later
export const Before = finalClass(Proposition, "aesop:Before:v1"); // earlier, later
export const Causes = finalClass(Proposition, "aesop:Causes:v1"); // cause, effect
export const Enables = finalClass(Proposition, "aesop:Enables:v1"); // enabler, enabled
// An intended deed is a pattern-accepting field (spec §6.4): a plain
// event names that particular deed, a Virtual pattern any deed of the
// kind; fulfilment is an occurred instance under the pattern (§9.1,
// positive direction).
export const InOrderTo = class extends Proposition {
  static BRAND = Brand("aesop:InOrderTo:v1");
  static PATTERN = ["goal"];
  constructor(situated) {
    Final(InOrderTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}; // action, goal
export const Motivates = finalClass(Proposition, "aesop:Motivates:v1"); // driver, action
// Goal.objective: an intended deed (see InOrderTo above).
export const Goal = class extends Proposition {
  static BRAND = Brand("aesop:Goal:v1");
  static PATTERN = ["objective"];
  constructor(situated) {
    Final(Goal, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}; // actor, objective

// Attitudes: ordinary propositions whose content references a Situation
// (§12). The content Situation's own Assertions are what is believed,
// said, or planned; nothing of it leaks into the outer Situation.
export const Believes = finalClass(Proposition, "aesop:Believes:v1"); // believer, content
export const Plans = finalClass(Proposition, "aesop:Plans:v1"); // planner, content
// Promise.deed: an intended deed (see InOrderTo above).
export const Promise = class extends Proposition {
  static BRAND = Brand("aesop:Promise:v1");
  static PATTERN = ["deed"];
  constructor(situated) {
    Final(Promise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}; // actor, deed
export const Deceives = finalClass(Proposition, "aesop:Deceives:v1"); // deceiver, victim

// The n-th event matching a description along the Situation's own order
// (final shape open, spec §16 item 11). Fields pattern, index. Used as a
// selector value inside question constraints; the pattern is the usual
// pattern-accepting field.
export const Nth = class extends SituatedNode {
  static BRAND = Brand("aesop:Nth:v1");
  static PATTERN = ["pattern"];
  constructor(situated) {
    Final(Nth, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
};
