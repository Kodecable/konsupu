// Commons core vocabulary, one class per section of
// doc/Commons_再重构原型.md (section numbers cited below). API shapes the
// spec leaves open are trial choices and are listed in OBSERVATIONS.md.
// Construction style follows the phase2 fixtures: construct with the
// Situation only, then assign fields as plain writable properties.
import {
  Brand,
  Final,
  SituatedNode,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// 5.2 — an Assertion is world content, not a Proposition: one occurrence
// means the owning Situation holds `proposition` true. Only a Proposition
// is assertable; the context-link declarations and Validity take effect
// by occurring (6.1, 8.4) and are rejected here.
export class Assertion extends SituatedNode {
  static BRAND = Brand("commons:Assertion:v1");
  constructor(situated) {
    Final(Assertion, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Fixture helper: push the proposition (unless it already occurs) and an
// Assertion for it in the holding Situation. The holder defaults to the
// proposition's own Situation; holding elsewhere names the holder.
export function Assert(input, proposition, holder = proposition.situated) {
  if (!(proposition instanceof Proposition)) {
    throw new TypeError("Assert requires a Proposition");
  }
  if (!input.includes(proposition)) input.push(proposition);
  const assertion = new Assertion(holder);
  assertion.proposition = proposition;
  input.push(assertion);
  return proposition;
}

// Whether some visible Assertion names exactly this proposition object.
// (Trial helper for lint only; no solver is implemented.)
export function IsAsserted(view, proposition) {
  return view.Bindings(proposition).some((node) => {
    return node instanceof Assertion && node.proposition === proposition;
  });
}

// 6.1 — the shared abstract base of context-link Nodes: they modify a
// plain Node's default contextual reading or state an actual
// correspondence. They are not ordinary contextual objects, carry no
// default instantiation, and take effect without Assertion.
export class ContextLink extends SituatedNode {
  static BRAND = Brand("commons:ContextLink:v1");
  constructor(situated) {
    if (new.target === ContextLink) {
      throw new TypeError("ContextLink is abstract");
    }
    super(situated);
  }
}

// 6.2 — `node`'s referent is one of the referents `situation` talks
// about. A declaration, not a Proposition: definiteness ("that wolf");
// existence questions use Virtual patterns (10.1). The correspondence it
// fixes is visible only in its Situation and descendants (6.3).
export class Among extends ContextLink {
  static BRAND = Brand("commons:Among:v1");
  constructor(situated) {
    Final(Among, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 6.3 — the owning Situation has adopted that `left` and `right` share
// one referent. A declaration describing the correspondence actually in
// use; the believed/disputed reading is SameReferent below. Never merges
// Node identity; visible only in its Situation and descendants.
export class Corresponds extends ContextLink {
  static BRAND = Brand("commons:Corresponds:v1");
  constructor(situated) {
    Final(Corresponds, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 6.4 — cancels the plain Node's default instantiation ("there is one
// such object here"): the modified Node now stands for the description
// itself. Fields of it pointing at concrete Nodes are the pattern's
// constants; fields pointing at other Virtual Nodes are more variable
// positions. `Virtual` defines no quantifier — the consuming cognition
// does (Unable.deed, NoInstance.of, Only.of, …).
export class Virtual extends ContextLink {
  static BRAND = Brand("commons:Virtual:v1");
  // The node field is the declaration channel itself, so the pattern
  // check treats it as such.
  static PATTERN = ["node"];
  constructor(situated) {
    Final(Virtual, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 8.4 — declares `variable` to be the validity of `proposition` in
// `situated`. A declaration like Among: no Assertion needed, none
// allowed. Deriving true/false uses every available cognition (explicit
// Assertions and derivation rules), not only situated's own members.
export class Validity extends SituatedNode {
  static BRAND = Brand("commons:Validity:v1");
  constructor(situated) {
    Final(Validity, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 8.2 — the holder holds the negation of `proposition`'s content. No
// global refutation ontology; refuted = Not(P) derivable. Time is not
// negatable through Not (14.5, checked by the trial lint).
export class Not extends Proposition {
  static BRAND = Brand("commons:Not:v1");
  constructor(situated) {
    Final(Not, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 11.1 — conjunction of propositions; mainly for Conditional parts. A
// single proposition needs no wrapper.
export class And extends Proposition {
  static BRAND = Brand("commons:And:v1");
  constructor(situated) {
    Final(And, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 11.2 — explicit quantification over Virtual Nodes. `forall`/`exists`
// list the quantified Virtual positions; `antecedent` and `consequence`
// share them through object identity. No scope Situation, no open items;
// derivation never writes back into the Situation.
export class Conditional extends Proposition {
  static BRAND = Brand("commons:Conditional:v1");
  // The quantifier lists name Virtual positions; antecedent and
  // consequence are the two halves of one pattern (§11.2), so they also
  // accept pattern content.
  static PATTERN = ["forall", "exists", "antecedent", "consequence"];
  constructor(situated) {
    Final(Conditional, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 10.2 — negated existence: no instance of the Virtual description `of`
// (the pattern head; the constraint body is the connected component,
// 6.4). Replaces NoEvent/NoneSuch; the time window is an ordinary
// constraint of the body (an In over the head's occurrence).
export class NoInstance extends Proposition {
  static BRAND = Brand("commons:NoInstance:v1");
  static PATTERN = ["of"]; // the head is a Virtual-modified Node
  constructor(situated) {
    Final(NoInstance, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 10.3 — exhaustive listing: every instance of the Virtual description
// `of` in this Situation is one of `among`. The negative consequences
// come from Only's own derivation rule, never from a global refutes
// system.
export class Only extends Proposition {
  static BRAND = Brand("commons:Only:v1");
  static PATTERN = ["of"]; // the head is a Virtual-modified Node
  constructor(situated) {
    Final(Only, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 6.3 — an ordinary Proposition: some Situation holds that left and
// right share a referent. Unlike Corresponds it is belief content that
// can be believed, denied, or asked about, which is what a belief
// context's identification is (the dog's "the shadow is another dog").
export class SameReferent extends Proposition {
  static BRAND = Brand("commons:SameReferent:v1");
  constructor(situated) {
    Final(SameReferent, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
