// Time vocabulary per doc/Commons_再重构原型.md §14–15. Time belongs to
// propositions: an unmodified proposition is naturally AllTime (14.7),
// and At/In/Within narrow it by intersection. Anchors are Nodes (14.10);
// Durations and the set operations are frozen plain values, never Nodes.
// The exact anchor accessor API is open in the spec (§16 item 8); the
// memoized Start/End accessors below are this trial's proposal.
import {
  Brand,
  Final,
  Proposition,
  SituatedNode,
  ReportDataMembers,
  GlobalNode,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// 14.2 — a plain, empty time anchor with no built-in meaning. What a
// particular anchor is (story start, story end, …) is stated by the
// input's own cognition, never by the class. Open: §14.3 lets inner
// anchors (vertex, turning point, …) subclass it.
export class TimeAnchor extends SituatedNode {
  static BRAND = Brand("commons:TimeAnchor:v1");
  constructor(situated) {
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 14.3 — an Event's start / end anchor. Final kinds; inner anchors
// subclass TimeAnchor above.
export class StartAnchor extends TimeAnchor {
  static BRAND = Brand("commons:StartAnchor:v1");
  // `of` names the Event this anchor bounds.
  constructor(situated) {
    Final(StartAnchor, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

export class EndAnchor extends TimeAnchor {
  static BRAND = Brand("commons:EndAnchor:v1");
  constructor(situated) {
    Final(EndAnchor, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// One stable anchor object per event (trial API; spec §16 item 8): the builder
// pushes it into the Input exactly once, next to the event.
const startOf = /* @__PURE__ */ new WeakMap();
const endOf = /* @__PURE__ */ new WeakMap();

export function Start(event) {
  let anchor = startOf.get(event);
  if (anchor === undefined) {
    anchor = new StartAnchor(event.situated);
    anchor.of = event;
    startOf.set(event, anchor);
  }
  return anchor;
}

export function End(event) {
  let anchor = endOf.get(event);
  if (anchor === undefined) {
    anchor = new EndAnchor(event.situated);
    anchor.of = event;
    endOf.set(event, anchor);
  }
  return anchor;
}

// 14.5 — a Duration: the union of the given anchors and the regions
// they span. A frozen plain value (not a Node, never Virtual); the
// anchor references inside it are reported through the mention
// declaration of the cognition holding the value.
const DURATION = "commons:Duration:v1";

export function Duration(...anchors) {
  return Object.freeze({ brand: DURATION, anchors: Object.freeze([...anchors]) });
}

// 14.3 — the Duration an Event carries, bounded by its own anchors.
// In(Occurs(e), EventDuration(e)) is the canonical occurrence write
// (13.1); a bare Occurs(e) would mean the event's Duration is AllTime.
export function EventDuration(event) {
  return Duration(Start(event), End(event));
}

// 14.6 — the top of time restriction, provided through the Foundation
// global mechanism. Not "never ends", not "unknown": simply the widest
// range, T ∩ AllTime = T.
export class AllTimeGlobal extends GlobalNode {
  static BRAND = Brand("commons:AllTime:v1");
}

export const AllTime = AllTimeGlobal.Ref();

// 14.8 — at a point: P holds at anchor A, on top of P's own time.
export class At extends Proposition {
  static BRAND = Brand("commons:At:v1");
  // fields: proposition, anchor
  constructor(situated) {
    Final(At, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 14.9 — throughout a duration: P holds at every point of D, on top of
// P's own time. Nested time modifiers intersect at every level.
export class In extends Proposition {
  static BRAND = Brand("commons:In:v1");
  // fields: proposition, duration
  constructor(situated) {
    Final(In, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 14.4 — the anchor lies somewhere inside the duration. "P at some
// moment of D" is a fresh anchor plus Within and At, never a looser In.
export class Within extends Proposition {
  static BRAND = Brand("commons:Within:v1");
  // fields: anchor, duration
  constructor(situated) {
    Final(Within, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// 14.5 — set operations over times. Frozen plain values; the empty
// result is an empty value and the consumer reports it.
const SETOP = "commons:TimeSetOp:v1";

export function TimeIntersection(...times) {
  return Object.freeze({ brand: SETOP, op: "intersection", times: Object.freeze([...times]) });
}

export function TimeUnion(...times) {
  return Object.freeze({ brand: SETOP, op: "union", times: Object.freeze([...times]) });
}

export function TimeComplement(time) {
  return Object.freeze({ brand: SETOP, op: "complement", times: Object.freeze([time]) });
}
