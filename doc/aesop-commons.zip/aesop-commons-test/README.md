# aesop-commons-test

用《Commons 再重构原型》（`doc/Commons_再重构原型.md`）的语义机制重新
构造 aesop-phase2 的故事与问题的构造试验。**只构造，不求解**；结论与
逐条观察在 [OBSERVATIONS.md](./OBSERVATIONS.md)。

```shell
node check.mjs   # 19 问构造 + 7 负例 + 1 正例 + Foundation 副本 diff 锁，应 28/28
```

布局：

- `space/Memory/Foundation/`、`space/Interface/Nodes.js` 等 ——
  `src/foundation` 的字节级副本（check.mjs 每次运行核对），零修改。
- `space/Memory/Commons/` —— 原型词汇层：`Core.js`（语境关联、逻辑、
  Validity、Assertion）、`Time.js`（锚点、Duration、At/In/Within、
  AllTime、集合运算）、`Aesop.js`（试验故事词表）；公共出口
  `space/Interface/Commons.js`。
- `cases/story-{1,4,8,10}/` —— 每故事 `story.mjs`（事实）与
  `questions.mjs`（问题，含手工 `intent`），共享 `cases/helpers.mjs`
  的 `Occurred`/`Chain`/`Bounds`/`BuildCase`。

试验约定（规范未定、本试验自选的写法）见 OBSERVATIONS.md 第 2 节。
