// Construction-only gate for the aesop-commons-test trial: for every
// story/question case, build the Input and run (1) the Foundation
// structural pass (Analyze: occurrence, order, Situation mention, Query
// discipline) and (2) the trial lint — the structural rules the spec
// itself states (pattern fields §6.4, Not over time §14.5, Virtual
// heads §10.2/10.3/11.2, quantified Conditional nodes §11.2, root
// contexts §12). No solver runs: expected resolutions are
// recorded per question as `intent` and argued by hand in
// OBSERVATIONS.md. The Foundation copy is diff-locked against
// src/foundation so the layering claim stays checkable.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { Analyze } from "./space/Memory/Foundation/Analyze.js";
import {
  Assertion,
  Virtual,
  Not,
  At,
  In,
  NoInstance,
  Only,
  Conditional,
  Validity,
  Among,
  Proposition,
  Entity,
  Situation,
  Variable,
  Present,
  TimeAnchor,
  StartAnchor,
  EndAnchor,
  Believes,
  Cry,
  Throw,
  Promise,
} from "./space/Interface/Commons.js";
import { BuildCase, Virtualize } from "./cases/helpers.mjs";

const root = join(fileURLToPath(import.meta.url), "..");

// --- the trial lint ------------------------------------------------------

// Every Node reachable from one field value through plain containers
// (arrays, records, Map/Set, frozen values), without crossing into the
// found Nodes' own fields — each Node's own lint pass covers those.
// A Node here is anything with an own "situated" data member.
function reachableNodes(value) {
  const found = [];
  const seen = new Set();
  const pending = [value];
  while (pending.length > 0) {
    const item = pending.pop();
    if (item === null || typeof item !== "object") continue;
    if (seen.has(item)) continue;
    seen.add(item);
    if (Object.hasOwn(item, "situated")) {
      found.push(item);
      continue;
    }
    if (Array.isArray(item)) pending.push(...item);
    else if (item instanceof Map) pending.push(...item.keys(), ...item.values());
    else if (item instanceof Set) pending.push(...item.values());
    else pending.push(...Object.values(item));
  }
  return found;
}

// Whether the value graph from `start` (crossing Node fields, once each)
// contains an instance of any of the `types`.
function deepContainsType(start, types) {
  const seen = new Set();
  const pending = [start];
  while (pending.length > 0) {
    const item = pending.pop();
    if (item === null || typeof item !== "object") continue;
    if (seen.has(item)) continue;
    seen.add(item);
    if (types.some((type) => item instanceof type)) return true;
    if (Object.hasOwn(item, "situated")) {
      for (const [key, value] of Object.entries(item)) {
        if (key !== "situated") pending.push(value);
      }
    } else if (Array.isArray(item)) pending.push(...item);
    else if (item instanceof Map) pending.push(...item.keys(), ...item.values());
    else if (item instanceof Set) pending.push(...item.values());
    else pending.push(...Object.values(item));
  }
  return false;
}

// The Virtual nodes of a Conditional's component reachable from its
// antecedent and consequence: the walk expands propositions and Virtual
// nodes, and stops at concrete non-proposition nodes, which are the
// pattern's constants (§6.4).
function conditionalVirtuals(roots, virtualized) {
  const found = new Set();
  const seen = new Set();
  const pending = [...roots];
  while (pending.length > 0) {
    const item = pending.pop();
    if (item === null || typeof item !== "object") continue;
    if (seen.has(item)) continue;
    seen.add(item);
    if (Object.hasOwn(item, "situated")) {
      if (virtualized.has(item)) found.add(item);
      if (!(item instanceof Proposition) && !virtualized.has(item)) continue;
      for (const [key, value] of Object.entries(item)) {
        if (key !== "situated") pending.push(value);
      }
    } else if (Array.isArray(item)) pending.push(...item);
    else if (item instanceof Map) pending.push(...item.keys(), ...item.values());
    else if (item instanceof Set) pending.push(...item.values());
    else pending.push(...Object.values(item));
  }
  return found;
}

export function Lint(input) {
  const errors = [];
  const virtualized = new Map(); // node -> Virtual declaration
  const asserted = new Set();
  for (const node of input) {
    if (node instanceof Virtual) virtualized.set(node.node, node);
    if (node instanceof Assertion) asserted.add(node.proposition);
  }
  const patternFields = (node) => node.constructor?.PATTERN ?? [];

  for (const node of input) {
    for (const [field, value] of Object.entries(node)) {
      if (field === "situated") continue;
      for (const target of reachableNodes(value)) {
        if (!virtualized.has(target)) continue;
        if (patternFields(node).includes(field)) continue;
        // A Virtual node pointing at another Virtual node is one more
        // variable position of the same pattern (§6.4).
        if (virtualized.has(node)) continue;
        if (node instanceof Proposition) {
          if (asserted.has(node)) {
            // §6.4 lint: an asserted proposition reaching a Virtual node
            // through an ordinary field states a pattern as a fact.
            errors.push(
              `${node.constructor.name}.${field} reaches Virtual ${target.constructor.name} but is asserted (§6.4)`,
            );
          }
        } else {
          // §6.4 lint: a plain non-Virtual node referencing a Virtual
          // node through an ordinary field.
          errors.push(
            `${node.constructor.name}.${field} references Virtual ${target.constructor.name} without being Virtual itself (§6.4)`,
          );
        }
      }
    }
    if (node instanceof Not) {
      if (deepContainsType(node.proposition, [At, In])) {
        errors.push(
          "Not over time: write In(Not(P), D) or complements instead of Not(At/In) (§14.5)",
        );
      }
    }
    if (node instanceof NoInstance || node instanceof Only) {
      if (!virtualized.has(node.of)) {
        errors.push(
          `${node.constructor.name}.of must be a Virtual-modified head (§10.2/10.3)`,
        );
      }
    }
    if (node instanceof Conditional) {
      const quantified = new Set([...(node.forall ?? []), ...(node.exists ?? [])]);
      for (const side of quantified) {
        if (!virtualized.has(side)) {
          errors.push(
            "Conditional.forall/exists entries must be Virtual-modified (§11.2)",
          );
        }
      }
      // §11.2: every Virtual node of the component is quantified; an
      // event's Start/End anchors go with their event.
      const reached = conditionalVirtuals([node.antecedent, node.consequence], virtualized);
      for (const target of reached) {
        if (quantified.has(target)) continue;
        const anchor = target instanceof StartAnchor || target instanceof EndAnchor;
        if (anchor && quantified.has(target.of)) continue;
        errors.push(
          `Conditional leaves Virtual ${target.constructor.name} unquantified: list it in forall or exists (§11.2)`,
        );
      }
    }
    // §12: a Situation named as content is a context and must be a root;
    // a child Situation would inherit the narrator's cognition.
    if (Object.hasOwn(node, "content") && node.content instanceof Situation) {
      if (node.content.situated !== null) {
        errors.push(
          `${node.constructor.name}.content names a non-root Situation; contexts must be roots (§12)`,
        );
      }
    }
    if (node instanceof Validity) {
      if (!(node.proposition instanceof Proposition)) {
        errors.push("Validity.proposition must be a Proposition (§8.4)");
      }
      if (!(node.variable instanceof Variable)) {
        errors.push("Validity.variable must be a Variable (§8.4)");
      }
    }
    if (node instanceof Among) {
      if (!(node.situation instanceof Situation)) {
        errors.push("Among.situation must be a Situation (§6.2)");
      }
    }
  }
  return errors;
}

// --- foundation diff lock -------------------------------------------------

function walkFiles(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) out.push(...walkFiles(path));
    else out.push(path);
  }
  return out;
}

function CheckFoundationCopy() {
  const source = join(root, "..", "..", "src", "foundation");
  const space = join(root, "space");
  const drifted = [];
  for (const file of walkFiles(source)) {
    const rel = relative(source, file);
    let same = false;
    try {
      same = readFileSync(file).equals(readFileSync(join(space, rel)));
    } catch (_) {
      same = false;
    }
    if (!same) drifted.push(rel);
  }
  return drifted;
}

// --- positive cases --------------------------------------------------------

const suites = [
  { id: 1, title: "The Crow and the Pitcher" },
  { id: 4, title: "The Dog and the Shadow" },
  { id: 8, title: "The Nurse and the Wolf" },
  { id: 10, title: "The Shepherd's Boy" },
];

let passed = 0;
let failed = 0;
for (const suite of suites) {
  const cases = await import(`./cases/story-${suite.id}/questions.mjs`);
  const story = (await import(`./cases/story-${suite.id}/story.mjs`)).BuildStory;
  for (const [index, question] of cases.Questions.entries()) {
    const label = `Story ${suite.id} Q${index + 1}  ${question.text}`;
    try {
      const input = BuildCase(question, story);
      Analyze(input);
      const errors = Lint(input);
      if (errors.length > 0) throw new Error(errors.join("; "));
      passed += 1;
      console.log(`PASS  ${label}`);
      console.log(`        intent: ${question.intent}`);
    } catch (caught) {
      failed += 1;
      console.log(`FAIL  ${label}`);
      console.log(`        ${caught.message ?? caught}`);
    }
  }
}

// --- negative controls -----------------------------------------------------

function expectLint(name, fn) {
  const errors = fn();
  if (errors.length > 0) {
    passed += 1;
    console.log(`PASS  NEG  ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL  NEG  ${name} — no error reported`);
  }
}

expectLint("asserted proposition reaching a Virtual node through an ordinary field", () => {
  const story = new Situation();
  const e = new Entity(story);
  const input = [story, e];
  Virtualize(input, e);
  const p = new Present(story);
  p.subject = e;
  input.push(p);
  const a = new Assertion(story);
  a.proposition = p;
  input.push(a);
  return Lint(input);
});

expectLint("plain node referencing a Virtual node through an ordinary field", () => {
  const story = new Situation();
  const e = new Entity(story);
  const input = [story, e];
  Virtualize(input, e);
  const holder = new Entity(story);
  holder.friend = e;
  input.push(holder);
  return Lint(input);
});

expectLint("Not over a time modifier", () => {
  const story = new Situation();
  const p = new Present(story);
  const anchor = new TimeAnchor(story);
  const at = new At(story);
  at.proposition = p;
  at.anchor = anchor;
  const not = new Not(story);
  not.proposition = at;
  return Lint([story, p, anchor, at, not]);
});

expectLint("NoInstance over a non-Virtual head", () => {
  const story = new Situation();
  const e = new Entity(story);
  const n = new NoInstance(story);
  n.of = e;
  return Lint([story, e, n]);
});

expectLint("context Situation that is a child of the narrator", () => {
  const story = new Situation();
  const belief = new Situation(story);
  const believer = new Entity(story);
  const believes = new Believes(story);
  believes.believer = believer;
  believes.content = belief;
  return Lint([story, belief, believer, believes]);
});

expectLint("Conditional leaving a Virtual node unquantified", () => {
  const story = new Situation();
  const child = new Entity(story);
  const input = [story, child];
  const noise = new Cry(story);
  noise.theme = child;
  input.push(noise);
  Virtualize(input, noise);
  const heard = new Present(story);
  heard.subject = noise;
  input.push(heard);
  const warning = new Conditional(story);
  warning.forall = [];
  warning.exists = [];
  warning.antecedent = heard;
  warning.consequence = heard;
  input.push(warning);
  return Lint(input);
});

expectLint("Analyze rejects a member occurring before its parent Situation", () => {
  const story = new Situation();
  const child = new Situation(story);
  const member = new Entity(child);
  try {
    Analyze([story, member, child]);
    return [];
  } catch (_) {
    return ["rejected as expected"];
  }
});

function expectClean(name, fn) {
  const errors = fn();
  if (errors.length === 0) {
    passed += 1;
    console.log(`PASS  POS  ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL  POS  ${name} — ${errors.join("; ")}`);
  }
}

// §6.4: an intended deed is a pattern-accepting field, so a story may
// assert a promise of a kind of deed.
expectClean("asserted Promise whose deed is a Virtual pattern", () => {
  const story = new Situation();
  const fox = new Entity(story);
  const crow = new Entity(story);
  const input = [story, fox, crow];
  const share = new Throw(story);
  share.to = crow;
  input.push(share);
  Virtualize(input, share);
  const promised = new Promise(story);
  promised.actor = fox;
  promised.deed = share;
  input.push(promised);
  const held = new Assertion(story);
  held.proposition = promised;
  input.push(held);
  return Lint(input);
});

// --- foundation lock --------------------------------------------------------

const drifted = CheckFoundationCopy();
if (drifted.length > 0) {
  failed += 1;
  console.log(`FAIL  foundation copy drifted from src/foundation: ${drifted.join(", ")}`);
} else {
  passed += 1;
  console.log("PASS  foundation copy is byte-identical to src/foundation");
}

console.log(`\nConstruction check: ${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
