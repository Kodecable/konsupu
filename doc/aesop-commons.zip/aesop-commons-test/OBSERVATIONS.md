# 用《Commons 再重构原型》构造 aesop-phase2 故事与问题的试验观察

试验目录：`run/aesop-commons-test/`（2026-10-06）。
问题：**用 `doc/Commons_再重构原型.md` 的语义机制，把 aesop-phase2 的故事和
问题构造出来，方便吗？** 不要求求解器；本试验只构造，不求解。

> **复查修订（2026-10-06）**：试验经复查后已按规范修订，修订内容与被取代
> 的结论见第 9 节。第 2–5 节保留首次试验的记录，其中标注"已由第 9 节取代"
> 的部分不再成立。第 1–8 节引用的节号（尤其 §15–§18）是当时的原型草案，
> 原文备份为 `doc/Commons_再重构原型_备份.md`；正式草案中第 0–14 节编号
> 不变，原 §15/§17 移入附录 A 与 §14.12，原 §16 为 §15，原 §18 为 §16。

## 0. 结论

**大体方便，方向正确；但有一处必须先补规范才能用的结构性缺口。**

- 事实侧（故事认知）构造顺手：态度语境、未发生事件对象、Virtual 模式、
  NoInstance/Only、显式时间区间，覆盖了 phase2 全部六种否定形态和五种
  "与事实不符"，且多数比 phase2 写法更短、更少特殊机制。
- 是非问一侧是明确的改进：`Validity` 一条声明取代 phase2 的
  `AskWhether` + `HoldsIn` + verdict 包装，`Unknown` 从开放世界自然涌现，
  对应 phase2 的 NotEstablished 而不需要 `{constraints, level}` 结构。
- **缺口（G1/G2，见第 5 节）：wh 问题的"约束载体"在规范中没有定义。**
  §5.2 禁止了 asked-held Assertion（"不存在双重解释"），§7.2 只示范了
  "描述 + Among + 字段里的 Variable"这一种属性问法；关系问法
  （`Next(?, V)`、`Causes(V, ?)`、`InOrderTo(?, V)`）只能靠**未断言命题
  携带 Variable** 充当约束，而规范从未说未断言命题可以这样用。读另一
  语境所持命题（"狗以为影子是什么"）同样没有第一类形式。本试验采用两
  条**试验约定**绕过（见第 2 节），求解器实现之前必须把它们定进规范。

## 1. 试验设定

- 选材：story-1（乌鸦和水罐）、story-4（狗和影子）、story-8（保姆和
  狼）、story-10（牧童），共 **4 故事 19 问**。选择标准是覆盖 phase2 的
  主要语义机制：定指与描述、信念/言语/计划/期望语境、未发生事件对象、
  穷尽（Only）、否定存在（NoInstance）、序数（Nth）、时间窗、是非问的
  是/否/未定三种结果、真话判断。
- 分层：`space/` 内是 `src/foundation` 的字节级副本（`check.mjs` 每次
  运行都 diff 锁定，Foundation 零修改），其上是 `Memory/Commons/` 的
  原型词汇层（Core/Time/Aesop 共约 500 行），再上是每故事的
  story/questions fixture。
- 门禁：`node check.mjs` → 25/25 通过（修订后 27/27，见第 9 节）。每问一个 Input，过 Foundation
  `Analyze`（结构：出现、顺序、Situation mention、Query 纪律）+ 本试验
  lint（§6.4 模式字段、§14.5 Not 不作用于时间、§10.2/10.3/11.2 Virtual
  头）+ 5 条负例 + Foundation 副本 diff。**没有求解器**：每问的期望结
  果以 `intent` 字段手工记录在 questions.mjs 中，下文推导为人工论证。
- 问题布局：全部采用 §7.2 示例的扁平式——问题认知（未断言约束、
  Variable、Query）与故事事实同住一个 Situation。phase2 的三层
  dialogue/asked + Asks + Reply + Imperative 是运行时管线，不是 Commons
  语义，本试验不建。

## 2. 试验性 API 决定（填补 §18 的空白）

规范未定、试验必须选形的地方，全部记录如下；这些是**提案**，不是结论：

| 空白 | 规范条目 | 试验选择 |
|---|---|---|
| 锚点 API | 18.10 | 每个 Event 的 `Start(e)`/`End(e)` 是 WeakMap 记忆化的锚点 Node（身份稳定、Input 中恰好出现一次）；`EventDuration(e) = Duration(Start(e), End(e))` |
| Duration 形态 | 18.11 | 冻结普通值 `{brand, anchors}`（§14.5 的集合运算值可直接作参数）；锚点经持有者的提及声明进反查（`ReportDataMembers` 天然穿透冻结对象） |
| `AllTime` | 14.6 | Foundation GlobalNode 子类的 `.Ref()` |
| 模式接受字段声明 | 6.4 / 18.9 | 类上静态 `PATTERN = ["deed", ...]`；lint 按它区分"约束体成员"与"非法引用 Virtual" |
| 施事 | —— | ~~`actor` 作为事件的普通字段~~（已由第 9 节取代：独立 `Agent`） |
| 序数 | 18.13 | 保留 `Nth(pattern, index)` 选择子（S10Q1 的 "first" 证明仍需要） |
| 内部锚点 | 14.3 | `TimeAnchor` 为开放基类，`StartAnchor`/`EndAnchor` final（规范原文如此；实现上"开放"意味着不能被 `Final` 关闭，第一次实现时在这里踩了坑） |

**两条试验约定（求解器实现前必须定进规范，见 G1/G2）：**

1. ~~**未断言认知 + 提及被查 Variable = 该 Query 的约束**~~（已由第 9 节
   取代：它按是否 Assertion 推断角色，违反原则 2；改用约定 2）。断言它就成了真
   值声明（§5.2 禁止双重解释），所以约束只能是未断言的。§7.2 的属
   性问法（Variable 在 Among 绑定描述的字段里）是它的特例。
2. **Among 的 node 可以是命题模式**，用于在指定语境的所持命题中按内
   容匹配（S4Q1、S10Q1 实际用到；§6.2 只对"对象"立了此机制）。

## 3. 旧 → 新映射（本试验实际用到的）

| phase2 | 原型 | 试验案例 |
|---|---|---|
| asked Situation + 持有约束 + Query | 同 Situation 未断言约束 + Query（§7.2 布局） | 全部 19 问 |
| AskWhether + verdict + NotEstablished{constraints,level} | `Validity(P, v)` + Query(v)；未定即 `Unknown` | S4Q4/Q5、S8Q3–Q5、S10Q2/Q4/Q5 |
| HoldsIn（读语境所持） | Among 直入语境（对象）/ 命题模式（试验约定 2） | S8Q2、S4Q1 |
| Initially / Ends / TheEnd | 输入自造 storyStart/storyEnd 锚点 + `Before` 框定 + `In(P, Duration(...))` | S1、S4、S8、S10 |
| ResultsIn(E, P) | 时间半：`In(P, Duration(Start(E), …))`；因果半：`Causes(E, P)` 分开写 | S1Q4、S1 石头落位 |
| Ends 的期后否定 | 显式 `In(Not(P), Duration(Start(E), storyEnd))` | S1 解渴、复能 |
| NoEvent / NoneSuch + anchorWindow 四窗口 | `NoInstance(of=Virtual头)`，窗口是模式约束体里的 `In` | S10 两个否定存在 |
| OnlyDid{actor, deeds, from, until} | `Only(of=Virtual头, among=[…])`，窗口同样是约束体 | S8 "all the nurse did" |
| Shapes.js 三角色（形状/描述/常量）标记 | `Virtual` 声明 + `PATTERN` 字段声明机械区分 | 所有模式 |
| Kind 常量 | 子类继承（`Wolf extends Entity`） | S10Q2 |
| SameReferent（语境内同一认定） | 保留为普通命题；`Corresponds` 留给语境实际采用的对应（本语料未用到后者） | S4 信念 |
| Agent(action, actor) 命题 | `actor` 字段（试验决定，见 G9） | 全部 |

## 4. 方便之处（按证据强度排序）

1. **是非问一条声明。** "护士把孩子扔给狼了吗"= 未断言
   `In(Occurs(t), Duration(Start(cry), storyEnd))` + `Validity(., v)` +
   `Query(v)`（S8Q3）。"狗得到另一块肉了吗"直接 `Unknown`（S8Q4 承
   诺、S4Q4/Q5 同）——不需要 verdict 包装、不需要失败分级，开放世界
   给的就是想要的答案。
2. **读语境不需要专门机制。** "狼想吃什么"：`Eat` 描述 + `Among(node=e,
   situation=wolfThought)`（S8Q2）。语境只是 Situation，Among 直入，
   phase2 的"语境确定 + HoldsIn 内容匹配"两条机制合成一条。
3. **未发生事件对象免费。** 狗的目标是信念里的"另一块肉"：world 中一
   个不发生的 `Get` 事件对象、theme 跨 Situation 引用信念内常量
   （S4）；威胁的内容是 Conditional 的 consequence（S8）。"存在 ≠ 发
   生"一条原则覆盖了 phase2 中 Goal/Promise/威胁的整块特殊讨论。
4. **问题层扁平化省掉整层管线。** 每问少建 dialogue/asked 两个
   Situation 和 Asks/re-export Query/Reply/Imperative 四个节点，还要
   求的交错布局规则（dialogue 第一、成员最后）整个消失。Situation 语
   义中立（§4）使这是合法选择。
5. **Virtual 模式 + PATTERN 声明统一了三角色。** Unable.deed、
   NoInstance.of、Only.of、Nth.pattern、存在问的模式头全是同一机制；
   lint 规则来自类的静态声明而非 Shapes 式的运行时标记表（check.mjs
   的 4 条负例证明它有牙）。
6. **穷尽/否定存在+时间窗一次写完。** "从孩子哭起保姆只做了关窗和呼
   救"= `Only(of=Virtual deed{actor=nurse}, among=[shut, call])`，窗口
   是模式自己的 `In(Occurs(头), Duration(Start(cry), …))` 约束
   （S8）；"第三次没人来"同理（S10）。phase2 的 anchorWindow 四种窗
   口判定不再需要——窗口就是普通的 Duration。
7. **态度=普通命题。** 信念（S4/S10）、威胁内容（S8 Conditional）、期
   待（S8 狼的自语）、计划（S10）、主张（S10 第三次哭的 content）全
   是 `content` 引用一个 Situation，写法一致。
8. **类型继承替代 Kind。** `Virtual(Wolf实例)` 即"有狼吗"的量域
   （S10Q2）。

## 5. 摩擦与缺口

**G1（最大）：wh 问题的约束载体未定义。**
§5.2 明确禁止 phase2r4 的"约束就是持有"（"不存在'普通 Situation 中是
Assertion，Query Situation 中就变成 condition'这种双重解释"），这是对
的；但替代物只写了属性问法一种（§7.2：Variable 放在 Among 绑定描述的
字段里）。关系问法无处安放："之后发生了什么"（`Next(putBeak, V)`）、
"为什么"（`Causes(V, waterRise)`）、"为了什么"（`InOrderTo(snap, V)`）
都只能是**未断言命题携带 Variable**——试验约定 1。规范需要一句定义
（例如：Query 的约束集 = 未断言且（直接或经 Among）涉及被查 Variable
的认知），否则每个实现都要自己发明这一层。

**G2：读另一语境所持的命题没有第一类形式。**
"狗以为影子是什么"：信念里的 `SameReferent(shadow, anotherDog)` 是断
言对象，问它只能（a）未断言同构模式 + Among(node=命题, situation=信
念)——试验约定 2，§6.2 只对对象立过；或（b）经信念内对象的间接描述
（"信念里叼着另一块肉的那位"）。HoldsIn 被移除（§17）是对的，但替代
缺口真实存在；真话问（S10Q4）同族：主张语境的 `Present(wolf)` 与世界
里重锚的 `Present(wolf)` 是不同对象，成立性推导必须做内容匹配
（§9/18.17 未定）。另注意：声明（Among/Corresponds/Virtual/Validity）
出现即生效，**不能**作问题模式——这是设计而非缺陷，但值得写进规范，
因为它把跨语境问法挤向了 (a)/(b) 两条窄路。

**G3：发生是样板代码。**
每个发生事件 5 个节点：事件 + 起/止锚点 + `Occurs` +
`In(Occurs(e), EventDuration(e))` + Assertion（§13.1 canonical 写法；
裸 `Occurs(e)` 会与锚点约束冲突）。story-1 的 133 节点中约 60 个是这
个模式的产物。必须提供 `Occurred` 一类的规范 sugar（本试验在
helpers.mjs 里做了），否则手写必然漏锚点或漏 In。

**G4：状态两写 + 无惯性默认的代价。**
"解渴"= `In(Thirsty, [storyStart, Start(drink)])` **加上**
`In(Not(Thirsty), [Start(drink), storyEnd])`（S1 同款还有无能力）。
phase2 的 `Ends` 一次写完两件事；新版显式、语义干净，但漏写期后
`Not` 时"喝完还渴吗"得 `Unknown` 而非"否"。§15 删惯性默认是对的，
代价应作为翻译规范写明：**每个有界状态都要回答"之后呢"**。

**G5：Among 歧义传播迫使问句翻译更精确。**
"谁往罐里丢过石头"：故事有三次投石，不钉 theme 则 §6.2 的多候选规则
使答案 `Ambiguous`——**即使三个候选的施事都是乌鸦**（"不再查看各候
选各自的结论"）。phase2 的字段子集匹配下同一句自然得到唯一答案
（FRAMEWORK_NOTES r4 第 6 条曾**故意**取信息量更少的译法）。这是行为
差异，不是构造错误；要么接受"译文必须与问句的定指程度一致"，要么给
Among/查询一个 join 语义（所有候选结论一致则 OK）。规范应二选一并写
明。本试验在 S1Q1 钉了 theme。

**G6：问句描述的默认实例化需要一句明示。**
§7.2 例中的 `c = Wolf(color=b)` 未 Virtual 化；按 §1.2 它默认声明"又
有一只这样的狼"，除非把 §6.1"语境关联修改普通 Node 的默认语境解释"读
成：**Among 绑定后，c 的'有一个'对应到被选中的候选，不新增对象**。本
试验按后者理解（所有 Among 描述都没 Virtual 化，也没产生伪存在）。这
个读法应该写进规范，否则问句会虚构存在物，计数/穷尽类问题会被污染。

**G7：故事边界自造。**
storyStart/storyEnd 锚点 + 两条 `Before` 框定每故事必写（替代
Initially/TheEnd）。开销可接受（+4 节点），但"哪些锚点界定本故事"成
了每个翻译的固定起手式，规范可给个名字收编。

**G8：agent 字段 vs reified Agent 未裁决。**
字段形式与 §7.2 问法契合（"谁丢的"= 绑定事件的 actor 字段，S1Q1）；
phase2 升级 Agent 为 Node 的证据（FRAMEWORK_NOTES #9）是**求解器 join**
需要，构造层面字段形式没有表达力问题。若规范保留 reified Agent，属
性问法对施事失效、退回 G1。建议规范明确表态（本试验选了字段）。

**G9：可用但欠定义的小项。** `Nth` 保留（18.13，S10Q1 证明需要）；
`Conditional` 的 PATTERN 字段含 antecedent/consequence（前件携带
Virtual 模式，S8 威胁）；`Promise.deed` 指向常量未发生事件（S8Q4）合
法但"deed 是否也应接受模式"未定；`Causes(effect=NoInstance)`（S10Q3）
——"导致（没有发生）"的效应位放否定存在命题，规范未置可否，本试验
按普通命题处理。

## 6. 规模对比

每问 Input 节点数（新 vs phase2）：

| 故事 | 新 | phase2 | 差异主因 |
|---|---|---|---|
| story-1 | 132–136 | 119–125 | 发生样板 +5/事件，抵消了扁平问题层 |
| story-4 | 82–85 | 75–80 | 同上，故事小差异小 |
| story-8 | 118–121 | 117–127 | 大致持平 |
| story-10 | 103–107 | 138–145 | phase2 的序数/窗口机制更重，新版更省 |

总体同数量级：样板增加与扁平化、机制统一各省下的大致相抵。词汇层本
身约 500 行（含注释），新增机制类 13 个（Among/Corresponds/Virtual/
Validity/Not/And/Conditional/NoInstance/Only/SameReferent/At/In/
Within），其余全是普通 ontology。

## 7. 给规范定稿的建议（按优先级）

1. **定义 Query 的约束载体**（G1）：未断言 + 提及被查 Variable 的认知
   如何成为约束；含命题模式时 Among 的语义（G2）。
2. **明示 Among 对描述节点默认实例化的修改**（G6），并裁决 G5（歧义
   传播 vs join）。
3. **收编两条 sugar 为规范写法**（G3/G4）：`Occurred(e)` 与"区间 + 期
   后 Not"的组合示例放进 §13/§14。
4. 落定 18.10 锚点 API（本试验的 memoized accessor 方案可行）与
   18.9 的字段方向/模式声明（`PATTERN` 静态声明够用）。
5. 裁决 agent 字段 vs reified Agent（G8）。
6. 小项：Nth 去留（建议留）、Causes.effect 是否接受否定存在、
   Promise.deed 的模式性（G9）。

## 8. 试验的边界

- 无求解器：`intent` 是人工推导；Among/Validity/NoInstance/Only 的**求
  解**语义（候选搜索、窗口包含推导、内容匹配推导）均未实现、未验证。
  结构与 lint 层面由 check.mjs 的 25 项检查锁定。
- 4/13 故事、19/65 问：机制覆盖按第 1 节清单选取，未覆盖的语料（如
  Habitual、Lasted、Overlaps、嵌套序数、S12 谎言/言语真假的双语境时
  间）可能暴露新缺口。
- 本目录自包含（Foundation 副本 diff 锁定），不触碰 `src/`；运行方式
  见 README。

## 9. 复查修订（2026-10-06）

复查发现首次试验有四处建模错误，并与规范的若干既定内容不一致。规范已相应
补充（`doc/Commons_再重构原型.md` §0 原则 9、§6.2、§6.3、§11.2、§12、
§13.1–13.2、§14.4），fixture 已修订，`node check.mjs` → 27/27。

**建模错误（已修）：**

1. **语境不是 root。** 信念、威胁、计划、言语内容都建成了故事的子
   Situation。Foundation 中子 Situation 继承祖先认知，信念因此继承了整个
   故事，§12 的语境隔离失效。现在全部是 root；lint 增加"content 引用的
   Situation 必须是 root"（规范 §12）。
2. **狗的信念里出现了影子。** 信念曾持有 `SameReferent(shadow, otherDog)`，
   但狗并不认为那是影子。现在信念只含"另一只狗叼着另一块肉"，"那只狗其实
   是影子"由故事声明 `Corresponds(left=otherDog, right=shadow)`；"狗以为影
   子是什么"写成 `Corresponds(left=answer, right=shadow)`（规范 §6.3"询问
   对应"）。`Corresponds` 放在故事里就是叙述者的认定，原注释"Corresponds
   是信念语境采纳"是误读。
3. **否定存在与穷尽的时间窗写成了 `In`。** `In` 是"每一点"，
   `In(Occurs(x), D)` 只描述在整个 D 内持续发生的事，`NoInstance`/`Only`
   因此几乎不排除任何东西。现在事件写成 canonical 发生加
   `Within(Start(x), D)`，状态写成 Virtual 锚点加 `Within` 与 `At`（规范
   §13.1、§14.4；helpers 的 `PatternEvent`、`StartsWithin`）。同类问题还有
   几处裸 `Occurs`（S4Q4、S8Q5、威胁的前后件），按 §13.1 它表示"在
   `AllTime` 的每一点发生"，也已改为 canonical 写法。
4. **威胁的 `Conditional` 量词为空。** 现在 `forall: [noise]`、
   `exists: [throwChild]`；lint 增加"分量中的 Virtual Node 必须列入
   forall/exists，事件锚点随事件量化"（规范 §11.2）。

**与规范一致化：**

- **G1 / 试验约定 1 取消。** 关系问法改用 `Among` 作用于 Proposition（约
  定 2 进入规范 §6.2）：候选是在该 Situation 中成立（可推出）的命题，派生
  命题也在内。S1Q2/Q3/Q4、S4Q3、S10Q1/Q3 已改写。
- **G2。** 读语境命题即 `Among(node=模式, situation=语境)`；真话问直接对
  言语内容自己的命题做 `Validity`（规范 §12.2），言语内容写明时间
  `At(Present(wolf), Start(cry3))`（§12.1），不再在故事里重写一遍。
- **G6。** 规范 §6.2 已明示：`Among` 取消描述节点的默认实例化。
- **G8 / 施事。** 规范采用原则 9：被讨论的关系提升为独立 Node。施事改为
  独立的 `Agent(action, actor)`，事件不再有 `actor` 字段；"谁丢的"是对
  `Agent` 描述的 `Among`（S1Q1、S8Q1）。`Goal.actor`、`Promise.actor`、
  `Unable.actor` 是命题自身的角色字段，保留。
- **G5** 是既定行为（所有候选结论相同也是 `Ambiguous`），不改。
- 试验 lint 的一个缺陷：原实现把"Virtual Node 指向另一个 Virtual Node"也报
  为错误（§6.4 允许，那是同一模式的另一个可变位置）。首次试验没有这种写
  法所以没暴露，修订后 Virtual 事件的锚点触发了它，已修。
- S8Q4 承诺问中的 deed 改为 Virtual：原写法的普通 `Throw` 会在故事中引入
  一次扔孩子事件。

