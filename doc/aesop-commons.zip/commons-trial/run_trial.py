#!/usr/bin/env python3
"""Send the Commons summary and the trial questions to an OpenAI-compatible
chat completion endpoint and save the answer.

Only the standard library is used. Examples:

  ./run_trial.py --base-url https://api.example.com/v1 --model some-model \
      --api-key "$API_KEY" --out 答案-flash.md

  # Provider-specific switches (e.g. turning thinking off) go in --extra-body:
  ./run_trial.py ... --extra-body '{"thinking": {"type": "disabled"}}'
  ./run_trial.py ... --extra-body '{"enable_thinking": false}'
  ./run_trial.py ... --extra-body '{"reasoning_effort": "none"}'

  # Extra HTTP headers, repeatable:
  ./run_trial.py ... --header "X-Title: commons-trial" --header "Foo: bar"

  # Repeat the same request to measure variance; 3 requests at a time:
  ./run_trial.py ... --runs 8 --parallel 3
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent

SYSTEM_PROMPT = (
    "你是 Konsupu 的 Input 编码者。用户会给你一份 Commons 摘要和一份题目。"
    "严格依据摘要作答：按摘要第 11 节编码故事，按第 12 节的步骤编码问题，"
    "按题目要求的格式给出代码、预测结果、理由与拿不准之处。"
    "只输出答案本身，使用 Markdown。"
)


def parse_header(text):
    name, sep, value = text.partition(":")
    if not sep or not name.strip():
        raise argparse.ArgumentTypeError(f"header must be 'Name: value', got {text!r}")
    return name.strip(), value.strip()


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--base-url", default=os.environ.get("TRIAL_BASE_URL"),
                   help="API base URL, e.g. https://api.openai.com/v1 "
                        "(env TRIAL_BASE_URL); /chat/completions is appended")
    p.add_argument("--api-key", default=os.environ.get("TRIAL_API_KEY"),
                   help="Bearer token (env TRIAL_API_KEY); omit for none")
    p.add_argument("--model", default=os.environ.get("TRIAL_MODEL"),
                   help="model name (env TRIAL_MODEL)")
    p.add_argument("--header", action="append", type=parse_header, default=[],
                   help="extra HTTP header 'Name: value', repeatable")
    p.add_argument("--extra-body", default=None,
                   help="JSON object merged into the request body")
    p.add_argument("--temperature", type=float, default=None)
    p.add_argument("--max-tokens", type=int, default=None)
    p.add_argument("--timeout", type=float, default=600, help="seconds")
    p.add_argument("--summary", type=Path, default=HERE / "Commons_摘要.md")
    p.add_argument("--questions", type=Path, default=HERE / "题目.md")
    p.add_argument("--out", type=Path, default=None,
                   help="answer file (default: 答案-<model>-<time>.md here); "
                        "with --runs > 1 it is the stem of <out>-NN.md")
    p.add_argument("--runs", type=int, default=1,
                   help="send the same request this many times")
    p.add_argument("--parallel", type=int, default=1,
                   help="number of requests in flight at once")
    p.add_argument("--dry-run", action="store_true",
                   help="print the request body and exit")
    args = p.parse_args()
    if args.runs < 1 or args.parallel < 1:
        p.error("--runs and --parallel must be at least 1")
    if not args.dry_run:
        missing = [n for n in ("base_url", "model") if not getattr(args, n)]
        if missing:
            p.error("missing " + ", ".join("--" + n.replace("_", "-") for n in missing))
    return args


def build_body(args):
    summary = args.summary.read_text(encoding="utf-8")
    questions = args.questions.read_text(encoding="utf-8")
    user = (
        "# 文件一：Commons_摘要.md\n\n" + summary
        + "\n\n---\n\n# 文件二：题目.md\n\n" + questions
    )
    body = {
        "model": args.model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    }
    if args.temperature is not None:
        body["temperature"] = args.temperature
    if args.max_tokens is not None:
        body["max_tokens"] = args.max_tokens
    if args.extra_body:
        extra = json.loads(args.extra_body)
        if not isinstance(extra, dict):
            raise SystemExit("--extra-body must be a JSON object")
        body.update(extra)
    return body


def post(args, body):
    url = args.base_url.rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json", "User-Agent": "ktrial/0.1"}
    if args.api_key:
        headers["Authorization"] = "Bearer " + args.api_key
    for name, value in args.header:
        headers[name] = value
    request = urllib.request.Request(
        url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=args.timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {error.code} from {url}:\n{detail}") from None


def output_paths(args):
    """Return one answer path per run."""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    safe_model = "".join(c if c.isalnum() or c in "-_." else "_" for c in args.model)
    if args.runs == 1:
        return [args.out or HERE / f"答案-{safe_model}-{stamp}.md"]
    if args.out:
        stem = args.out.with_suffix("")
        return [stem.parent / f"{stem.name}-{i:02d}.md" for i in range(1, args.runs + 1)]
    folder = HERE / f"答案-{safe_model}-{stamp}"
    folder.mkdir(exist_ok=True)
    return [folder / f"run-{i:02d}.md" for i in range(1, args.runs + 1)]


def run_once(args, body, out):
    """Send one request and write its answer; return a one-line status."""
    started = time.time()
    reply = post(args, body)
    elapsed = time.time() - started

    choices = reply.get("choices") or []
    if not choices:
        raise RuntimeError("no choices in response:\n" + json.dumps(reply, ensure_ascii=False, indent=2))
    message = choices[0].get("message") or {}
    content = message.get("content") or ""
    # Some providers return their reasoning separately; keep it so it is
    # visible whether thinking was really off.
    reasoning = message.get("reasoning_content") or message.get("reasoning") or ""
    finish = choices[0].get("finish_reason")

    parts = [
        f"<!-- model: {args.model}; finish_reason: {finish}; "
        f"elapsed: {elapsed:.1f}s; usage: {json.dumps(reply.get('usage'), ensure_ascii=False)} -->",
        "",
        content,
    ]
    if reasoning:
        parts += ["", "---", "", "## 附：模型返回的 reasoning", "", reasoning]
    out.write_text("\n".join(parts) + "\n", encoding="utf-8")
    out.with_suffix(".json").write_text(
        json.dumps(reply, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    status = f"wrote {out} ({len(content)} chars, {elapsed:.1f}s)"
    if reasoning:
        status += f"; carried {len(reasoning)} chars of reasoning"
    if finish == "length":
        status += "; WARNING: cut by max_tokens"
    return status


def main():
    args = parse_args()
    body = build_body(args)
    if args.dry_run:
        print(json.dumps(body, ensure_ascii=False, indent=2))
        return

    paths = output_paths(args)

    def attempt(out):
        try:
            return True, run_once(args, body, out)
        except Exception as error:  # one failed run must not stop the others
            return False, f"{out.name} failed: {error}"

    failures = 0
    with ThreadPoolExecutor(max_workers=min(args.parallel, len(paths))) as pool:
        for ok, status in pool.map(attempt, paths):
            print(status, file=sys.stdout if ok else sys.stderr, flush=True)
            failures += not ok
    if len(paths) > 1:
        print(f"{len(paths) - failures}/{len(paths)} runs succeeded")
    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
