<!-- model: deepseek-v4.1-flash; finish_reason: stop; elapsed: 13.8s; usage: {"prompt_tokens": 7444, "completion_tokens": 1694, "total_tokens": 9138, "prompt_tokens_details": {"cached_tokens": 0, "cache_write_tokens": null}, "completion_tokens_details": {"reasoning_tokens": 0}} -->

## 1. Who walked away from the vine?

```js
const leaving = new Leave(question); leaving.source = w.vine; input.push(leaving);
const desc = new Among(question); desc.situation = world; desc.node = leaving;
Assert(input, desc, question);
const by = new Agent(question); by.action = leaving; by.actor = answer;
Assert(input, by, question);
const happened = new Occurs(question); happened.event = leaving;
Assert(input, happened, question);
```

**预测结果**：`Entity(the Fox)`

**理由**：故事中 `leave` 是 `Leave{source: vine}`，其 `Agent.actor` 是 fox；问题用 `Among` 把 `Leave{source: w.vine}` 绑定到该描述（注意 `Leave.source` 不是反向字段，问题写 `source` 要求故事也有 `source`，故事确实有）。`Agent` 上的 `answer` Variable 唯一绑定到 fox。`Occurs` 由次序关系 `Next` 蕴含，被支持。只有这一个解，故输出该个体。

**拿不准**：`w.vine` 是世界中的唯一实体，按 §3 可以直接引用常量；但 `Leave.source` 在故事中恰好写的就是 vine，若故事未写 `source` 就会不匹配。检查过故事，`leave.source = vine`，所以可行。

---

## 2. Did the Fox get the grapes on his second jump?

```js
// The second jump: an ordinal over a type of jump toward the grapes.
const js = new Situation(question); input.push(js);
const j = new Jump(js); j.toward = w.grapes; input.push(j);
const jumps = new Such(question); jumps.scope = js; jumps.node = j; input.push(jumps);
const second = new Nth(question); second.of = jumps; second.index = 2; input.push(second);
const when = new MomentOf(question); when.event = second; input.push(when);

// Some acquisition of the grapes at that moment.
const gs = new Situation(question); input.push(gs);
const got = new Acquire(gs); got.theme = w.grapes; input.push(got);
const occurred = new Occurs(gs); occurred.event = got; Assert(input, occurred, gs);
const some = new Some(question); some.scope = gs; input.push(some);
const at = new At(question); at.proposition = some; at.time = when; input.push(at);

const ask = new AskWhether(question); ask.content = at; ask.verdict = answer;
Assert(input, ask, question);
```

**预测结果**：`{result=no}`

**理由**：故事持有 `Not{At{Some{Acquire{theme: grapes} ∧ Agent(fox) ∧ Occurs}}, Between{全程}}`，即“狐狸从未得到葡萄”对全程的否定存在。问题要判断的 `Some{Acquire{theme: grapes} ∧ Occurs}` 与故事中 `ns` 里的 `Some` 至少一样具体（故事还额外加了 `Agent{fox}`），且 `MomentOf{第二次跳}` 落在 `Between{全程}` 内，因此被反驳。没有任何 `Occurs{Acquire}` 被支持，故只被反驳 → `no`。

**拿不准**：

- 问题要不要在 `Some` 里加 `Agent{action: got, actor: w.fox}`？摘要 §8 说否定存在要求问题中的 `Some{S_q}` 至少与故事 `S` 一样具体。故事 `ns` 里的 `Some` 含 `Agent{fox}`，所以问题里若只写 `Occurs`、不加 `Agent`，就比故事更笼统，可能不被否定覆盖 → 会得到未确立。为稳妥应该加上 `Agent{fox}`。我下面给出加上 Agent 的版本，并把它作为最终预测。
- “第二次跳”的界定：故事里 `jump1, jump2, jump3` 是按 `Next` 排列的，`Nth{of: Such{Jump{toward: grapes}}, index: 2}` 应绑定到 `jump2`。若求解器把 `jump1` 也算进去，就是 `jump2`；这是预期的。

补充后的最终编码：

```js
const js = new Situation(question); input.push(js);
const j = new Jump(js); j.toward = w.grapes; input.push(j);
const jumps = new Such(question); jumps.scope = js; jumps.node = j; input.push(jumps);
const second = new Nth(question); second.of = jumps; second.index = 2; input.push(second);
const when = new MomentOf(question); when.event = second; input.push(when);

const gs = new Situation(question); input.push(gs);
const got = new Acquire(gs); got.theme = w.grapes; input.push(got);
const by = new Agent(gs); by.action = got; by.actor = w.fox; Assert(input, by, gs);
const occurred = new Occurs(gs); occurred.event = got; Assert(input, occurred, gs);
const some = new Some(question); some.scope = gs; input.push(some);
const at = new At(question); at.proposition = some; at.time = when; input.push(at);

const ask = new AskWhether(question); ask.content = at; ask.verdict = answer;
Assert(input, ask, question);
```

**预测结果**：`{result=no}`

---

## 3. Did the Fox believe the grapes were sour?

```js
// The Fox's belief context: a Variable bound by matching Believes.
const ctx = new Variable(question); input.push(ctx); unknowns.push(ctx);
const belief = new Believes(question); belief.believer = w.fox;
belief.content = ctx;
Assert(input, belief, question);

// What is judged inside that context.
const sour = new Sour(question); sour.thing = w.grapes; input.push(sour);
const ask = new AskWhether(question); ask.context = ctx; ask.content = sour;
ask.verdict = answer;
Assert(input, ask, question);
```

**预测结果**：`{constraints=[Believes],level=instance,result=not-established}`

**理由**：故事只有一个言语语境 `claim`（`Says.content = claim`），它并非信念——`Says` 的内容由言语语境持有，言语不等于信念（§10）。故事没有任何 `Believes{believer: fox, content: …}` 被持有，因此 `Believes` 约束无支持，结果未确立，而不是 `no`。

**拿不准**：

- 题目问“Did the Fox believe…”，可能有人会把 `claim`（言语语境）直接当作语境去判断——但摘要 §10 明确“言语、信念、计划是不同的语境，互不推出”，故不能直接引用 `claim` 当信念。我按“某人是否相信 P”那行写法，用 Variable 匹配 `Believes`。
- 是否要在问题里也判断世界对 `Sour{grapes}` 的持有？不需要：问题只问信念语境中是否认为 P；`Sour` 只被 `AskWhether` 引用，不被问题持有（否则它会被当成问题的约束）。按示例的写法，`Sour` 节点推入但不 `Assert`。
- 最终预测取决于故事是否持有该信念。按给定故事编码，没有 `Believes`，故未确立。
- 若 `Believes` 约束在求解时先于 `AskWhether.context` 绑定，仍会因无匹配语境而无支持；这是预期。
