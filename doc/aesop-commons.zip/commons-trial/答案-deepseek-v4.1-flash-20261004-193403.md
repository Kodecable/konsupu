<!-- model: deepseek-v4.1-flash; finish_reason: stop; elapsed: 13.4s; usage: {"prompt_tokens": 8392, "completion_tokens": 3215, "total_tokens": 11607, "prompt_tokens_details": {"cached_tokens": 0, "cache_write_tokens": null}, "completion_tokens_details": {"reasoning_tokens": 0}} -->

# 任务一：编码故事

## `BuildWorld`

```js
export function BuildWorld(input, world) {
  // 个体
  const fox = new Entity(world); fox.name = "the Fox"; input.push(fox);
  const grapes = new Entity(world); grapes.name = "the Grapes"; input.push(grapes);
  const vine = new Entity(world); vine.name = "the vine"; input.push(vine);
  const branch = new Entity(world); branch.name = "the branch"; input.push(branch);

  // 状态：thirsty（开头就成立）
  const thirsty = new Thirsty(world); thirsty.subject = fox; input.push(thirsty);
  const initially = new Initially(world); initially.state = thirsty;
  Assert(input, initially);

  // 事件
  const stroll = new Move(world); stroll.path = vine; stroll.manner = null;
  const jump1 = new Jump(world); jump1.toward = grapes;
  const jump2 = new Jump(world); jump2.toward = grapes;
  const jump3 = new Jump(world); jump3.toward = grapes;
  const giveUp = new Action(world);
  const walkAway = new Move(world); walkAway.path = vine; walkAway.manner = null;
  input.push(stroll, jump1, jump2, jump3, giveUp, walkAway);

  // 施事
  for (const a of [stroll, jump1, jump2, jump3, giveUp, walkAway]) {
    const ag = new Agent(world); ag.action = a; ag.actor = fox;
    Assert(input, ag);
  }

  // 言语：内容语境
  const saidSour = new Situation(); saidSour.title = "the grapes are sour";
  input.push(saidSour);
  const sour = new Sour(saidSour); sour.thing = grapes;
  Assert(input, sour, saidSour);

  const say = new Says(world); say.content = saidSour;
  say.text = "I am sure they are sour.";
  input.push(say);
  const sayAg = new Agent(world); sayAg.action = say; sayAg.actor = fox;
  Assert(input, sayAg);

  // 叙事顺序：stroll -> jump1 -> jump2 -> jump3 -> giveUp -> walkAway -> say
  const chain = [stroll, jump1, jump2, jump3, giveUp, walkAway, say];
  for (let i = 1; i < chain.length; i++) {
    const nx = new Next(world); nx.earlier = chain[i - 1]; nx.later = chain[i];
    Assert(input, nx);
  }

  // 三次跳都失败
  for (const j of [jump1, jump2, jump3]) {
    const fail = new Failed(world); fail.action = j; Assert(input, fail);
  }

  // "he never got the grapes"：否定存在，范围条件逐词对照原文
  const ns = new Situation(world); input.push(ns);
  const get = new Acquire(ns); get.theme = grapes; input.push(get);
  const getBy = new Agent(ns); getBy.action = get; getBy.actor = fox;
  Assert(input, getBy, ns);
  const getDone = new Occurs(ns); getDone.event = get; Assert(input, getDone, ns);
  const some = new Some(world); some.scope = ns; input.push(some);
  const ever = new Between(world); input.push(ever);
  const at = new At(world); at.proposition = some; at.time = ever; input.push(at);
  const never = new Not(world); never.proposition = at; Assert(input, never);

  return { fox, grapes, vine, branch };
}
```

## 说明

**原文没有编码的内容及原因**：

- "one hot summer's day"、"orchard"、"lofty branch" 等背景描写：不是个体、事件或状态，没有对应词汇，不编码。
- "hanging from a vine"：葡萄挂在藤上，是静态背景。词汇里没有合适的"悬挂"状态类（`LocatedAt{entity, place}` 语义上偏位置，且需要 place 常量），编码它会让问题变得复杂且与三道题无关，故省略。
- "with no greater success"、"missed again"：这三次跳跃的结果都是没够到，用 `Failed{jump}` 表示。`Failed` 只说"这次没成"，三次各写一个。
- "he gave up"：词汇里没有"放弃"类，选最接近的上位类 `Action`。它是事件，不是状态或态度，故用 `Action` 表示一个发生过的行为。
- "with his nose in the air"：方式描写，词汇里没有 `Manner` 常量对应，不编码。
- "I am sure they are sour"：句子内容是"葡萄酸"，编码在言语语境 `saidSour` 中，`Sour{thing: grapes}`。注意这只是说出的内容，不代表狐狸相信——这正是第三题要问的。

**用到的类**：`Move`（strolling、walking away）、`Jump`（三次跳）、`Action`（gave up）、`Says`（说"它们酸"）、`Sour`（酸，状态）、`Thirsty`（口渴）、`Failed`（三次跳没成）、`Acquire`（取得葡萄，用于否定存在）、`Not`/`At`/`Some`/`Between`（"从未取得"）。

**次序**：用 `Next` 把七个事件串起来。注意 `Next` 已蕴含两端发生，所以不再单独写 `Occurs`。唯一需要单独 `Occurs` 的是否定存在范围内的 `Acquire`。

---

# 任务二：编码问题

## 题目 1：Who walked away from the vine?

### 模板中间部分

```js
  // 描述：故事里那个"从藤边走开"的事件
  const walking = new Move(question);
  walking.path = w.vine;
  input.push(walking);
  const desc = new Among(question);
  desc.situation = world; desc.node = walking;
  Assert(input, desc, question);

  // 施事是答案
  const by = new Agent(question);
  by.action = walking; by.actor = answer;
  Assert(input, by, question);

  // 原文预设该事件已发生
  const happened = new Occurs(question);
  happened.event = walking;
  Assert(input, happened, question);
```

### 预测结果

`Entity(the Fox)`

### 理由

故事中 `walkAway` 是一个 `Move`，其 `path` 为 `vine`，且持有 `Agent{action: walkAway, actor: fox}` 和 `Next{..., later: walkAway}`（故已发生）。问题的描述 `Move{path: vine}` 匹配到 `walkAway`，`Agent.actor` 被绑定到 `fox`，`Occurs` 被 `Next` 蕴含所支持。答案是唯一的 `fox`。

### 拿不准之处

- 问题问"walked away from the vine"，我在 `path` 字段上放了 `vine`。但 `Move.path` 语义是"经过的路径"，而"从藤边走开"更接近 source 或 destination。考虑到 `Leave` 有 `source` 字段，但词汇里 `Leave{source?}` 是 `Move` 的子类，而故事中"walked away"我编成了 `Move`，两者要能匹配。我选择在问题和故事里都用 `Move.path = vine`，保证匹配。如果求解器把 `path` 仅理解为经过路径，可能语义偏差，但这是词汇允许的最接近写法。
- `Occurs{walking}` 是原文预设"他走开了"已发生，加它是为了支持约束。故事里 `walkAway` 通过 `Next` 已发生，所以支持。

---

## 题目 2：Did the Fox get the grapes on his second jump?

### 模板中间部分

```js
  // 第 2 次跳：对一类跳的序数
  const js = new Situation(question); input.push(js);
  const j = new Jump(js); j.toward = w.grapes; input.push(j);
  const by = new Agent(js); by.action = j; by.actor = w.fox;
  Assert(input, by, js);
  const jumps = new Such(question); jumps.scope = js; jumps.node = j;
  input.push(jumps);
  const second = new Nth(question); second.of = jumps; second.index = 2;
  input.push(second);
  const when = new MomentOf(question); when.event = second; input.push(when);

  // 在那一刻有没有"狐狸取得葡萄"这回事
  const gs = new Situation(question); input.push(gs);
  const get = new Acquire(gs); get.theme = w.grapes; input.push(get);
  const getBy = new Agent(gs); getBy.action = get; getBy.actor = w.fox;
  Assert(input, getBy, gs);
  const getDone = new Occurs(gs); getDone.event = get; Assert(input, getDone, gs);
  const some = new Some(question); some.scope = gs; input.push(some);
  const at = new At(question); at.proposition = some; at.time = when;
  input.push(at);

  const ask = new AskWhether(question);
  ask.content = at; ask.verdict = answer;
  Assert(input, ask, question);
```

### 预测结果

`{result=no}`

### 理由

故事持有 `Not{At{Some{Acquire{theme: grapes}, Agent=fox, Occurs}}, Between{}}}`，即"狐狸从未在全程内取得葡萄"。问题问的是"第二次跳的那一刻，有没有狐狸取得葡萄"。否定存在的范围 `Acquire{theme: grapes} + Agent(fox) + Occurs` 与问题的 `Some{Acquire{theme: grapes}, Agent=fox, Occurs}` 至少一样具体（问题约束是故事约束的实例），且第二次跳的时刻落在 `Between{}` 全程内，故被反驳，结果为 `no`。

### 拿不准之处

- 序数 `Nth{of: Such{Jump{toward: grapes}, Agent=fox, Occurs}, index: 2}`：故事中三次跳都是 `Jump{toward: grapes}` 且 `Agent=fox`，`Next` 保证它们已发生。`Such` 的条件是否要写 `Occurs`？摘要 §6 说"范围的条件就是原文对这类东西说的全部内容……是否发生（`Occurs`）"。问题问"第二次跳"，预设跳已发生，所以应写 `Occurs`。但 `Such` 的节点是开放项，`Occurs` 在范围中如何被判断需要故事支持。故事里三次跳都通过 `Next` 发生，应该支持。为稳妥，我写了 `Agent` 而没有额外写 `Occurs` 在 `js` 中——因为 `Nth` 的 `of` 是"满足 of 的已发生事件"，`Nth` 本身要求事件已发生，可能隐含 `Occurs`。但摘要 §6 明确要求逐词对照原文，"第二次跳"原文没有明说"已发生"之外的语义，跳本身是发生。我最终没在 `js` 里加 `Occurs`，依赖 `Nth` 的语义。这是一个有风险的选择。
- 时刻 `MomentOf{second}`：摘要 §7.2 说 `MomentOf.event` 是"事件那一点"，`second` 是 `Nth`，是时间项，可以接受。`At.time` 是 `MomentOf`，合法。
- 否定存在的时间窗口 `Between{}` 是全程。问题的时间 `MomentOf{second}` 是一个点，落在全程内，所以被反驳。如果求解器对"点落在窗口内"的判断有别的约定，结果可能不同，但按 §8 表格应该成立。

---

## 题目 3：Did the Fox believe the grapes were sour?

### 模板中间部分

```js
  // 狐狸的信念语境：用 Variable 绑定故事中的 Believes
  const ctx = new Variable(question);
  input.push(ctx);
  unknowns.push(ctx);

  const belief = new Believes(question);
  belief.believer = w.fox;
  belief.content = ctx;
  Assert(input, belief, question);

  // 在该语境中判断：葡萄是酸的
  const sour = new Sour(question);
  sour.thing = w.grapes;
  input.push(sour);

  const ask = new AskWhether(question);
  ask.context = ctx;
  ask.content = sour;
  ask.verdict = answer;
  Assert(input, ask, question);
```

### 预测结果

`{constraints=[Believes],level=instance,result=not-established}`

### 理由

故事里狐狸**只是说出**"它们是酸的"（`Says{content: saidSour}`），并没有持有 `Believes{believer: fox, content: ...}`。按摘要 §11 第 7 条，说出某事不等于相信它。问题要求 `Believes{believer: fox, content: ctx}`，故事中没有匹配的 `Believes`，该约束无支持，结果为未确立。

（注意：`saidSour` 语境持有 `Sour{thing: grapes}`，但那是言语语境，不是信念语境。问题的 `ctx` 是通过 `Believes.content` 绑定的，不会匹配到言语语境。）

### 拿不准之处

- 我确信故事没有编码狐狸的信念，因为原文只说他说"我确信它们是酸的"——"I am sure"是他说的话的一部分，不是叙述者断言他相信。这是本题的关键陷阱，我选择忠于原文，不把说的话升格为信念。
- 如果求解器把 `Believes.content` 的 Variable 也尝试匹配 `Says.content` 的语境，那会错误。按摘要 §10，言语、信念、计划是不同的语境，互不推出，所以不会。
- 未确立的具体 level：`Believes` 约束无支持，属于 `instance`（某条约束无支持）。我预测 `constraints=[Believes]`。如果求解器还报告其他约束，可能略有不同，但核心是未确立。
