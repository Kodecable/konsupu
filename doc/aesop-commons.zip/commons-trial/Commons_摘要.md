# Konsupu Foundation + Commons 摘要（供 Input 编码者阅读）

你的任务是把自然语言的故事与问题写成 Konsupu 的 Input：一段 JavaScript，
按顺序构造认知节点并推入数组 `input`。符号求解器读取 Input，按下面的
规则求出答案。你不需要实现求解器，但需要知道它怎样理解你写的东西，
否则写出来的 Input 可能合法却答错。

你要编码的是**整个 Input**：故事（世界）与问题。故事按 §11 编码，问题按
§12 编码。Input 有结构错误时，运行时会把 lint 给出的错误原因交回给你重写
（§15）；但结构合法、语义选错的写法不会被发现，只会得到错误的答案。

本摘要只包含编码所需的内容。完整定义见 Commons 规范草案；两者冲突时以
规范为准。

---

## 1. Foundation：节点与 Input

- `new Situation(parent = null)`：情境。parent 为 null 时是根；Situation
  组成森林。
- `new X(situation)`：在某个 Situation 中**引入**一个节点（X 是任何认知类）。
  字段直接赋值：`const e = new Leave(world); e.source = vine;`。
- **Input 是有序数组。** 每个节点（包括 Situation）都要 `input.push` 恰好
  一次，并且排在它引用的所有节点之后。Input 顺序只表示依赖，从不表示时间。
- `new Variable(question)`：未知量；`new Query(question, [v, …])`：声明问题的
  未知量。
- 引用别的 Situation 中的常量（个体、事件、Situation）直接引用即可；引用
  别的 Situation 中的 Variable 要用 `ref(situation, variable)`。在本次
  试验中，只有对话部分用到 `ref`，模板已经写好。
- 辅助函数：
  - `Assert(input, p, holder = p.situated)`：推入命题 p，再推入一个
    `Assertion`，表示 holder **持有** p；
  - `Hold(input, p, holder)`：p 已在 Input 中，只推入 `Assertion`。

## 2. 持有：只有被持有的命题才算数

- 一个 Situation 持有的命题，就是它的 `Assertion` 点名的命题。命题由哪个
  Situation 引入，与谁持有它无关。
- 没被持有的命题什么也不断言，只能作为别的认知的字段值（例如被说出的内容、
  某个 `At` 的内部命题）。
- 持有的含义随 Situation 的种类而定：

| 种类 | 怎样得到 | 它持有的是 |
|---|---|---|
| 对话 | Input 的第一个 Situation | 对话结构（模板已写好） |
| 世界 | 根，被 `Asks.world` 提及 | 故事事实 |
| 语境 | 根，作为被持有的 `Believes`/`Fears`/`Plans` 的 content，或已发生的 `Says`/`CryOut`/`Propose` 的 content | 信念、言语内容、计划等 |
| 问题 | 世界的子，被 `Asks.question` 提及 | **约束**，不是事实 |
| 范围 | 使用者的直接子，恰好被一个 `Some`/`Such`/`Conditional` 的 scope 点名 | **条件** |

- 一个 Situation 只能属于一种。
- **问题不能新建语境。** 语境只由世界或其他语境持有的态度、发生的言语
  确立，问题自己持有的约束不确立语境。问题需要谈论某个语境时，用
  Variable 去绑定故事中已有的语境（§10）。在问题里 `new Situation()` 只有
  一种合法用途：作为范围（§6）。
- 世界的事实对问题可见，问题自己持有的只是约束。
- 语境之间互不可见：信念语境看不到言语语境，世界也看不到语境的内容。

## 3. 问题中的节点：每个节点的角色都要写明

在**问题** Situation 中 `new` 出来的 Entity 或 Event（含 Action 及其子类），
必须是**描述**：由问题持有的 `Among{situation, node}` 点名，意思是"故事里
那个……"。否则就是输入错误。

- `Among{situation: world, node: x}`：x 绑定到世界中被谈及的、满足 x 的类与
  所写字段的对象。几个候选都满足时，每个候选各成一个解。
- 零个候选时，预设落空，结果是"未确立"，**不是"否"**。
- 世界中**唯一**的个体，问题可以直接引用其常量（如 `w.fox`），不必描述。
  **事件**一律用描述，不直接引用故事事件。
- 在范围中 `new` 出来的 Entity/Event 是**开放项**（见 §6），不用 `Among`。
- Variable 只能在问题中 `new`，并且必须列入该问题的 `Query`。

## 4. 匹配：问题可以比故事更笼统

- **Variable 匹配任何值并绑定到它**：字段上放 Variable，就是"这里是什么都
  行，求出来"。同一个 Variable 出现在几条约束中，各处必须绑定到同一个值。
  被绑定的可以是个体、事件、命题，也可以是语境 Situation（见 §10）。
- 描述（`Among` 点名的节点）同样绑定到故事中的一个对象。
- 类含子类：问题写 `Move`，能匹配故事里的 `Leave`、`ComeTo` 等任何移动。
- 只比较写出的字段：问题没写的字段不受约束；问题写了、故事没写的字段
  不匹配。
- 个体与 `Manner` 常量按**身份**比较：问题中新建一个同名的 Entity 或
  `Manner`，与故事里的那个不相等。
- 命题按内容（类与字段）匹配。
- 反向字段：这些字段反过来，要求故事一侧更一般，包括 `Not.proposition`、
  `Unable.deed`、`Forbids.deed`、`Conditional.antecedent`、`Only.of`。
  例如"不能做任何 X"蕴含"不能做这个 X"。

## 5. 判断：开放世界

求解器对每条约束只做两种判断：**被支持**（可见的持有能推出它）与**被
反驳**（被持有的否定认知覆盖它）。

- 是非问 `AskWhether` 的结果：
  - 被支持且未被反驳：`{result=yes}`；
  - 被反驳且未被支持：`{result=no}`；
  - 两者都成立：`{result=conflict}`；
  - 两者都不成立，或描述没有对应者：未确立。
- **"否"只来自被持有的否定**：`Not`、`Ends`、否定存在、`Only` 等（§8）。
  故事没说的就是未确立，求解器不会因为"没找到"而答"否"。
- 值问题（问 X 是什么或是谁）：唯一值时输出该值；多个值时为 `Ambiguous`；
  约束没被支持时为 `NotEstablished{constraints, level}`：
  - level 为 `correspondence`：描述没有对应者；
  - level 为 `instance`：某条约束无支持；
  - level 为 `joint`：每条约束单独都有支持，合起来没有。

## 6. 范围与量化

范围是一个子 Situation，里面 `new` 出来的 Entity/Event 是开放项，持有的
命题是条件。

| 写法 | 含义 |
|---|---|
| `Some{scope}` | **被判断的存在**："有没有满足这些条件的东西"。不成立时可以是"否" |
| `Such{scope, node}` | **一类东西**：满足条件的那种 node。不指称具体对象，供 `Nth`、`Only`、`Unable.deed` 等使用 |
| `Only{of: Such, among: [...]}` | 满足 `of` 的全都在 `among` 中（穷尽） |
| `Distinct{left, right}` | 两个开放项或两个描述取不同对象。不写时，两个开放项可以取同一个对象 |
| `Conditional{scope, antecedent, consequence}` | 若前件则后件。scope 只引入共享的开放项；antecedent 与 consequence 是 scope 的两个子 Situation，分别持有前件与后件 |

- **范围的条件就是原文对这类东西说的全部内容**：类、字段、施事（`Agent`）、
  是否发生（`Occurs`）、时间。逐词对照原文，原文提到的参与者每一个都要写进
  条件，原文没说的不写。问题和故事都按这条规则写，不要靠对照另一侧的写法
  来增减条件。
  - 例："狮子从没吃过老鼠"的范围是 `{e: Eat{theme: mouse}; Agent(e, lion);
    Occurs(e)}`；漏掉 `Agent` 就成了"从没有谁吃过老鼠"。
- 开放项只在自己的范围内有效，不能被范围之外引用。
- 范围的条件可以直接引用外层的常量、描述与 Variable。
- **`Among` 与 `Some` 的选择是最常见的错误来源：**
  - "那只狼跑了吗"：狼是预设存在的，用 `Among` 或直接引用常量；
  - "有没有一只狼在场""老鼠咬断绳子了吗"：存在本身是被问的内容，用
    `Some`。后者问的是"有没有一次老鼠咬断绳子的已发生事件"；
  - 用 `Among` 写被问的存在，lint 不会报错，但故事里没有该对象时，结果是
    "未确立"而不是"否"。
- `Some` 的论域是被谈及的对象，所以"有没有"只有在故事持有否定存在时才能
  答"否"。

## 7. 时间

### 7.1 次序与状态

| 类 | 字段 | 含义 |
|---|---|---|
| `Next` | `earlier`、`later` | 叙事上紧接着的下一件事 |
| `Before` | `earlier`、`later` | 字面的"之前/之后"，可传递 |
| `Overlaps` | `first`、`second` | 两件事同时发生（例如"一边走一边说"） |
| `Initially` | `state` | 状态从故事开头就成立 |
| `ResultsIn` | `event`、`proposition` | 事件发生后，命题从该事件起成立 |
| `Ends` | `event`、`state` | 状态在该事件结束，之后被否定 |

- `Next`、`Before`、`Overlaps` 蕴含两端事件已发生。
- 事件是时间线上的点；状态在区间上成立。已开始的状态一直成立，直到被
  `Ends` 结束，这是唯一的默认推理（惯性）。
- 两个事件的先后只能由次序关系推出；推不出就是无定义，不是"否"。

### 7.2 时间项与 `At`

| 项 | 字段 | 所指 |
|---|---|---|
| `MomentOf` | `event` | 事件那一点（状态取事件发生后的值） |
| `JustBefore` | `event` | 紧接事件之前，**只用于状态** |
| `Between` | `from?`、`until?`（时刻） | [from, until)；都不写即全程 |
| `While` | `state` | 该状态成立的期间 |
| `Nth` | `of`（`Such`）、`index`（从 1 起） | 按先后的第 n 个满足 of 的已发生事件 |
| `Episode` | `ordinal`（`Nth`） | "第 n 次"的期间：从第 n 个到第 n+1 个之前 |
| `TheBeginning` / `TheEnd` | — | 起点 / 终点 |

- `At{proposition, time}`：在某时刻或窗口判断 proposition。时刻项要包一层：
  `const m = new MomentOf(question); m.event = x;`，再 `at.time = m`。
- 不写 `At` 时，求值时间是全程：
  - 状态问题读作"某时是否成立"；
  - 发生问题读作"全程中有没有发生"。
- 窗口中：
  - 状态在某一时刻成立即被支持，每一时刻都被否定才被反驳；
  - 发生要落在窗口内。

## 8. 否定

| 来源 | 写法 | 否定什么 |
|---|---|---|
| 显式否定 | 持有 `Not{P}` | 在 `Not` 成立期间，P 以及比 P 更具体的命题被否定 |
| 结束 | `Ends{event, state}` | state 从 event 起被否定 |
| 否定存在 | 持有 `Not{At{Some{S}, W}}` | 问题中的 `Some{S_q}`：若 S_q 至少与 S 一样具体、且问的时间落在 W 内，则被反驳 |
| 穷尽 | `Only{of, among}` | among 之外满足 of 的存在被反驳 |

- 被谈论但没被 `Occurs` 持有的事件，问它是否发生得到"未确立"。
- `Failed`（尝试未达目的）、"没发生"、`Unable`（不能）三者互不蕴含。
- 语境中的否定只在该语境成立，不回答世界的问题。

## 9. 事件关系

| 类 | 字段 | 含义 |
|---|---|---|
| `Occurs` | `event` | 事件发生了。只有被持有的 `Occurs`（或次序关系）表示发生 |
| `Agent` | `action`、`actor` | 施事。施事从不是事件自己的字段 |
| `Causes` | `cause`、`effect` | 因果，"why" 问原因 |
| `InOrderTo` | `action`、`goal` | 目的，"why" 问目的 |
| `Motivates` | `driver`、`action` | 动机 |
| `Means` | `event`、`means` | 方式，"how" |
| `Enables` | `enabler`、`enabled` | 使之成为可能 |
| `Goal` | `actor`、`objective` | 想要某个（未发生的）事件 |
| `Failed` | `action` | 尝试未达目的 |
| `ByChance` | `event` | 偶然 |

`Agent`、`Causes`、`InOrderTo`、`Goal` 等**不**蕴含事件发生。需要事件已经
发生时，另加 `Occurs`。

## 10. 语境

| 类 | 字段 | 含义 |
|---|---|---|
| `Believes` / `Fears` / `Plans` | `believer`/`fearer`/`planner`、`content`（语境 Situation） | 态度，状态命题 |
| `Says`（Action） | `content`（语境）、`text?`、`to?` | 说话。说出的内容由言语语境持有，说出不等于成立，也不等于说话者相信 |
| `CryOut`（Action） | `call`、`content?` | 喊出某句话 |
| `HoldsIn` | `context`、`proposition` | 命题被该语境自己持有。proposition 可以是 Variable，用来取出整个被持有的命题 |

- 是非问在某语境中判断：`AskWhether.context = 语境`。
- 问题中的语境写成 Variable，不写成 Situation：
  - 在 `Believes.content`、`Says.content` 等字段上放一个 Variable，求解器
    就把它绑定到故事中匹配的语境；
  - 再把同一个 Variable 用作 `AskWhether.context` 或 `HoldsIn.context`；
  - 写 `content: someSituation` 只会按身份比较，永远匹配不上故事里的
    语境。
- 故事中没有匹配的语境时，含该 Variable 的约束无支持，结果为未确立。
- 言语、信念、计划是不同的语境，互不推出。

## 11. 故事的编码

故事只依据原文编码，不为某个问题增减内容：原文说了的写出来，原文没说的
不写。逐句处理：

1. **个体**：每个人、动物、物体一个 `Entity`，`name` 用原文的称呼。需要谈论
   "一只 X"时，建一个 `Kind` 并赋给 `kind`。
2. **事件**：每个动作或发生一个事件节点，选词汇中最具体的类（§14），原文
   给出的对象、去向、方式写进字段，方式用 `Manner` 常量。
   - 有行为者的，持有 `Agent{action, actor}`；
   - 无行为者的发生（掉落、醒来）用 Event 类，不写 `Agent`。
3. **次序与发生**：
   - 按叙事顺序，用 `Next` 把紧接着的事件串起来；
   - 同时发生的事件用 `Overlaps`（例如"一边走一边说"）；
   - `Next`、`Overlaps` 已表示两端发生；不在任何次序关系中的已发生事件，
     单独持有 `Occurs`。
   - 没发生的事件（目标、计划、承诺中的）不写 `Occurs`。
4. **状态**：
   - 开头就成立的：`Initially{state}`；
   - 某事件带来的：`ResultsIn{event, proposition}`；
   - 某事件结束的：`Ends{event, state}`。
   - 原文没说结束的状态会一直持续。
5. **否定**：只在原文明说"没有、从未、不再"时写，写法见 §8：
   - 某状态不成立：`Not{P}`；
   - "从未做过某类事"：否定存在 `Not{At{Some{…}, Between{}}}`，范围的条件
     按 §6 逐词对照原文；
   - 尝试没成功：`Failed{action}`。`Failed` 只说"这次没成"，不说"从未得到"；
     原文两者都说了，就两者都写。
6. **原因与目的**：原文明说时才写 `Causes`、`InOrderTo`、`Goal`、`Motivates`。
7. **言语与心理**：
   - 说话：先建言语语境（`new Situation()`，`title` 写内容摘要），在其中
     持有说出的内容，再建 `Says{content, text}`，并让它发生（§11 第 3 条）；
   - 信念、恐惧、计划：只在原文明说某人相信、害怕、打算时，才由世界持有
     `Believes`/`Fears`/`Plans`，content 是一个新的语境；
   - 说出某事不等于相信它，引号里的话只进言语语境。
8. 词汇里没有合适的类时，在答案中说明，选最接近的上位类（如 `Action`、
   `Move`、`Acquire`），不要自造类名。

### 故事示例

> A Lion was asleep. A Mouse ran over him and woke him up. The Lion seized
> the Mouse. The Mouse said: "I am frightened." The Lion let him go. The Lion
> never ate the Mouse.

```js
export function BuildWorld(input, world) {
  const lion = new Entity(world); lion.name = "the Lion";
  const mouse = new Entity(world); mouse.name = "the Mouse";
  input.push(lion, mouse);
  const running = new Manner(world); running.name = "running"; input.push(running);

  // A state from the start, ended by an event.
  const asleep = new Asleep(world); asleep.subject = lion; input.push(asleep);
  const initially = new Initially(world); initially.state = asleep;
  Assert(input, initially);

  // Speech content: a context created before the speech that names it.
  const said = new Situation(); said.title = "the Mouse is frightened";
  input.push(said);
  const afraid = new Frightened(said); afraid.subject = mouse;
  Assert(input, afraid, said);

  // Events, most specific class, fields from the text.
  const run = new Move(world); run.path = lion; run.manner = running;
  const wake = new WakeUp(world); wake.theme = lion;         // no agent
  const seize = new Seize(world); seize.theme = mouse;
  const say = new Says(world); say.content = said; say.text = "I am frightened.";
  const spare = new Spare(world); spare.theme = mouse;
  input.push(run, wake, seize, say, spare);
  for (const [action, actor] of [[run, mouse], [seize, lion], [say, mouse], [spare, lion]]) {
    const agent = new Agent(world); agent.action = action; agent.actor = actor;
    Assert(input, agent);
  }
  const woke = new Causes(world); woke.cause = run; woke.effect = wake;
  Assert(input, woke);
  const ended = new Ends(world); ended.event = wake; ended.state = asleep;
  Assert(input, ended);

  // Narrative order; Next also means these events occurred.
  const chain = [run, wake, seize, say, spare];
  for (let i = 1; i < chain.length; i++) {
    const next = new Next(world); next.earlier = chain[i - 1]; next.later = chain[i];
    Assert(input, next);
  }

  // "Never ate the Mouse": every participant the text names is a condition.
  const ns = new Situation(world); input.push(ns);
  const eat = new Eat(ns); eat.theme = mouse; input.push(eat);
  const by = new Agent(ns); by.action = eat; by.actor = lion; Assert(input, by, ns);
  const done = new Occurs(ns); done.event = eat; Assert(input, done, ns);
  const some = new Some(world); some.scope = ns; input.push(some);
  const ever = new Between(world); input.push(ever);
  const at = new At(world); at.proposition = some; at.time = ever; input.push(at);
  const never = new Not(world); never.proposition = at; Assert(input, never);

  return { lion, mouse };
}
```

## 12. 问题的 canonical 写法

每种问法只有一种写法。编码一个问题按以下步骤：

1. 判断原文的问法，在下表中找到对应的一行；一个问题可能组合几行，例如
   "第二次……时有没有……"是"第 n 次"加"某时有没有某种东西"；
2. 按该行的写法与 §13 中最接近的示例写出结构；
3. 问题提到的个体：故事中唯一的，直接引用常量；事件一律写成描述
   （`Among`）或范围中的开放项（`Some`）；语境一律写成 Variable；
4. 检查每个在问题中 `new` 的节点是否有合法角色（§3），每个新建的
   Variable 是否列入 `unknowns`。

写法只依据原文的问法：问句里的主语、宾语、时间都要写进约束或范围的条件
（§6）。不要回头对照你的故事编码来增减条件；问题与故事各自忠于原文，
求解器负责把两者对上。

| 问法 | 写法 |
|---|---|
| X 是什么/谁 | 约束字段上放 Variable；"那个……的 X"用描述（`Among` 加约束） |
| 谁做了 X | `Agent{action: X, actor: answer}`，X 为描述；原文预设 X 已发生时加 `Occurs{X}` |
| X 之后紧接着发生了什么 | `Next{earlier: X, later: answer}` |
| X 之前/之后（字面） | `Before` |
| 为什么（原因/目的/动机） | `Causes{cause: answer, effect: X}` / `InOrderTo{action: X, goal: answer}` / `Motivates{driver: answer, action: X}` |
| 怎样做到的 | `Means{event: X, means: answer}` |
| 某人做没做某类事 | `AskWhether{content: Some{e: 类与字段; Agent(e, 某人); Occurs(e)}}` |
| 某个已知事件发生了没有 | `AskWhether{content: Occurs{X}}` |
| 某状态在某时是否成立 | `AskWhether{content: At{P, 时刻}}`；不带时间即"某时" |
| 某时有没有某种东西 | `AskWhether{content: At{Some{…}, 时间}}` |
| 能不能 | `AskWhether{content: Not{Unable{actor, deed: Such{…}}}}` |
| 某语境中是否认为 P | `AskWhether{context: 语境, content: P}`；语境是故事中已有的、可直接引用的 Situation 时才这样写 |
| 某人是否相信 / 害怕 / 计划 P | 问题持有 `Believes{believer: 某人, content: ctx}`（ctx 为 Variable），再写 `AskWhether{context: ctx, content: P}` |
| 某人说的是不是真话 | `HoldsIn` 取出言语内容，再以世界为语境、以言语时刻为时间判断 |
| 第 n 次 | `Nth{of: Such{…}, index}`；"那一次"的期间用 `Episode` |
| 期间内某事有没有发生 | `At{Some{…; Occurs(e)}, Between{…}}` |

`AskWhether` 的字段：`content`（被判断的命题）、`verdict`（问题的
Variable，答案写入这里）、`context?`。`AskWhether` 本身要被问题持有。

## 13. 示例

示例来自其他故事，`w.xxx` 指该故事编码返回的常量。

**"Was there a wolf when the boy cried 'Wolf' the second time?"**（问题部分）

```js
// The second cry: an ordinal over a type of cry.
const cs = new Situation(question); input.push(cs);
const c = new CryOut(cs); c.call = "Wolf, Wolf"; input.push(c);
const cries = new Such(question); cries.scope = cs; cries.node = c; input.push(cries);
const second = new Nth(question); second.of = cries; second.index = 2; input.push(second);
const when = new MomentOf(question); when.event = second; input.push(when);
// Judged existence: some wolf present at that moment.
const ws = new Situation(question); input.push(ws);
const x = new Entity(ws); x.kind = w.wolfKind; input.push(x);
const present = new Present(ws); present.subject = x; Assert(input, present, ws);
const some = new Some(question); some.scope = ws; input.push(some);
const at = new At(question); at.proposition = some; at.time = when; input.push(at);
const ask = new AskWhether(question); ask.content = at; ask.verdict = answer;
Assert(input, ask, question);
```

如果故事持有 `Not{At{Some{有一只狼在场}, Between{until: MomentOf{狼真的来了}}}}`，
而第二次喊叫在狼来之前，结果为 `{result=no}`。

**"Who opened the door?"**（问题部分）

```js
const opening = new Open(question); opening.theme = w.door; input.push(opening);
const desc = new Among(question); desc.situation = world; desc.node = opening;
Assert(input, desc, question);
const by = new Agent(question); by.action = opening; by.actor = answer;
Assert(input, by, question);
const happened = new Occurs(question); happened.event = opening;
Assert(input, happened, question);
```

**"Did the villagers believe that the boy was deceiving them?"**（问题部分）

```js
// The villagers' belief context: a Variable bound by matching Believes.
const ctx = new Variable(question); input.push(ctx); unknowns.push(ctx);
const belief = new Believes(question); belief.believer = w.villagers;
belief.content = ctx;
Assert(input, belief, question);
// What is judged inside that context.
const deceiving = new Deceives(question); deceiving.deceiver = w.boy;
deceiving.victim = w.villagers; input.push(deceiving);
const ask = new AskWhether(question); ask.context = ctx; ask.content = deceiving;
ask.verdict = answer;
Assert(input, ask, question);
```

- 故事持有村民的信念、且该信念语境持有 `Deceives{boy, villagers}` 时，结果
  为 `{result=yes}`。
- 故事没有村民的信念时，`Believes` 约束无支持，结果为
  `{constraints=[Believes],level=instance,result=not-established}`。
- 被判断的 `Deceives` 只被 `AskWhether` 引用，不被问题持有：它是要判断的
  内容，不是约束。

## 14. 词汇（节选）

骨架：

- `Entity{name, kind?}`：个体；`Kind{name}`：种；`Manner{name}`：方式常量。
- `Event`、`Action`：发生与行为，可直接实例化。
- `Condition`：状态的抽象基类。

**移动**（都是 `Move{source?, destination?, path?, manner?}` 的子类）：
- `ComeTo{destination}`、`HeadTo{destination}`、`ComeOut{source}`；
- `Leave{source?}`、`ComeBack{destination?}`、`Enter{destination}`；
- `Cross{path}`、`Follow{after}`、`Carry{theme, destination?}`。

**无施事的事件**：`Fall{theme, destination?}`、`Rise{theme}`、`WakeUp{theme}`、
`GetTrapped{theme, location?}`。

**取得**（`Acquire{theme, manner?}` 的子类，`Acquire` 本身也可用）：
`Take{theme, source?}`、`Steal`、`Buy{theme, from?}`。不属于取得的：
- `Reach{theme}`（够到）；
- `Find{theme}`（找到不等于取得）；
- `Seize{theme}`（抓住）；
- `SearchFor{theme}`。

**接触与操作**：`Touch`、`SnapAt`、`Pounce`、`Hurt`、`Gnaw`、`Open`、`Shut`、
`Eat`、`Drink`、`Help`、`Save`、`Spare`、`Hide`，字段都是 `{theme}`；另有
`Put{theme, destination}`、`Drop{theme, destination?}`、`Throw{theme, to?}`。

**尝试**：`Attempt{deed}`。做成了用 `Occurs{deed}`，没做成用 `Failed{action}`。

**感知与心智**：`See{theme}`、`LookAt{theme, manner?}`、`Notice{theme}`、
`Hear{theme}`、`ThinkOf{theme}`、`Wait{theme?}`。

**态度与评价**：`Deceives{deceiver, victim}`（成功欺骗，状态）、
`Trusts{truster, trusted}`、`Approves{approver, of}`。

**言语**：`Says`、`CryOut`、`Cry{theme?}`、`CallForHelp{to?}`、`Sing{manner?}`、
`Flatter{theme}`、`Advise{to, advised}`。

**状态**（`Condition` 子类）：
- 位置与归属：`LocatedAt{entity, place}`、`Inside{entity, container}`、
  `Present{subject}`、`Owns{owner, thing}`、`Carrying{carrier, theme}`；
- 缺失与能力：`Missing{thing}`、`Empty{container}`、`Unable{actor, deed}`；
- 一元状态（字段都是 `{subject}`）：`Thirsty`、`Asleep`、`Frightened`、
  `Lonely`。

## 15. 输入错误

Input 写错时，求解器不作答，而是把错误原因交回给你修正，你重写整个
Input 再提交。按原因中 Fix 的指示改，不要换一种未经说明的写法绕开它。原因的形式是
`<问题>. Fix: <改法>.`，例如：

- `CryOut in the question is not described by any held Among. Fix: if the
  question refers to one the story already has, hold Among{situation: world,
  node}; if it asks whether there is or was such a thing, create it in a scope
  Situation and judge it with Some.`
- `At.time is an Event; it accepts a moment (MomentOf, JustBefore,
  TheBeginning, TheEnd) or a window (Between, While, Episode). Fix: wrap the
  event as MomentOf{event}.`
- `Present has no field "place"; its fields are subject. Fix: use a class
  that has the field, for example LocatedAt{entity, place}.`
- `Action has no field "actor"; the doer is never a field of an event. Fix:
  remove the field and hold Agent{action, actor} next to the event.`
- `Move.manner is null. Fix: omit the field when the text does not say it;
  an omitted field already means "not stated".`
- `Node references must point to preceding occurrences: Leave at Input[12]
  field "manner" references Manner at Input[13]. Fix: push the Manner into
  Input before the Leave.`
- `Believes.content in the question is a new Situation; a question cannot
  create a context, and a new Situation never matches the story's contexts.
  Fix: put a Variable in Believes.content, list it in the question's Query,
  and ask with AskWhether{context: that Variable, content: P}; hold the
  Believes, not P.`

**不是**输入错误的情况：故事不支持某约束、序数无定义、时刻无法比较、
描述没有对应者。这些都是正常的"未确立"结果。
