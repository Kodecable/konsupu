# RESULTS — aesop-commons-phase2

逐题记录：冻结的英文题面、机器 expected（实现时固定，与语义 expected
一致）、实际输出（✓ = 逐字节一致）。机器投影为 Result 盒形状（`OK:…` /
`Unknown` / `Ambiguous:…`），与 phase2 投影的映射见 OBSERVATIONS 第 4 节。
Guide twins（每故事 2 道，共 18 道 + 旧三篇无 twin）不在此表，由回归
`twins:` 逐题跑通。

基线：`node run.mjs` → 回归 21/21 + 65/65；`node mutation.mjs` → 12/12。

## 逐题（65/65 通过）

### Story 1 — The Crow and the Pitcher

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Who dropped a pebble into the pitcher? | `OK:Entity(the crow)` | `✓` |
| Q2 | What happened after the crow put its beak into the pitcher? | `OK:TryToDrink(theme=Entity(the water))` | `✓` |
| Q3 | Why did the water mount up? | `OK:Series(parts=[Drop(destination=Entity(the pitcher),theme=Entity(a pebble)),Drop(destination=Entity(the pitcher),theme=Entity(the other pebbles))])` | `✓` |
| Q4 | What was the crow able to do after the water mounted up? | `OK:Quench(theme=Entity(its thirst))` | `✓` |
| Q5 | Where did the pebble end up after the crow dropped it? | `OK:Entity(the pitcher)` | `✓` |

### Story 2 — The Fox and the Crow

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What fell to the ground? | `OK:Entity(the cheese)` | `✓` |
| Q2 | What happened when the crow began to sing? | `OK:Fall(destination=Entity(the ground),theme=Entity(the cheese))` | `✓` |
| Q3 | What did the crow believe about her voice? | `OK:VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))` | `✓` |
| Q4 | What did the fox want to get? | `OK:Entity(the cheese)` | `✓` |
| Q5 | Who made the cheese fall? | `OK:Entity(the crow)` | `✓` |

### Story 3 — The Lion and the Mouse

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Who gnawed away the ropes? | `OK:Entity(the mouse)` | `✓` |
| Q2 | What did the hunters do after the lion got caught in the trap? | `OK:Tie(destination=Entity(the tree),theme=Entity(the lion))` | `✓` |
| Q3 | Why did the lion spare the mouse? | `OK:Tickled(at=Believes(believer=Entity(the lion),content=Context(the Mouse being able to help him)),subject=Entity(the lion))` | `✓` |
| Q4 | What did the mouse promise to do for the lion? | `OK:Help(theme=Entity(the lion))` | `✓` |
| Q5 | Why did the hunters tie the lion to the tree? | `OK:Carry(destination=Entity(the king),theme=Entity(the lion))` | `✓` |

### Story 4 — The Dog and the Shadow

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What did the dog think his shadow was? | `OK:Entity(another dog)` | `✓` |
| Q2 | What did the dog really see in the water? | `OK:Entity(his own shadow reflected in the water)` | `✓` |
| Q3 | Where was the piece of meat before the dog snapped at the shadow? | `OK:Entity(the dog's mouth)` | `✓` |
| Q4 | Where did the piece of meat end up? | `OK:Entity(the water beneath)` | `✓` |
| Q5 | Why did the dog snap at the shadow? | `OK:Get(theme=Entity(another piece of meat))` | `✓` |

### Story 5 — The Fox and the Mask

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What did the fox at first take the mask to be? | `OK:Entity(a face glaring down on him)` | `✓` |
| Q2 | Why was the fox frightened? | `OK:Believes(believer=Entity(the fox),content=Context(a face was glaring down on him))` | `✓` |
| Q3 | After looking more closely, did the fox still think a face was glaring down on him? | `OK:false` | `✓` |
| Q4 | How did the fox get into the store-room? | `Unknown` | `✓` |
| Q5 | What did the fox say the mask did not have? | `OK:Entity(brains)` | `✓` |

### Story 6 — The Miser and His Gold

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Where did the miser use to hide his gold? | `OK:Entity(the foot of a tree in his garden)` | `✓` |
| Q2 | How often did the miser dig up his gold? | `OK:Entity(every week)` | `✓` |
| Q3 | Who took the gold? | `OK:Entity(a robber)` | `✓` |
| Q4 | What did the miser find when he next came to gloat over his treasures? | `OK:Entity(the empty hole)` | `✓` |
| Q5 | According to the miser, did he ever take any of the gold out? | `OK:false` | `✓` |

### Story 7 — The Milkmaid and Her Pail

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What did Patty plan to buy with the money from the milk? | `OK:Buy(from=Entity(Farmer Brown),what=Entity(some fowls))` | `✓` |
| Q2 | Who did Patty imagine would be jealous of her? | `OK:Entity(Polly Shaw)` | `✓` |
| Q3 | Did Patty buy any fowls? | `Unknown` | `✓` |
| Q4 | What did Patty do just before the pail fell off her head? | `OK:Toss(manner=back,theme=Entity(her head))` | `✓` |
| Q5 | Where was the pail before Patty tossed her head back? | `OK:Entity(her head)` | `✓` |

### Story 8 — The Nurse and the Wolf

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Who was the nurse speaking to when she mentioned the wolf? | `OK:Entity(the child)` | `✓` |
| Q2 | What did the wolf hope to eat? | `OK:Entity(the child)` | `✓` |
| Q3 | Did the child make the noise again? | `OK:true` | `✓` |
| Q4 | When the child began to cry, did the nurse throw it to the wolf? | `OK:false` | `✓` |
| Q5 | Why did the wolf crouch down by the house and wait? | `OK:Believes(believer=Entity(the wolf),content=Context(the child will cry and be thrown out))` | `✓` |

### Story 9 — The Wolf in Sheep's Clothing

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Whose skin was the wolf wearing? | `OK:Entity(the sheep that had been flayed)` | `✓` |
| Q2 | How did the wolf deceive the sheep? | `OK:PutOn(over=Entity(its own pelt),theme=Entity(the skin of a sheep))` | `✓` |
| Q3 | For how long did the wolf succeed in deceiving the sheep? | `OK:Entity(some time)` | `✓` |
| Q4 | Did the lamb think the wolf was its mother? | `Unknown` | `✓` |
| Q5 | Before he found the sheep's skin, could the wolf get at the sheep easily? | `OK:false` | `✓` |

### Story 10 — The Shepherd's Boy

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | Why did the boy first cry "Wolf"? | `OK:Get(theme=[Entity(a little company),Entity(some excitement)])` | `✓` |
| Q2 | Was there a wolf when the boy cried "Wolf" the second time? | `OK:false` | `✓` |
| Q3 | Why did nobody come to help the boy the third time? | `OK:Believes(believer=Entity(the villagers),content=Context(the boy was again deceiving them))` | `✓` |
| Q4 | Was the boy telling the truth when he cried "Wolf" the third time? | `OK:true` | `✓` |
| Q5 | Did any villager come to help the boy the third time? | `OK:false` | `✓` |

### Story 11 — The Fox and the Goat

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | How did the fox really get into the well? | `OK:Chance(destination=Entity(a deep well),theme=Entity(the Fox))` | `✓` |
| Q2 | How did the fox say he got into the well? | `OK:JumpDown(destination=Entity(a deep well),theme=Entity(the Fox))` | `✓` |
| Q3 | Why did the goat jump into the well? | `OK:Believes(believer=Entity(the Goat),content=Context(the fox's advice was good))` | `✓` |
| Q4 | Could the fox get out of the well before the goat came down? | `OK:false` | `✓` |
| Q5 | Was what the fox told the goat about why he was in the well true? | `OK:false` | `✓` |

### Story 12 — The Ass's Brains

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What did the lion propose to the ass? | `OK:Entity(an alliance between their two families)` | `✓` |
| Q2 | What did the lion forbid the fox to do? | `OK:Touch(theme=Entity(the prey))` | `✓` |
| Q3 | What did the fox eat while the lion was away? | `OK:Entity(the brains of the Ass)` | `✓` |
| Q4 | What did the lion notice when he came back? | `OK:Missing(thing=Entity(the brains of the Ass))` | `✓` |
| Q5 | Was the fox telling the truth when he said the ass had no brains? | `OK:false` | `✓` |

### Story 13 — The Fox, the Cock, and the Dog

| # | 问题 | 机器 expected | 实际输出 |
|---|---|---|---|
| Q1 | What did the fox say King Lion had declared? | `OK:Entity(a universal truce)` | `✓` |
| Q2 | According to the fox's news, may a beast hurt a bird? | `OK:false` | `✓` |
| Q3 | Could the fox reach the cock? | `OK:false` | `✓` |
| Q4 | What did the fox do as soon as he heard that the dog was coming? | `OK:TurnAway()` | `✓` |
| Q5 | What reason did the fox give for not staying to congratulate the dog? | `OK:Fears(content=Context(the dog may not have heard of King Lion's decree),experiencer=Entity(the Fox))` | `✓` |

## 翻译判断与 expected 变化（相对 phase2）

- **状态前缀**：全部值答案从 `X` 变为 `OK:X`；是非题 `{result=yes/no}`
  → `OK:true/false`；`NotEstablished{…}` → `Unknown`。语义不变。
- **能力与许可按问句极性翻译（4 题）**：
  - S9Q5 / S11Q4 / S13Q3 "could …?"：`In(Not(Unable(actor, deed)), 窗口)`，
    窗口内任一时刻无能力即 `OK:false`。lint 只禁止 `Not` 内部带时间修饰，
    `Not` 被 `In`/`At` 包住是允许的。
  - S13Q2 "may a beast hurt a bird?"：在 news 中问 `Not(Forbids(…))`，
    禁令成立即 `OK:false`。`Forbids` 不推出“不发生”是对的（违禁正是
    故事常写的内容），许可问句问的就是“没有禁令”。
  - 初版把这 4 题按补集翻译（问无能力、问禁令，`OK:true` 读作“否”），
    依据是“Not(Unable) 不得带时间”，那是误读，已更正。
- **序数（B-6）**：S6Q4 "when he next came"、S10Q1/Q2/Q3/Q5 的
  first/second/third 由翻译解析到具体事件；"插入更早事件序数移动"
  的回归无法移植。
- **S1Q1 钉 theme**：故事有三次投石，Commons 多候选即 Ambiguous
  （即使施事一致），描述必须与问句定指程度一致（试验 G5 的既定差异）。
- **S4Q1/S11Q1**：Corresponds 问"其实是什么"，答案取对应组的非问侧。
- **S5Q2**：Frightened 是单例，直引节点（命题位置不能 Virtual）。
- **S5Q3/Q5、S6Q5、S13Q2、S10 twin2**：按语境求值的问题在目标语境下
  开 seat 子 Situation。
- **S7Q4/S4 "as X, Y"**：phase2 的 Overlaps（共一时刻）在锚点序下无
  对应边；改译 `Within(start(Y), duration(X))`（Y 的开始落在 X 的持续
  内），更贴原文。Overlaps 类保留在词表中但语料未再用。
- **S11 掉落**：偶然性做进事件类（`Chance extends Fall`），ForPurpose
  的规则以 `api.Is` 判定，并声明为定义性（`DEFINITIONAL`）：在世界中
  断言“偶然的掉落为了某目的”是输入错误。Commons 修复 B-3 后，对应组
  的描述与 Input 先后无关，掉落回到叙事位置（言语节点在前）。
- **S12Q3 "while"**：`And([Agent, Within(start(吃), 离开窗口)])` join。
- **窗口否定存在（S4/S6/S8/S10）**：时刻形模式
  `At(body, moment)+Within(moment, window)+NoInstance/Only`。它与问句的
  “每一点”和“某一时刻”形状都相容；规范 10.3 的 `Within(start(e), D)`
  形状只排除写明“开始于 D”的问句（OBSERVATIONS B-1 更正、规范 13.1）。
- **S13 "henceforth"**：news 内的规范未写时间区间（AllTime 持有），
  简化记录：无问题依赖该边界。

## 规模

- 领域层 11 文件 750 行（词表/投影/祈使）；cases 5065 行。
- story-1 Q1 全 Input 159 节点（phase2 124，+28%，主要来自 canonical
  发生样板与显式区间）。
