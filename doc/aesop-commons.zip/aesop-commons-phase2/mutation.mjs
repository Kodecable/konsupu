// Targeted mutations: each disables exactly one semantic rule — a domain
// rule, a lint rule, or one engine behavior — and must break at least one
// regression or question. A mutation that nothing catches is a hole in
// the test wall and is reported as such.
import {
  cpSync,
  mkdirSync,
  rmSync,
  writeFileSync,
  readFileSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));

const Mutations = [
  {
    name: "then-derivation-off",
    file: "space/Memory/Aesop/Ties.js",
    find: `  static Derive(api, emit) {
    emit(Before, {
      earlier: api.Field("earlier"),
      later: api.Field("later"),
    });
  }`,
    replace: `  static Derive(api, emit) {}`,
  },
  {
    name: "chance-rule-off",
    file: "space/Memory/Aesop/Ties.js",
    find: `  static Judge(api) {
    return api.Is("action", Chance) ? false : null;
  }`,
    replace: `  static Judge(api) {
    return null;
  }`,
  },
  {
    // B-3 back: a correspondence group is its earliest member in Input and
    // only that. Story 11 narrates the claimed jumping before the chance
    // fall, so the world would see a jumping and lose the chance.
    name: "groups-earliest-member-only",
    file: "space/Memory/Commons/Engine/Groups.js",
    find: `      const facets = own.length > 0 ? own : all;
      const at = (node) => index.Position(node);
      const rep = facets.reduce((a, b) => (at(b) < at(a) ? b : a));
      for (const node of all) this.reps.set(node, rep);
      this.facets.set(rep, facets);`,
    replace: `      void own;
      const at = (node) => index.Position(node);
      const rep = all.reduce((a, b) => (at(b) < at(a) ? b : a));
      for (const node of all) this.reps.set(node, rep);
      this.facets.set(rep, [rep]);`,
  },
  {
    name: "chance-not-definitional",
    file: "space/Memory/Aesop/Ties.js",
    find: `  static DEFINITIONAL = true;`,
    replace: ``,
  },
  {
    name: "only-excludes-off",
    file: "space/Memory/Commons/Vocabulary/Logic.js",
    find: `  static Excludes(api) {
    const among = api.Field("among");
    return api.Embeddings(api.Field("of")).some((head) => {
      return api.Outside(head, among);
    });
  }`,
    replace: `  static Excludes(api) {
    return false;
  }`,
  },
  {
    name: "noinstance-excludes-off",
    file: "space/Memory/Commons/Vocabulary/Logic.js",
    find: `  static Excludes(api) {
    return api.Embeddings(api.Field("of")).length > 0;
  }`,
    replace: `  static Excludes(api) {
    return false;
  }`,
  },
  {
    name: "within-judge-off",
    file: "space/Memory/Commons/Vocabulary/TimeRelations.js",
    find: `  static Judge(api) {
    return api.Member(api.Field("anchor"), api.Field("duration"));
  }`,
    replace: `  static Judge(api) {
    return null;
  }`,
  },
  {
    name: "among-deref-off",
    file: "space/Memory/Commons/Engine/Terms.js",
    find: `    const among = env.raw?.has(term) ? null : ctx.world.index.AmongOf(term);`,
    replace: `    const among = null;`,
  },
  {
    name: "time-fit-off",
    file: "space/Memory/Commons/Engine/Times.js",
    find: `    const fits =
      ctx.mode === "overlap"
        ? Disjoint(ctx, time, factTime) === false
        : Subset(ctx, time, factTime) === true;
    if (fits) yield env;
    return;`,
    replace: `    yield env;
    return;`,
  },
  {
    name: "lint-not-time-off",
    file: "space/Memory/Commons/Lint/Time.js",
    find: `Not does not apply to time`,
    replace: `mutated: this check never fires`,
  },
  {
    name: "occurs-refute-off",
    file: "space/Memory/Commons/Vocabulary/Cognition.js",
    find: `  static Refute(api) {
    const time = api.EventTime(api.Field("event"));
    return time !== null && api.Subset(api.Time(), time) === false;
  }`,
    replace: `  static Refute(api) {
    return false;
  }`,
  },
  {
    name: "project-status-off",
    file: "space/Memory/Aesop/Project.js",
    find: `    if (value.status === "OK") return \`OK:\${Project(value.result)}\`;`,
    replace: `    if (value.status === "OK") return Project(value.result);`,
  },
];

function run(cwd, script) {
  // A mutation makes the suite exit non-zero; the output still counts.
  try {
    return execFileSync("node", [script], {
      cwd,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
      maxBuffer: 64 * 1024 * 1024,
    });
  } catch (caught) {
    return `${caught.stdout ?? ""}\n${caught.stderr ?? ""}`;
  }
}

function summarize(stdout) {
  const regression = /Regression tests: (\d+)\/(\d+) passed/.exec(stdout);
  const questions = /Aesop questions: (\d+)\/(\d+) passed/.exec(stdout);
  // The source-identity tests compare the scratch copy against src/ and
  // fail trivially there; they never count as a catch.
  const failing = [...stdout.matchAll(/^FAIL  (?:REG  )?(.+)$/gm)]
    .map((m) => m[1])
    .filter((name) => !name.startsWith("source: "));
  return {
    regressions: regression
      ? `${regression[1]}/${regression[2]}`
      : "crashed",
    questions: questions ? `${questions[1]}/${questions[2]}` : "crashed",
    failing,
  };
}

const scratch = join(here, ".mutation-scratch");
const carried = [
  "space",
  "cases",
  "regression.mjs",
  "regression-worlds.mjs",
  "run.mjs",
  "package.json",
];

let holes = 0;
for (const mutation of Mutations) {
  rmSync(scratch, { recursive: true, force: true });
  mkdirSync(scratch, { recursive: true });
  for (const item of carried) {
    cpSync(join(here, item), join(scratch, item), {
      recursive: true,
    });
  }
  const path = join(scratch, mutation.file);
  const source = readFileSync(path, "utf8");
  if (!source.includes(mutation.find)) {
    console.log(`ANCHOR MISSING  ${mutation.name}`);
    holes += 1;
    continue;
  }
  writeFileSync(path, source.replace(mutation.find, mutation.replace));
  const regression = summarize(run(scratch, "regression.mjs"));
  const questions = summarize(run(scratch, "run.mjs"));
  const caught = regression.failing.length > 0 || questions.failing.length > 0;
  if (!caught) holes += 1;
  console.log(
    `${caught ? "CAUGHT" : "NOT CAUGHT"}  ${mutation.name}  ` +
      `regressions ${regression.regressions}, questions ${questions.questions}`,
  );
  // run.mjs runs the regressions too; each failing check is listed once.
  for (const name of new Set([
    ...regression.failing.slice(0, 4),
    ...questions.failing.slice(0, 6),
  ])) {
    console.log(`   - ${name}`);
  }
}
rmSync(scratch, { recursive: true, force: true });
console.log(
  holes === 0
    ? "every mutation broke at least one check"
    : `${holes} mutation(s) caught by nothing`,
);
process.exit(holes === 0 ? 0 : 1);
