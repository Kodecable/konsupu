// BuildStory for "The Fox, the Cock, and the Dog". The fox's news is a
// speech context holding King Lion's declaring (as claimed), the
// prohibition and the enjoining it carries — all inside the speech. The
// cock's sightings are speech content the narrator never confirms; the
// fox's excuse nests a fearing around a negated having-heard. The cock
// stays beyond the fox's reach all along. Nothing here says what the dog
// or the fox believed about the truce.
import {
  Agent,
  Assert,
  Congratulate,
  Declare,
  Dwell,
  Duration,
  Fears,
  Forbids,
  GetAt,
  Hear,
  HeardOf,
  Hurt,
  In,
  Mandates,
  Motivates,
  Not,
  Occurred,
  Occurs,
  Prowl,
  See,
  SameReferent,
  Speak,
  TimeAnchor,
  TurnAway,
  Unable,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import {
  Bounds,
  Chain,
  Did,
  Happened,
  Virtualize,
  entity,
} from "../helpers.mjs";

export function BuildStory(input, root) {
  const fox = entity(root, "the Fox");
  const cock = entity(root, "the Cock");
  const dog = entity(root, "my master's Dog");
  const henCoop = entity(root, "a farmer's hen-coop");
  input.push(fox, cock, dog, henCoop);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The fox's news: King Lion's declaring and what it forbids and
  // enjoins — all inside the speech.
  const news = context(
    new Situation(),
    "King Lion has declared a universal truce",
  );
  input.push(news);
  const kingLion = entity(news, "King Lion");
  const truce = entity(news, "a universal truce");
  const bird = entity(news, "a bird");
  const beast = entity(news, "a beast");
  input.push(kingLion, truce, bird, beast);
  const declared = new Declare(news, { declaration: truce });
  const hurtBird = new Hurt(news, { doer: beast, theme: bird });
  const forbidden = new Forbids(news, {
    authority: kingLion,
    deed: hurtBird,
  });
  const dwellTogether = new Dwell(news, {
    manner: "in brotherly friendship",
  });
  const enjoined = new Mandates(news, {
    authority: kingLion,
    deed: dwellTogether,
  });
  input.push(declared, hurtBird, forbidden, dwellTogether, enjoined);
  Virtualize(input, hurtBird);
  Virtualize(input, dwellTogether);
  Happened(input, declared, kingLion);
  Assert(input, forbidden, news);
  Assert(input, enjoined, news);

  // The cock's sighting: some one coming — speech content, unconfirmed.
  const sightCtx = context(new Situation(), "the Cock's sighting");
  input.push(sightCtx);
  const someone = entity(sightCtx, "some one coming");
  input.push(someone);
  Happened(input, new See(sightCtx, { theme: someone }), cock);

  // The identification: the coming one is the dog — the cock's claim.
  const claimCtx = context(new Situation(), "the Cock's identification");
  input.push(claimCtx);
  Assert(
    input,
    new SameReferent(claimCtx, { left: someone, right: dog }),
    claimCtx,
  );

  // The fox's excuse: a fearing of a negated having-heard, and the
  // fearing given as the reason for not congratulating the dog. All of
  // it is what the fox said; the narrator never confirms the fear.
  const fearCtx = context(
    new Situation(),
    "the dog may not have heard of King Lion's decree",
  );
  input.push(fearCtx);
  const hearing = new HeardOf(fearCtx, { hearer: dog, news: truce });
  const heardOf = new Occurs(fearCtx, { event: hearing });
  const notHeard = new Not(fearCtx, { proposition: heardOf });
  input.push(hearing, heardOf, notHeard);
  Assert(input, notHeard, fearCtx);
  const excuseCtx = context(new Situation(), "the fox's excuse");
  input.push(excuseCtx);
  const feared = new Fears(excuseCtx, {
    experiencer: fox,
    content: fearCtx,
  });
  const congratulating = new Congratulate(excuseCtx, { theme: dog });
  const happening = new Occurs(excuseCtx, { event: congratulating });
  const notDoing = new Not(excuseCtx, { proposition: happening });
  input.push(feared, congratulating, happening, notDoing);
  Assert(input, feared, excuseCtx);
  Assert(
    input,
    new Motivates(excuseCtx, { driver: feared, action: notDoing }),
    excuseCtx,
  );

  const prowl = new Prowl(root);
  const seeCock = new See(root, { theme: cock });
  const foxCry = new Speak(root, { call: "Good news, good news!" });
  const cockAsk = new Speak(root, { call: "Why, what is that?" });
  const foxTell = new Speak(root, {
    call:
      "King Lion has declared a universal truce. No beast may hurt a bird henceforth, but all shall dwell together in brotherly friendship.",
    content: news,
  });
  const cockSee = new Speak(root, {
    call:
      "Why, that is good news; and there I see some one coming, with whom we can share the good tidings.",
    content: sightCtx,
  });
  const foxAsk = new Speak(root, { call: "What is it you see?" });
  const cockTell = new Speak(root, {
    call: "It is only my master's Dog that is coming towards us.",
    content: claimCtx,
  });
  const heardNews = new Hear(root, { theme: cockTell });
  const turnedAway = new TurnAway(root);
  const cockTease = new Speak(root, {
    call:
      "What, going so soon? Will you not stop and congratulate the Dog on the reign of universal peace?",
  });
  const foxExcuse = new Speak(root, {
    call:
      "I would gladly do so, but I fear he may not have heard of King Lion's decree.",
    content: excuseCtx,
  });
  const happened = [
    [prowl, fox],
    [seeCock, fox],
    [foxCry, fox],
    [cockAsk, cock],
    [foxTell, fox],
    [cockSee, cock],
    [foxAsk, fox],
    [cockTell, cock],
    [heardNews, fox],
    [turnedAway, fox],
    [cockTease, cock],
    [foxExcuse, fox],
  ];
  for (const [event, actor] of happened) Happened(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, prowl, foxExcuse, storyEnd);

  // "Beyond his reach", all along.
  const reaching = new GetAt(root, { theme: cock });
  const beyond = new Unable(root, { actor: fox, deed: reaching });
  input.push(reaching, beyond);
  Virtualize(input, reaching);
  Assert(
    input,
    new In(root, {
      proposition: beyond,
      duration: Duration(storyStart, storyEnd),
    }),
  );

  return {
    root,
    storyStart,
    storyEnd,
    fox,
    cock,
    dog,
    news,
    kingLion,
    truce,
    declared,
    forbidden,
    enjoined,
    hurtBird,
    excuseCtx,
    notDoing,
    heardNews,
  };
}
