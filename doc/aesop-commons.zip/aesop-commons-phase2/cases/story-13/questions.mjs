// Frozen question texts and semantic expectations for "The Fox, the
// Cock, and the Dog" (guide section 6.3, Story 13). The English text
// never changes; `semantic` is binding. Guide twins are exercised in
// regression.
export const Frozen = [
  {
    text: "What did the fox say King Lion had declared?",
    semantic: "值:一场普遍休战",
    tests: "言语内容",
  },
  {
    text: "According to the fox's news, may a beast hurt a bird?",
    semantic: "否(在狐狸所说的语境中)",
    tests: "N4 规范否定;非 world 语境中的是非问",
  },
  {
    text: "Could the fox reach the cock?",
    semantic: "否",
    tests: "N3('beyond his reach')",
  },
  {
    text: "What did the fox do as soon as he heard that the dog was coming?",
    semantic: "值:开始转身离开",
    tests: "紧接",
  },
  {
    text: "What reason did the fox give for not staying to congratulate the dog?",
    semantic: "值:他担心狗可能还没听说狮王的命令",
    tests: "嵌套态度 + 否定",
  },
];

export const Twins = [
  {
    text: "Was there really a universal truce?",
    semantic: "未确立",
  },
  {
    text: "According to the fox's news, shall all dwell together in brotherly friendship?",
    semantic: "是",
  },
];

// The five questions. Q1 reads the news context (the declared doing by
// King Lion); Q2 and the second twin judge inside the news itself — the
// seat Situation is a child of the speech context, so its knowledge is
// exactly what the fox said (a permission question asks that no
// prohibition holds, Not(Forbids)); Q3 asks "could he" as not being
// unable at any moment of the story; Q4 the immediate successor of the
// hearing; Q5 the fearing the excuse speech gives as its reason.
import {
  Agent,
  And,
  Declare,
  Duration,
  Forbids,
  GetAt,
  In,
  Mandates,
  Motivates,
  Not,
  Situation,
  start,
  Then,
  Unable,
  Validity,
  Virtual,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

function seatIn(input, target, mentions) {
  const seat = new Situation(target);
  input.push(seat);
  mentions.push(seat);
  return seat;
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(a universal truce)",
    build(input, asked, world, answer) {
      const declaring = new Declare(asked, { declaration: answer });
      input.push(declaring);
      input.push(new Virtual(asked, { node: declaring }));
      const byKing = new Agent(asked, {
        action: declaring,
        actor: world.kingLion,
      });
      input.push(byKing);
      among(input, byKing, world.news);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:false",
    // "May a beast hurt a bird" asks permission: that no prohibition holds
    // inside the news, Not(Forbids). The decree forbids it, so false.
    open(input, world, mentions) {
      return seatIn(input, world.news, mentions);
    },
    build(input, seat, world, answer) {
      const may = new Not(seat, { proposition: world.forbidden });
      input.push(may);
      input.push(new Validity(seat, { proposition: may, variable: answer }));
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const deed = new GetAt(asked, { theme: world.cock });
      input.push(deed);
      input.push(new Virtual(asked, { node: deed }));
      // "Could he" over the story: not unable at any moment of it.
      const unable = new Unable(asked, { actor: world.fox, deed });
      const able = new Not(asked, { proposition: unable });
      input.push(unable, able);
      const held = new In(asked, {
        proposition: able,
        duration: Duration(world.storyStart, world.storyEnd),
      });
      input.push(held);
      input.push(
        new Validity(asked, { proposition: held, variable: answer }),
      );
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:TurnAway()",
    build(input, asked, world, answer) {
      const sequel = new Then(asked, {
        earlier: world.heardNews,
        later: answer,
      });
      input.push(sequel);
      among(input, sequel, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected:
      "OK:Fears(content=Context(the dog may not have heard of King Lion's decree),experiencer=Entity(the Fox))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked, {
        driver: answer,
        action: world.notDoing,
      });
      input.push(why);
      among(input, why, world.excuseCtx);
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const declaring = new Declare(asked, { declaration: world.truce });
      const occurred = PatternEvent(input, declaring);
      const byKing = new Agent(asked, {
        action: declaring,
        actor: world.kingLion,
      });
      input.push(byKing);
      const joined = new And(asked, { propositions: [occurred, byKing] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:true",
    open(input, world, mentions) {
      return seatIn(input, world.news, mentions);
    },
    build(input, seat, world, answer) {
      input.push(
        new Validity(seat, {
          proposition: world.enjoined,
          variable: answer,
        }),
      );
    },
  },
];
