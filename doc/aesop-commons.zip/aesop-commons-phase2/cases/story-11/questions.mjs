// Frozen question texts and semantic expectations for "The Fox and the
// Goat" (guide section 6.3, Story 11). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "How did the fox really get into the well?",
    semantic: "值:他(出于不幸的偶然)掉了进去",
    tests: "world 事件",
  },
  {
    text: "How did the fox say he got into the well?",
    semantic: "值:他自己跳了下来(为了确保身边有水)",
    tests: "言语语境;与 Q1 是同一事件的不同描述",
  },
  {
    text: "Why did the goat jump into the well?",
    semantic: "值:她认为狐狸的建议很好",
    tests: "被诱导的评价驱动行动",
  },
  {
    text: "Could the fox get out of the well before the goat came down?",
    semantic: "否",
    tests: "N3 无能力,时间锚定",
  },
  {
    text: "Was what the fox told the goat about why he was in the well true?",
    semantic: "否",
    tests: "言语内容对照 world:'by an unlucky chance' 与 'in order to' 不相容",
  },
];

export const Twins = [
  {
    text: "Did the fox get out of the well?",
    semantic: "是",
  },
  {
    text: "Was there going to be a great drought?",
    semantic: "未确立(只有狐狸的说法,故事既未确立也未否定)",
  },
];

// The five questions. Q1 reads the world's Corresponds (what the said
// jumping really was); Q2 reads the news context; Q4 asks "could he" as
// not being unable at any moment of the window, In(Not(Unable), window);
// Q5 judges the told purpose in the world, where the Corresponds hands
// the claimed jumping to the chance falling and the class rule decides
// a chance happening serves no purpose.
import {
  Agent,
  And,
  Corresponds,
  Drought,
  Duration,
  GetOut,
  In,
  Motivates,
  Not,
  start,
  Unable,
  Validity,
  Virtual,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Chance(destination=Entity(a deep well),theme=Entity(the Fox))",
    build(input, asked, world, answer) {
      input.push(
        new Corresponds(asked, { left: answer, right: world.saidJump }),
      );
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected:
      "OK:JumpDown(destination=Entity(a deep well),theme=Entity(the Fox))",
    build(input, asked, world, answer) {
      const said = new Agent(asked, { action: answer, actor: world.fox });
      input.push(said);
      among(input, said, world.news);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected:
      "OK:Believes(believer=Entity(the Goat),content=Context(the fox's advice was good))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked, {
        driver: answer,
        action: world.goatJump,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const deed = new GetOut(asked, { from: world.well });
      input.push(deed);
      input.push(new Virtual(asked, { node: deed }));
      // "Could he" over the window: not unable at any moment of it.
      const trapped = new Unable(asked, { actor: world.fox, deed });
      const able = new Not(asked, { proposition: trapped });
      input.push(trapped, able);
      const held = new In(asked, {
        proposition: able,
        duration: Duration(start(world.fellIn), start(world.goatJump)),
      });
      input.push(held);
      input.push(
        new Validity(asked, { proposition: held, variable: answer }),
      );
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      input.push(
        new Validity(asked, {
          proposition: world.saidWhy,
          variable: answer,
        }),
      );
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const deed = new GetOut(asked, { from: world.well });
      const occurred = PatternEvent(input, deed);
      const did = new Agent(asked, { action: deed, actor: world.fox });
      input.push(did);
      const joined = new And(asked, { propositions: [occurred, did] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const dry = new Drought(asked);
      input.push(dry);
      input.push(new Validity(asked, { proposition: dry, variable: answer }));
    },
  },
];
