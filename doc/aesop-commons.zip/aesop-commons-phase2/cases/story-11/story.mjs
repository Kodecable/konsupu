// BuildStory for "The Fox and the Goat". The fox's news is a speech
// context: the drought it claims, the jumping it claims, and the purpose
// it gives all live there — the world holds none of them. The world does
// hold the Corresponds between the claimed jumping and the actual
// falling (the narrator frames the same getting-in both ways; RESULTS),
// and the falling itself is a Chance event — the class incompatibility
// (a chance happening serves no purpose) is what makes the told reason
// false rather than merely unestablished. The inability to get out
// starts at the fall and ends when its means arrives — the goat coming
// down — not when the escape is made: being able is not having done it.
import {
  Agent,
  Approves,
  Assert,
  Believes,
  Chance,
  Corresponds,
  Drought,
  Duration,
  end,
  Enables,
  ForPurpose,
  Fall,
  GetOut,
  Has,
  In,
  JumpDown,
  JumpOn,
  JumpUp,
  LocatedAt,
  Motivates,
  Not,
  Occurred,
  PassBy,
  Put,
  Speak,
  TimeAnchor,
  Unable,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, Happened, Virtualize, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const fox = entity(root, "the Fox");
  const goat = entity(root, "the Goat");
  const well = entity(root, "a deep well");
  const water = entity(root, "water");
  const horns = entity(root, "her long horns");
  const edge = entity(root, "the edge of the well");
  const foot = entity(root, "his foot");
  const herBack = entity(root, "her back");
  input.push(fox, goat, well, water, horns, edge, foot, herBack);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The fox's news: a coming drought, his claimed jumping, the purpose.
  const news = context(
    new Situation(),
    "there is going to be a great drought, so I jumped down",
  );
  input.push(news);
  const drought = new Drought(news);
  input.push(drought);
  Assert(input, drought, news);
  // "So I jumped down here": what he says happened, and who did it.
  const saidJump = new JumpDown(news, {
    theme: fox,
    destination: well,
  });
  const saidJumper = new Agent(news, { action: saidJump, actor: fox });
  const waterNear = new Has(news, { holder: fox, thing: water });
  const saidWhy = new ForPurpose(news, {
    action: saidJump,
    goal: waterNear,
  });
  input.push(saidJump, saidJumper, waterNear, saidWhy);
  Happened(input, saidJump, fox);
  Assert(input, waterNear, news);
  Assert(input, saidWhy, news);

  // The goat's approving belief of that advice, held by the world.
  const approval = context(new Situation(), "the fox's advice was good");
  input.push(approval);
  Assert(
    input,
    new Approves(approval, { approver: goat, of: news }),
    approval,
  );
  // "Only too taken in by the smooth cunning of the Fox" — the guide's
  // semantics for Q3 is that she believed; so the world holds it.
  const believed = new Believes(root, {
    believer: goat,
    content: approval,
  });
  input.push(believed);

  // The chance fall takes its place in the narration: the class rule on
  // the purpose tie sees every description of the Corresponds group in the
  // world, whichever member comes first in Input (6.3).
  const fellIn = new Chance(root, { theme: fox, destination: well });
  const goatPassed = new PassBy(root);
  const goatAsked = new Speak(root, {
    call: "What are you doing down there?",
  });
  const foxNews = new Speak(root, {
    call:
      "Oh, have you not heard? There is going to be a great drought, so I jumped down here in order to be sure to have water by me. Why don't you come down too?",
    content: news,
  });
  const goatJump = new JumpDown(root, { theme: goat, destination: well });
  const foxOnBack = new JumpOn(root, { target: herBack });
  const footOnHorns = new Put(root, { theme: foot, destination: horns });
  const escape = new JumpUp(root, { from: well, to: edge });
  const foxBye = new Speak(root, {
    call: "Good-bye, friend. Remember next time...",
  });
  const happened = [
    [fellIn, undefined],
    [goatPassed, goat],
    [goatAsked, goat],
    [foxNews, fox],
    [goatJump, goat],
    [foxOnBack, fox],
    [footOnHorns, fox],
    [escape, fox],
    [foxBye, fox],
  ];
  for (const [event, actor] of happened) Happened(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, fellIn, foxBye, storyEnd);

  // The world's identification of the said jumping with the actual
  // falling: the narrator frames the same getting-in both ways.
  input.push(new Corresponds(root, { left: saidJump, right: fellIn }));

  Assert(
    input,
    new In(root, {
      proposition: believed,
      duration: Duration(start(foxNews), storyEnd),
    }),
  );
  Assert(input, new Motivates(root, { driver: believed, action: goatJump }));

  // Could not get out, from the fall until the goat came down: "by
  // putting his foot on her long horns [he] managed to jump up" names the
  // goat as the means, so her coming down is what made it possible; the
  // escape is the ability exercised, not its start.
  const gettingOut = new GetOut(root, { from: well });
  input.push(gettingOut);
  Virtualize(input, gettingOut);
  const trapped = new Unable(root, { actor: fox, deed: gettingOut });
  input.push(trapped);
  Assert(
    input,
    new In(root, {
      proposition: trapped,
      duration: Duration(start(fellIn), start(goatJump)),
    }),
  );
  const freeAgain = new Not(root, { proposition: trapped });
  input.push(freeAgain);
  Assert(
    input,
    new In(root, {
      proposition: freeAgain,
      duration: Duration(end(goatJump), storyEnd),
    }),
  );
  Assert(input, new Enables(root, { enabler: goatJump, enabled: escape }));

  return {
    root,
    fox,
    goat,
    well,
    fellIn,
    goatJump,
    escape,
    news,
    saidJump,
    waterNear,
    saidWhy,
  };
}
