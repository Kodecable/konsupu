// BuildStory for "The Shepherd's Boy". The boy's plan is a root
// Situation holding the cried-wolf trick aimed at company and
// excitement; the first cry is the planned one by the narrator's
// Corresponds, which makes the two interchangeable in matching. The two
// trick cries happen, help comes twice, then the wolf actually comes out
// and worries the flock while the third cry gets a claim Situation of
// its own (the wolf is present at the cry, written against the story's
// own anchor, 12.1). The wolf's presence holds from its coming out on;
// before that no wolf was present at any moment — a NoInstance over a
// Virtual wolf pattern with a moment inside the window; after the third
// cry no help came — a NoInstance over a Virtual helping of the boy
// pinned to a moment of the window; the villagers believing the boy was
// again deceiving them is what caused the nobody-coming.
import {
  And,
  Assert,
  At,
  Believes,
  Causes,
  ComeOut,
  ComeToHelp,
  Corresponds,
  Worry,
  CryOut,
  Deceives,
  Duration,
  ForPurpose,
  Get,
  In,
  NoInstance,
  Occurs,
  Plans,
  Person,
  Present,
  TimeAnchor,
  Virtual,
  Within,
  Wolf,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, Happened, Virtualize, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const boy = entity(root, "the boy");
  const flock = entity(root, "his flock");
  const villagers = entity(root, "the villagers");
  const forest = entity(root, "the forest");
  const wolf = new Wolf(root);
  wolf.name = "the wolf";
  input.push(boy, flock, villagers, forest, wolf);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The plan: cry wolf to get a little company and some excitement. A
  // root Situation (12): it holds only what the boy plans.
  const plan = context(new Situation(), "cry wolf for company");
  input.push(plan);
  const company = entity(plan, "a little company");
  const excitement = entity(plan, "some excitement");
  input.push(company, excitement);
  const getBoth = new Get(plan, { theme: [company, excitement] });
  const cryPlan = new CryOut(plan, { call: "Wolf, Wolf" });
  input.push(getBoth, cryPlan);
  Did(input, getBoth, boy);
  Did(input, cryPlan, boy);
  Assert(
    input,
    new ForPurpose(plan, { action: cryPlan, goal: getBoth }),
    plan,
  );

  // The third cry's own claim, a root Situation; its content is about
  // the moment of the cry, so the time is written out (12.1).
  const claim3 = context(new Situation(), "a wolf is present now");
  input.push(claim3);

  const cry1 = new CryOut(root, { call: "Wolf, Wolf" });
  const help1 = new ComeToHelp(root, { theme: boy });
  const cry2 = new CryOut(root, { call: "Wolf, Wolf" });
  const help2 = new ComeToHelp(root, { theme: boy });
  const comeOut = new ComeOut(root, { from: forest });
  const worry = new Worry(root, { theme: flock });
  const cry3 = new CryOut(root, { call: "Wolf, Wolf", content: claim3 });
  const happened = [
    [cry1, boy],
    [help1, villagers],
    [cry2, boy],
    [help2, villagers],
    [comeOut, wolf],
    [worry, wolf],
    [cry3, boy],
  ];
  for (const [event, actor] of happened) Happened(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, cry1, cry3, storyEnd);

  const claimed = new Present(claim3, { subject: wolf });
  input.push(claimed);
  const claimedAtCry = new At(claim3, {
    proposition: claimed,
    anchor: start(cry3),
  });
  input.push(claimedAtCry);
  Assert(input, claimedAtCry, claim3);

  // The first cry is the planned trick: the narrator's correspondence.
  input.push(new Corresponds(root, { left: cryPlan, right: cry1 }));

  const plans = new Plans(root, { planner: boy, content: plan });
  input.push(plans);
  Assert(
    input,
    new In(root, {
      proposition: plans,
      duration: Duration(storyStart, start(cry1)),
    }),
  );

  // The wolf was present from its coming out on.
  const presentHeld = new Present(root, { subject: wolf });
  input.push(presentHeld);
  Assert(
    input,
    new In(root, {
      proposition: presentHeld,
      duration: Duration(start(comeOut), storyEnd),
    }),
  );

  // …and before that there was no wolf at any moment: negated existence
  // over a Virtual wolf present at a Virtual moment within the window
  // (14.4), not an In over the window, which would only exclude a wolf
  // present at every point of it.
  const anyWolf = new Wolf(root);
  const someMoment = new TimeAnchor(root);
  const wolfPresent = new Present(root, { subject: anyWolf });
  const wolfAt = new At(root, { proposition: wolfPresent, anchor: someMoment });
  input.push(anyWolf, someMoment, wolfPresent, wolfAt);
  Virtualize(input, anyWolf);
  Virtualize(input, someMoment);
  input.push(
    new Within(root, {
      anchor: someMoment,
      duration: Duration(storyStart, start(comeOut)),
    }),
  );
  Assert(input, new NoInstance(root, { of: anyWolf }));

  // After the third cry, nobody came to help: no helping of the boy at
  // any moment from the cry on, whoever the helper.
  const anyHelp = new ComeToHelp(root, { theme: boy });
  const helpMoment = new TimeAnchor(root);
  const helpOccurs = new Occurs(root, { event: anyHelp });
  input.push(anyHelp, helpMoment, helpOccurs);
  Virtualize(input, anyHelp);
  Virtualize(input, helpMoment);
  input.push(
    new At(root, { proposition: helpOccurs, anchor: helpMoment }),
    new Within(root, {
      anchor: helpMoment,
      duration: Duration(start(cry3), storyEnd),
    }),
  );
  const noHelp = new NoInstance(root, { of: anyHelp });
  input.push(noHelp);
  Assert(input, noHelp);

  // The villagers' belief that the boy was again deceiving them caused
  // the nobody-coming. The belief is a root Situation holding the
  // deceiving; "again" is the same trick as the first two cries.
  const again = context(
    new Situation(),
    "the boy was again deceiving them",
  );
  input.push(again);
  const tricking = new Deceives(again, { deceiver: boy, victim: villagers });
  input.push(tricking);
  Assert(input, tricking, again);
  const believed = new Believes(root, {
    believer: villagers,
    content: again,
  });
  input.push(believed);
  Assert(
    input,
    new In(root, {
      proposition: believed,
      duration: Duration(start(cry3), storyEnd),
    }),
  );
  Assert(input, new Causes(root, { cause: believed, effect: noHelp }));

  return {
    root,
    storyStart,
    storyEnd,
    boy,
    villagers,
    wolf,
    plan,
    cry1,
    cry2,
    cry3,
    claim3,
    claim3At: claimedAtCry,
    comeOut,
    noHelp,
    believed,
  };
}
