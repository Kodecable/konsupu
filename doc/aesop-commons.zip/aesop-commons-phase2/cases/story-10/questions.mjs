// Frozen question texts and semantic expectations for "The Shepherd's
// Boy" (guide section 6.3, Story 10). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Why did the boy first cry \"Wolf\"?",
    semantic: "值:为了得到一点陪伴和一些刺激",
    tests: "计划/目的;序数 'first'",
  },
  {
    text: "Was there a wolf when the boy cried \"Wolf\" the second time?",
    semantic: "否",
    tests: "序数;时间锚定的否定('actually'、'the same trick')",
  },
  {
    text: "Why did nobody come to help the boy the third time?",
    semantic: "值:村民以为他又在骗他们",
    tests: "错误信念作为原因",
  },
  {
    text: "Was the boy telling the truth when he cried \"Wolf\" the third time?",
    semantic: "是",
    tests: "同一内容的真值随时间不同",
  },
  {
    text: "Did any villager come to help the boy the third time?",
    semantic: "否",
    tests: "N2 时间窗口内的否定存在",
  },
];

export const Twins = [
  {
    text: "Did the villagers come to help the boy the second time?",
    semantic: "是",
  },
  {
    text: "Was the boy telling the truth the first time?",
    semantic: "否",
  },
];

// The five questions. Ordinals ("first", "the second time") resolve at
// translation to the matching cry along the chain — Commons has no
// ordinal mechanism, and the phase2 insert-earlier regression cannot be
// carried over (OBSERVATIONS G-6). The wolf's presence and its negation
// are anchored states, so the same asked content answers differently at
// different cries; the truth of the third cry is judged on the claim's
// own proposition in the world (12.2); the nobody-coming is a NoInstance
// pinned to moments of its window; its cause is the villagers'
// believing.
import {
  Agent,
  And,
  At,
  Causes,
  ComeToHelp,
  CryOut,
  Deceives,
  Duration,
  ForPurpose,
  In,
  Occurs,
  Present,
  Validity,
  Virtual,
  Wolf,
  start,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

// "Was there a wolf at the anchor": an existence question over a Virtual
// wolf present at the moment.
function wolfAt(situation, anchor) {
  const aWolf = new Wolf(situation);
  const there = new Present(situation, { subject: aWolf });
  const at = new At(situation, { proposition: there, anchor });
  return { wolf: aWolf, nodes: [aWolf, there, at], at };
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Get(theme=[Entity(a little company),Entity(some excitement)])",
    // "First" resolves to the first cry, which the narrator's
    // Corresponds makes the planned one. The purpose tie is held by the
    // plan context, so the question reads it there and matches the
    // planned cry by content (the Corresponds lives in the world and is
    // not visible inside the plan).
    build(input, asked, world, answer) {
      const plannedCry = new CryOut(asked, { call: "Wolf, Wolf" });
      input.push(plannedCry);
      input.push(new Virtual(asked, { node: plannedCry }));
      const why = new ForPurpose(asked, {
        action: plannedCry,
        goal: answer,
      });
      input.push(why);
      among(input, why, world.plan);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const there = wolfAt(asked, start(world.cry2));
      input.push(...there.nodes);
      input.push(new Virtual(asked, { node: there.wolf }));
      input.push(
        new Validity(asked, { proposition: there.at, variable: answer }),
      );
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected:
      "OK:Believes(believer=Entity(the villagers),content=Context(the boy was again deceiving them))",
    build(input, asked, world, answer) {
      const why = new Causes(asked, {
        cause: answer,
        effect: world.noHelp,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:true",
    // The truth of what he cried is the claim's own proposition — the
    // wolf present at the cry — judged in the world (12.2).
    build(input, asked, world, answer) {
      const truth = world.claim3At;
      input.push(
        new Validity(asked, { proposition: truth, variable: answer }),
      );
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const helping = new ComeToHelp(asked, { theme: world.boy });
      const occurs = new Occurs(asked, { event: helping });
      const did = new Agent(asked, { action: helping, actor: world.villagers });
      const body = new And(asked, { propositions: [did, occurs] });
      input.push(helping, occurs, did, body);
      input.push(new Virtual(asked, { node: helping }));
      const held = new In(asked, {
        proposition: body,
        duration: Duration(start(world.cry3), world.storyEnd),
      });
      input.push(held);
      input.push(
        new Validity(asked, { proposition: held, variable: answer }),
      );
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const helping = new ComeToHelp(asked, { theme: world.boy });
      const occurred = PatternEvent(input, helping);
      const did = new Agent(asked, {
        action: helping,
        actor: world.villagers,
      });
      input.push(did);
      const joined = new And(asked, { propositions: [occurred, did] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const there = wolfAt(asked, start(world.cry1));
      input.push(...there.nodes);
      input.push(new Virtual(asked, { node: there.wolf }));
      input.push(
        new Validity(asked, { proposition: there.at, variable: answer }),
      );
    },
  },
];
