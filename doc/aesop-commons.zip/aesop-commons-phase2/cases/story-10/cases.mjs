// One import per story: the frozen questions and the case assembly.
import { BuildCase } from "../helpers.mjs";
import { BuildStory } from "./story.mjs";
import { Questions, TwinQuestions } from "./questions.mjs";

export { Questions, TwinQuestions };

export function BuildCaseFor(question) {
  return BuildCase(question, BuildStory);
}
