// "The Crow and the Pitcher" under Commons. The narration is a chain of
// happened events (the canonical Occurred write); changeable states are
// intervals bounded by anchors — thirst from the story start until the
// drinking, the inability to get at the water from putting the beak in
// until the few more pebbles — and quenched / able-again are explicit Not
// over the following interval, since nothing ends a state by default
// (14.12). The droppings as one Series cause the rise; the rise enables
// and causes the drinking; the drinking saves the life; the pebble's
// resting place holds from the first drop on.
import {
  Causes,
  ComeUpon,
  Drop,
  Duration,
  Enables,
  ForPurpose,
  GetAt,
  Goal,
  In,
  LocatedAt,
  Not,
  Put,
  Quench,
  Rise,
  Save,
  Series,
  ThinkUp,
  Thirsty,
  TimeAnchor,
  TryToDrink,
  Unable,
  Assert,
  start,
} from "../../space/Interface/Aesop.js";
import { Bounds, Chain, Happened, Virtualize, entity } from "../helpers.mjs";

export function BuildStory(input, story) {
  const crow = entity(story, "the crow");
  const pitcher = entity(story, "the pitcher");
  const water = entity(story, "the water");
  const pebble = entity(story, "a pebble");
  const otherPebbles = entity(story, "the other pebbles");
  const morePebbles = entity(story, "a few more pebbles");
  const beak = entity(story, "its beak");
  const thirst = entity(story, "its thirst");
  const life = entity(story, "its life");
  input.push(
    crow,
    pitcher,
    water,
    pebble,
    otherPebbles,
    morePebbles,
    beak,
    thirst,
    life,
  );

  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  input.push(storyStart, storyEnd);

  const comeUpon = new ComeUpon(story, { theme: pitcher });
  const putBeak = new Put(story, { theme: beak, destination: pitcher });
  const tryDrink = new TryToDrink(story, { theme: water });
  const think = new ThinkUp(story);
  const dropFirst = new Drop(story, {
    theme: pebble,
    destination: pitcher,
  });
  const dropOthers = new Drop(story, {
    theme: otherPebbles,
    destination: pitcher,
  });
  const waterRise = new Rise(story, { theme: water });
  const castMore = new Drop(story, {
    theme: morePebbles,
    destination: pitcher,
  });
  const drink = new Quench(story, { theme: thirst });
  const saveLife = new Save(story, { theme: life });
  // Agency is an independent Agent proposition (13.2); the rise has no
  // agent.
  const happened = [
    comeUpon,
    putBeak,
    tryDrink,
    think,
    dropFirst,
    dropOthers,
    waterRise,
    castMore,
    drink,
    saveLife,
  ];
  for (const event of happened) {
    Happened(input, event, event === waterRise ? undefined : crow);
  }
  Chain(input, happened);
  Bounds(input, storyStart, comeUpon, saveLife, storyEnd);

  // Half-dead with thirst: from the story start until the drinking;
  // quenched from the drinking on (explicit, no default inertia).
  const thirsty = new Thirsty(story, { subject: crow });
  input.push(thirsty);
  Assert(
    input,
    new In(story, {
      proposition: thirsty,
      duration: Duration(storyStart, start(drink)),
    }),
  );
  const thirstGone = new Not(story, { proposition: thirsty });
  input.push(thirstGone);
  Assert(
    input,
    new In(story, {
      proposition: thirstGone,
      duration: Duration(start(drink), storyEnd),
    }),
  );

  // Could not reach the water, found when the beak went in, ended only
  // after the few more pebbles ("after casting in a few more pebbles he
  // was able to"). The deed is a Virtual description of getting at the
  // water, not the trying that occurred.
  const gettingAt = new GetAt(story, { theme: water });
  input.push(gettingAt);
  Virtualize(input, gettingAt);
  const unable = new Unable(story, { actor: crow, deed: gettingAt });
  input.push(unable);
  Assert(
    input,
    new In(story, {
      proposition: unable,
      duration: Duration(start(putBeak), start(castMore)),
    }),
  );
  const ableAgain = new Not(story, { proposition: unable });
  input.push(ableAgain);
  Assert(
    input,
    new In(story, {
      proposition: ableAgain,
      duration: Duration(start(castMore), storyEnd),
    }),
  );

  // The droppings together, one after another, made the water rise; the
  // risen water enabled and caused the drinking; the drinking saved the
  // crow's life; the droppings aimed at the rise; the goal was drinking.
  const dropping = new Series(story, { parts: [dropFirst, dropOthers] });
  Happened(input, dropping);
  Assert(
    input,
    new Causes(story, { cause: dropping, effect: waterRise }),
  );
  Assert(input, new Causes(story, { cause: waterRise, effect: drink }));
  Assert(input, new Causes(story, { cause: drink, effect: saveLife }));
  Assert(
    input,
    new Enables(story, { enabler: waterRise, enabled: drink }),
  );
  Assert(
    input,
    new ForPurpose(story, { action: dropping, goal: waterRise }),
  );
  Assert(input, new Goal(story, { actor: crow, objective: drink }));

  // Where the pebble ended up: at the pitcher, from the first drop on.
  const pebbleRests = new LocatedAt(story, {
    entity: pebble,
    place: pitcher,
  });
  input.push(pebbleRests);
  Assert(
    input,
    new In(story, {
      proposition: pebbleRests,
      duration: Duration(start(dropFirst), storyEnd),
    }),
  );

  return {
    root: story,
    storyStart,
    storyEnd,
    crow,
    pitcher,
    water,
    pebble,
    putBeak,
    tryDrink,
    dropFirst,
    dropping,
    waterRise,
    drink,
  };
}
