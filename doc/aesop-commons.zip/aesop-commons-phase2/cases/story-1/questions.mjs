// Five questions over the Crow-and-the-Pitcher cognition. Every question
// is expressed as explicit declarations — an Among over a description
// (6.2) — never as unasserted propositions left to be read as conditions
// by position (principle 2). The description is as definite as the question
// is: the story has three drops, and several Among candidates are
// Ambiguous even when every candidate would give the same answer, so
// "a pebble" pins the theme the way the phase2 subset-field reading did
// not have to. Expected answers are machine projections of the resolved
// values; the English `text` is for human comparison only and never
// reaches the resolver.
import {
  Agent,
  Causes,
  Drop,
  Duration,
  Enables,
  In,
  LocatedAt,
  Then,
  start,
} from "../../space/Interface/Aesop.js";
import { AgentOf, among } from "../helpers.mjs";

export const Questions = [
  {
    text: "Who dropped a pebble into the pitcher?",
    expected: "OK:Entity(the crow)",
    // "a pebble ... into the pitcher" describes the doing; the theme is
    // pinned because the story has three drops and several candidates are
    // Ambiguous even when their agents agree (6.2). Agency is the
    // independent Agent proposition (13.2), so "who" is an Among over an
    // Agent description whose actor is the answer; the pinned drop's own
    // Among resolves it inside the match.
    build(input, asked, world, answer) {
      const d = new Drop(asked, {
        theme: world.pebble,
        destination: world.pitcher,
      });
      input.push(d);
      among(input, d, world.root);
      const who = AgentOf(input, d, answer);
      among(input, who, world.root);
    },
  },
  {
    text: "What happened after the crow put its beak into the pitcher?",
    expected: "OK:TryToDrink(theme=Entity(the water))",
    // "after" asks for the narrative sequel: the unique holding Then whose
    // earlier side is putBeak. The candidates of an Among over a
    // proposition are the propositions that hold there, derived ones
    // included (6.2).
    build(input, asked, world, answer) {
      const sequel = new Then(asked, {
        earlier: world.putBeak,
        later: answer,
      });
      input.push(sequel);
      among(input, sequel, world.root);
    },
  },
  {
    text: "Why did the water mount up?",
    expected:
      "OK:Series(parts=[Drop(destination=Entity(the pitcher),theme=Entity(a pebble)),Drop(destination=Entity(the pitcher),theme=Entity(the other pebbles))])",
    // The cause is the dropping as a whole; no single Drop is credited.
    build(input, asked, world, answer) {
      const why = new Causes(asked, {
        cause: answer,
        effect: world.waterRise,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
  {
    text: "What was the crow able to do after the water mounted up?",
    expected: "OK:Quench(theme=Entity(its thirst))",
    // "able to" is the enabling. The temporal half ("after") is not a
    // second Among over a Before description: an unbound side of a
    // Before ranges over anchors (POINTS), not events, so the enabling
    // carries the question alone.
    build(input, asked, world, answer) {
      const able = new Enables(asked, {
        enabler: world.waterRise,
        enabled: answer,
      });
      input.push(able);
      among(input, able, world.root);
    },
  },
  {
    text: "Where did the pebble end up after the crow dropped it?",
    expected: "OK:Entity(the pitcher)",
    // "Ended up somewhere after the drop" is the state holding from the
    // drop's start anchor: the Among over that In picks among what holds,
    // derivable propositions included; the pinned drop's Among resolves
    // its start anchor inside the time fit.
    build(input, asked, world, answer) {
      const d = new Drop(asked, {
        theme: world.pebble,
        destination: world.pitcher,
      });
      input.push(d, start(d));
      among(input, d, world.root);
      const ended = new LocatedAt(asked, {
        entity: world.pebble,
        place: answer,
      });
      input.push(ended);
      const since = new In(asked, {
        proposition: ended,
        duration: Duration(start(d), world.storyEnd),
      });
      input.push(since);
      among(input, since, world.root);
    },
  },
];
