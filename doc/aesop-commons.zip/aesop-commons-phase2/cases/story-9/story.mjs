// BuildStory for "The Wolf in Sheep's Clothing". The deceiving is a
// state that starts at the disguising and succeeds "for some time" — a
// stated vague duration, never an Unknown. The wolf never speaks: the
// deception is the wearing, non-verbal by construction. Nothing says
// what the lamb believed (P6): no belief of its own exists anywhere.
// The difficulty before the skin is an anchored inability of the easy
// way only ("found great difficulty" is the lexical basis), ended by the
// disguising that resolved it.
import {
  Assert,
  BelongsTo,
  Causes,
  Deceives,
  Duration,
  Eat,
  Find,
  Follow,
  GetAt,
  In,
  Lasted,
  Lead,
  Occurred,
  PutOn,
  Stroll,
  TimeAnchor,
  Unable,
  Virtual,
  Wears,
  start,
} from "../../space/Interface/Aesop.js";
import { Bounds, Chain, Did, Happened, Virtualize, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const wolf = entity(root, "the Wolf");
  const shepherd = entity(root, "the shepherd");
  const dogs = entity(root, "his dogs");
  const sheep = entity(root, "the sheep");
  const lamb = entity(root, "the Lamb");
  const flayedSheep = entity(root, "the sheep that had been flayed");
  const skin = entity(root, "the skin of a sheep");
  const pelt = entity(root, "its own pelt");
  const someTime = entity(root, "some time");
  input.push(
    wolf,
    shepherd,
    dogs,
    sheep,
    lamb,
    flayedSheep,
    skin,
    pelt,
    someTime,
  );

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  const foundSkin = new Find(root, { theme: skin });
  const putOn = new PutOn(root, { theme: skin, over: pelt });
  const strolled = new Stroll(root);
  const lambFollowed = new Follow(root, { theme: wolf });
  const ledApart = new Lead(root, { theme: lamb });
  const madeMeal = new Eat(root, { theme: lamb });
  const happened = [foundSkin, putOn, strolled, lambFollowed, ledApart, madeMeal];
  for (const [event, actor] of [
    [foundSkin, wolf],
    [putOn, wolf],
    [strolled, wolf],
    [lambFollowed, lamb],
    [ledApart, wolf],
    [madeMeal, wolf],
  ]) {
    Happened(input, event, actor);
  }
  Chain(input, happened);
  Bounds(input, storyStart, foundSkin, madeMeal, storyEnd);

  // "Found great difficulty in getting at the sheep": he could not get
  // at them easily — an inability of the easy way only, never of getting
  // at them at all. It holds until the disguising that resolved it.
  const gettingAt = new GetAt(root, { theme: sheep, manner: "easily" });
  input.push(gettingAt);
  Virtualize(input, gettingAt);
  const strained = new Unable(root, { actor: wolf, deed: gettingAt });
  input.push(strained);
  Assert(
    input,
    new In(root, {
      proposition: strained,
      duration: Duration(storyStart, start(putOn)),
    }),
  );

  // The wearing runs from the disguising on; the deceiving of the sheep
  // begins with it and lasts "for some time" — a stated value.
  const wearing = new Wears(root, { wearer: wolf, clothing: skin });
  input.push(wearing);
  Assert(
    input,
    new In(root, {
      proposition: wearing,
      duration: Duration(start(putOn), storyEnd),
    }),
  );
  const deceiving = new Deceives(root, { deceiver: wolf, victim: sheep });
  input.push(deceiving);
  Assert(
    input,
    new In(root, {
      proposition: deceiving,
      duration: Duration(start(putOn), storyEnd),
    }),
  );
  Assert(input, new Causes(root, { cause: putOn, effect: deceiving }));
  Assert(
    input,
    new Lasted(root, { subject: deceiving, amount: someTime }),
  );

  // The skin's owner and the lamb's dam are explicit possessions.
  Assert(input, new BelongsTo(root, { thing: skin, owner: flayedSheep }));
  Assert(input, new BelongsTo(root, { thing: lamb, owner: flayedSheep }));

  return {
    root,
    storyStart,
    storyEnd,
    wolf,
    sheep,
    lamb,
    flayedSheep,
    skin,
    foundSkin,
    putOn,
    madeMeal,
    deceiving,
    strained,
  };
}
