// Frozen question texts and semantic expectations for "The Wolf in
// Sheep's Clothing" (guide section 6.3, Story 9). The English text never
// changes; `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Whose skin was the wolf wearing?",
    semantic: "值:那只被剥了皮的羊(小羊的母亲)",
    tests: "关系个体",
  },
  {
    text: "How did the wolf deceive the sheep?",
    semantic: "值:把羊皮披在自己的皮毛外面",
    tests: "非言语欺骗的手段",
  },
  {
    text: "For how long did the wolf succeed in deceiving the sheep?",
    semantic: "值:for some time(模糊时长,不是 Unknown)",
    tests: "时长",
  },
  {
    text: "Did the lamb think the wolf was its mother?",
    semantic: "未确立(P6:不从行为推断信念)",
    tests: "心理状态只取文本依据",
  },
  {
    text: "Before he found the sheep's skin, could the wolf get at the sheep easily?",
    semantic: "否",
    tests: "时间锚定的困难('great difficulty')",
  },
];

export const Twins = [
  {
    text: "Did the lamb follow the wolf?",
    semantic: "是",
  },
  {
    text: "Whom did the wolf deceive?",
    semantic: "the sheep",
  },
];

// The five questions. The wearing and its possession join in one And;
// every state question carries the time it asks about (an unmodified
// item is AllTime and matches no interval fact — OBSERVATIONS G-3). The
// means of the deceiving is its cause; the duration is a stated value;
// the lamb holds no belief, so a content question over a belief of its
// own is Unknown; "could he, before the skin" is asked as not being
// unable to get at them easily at any moment of that window,
// In(Not(Unable), window).
import {
  Agent,
  And,
  Believes,
  BelongsTo,
  Causes,
  Deceives,
  Duration,
  Follow,
  GetAt,
  In,
  Lasted,
  Not,
  Occurs,
  SameReferent,
  start,
  Unable,
  Validity,
  Variable,
  Virtual,
  Wears,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { among, PatternEvent } from "../helpers.mjs";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(the sheep that had been flayed)",
    build(input, asked, world, answer) {
      const c = new Variable(asked);
      input.push(c);
      const worn = new In(asked, {
        proposition: new Wears(asked, { wearer: world.wolf, clothing: c }),
        duration: Duration(start(world.putOn), world.storyEnd),
      });
      input.push(worn.proposition, worn);
      const owned = new BelongsTo(asked, { thing: c, owner: answer });
      input.push(owned);
      const joined = new And(asked, { propositions: [worn, owned] });
      input.push(joined);
      among(input, joined, world.root);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:PutOn(over=Entity(its own pelt),theme=Entity(the skin of a sheep))",
    build(input, asked, world, answer) {
      const how = new Causes(asked, {
        cause: answer,
        effect: world.deceiving,
      });
      input.push(how);
      among(input, how, world.root);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:Entity(some time)",
    build(input, asked, world, answer) {
      const lasted = new Lasted(asked, {
        subject: world.deceiving,
        amount: answer,
      });
      input.push(lasted);
      among(input, lasted, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Unknown",
    // The asked belief content — the wolf identified with the lamb's
    // dam — is a question-built context; no Believes of the lamb fits it
    // because the lamb holds no belief anywhere (P6).
    build(input, asked, world, answer) {
      const content = new Situation();
      input.push(content);
      const identified = new SameReferent(content, {
        left: world.wolf,
        right: world.flayedSheep,
      });
      input.push(identified);
      const belief = new Believes(asked, {
        believer: world.lamb,
        content,
      });
      input.push(belief);
      input.push(
        new Validity(asked, { proposition: belief, variable: answer }),
      );
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const easyGet = new GetAt(asked, {
        theme: world.sheep,
        manner: "easily",
      });
      input.push(easyGet);
      input.push(new Virtual(asked, { node: easyGet }));
      // "Could he" over the window: not unable at any moment of it.
      const strained = new Unable(asked, { actor: world.wolf, deed: easyGet });
      const able = new Not(asked, { proposition: strained });
      input.push(strained, able);
      const held = new In(asked, {
        proposition: able,
        duration: Duration(world.storyStart, start(world.foundSkin)),
      });
      input.push(held);
      input.push(
        new Validity(asked, { proposition: held, variable: answer }),
      );
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const followed = new Follow(asked, { theme: world.wolf });
      const occurred = PatternEvent(input, followed);
      const did = new Agent(asked, { action: followed, actor: world.lamb });
      input.push(did);
      const joined = new And(asked, { propositions: [occurred, did] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:Entity(the sheep)",
    build(input, asked, world, answer) {
      const deceived = new Deceives(asked, {
        deceiver: world.wolf,
        victim: answer,
      });
      input.push(deceived);
      among(input, deceived, world.root);
    },
  },
];
