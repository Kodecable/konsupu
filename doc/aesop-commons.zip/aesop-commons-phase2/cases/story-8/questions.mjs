// Frozen question texts and semantic expectations for "The Nurse and the
// Wolf" (guide section 6.3, Story 8). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Who was the nurse speaking to when she mentioned the wolf?",
    semantic: "值:the child",
    tests: "受话人 ≠ 偷听者",
  },
  {
    text: "What did the wolf hope to eat?",
    semantic: "值:the child",
    tests: "狼的预期语境",
  },
  {
    text: "Did the child make the noise again?",
    semantic: "是",
    tests: "条件前件实现",
  },
  {
    text: "When the child began to cry, did the nurse throw it to the wolf?",
    semantic: "否",
    tests: "N5 穷尽陈述推出的否定",
  },
  {
    text: "Why did the wolf crouch down by the house and wait?",
    semantic: "值:他预期孩子很快会哭、会被扔给他(他自己的预期,不是谁的承诺)",
    tests: "误解形成的预期驱动行动('So he crouched')",
  },
];

export const Twins = [
  {
    text: "Did anyone promise the wolf the child?",
    semantic: "未确立(只有狼自己在结尾称之为 promise)",
  },
  {
    text: "Did the nurse call for help?",
    semantic: "是",
  },
];

// The five questions. The threat's addressee is read through the speaking
// (a Virtual Speak whose content is the threat); the wolf's hope through
// an Among into his own expectation context; the crying through its
// canonical occurrence; the throwing through the windowed doing that the
// Only exhausts; the waiting through what motivated it.
import {
  Agent,
  And,
  Believes,
  Cry,
  Eat,
  In,
  Motivates,
  Occurs,
  Promises,
  Speak,
  Throw,
  Validity,
  Virtual,
  CallForHelp,
  duration,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

// "The doer did the deed (at some moment of `span`)": the plain form
// uses the canonical occurrence; the windowed form puts a bare Occurs
// under the window (the canonical duration of a Virtual deed cannot be
// placed in a window — its anchors carry no order).
function didDo(situation, deed, actor, span) {
  const occurs = new Occurs(situation, { event: deed });
  const did = new Agent(situation, { action: deed, actor });
  const body = new And(situation, { propositions: [did, occurs] });
  if (span === null) {
    return { deed, nodes: [deed, occurs, did, body], body };
  }
  const held = new In(situation, { proposition: body, duration: span });
  return { deed, nodes: [deed, occurs, did, body, held], body: held };
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(the child)",
    build(input, asked, world, answer) {
      const utterance = new Speak(asked, {
        content: world.threat,
        to: answer,
      });
      input.push(utterance);
      input.push(new Virtual(asked, { node: utterance }));
      const who = new Agent(asked, { action: utterance, actor: world.nurse });
      input.push(who);
      among(input, who, world.root);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:Entity(the child)",
    build(input, asked, world, answer) {
      const meal = new Eat(asked, { theme: answer });
      input.push(meal);
      among(input, meal, world.wolfThought);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const noise = new Cry(asked, { theme: world.child });
      const occurred = PatternEvent(input, noise);
      const made = new Agent(asked, { action: noise, actor: world.child });
      input.push(made);
      const joined = new And(asked, {
        propositions: [occurred, made],
      });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const thrown = didDo(
        asked,
        new Throw(asked, { theme: world.child, to: world.wolf }),
        world.nurse,
        world.window,
      );
      input.push(...thrown.nodes);
      input.push(new Virtual(asked, { node: thrown.deed }));
      input.push(
        new Validity(asked, {
          proposition: thrown.body,
          variable: answer,
        }),
      );
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected:
      "OK:Believes(believer=Entity(the wolf),content=Context(the child will cry and be thrown out))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked, { driver: answer, action: world.wait });
      input.push(why);
      among(input, why, world.root);
    },
  },
];

// Guide twins, executable: nobody promised (the wolf's own word "promise"
// at the end is his, not the world's), and the calling did happen.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const promised = new Promises(asked, {
        recipient: world.wolf,
        deed: new Throw(asked, { theme: world.child, to: world.wolf }),
      });
      input.push(promised.deed, promised);
      input.push(new Virtual(asked, { node: promised.deed }));
      input.push(
        new Validity(asked, { proposition: promised, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const called = new CallForHelp(asked);
      const occurred = PatternEvent(input, called);
      const did = new Agent(asked, { action: called, actor: world.nurse });
      input.push(did);
      const joined = new And(asked, { propositions: [occurred, did] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
];
