// BuildStory for "The Nurse and the Wolf". The threat is a root
// speech-content Situation holding a Conditional — for every crying
// there is a throwing by the nurse; the wolf's expectation is a root
// belief Situation of its own (the child will cry; he will eat the
// child), and his waiting is motivated by that believing. When the child
// does cry, all the Nurse did at any moment from the cry on was shut the
// window and call for help — an Only over a Virtual deed whose doing is
// pinned to a moment of the window (the At-around-the-body shape; a
// Within on the Virtual deed's own start does not refute, see
// OBSERVATIONS), from which "she did not throw the child" follows.
import {
  And,
  Assert,
  At,
  Believes,
  Conditional,
  ComeTo,
  Crouch,
  Cry,
  Duration,
  Eat,
  Event,
  In,
  Motivates,
  Occurs,
  Only,
  Agent,
  Speak,
  Throw,
  TimeAnchor,
  Virtual,
  Wait,
  Within,
  CallForHelp,
  RushOut,
  GallopAway,
  Shut,
  context,
  duration,
  end,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, Happened, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const nurse = entity(root, "the nurse");
  const child = entity(root, "the child");
  const wolf = entity(root, "the wolf");
  const house = entity(root, "the house");
  const window = entity(root, "the window");
  const dogs = entity(root, "the dogs of the house");
  input.push(nurse, child, wolf, house, window, dogs);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // "If you make that noise again I will throw you to the Wolf." The
  // threat is a root Situation (12). For every crying (forall) there is
  // a throwing by the nurse (exists); both are Virtual pattern events
  // with their canonical occurrence constraint (13.1), and the
  // quantifiers list every Virtual node of the Conditional (11.2).
  const threat = context(new Situation(), "the nurse's threat");
  input.push(threat);
  const noise = new Cry(threat, { theme: child });
  const throwChild = new Throw(threat, { theme: child, to: wolf });
  input.push(noise, throwChild);
  const noiseOccurs = new Occurs(threat, { event: noise });
  const noiseDuring = new In(threat, {
    proposition: noiseOccurs,
    duration: duration(noise),
  });
  const thrownOccurs = new Occurs(threat, { event: throwChild });
  const thrownDuring = new In(threat, {
    proposition: thrownOccurs,
    duration: duration(throwChild),
  });
  const byNurse = new Agent(threat, { action: throwChild, actor: nurse });
  const consequence = new And(threat, {
    propositions: [thrownDuring, byNurse],
  });
  input.push(
    start(noise),
    end(noise),
    noiseOccurs,
    noiseDuring,
    start(throwChild),
    end(throwChild),
    thrownOccurs,
    thrownDuring,
    byNurse,
    consequence,
  );
  input.push(new Virtual(threat, { node: noise }));
  input.push(new Virtual(threat, { node: throwChild }));
  const warning = new Conditional(threat, {
    forall: [noise],
    exists: [throwChild],
    antecedent: noiseDuring,
    consequence,
  });
  input.push(warning);
  Assert(input, warning, threat);

  const say = new Speak(root, {
    to: child,
    content: threat,
    call: "Be quiet now, or I shall throw you out of the window to the Wolf.",
  });
  const crouch = new Crouch(root, { place: house });
  const wait = new Wait(root, { place: house });

  // The wolf's own expectation: the child is sure to cry soon, and the
  // morsel he expects to eat is the child. A root Situation (12): it
  // holds only what the wolf expects.
  const wolfThought = context(
    new Situation(),
    "the child will cry and be thrown out",
  );
  input.push(wolfThought);
  const crySoon = new Cry(wolfThought, { theme: child });
  const eat = new Eat(wolfThought, { theme: child });
  const expects = new Believes(root, { believer: wolf, content: wolfThought });
  input.push(crySoon, eat, expects);
  Happened(input, crySoon);
  Happened(input, eat, wolf);
  Assert(input, expects);

  const cry = new Cry(root, { theme: child });
  const comeForward = new ComeTo(root, { destination: window });
  const shutWindow = new Shut(root, { theme: window });
  const callForHelp = new CallForHelp(root);
  const rushOut = new RushOut(root, { theme: dogs });
  const gallopAway = new GallopAway(root);
  const happened = [
    [say, nurse],
    [crouch, wolf],
    [wait, wolf],
    [cry, child],
    [comeForward, wolf],
    [shutWindow, nurse],
    [callForHelp, nurse],
    [rushOut, dogs],
    [gallopAway, wolf],
  ];
  for (const [event, actor] of happened) Happened(input, event, actor);
  Chain(input, happened.map(([event]) => event));
  Bounds(input, storyStart, say, gallopAway, storyEnd);

  // "So he crouched down … and waited": his own expecting drove it.
  Assert(input, new Motivates(root, { driver: expects, action: wait }));

  // "But all the Nurse did was to shut down the window and call for
  // help" — at any moment from the cry on. The deed is a Virtual doing
  // of the nurse; its doing is pinned to a moment of the window by an At
  // around the whole body plus a Within on the moment (a Within on the
  // Virtual deed's own start does not refute; OBSERVATIONS G-2).
  const window2 = Duration(start(cry), storyEnd);
  const deed = new Event(root);
  const deedOccurs = new Occurs(root, { event: deed });
  const deedAgent = new Agent(root, { action: deed, actor: nurse });
  const deedBody = new And(root, { propositions: [deedAgent, deedOccurs] });
  const moment = new TimeAnchor(root);
  const deedAt = new At(root, { proposition: deedBody, anchor: moment });
  input.push(deed, deedOccurs, deedAgent, deedBody, moment, deedAt);
  input.push(new Virtual(root, { node: deed }));
  input.push(new Virtual(root, { node: moment }));
  input.push(new Within(root, { anchor: moment, duration: window2 }));
  Assert(input, new Only(root, { of: deed, among: [shutWindow, callForHelp] }));

  return {
    root,
    storyStart,
    storyEnd,
    nurse,
    child,
    wolf,
    say,
    threat,
    wolfThought,
    cry,
    wait,
    shutWindow,
    callForHelp,
    window: window2,
    deed,
  };
}
