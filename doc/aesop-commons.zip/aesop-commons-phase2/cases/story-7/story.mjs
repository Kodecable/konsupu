// BuildStory for "The Milkmaid and Her Pail". Patty's calculating is one
// plan context, spoken aloud as she goes: it holds her intended buyings,
// the fowls' imagined habit, Polly's imagined jealousy, and an imagined
// head-toss of its own — none of which the world holds or hosts in its
// Then chain. The real toss, the pail's fall, and the spilt milk are
// world events; the pail's two locations are explicit intervals (on her
// head from the start, on the ground from the fall). Nothing in the plan
// leaks into the world: no buying ever happened.
import {
  Agent,
  Assert,
  Buy,
  Causes,
  ComeTo,
  Duration,
  Enables,
  Fall,
  HeadTo,
  In,
  Jealous,
  LocatedAt,
  Then,
  Occurred,
  Plans,
  Routine,
  Sell,
  Speak,
  Lay,
  TimeAnchor,
  Toss,
  Virtual,
  Within,
  duration,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const patty = entity(root, "Patty the Milkmaid");
  const milk = entity(root, "her milk");
  const pail = entity(root, "the Pail");
  const market = entity(root, "the market");
  const head = entity(root, "her head");
  const ground = entity(root, "the ground");
  const home = entity(root, "home");
  const mother = entity(root, "her mother");
  input.push(patty, milk, pail, market, head, ground, home, mother);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The plan context: everything Patty worked out for the money.
  const plan = context(
    new Situation(),
    "what she would do with the money for the milk",
  );
  input.push(plan);
  const fowls = entity(plan, "some fowls");
  const farmerBrown = entity(plan, "Farmer Brown");
  const eggs = entity(plan, "eggs");
  const eachMorning = entity(plan, "each morning");
  const parsonsWife = entity(plan, "the parson's wife");
  const frock = entity(plan, "a new dimity frock");
  const hat = entity(plan, "a chip hat");
  const polly = entity(plan, "Polly Shaw");
  const youngMen = entity(plan, "all the young men");
  input.push(
    fowls,
    farmerBrown,
    eggs,
    eachMorning,
    parsonsWife,
    frock,
    hat,
    polly,
    youngMen,
  );

  // "The money she would get for the milk": the milk's sale, which the
  // plan presupposes. Each purchase is funded by a sale, so the money is
  // told apart by what was sold, never by a surface name.
  const sellMilk = new Sell(plan, { seller: patty, what: milk });
  const buyFowls = new Buy(plan, { what: fowls, from: farmerBrown });
  const layEggs = new Lay(plan, { theme: eggs });
  const sellEggs = new Sell(plan, {
    seller: patty,
    what: eggs,
    to: parsonsWife,
  });
  const buyClothes = new Buy(plan, { what: [frock, hat] });
  const menComeUp = new ComeTo(plan, { destination: patty });
  const plannedToss = new Toss(plan, {
    theme: head,
    manner: "like this",
  });
  const imagined = [sellMilk, buyFowls, sellEggs, buyClothes, menComeUp, plannedToss];
  for (const event of imagined) Occurred(input, event);
  Did(input, sellMilk, patty);
  Did(input, buyFowls, patty);
  Did(input, sellEggs, patty);
  Did(input, buyClothes, patty);
  Did(input, menComeUp, youngMen);
  Did(input, plannedToss, patty);

  const layHabit = new Routine(plan, {
    actor: fowls,
    deed: layEggs,
    frequency: eachMorning,
  });
  input.push(layEggs);
  input.push(new Virtual(plan, { node: layEggs }));
  Assert(input, layHabit, plan);
  Assert(
    input,
    new Jealous(plan, { subject: polly }),
    plan,
  );
  Assert(
    input,
    new Enables(plan, { enabler: sellMilk, enabled: buyFowls }),
    plan,
  );
  Assert(
    input,
    new Enables(plan, { enabler: sellEggs, enabled: buyClothes }),
    plan,
  );
  for (let index = 0; index + 1 < imagined.length; index += 1) {
    Assert(
      input,
      new Then(plan, { earlier: imagined[index], later: imagined[index + 1] }),
      plan,
    );
  }

  // "Was going to market": atelic — on the way, arrival never implied.
  const going = new HeadTo(root, { destination: market });
  const planSay = new Speak(root, {
    call:
      "I'll buy some fowls from Farmer Brown, and they will lay eggs each morning, which I will sell to the parson's wife...",
    content: plan,
  });
  const tossHead = new Toss(root, { theme: head, manner: "back" });
  const pailFell = new Fall(root, { theme: pail, destination: ground });
  const milkFell = new Fall(root, { theme: milk, destination: ground });
  const wentHome = new ComeTo(root, { destination: home });
  const toldMother = new Speak(root, {
    to: mother,
    call: "what had occurred",
  });
  const happened = [
    going,
    planSay,
    tossHead,
    pailFell,
    milkFell,
    wentHome,
    toldMother,
  ];
  for (const [event, actor] of [
    [going, patty],
    [planSay, patty],
    [tossHead, patty],
    [pailFell, undefined],
    [milkFell, undefined],
    [wentHome, patty],
    [toldMother, patty],
  ]) {
    Occurred(input, event);
    if (actor !== undefined) Did(input, event, actor);
  }
  // The world's chain skips the speaking-to-tossing step: they overlap.
  Chain(input, [going, planSay]);
  Chain(input, [tossHead, pailFell, milkFell, wentHome, toldMother]);
  Bounds(input, storyStart, going, toldMother, storyEnd);

  // "As she spoke she tossed her head back": the toss began inside the
  // speaking's own duration. (A sharing-one-moment Overlaps cannot be
  // edges in the anchor order, so the containment reading carries the
  // time fact.)
  Assert(
    input,
    new Within(root, { anchor: start(tossHead), duration: duration(planSay) }),
  );

  const pailOnHead = new LocatedAt(root, { entity: pail, place: head });
  input.push(pailOnHead);
  Assert(
    input,
    new In(root, {
      proposition: pailOnHead,
      duration: Duration(storyStart, start(pailFell)),
    }),
  );
  const pailOnGround = new LocatedAt(root, { entity: pail, place: ground });
  input.push(pailOnGround);
  Assert(
    input,
    new In(root, {
      proposition: pailOnGround,
      duration: Duration(start(pailFell), storyEnd),
    }),
  );

  Assert(input, new Causes(root, { cause: tossHead, effect: pailFell }));

  // The calculating runs from the going until the tossing.
  const planning = new Plans(root, { planner: patty, content: plan });
  input.push(planning);
  Assert(
    input,
    new In(root, {
      proposition: planning,
      duration: Duration(start(going), start(tossHead)),
    }),
  );

  return {
    root,
    patty,
    milk,
    pail,
    head,
    ground,
    plan,
    fowls,
    farmerBrown,
    tossHead,
    pailFell,
    storyStart,
    storyEnd,
  };
}
