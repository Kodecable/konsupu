// Frozen question texts and semantic expectations for "The Milkmaid and
// Her Pail" (guide section 6.3, Story 7). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did Patty plan to buy with the money from the milk?",
    semantic: "值:一些家禽(from Farmer Brown)",
    tests: "计划语境",
  },
  {
    text: "Who did Patty imagine would be jealous of her?",
    semantic: "值:Polly Shaw",
    tests: "想象语境内的态度",
  },
  {
    text: "Did Patty buy any fowls?",
    semantic: "未确立(想象不泄漏到 world;也不能答'否')",
    tests: "想象语境隔离",
  },
  {
    text: "What did Patty do just before the pail fell off her head?",
    semantic: "值:向后甩头(实际发生的那一次)",
    tests: "world 时序;想象中的甩头不进入 world 的 Then 链",
  },
  {
    text: "Where was the pail before Patty tossed her head back?",
    semantic: "值:她头上",
    tests: "时间锚定的状态",
  },
];

export const Twins = [
  {
    text: "Did Patty toss her head?",
    semantic: "是(实际的甩头确实发生了)",
  },
  {
    text: "In Patty's plan, what would the fowls do each morning?",
    semantic: "下蛋",
  },
];

// The five questions. The plan is a context: an Among into it reads its
// content; nothing there supports a world question either way, so "did
// she buy" is Unknown, not false. The world's own chain answers the
// sequencing and anchored-state questions; the imagined toss never
// enters that chain.
import {
  Agent,
  And,
  Buy,
  Duration,
  Enables,
  In,
  Jealous,
  LocatedAt,
  Then,
  Occurs,
  Routine,
  Sell,
  Situation,
  Toss,
  Validity,
  Virtual,
  duration,
  start,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

function seatIn(input, target, mentions) {
  const seat = new Situation(target);
  input.push(seat);
  mentions.push(seat);
  return seat;
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Buy(from=Entity(Farmer Brown),what=Entity(some fowls))",
    // The buying is the one enabled by the milk's sale: the enabling's
    // enabler side is a Virtual sale of the milk, the enabled side the
    // answer.
    build(input, asked, world, answer) {
      const sale = new Sell(asked, { what: world.milk });
      input.push(sale);
      input.push(new Virtual(asked, { node: sale }));
      const funding = new Enables(asked, { enabler: sale, enabled: answer });
      input.push(funding);
      among(input, funding, world.plan);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:Entity(Polly Shaw)",
    build(input, asked, world, answer) {
      const jealous = new Jealous(asked, { subject: answer });
      input.push(jealous);
      among(input, jealous, world.plan);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "Unknown",
    // Whether she ever bought anything: asked of the world, where no
    // buying is written. The plan's buyings are not world facts, and no
    // negation is held either way.
    build(input, asked, world, answer) {
      const buying = new Buy(asked);
      const occurred = PatternEvent(input, buying);
      const did = new Agent(asked, { action: buying, actor: world.patty });
      input.push(did);
      const joined = new And(asked, { propositions: [did, occurred] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:Toss(manner=back,theme=Entity(her head))",
    build(input, asked, world, answer) {
      const before = new Then(asked, {
        earlier: answer,
        later: world.pailFell,
      });
      input.push(before);
      among(input, before, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:Entity(her head)",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked, {
        entity: world.pail,
        place: answer,
      });
      input.push(where);
      const held = new In(asked, {
        proposition: where,
        duration: Duration(world.storyStart, start(world.tossHead)),
      });
      input.push(held);
      among(input, held, world.root);
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const toss = new Toss(asked, { theme: world.head });
      const occurred = PatternEvent(input, toss);
      const did = new Agent(asked, { action: toss, actor: world.patty });
      input.push(did);
      const joined = new And(asked, { propositions: [did, occurred] });
      input.push(joined);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:Entity(each morning)",
    // Asked inside the plan: the fowls' habit of laying, each morning.
    open(input, world, mentions) {
      return seatIn(input, world.plan, mentions);
    },
    build(input, seat, world, answer) {
      const laying = new Routine(seat, {
        actor: world.fowls,
        frequency: answer,
      });
      input.push(laying);
      among(input, laying, world.plan);
    },
  },
];
