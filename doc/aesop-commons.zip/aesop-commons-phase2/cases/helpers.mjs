// Fixture helpers shared by the story builders: construction sugar over the
// Commons vocabulary — the canonical occurrence write with agency, pattern
// events, the narration chain, story-boundary anchors, and the three-layer
// case assembly (dialogue root, story root, the question's seat Situation).
// The seat defaults to a child of the story; a question that evaluates in
// another context (a speech content, a belief) opens its own seat there.
import {
  Agent,
  Among,
  Assertion,
  Before,
  Imperative,
  KonsupuIdentity,
  Then,
  Occurs,
  Occurred,
  Query,
  Situation,
  Thing,
  Variable,
  Virtual,
  Within,
  In,
  Asks,
  Reply,
  duration,
  end,
  ref,
  start,
} from "../space/Interface/Aesop.js";

export function entity(situation, name) {
  const value = new Thing(situation);
  value.name = name;
  return value;
}

// Assert `proposition` (pushing it first unless it is already in Input) in
// `holder`; holding and introducing stay apart (12), so the holder may
// differ from the proposition's own Situation.
export function assert(input, proposition, holder = proposition.situated) {
  if (!input.includes(proposition)) input.push(proposition);
  const assertion = new Assertion(holder, { proposition });
  input.push(assertion);
  return proposition;
}

// An unasserted Agent(action, actor). Asserted in a story it states who
// acted; left unasserted it is a pattern constraint or a question
// description (13.2).
export function AgentOf(input, event, actor) {
  const agent = new Agent(event.situated, { action: event, actor });
  input.push(agent);
  return agent;
}

// The asserted agency of a story event.
export function Did(input, event, actor) {
  return assert(input, AgentOf(input, event, actor));
}

// The happened write: the canonical Occurred(e) plus, when an actor is
// given, its asserted agency.
export function Happened(input, event, actor) {
  Occurred(input, event);
  if (actor !== undefined) Did(input, event, actor);
  return event;
}

// A Virtual declaration over `node`, pushed next to it.
export function Virtualize(input, node) {
  const declaration = new Virtual(node.situated, { node });
  input.push(declaration);
  return declaration;
}

// An unasserted Among(node, situation) declaration: what node talks about
// is one of the things situation talks about.
export function among(input, node, situation) {
  const declaration = new Among(node.situated, { node, situation });
  input.push(declaration);
  return declaration;
}

// A Virtual pattern event: the event is declared Virtual — its anchors
// are Virtual with it, without declarations of their own (memo 8) — plus
// the unasserted canonical occurrence constraint In(Occurs(e),
// duration(e)). Explicitly Virtualizing the anchors as well would turn
// them into logic variables of their own and break the time fit of the
// canonical constraint.
export function PatternEvent(input, event) {
  input.push(event);
  Virtualize(input, event);
  input.push(start(event), end(event));
  const occurs = new Occurs(event.situated, { event });
  input.push(occurs);
  const during = new In(event.situated, {
    proposition: occurs,
    duration: duration(event),
  });
  input.push(during);
  return during;
}

// "Happened at some moment of `span`": the event's start lies within it
// (14.4). Not In(Occurs(e), span), which would demand e be happening at
// every point of the span.
export function StartsWithin(input, event, span) {
  return input.push(
    new Within(event.situated, { anchor: start(event), duration: span }),
  );
}

// Narrative adjacency between consecutive events; Before is the derived
// transitive closure (the Then domain rule), never enumerated by hand.
export function Chain(input, events) {
  for (let index = 0; index + 1 < events.length; index += 1) {
    assert(
      input,
      new Then(events[index].situated, {
        earlier: events[index],
        later: events[index + 1],
      }),
    );
  }
}

// What makes two free anchors the story's bounds: they bracket the whole
// narration (14.2 — the anchors carry no built-in "story start/end"
// meaning, so the input states the bracketing itself).
export function Bounds(input, storyStart, first, last, storyEnd) {
  assert(
    input,
    new Before(storyStart.situated, {
      earlier: storyStart,
      later: start(first),
    }),
  );
  assert(
    input,
    new Before(storyEnd.situated, { earlier: end(last), later: storyEnd }),
  );
}

// Builds the complete Input for one question. The dialogue root comes
// first (it is the initial Situation and needs no mention), the story root
// holds only fable facts, and the question's seat holds the question
// cognition and its Query. A question that evaluates inside another
// context opens its seat there through `open`; every Situation the seat or
// the question created gets its semantic mention through Asks. The
// dialogue's member nodes come last: an Asks naming story and seat, a
// re-exporting Query, the reply Reply over ref(seat, answer), and the
// Konsupu Imperative. A fresh graph per call; nothing is shared.
export function BuildCase(question, buildStory) {
  const dialogue = new Situation();
  const story = new Situation();
  const input = [dialogue, story];
  const world = buildStory(input, story);
  const mentions = [story];
  const seat = question.open
    ? question.open(input, world, mentions)
    : openAsked(input, world, mentions);
  const answer = new Variable(seat);
  input.push(answer);
  const extra = question.build(input, seat, world, answer) ?? [];
  input.push(new Query(seat, [answer, ...extra]));
  const asks = new Asks(dialogue);
  asks.story = story;
  asks.asked = seat;
  asks.reading = mentions.filter((item) => item !== story && item !== seat);
  input.push(asks);
  input.push(new Query(dialogue, [ref(seat, answer)]));
  const reply = new Reply(dialogue);
  reply.content = ref(seat, answer);
  input.push(reply);
  input.push(new Imperative(dialogue, KonsupuIdentity.Ref(), reply));
  return input;
}

function openAsked(input, world, mentions) {
  const asked = new Situation(world.root);
  input.push(asked);
  mentions.push(asked);
  return asked;
}
