// Five questions over the Lion-and-the-Mouse cognition. Every question is
// an explicit Among declaration; Q2's doer and successor constraints join
// inside one connected pattern. Expected answers are machine projections
// of the resolved values; the English `text` is for human comparison only
// and never reaches the resolver.
import {
  Agent,
  And,
  ForPurpose,
  Motivates,
  Then,
  Promises,
} from "../../space/Interface/Aesop.js";
import { among } from "../helpers.mjs";

export const Questions = [
  {
    text: "Who gnawed away the ropes?",
    expected: "OK:Entity(the mouse)",
    build(input, asked, world, answer) {
      const who = new Agent(asked, { action: world.gnaw, actor: answer });
      input.push(who);
      among(input, who, world.root);
    },
  },
  {
    text: "What did the hunters do after the lion got caught in the trap?",
    expected: "OK:Tie(destination=Entity(the tree),theme=Entity(the lion))",
    // "the hunters" constrains the doer; "after" the immediate successor of
    // the trapping. The two constraints join inside one And description:
    // both bind the same answer Variable, so only a doing that is at once
    // the hunters' and the trapping's successor survives.
    build(input, asked, world, answer) {
      const who = new Agent(asked, { action: answer, actor: world.hunters });
      const sequel = new Then(asked, {
        earlier: world.getTrapped,
        later: answer,
      });
      const joined = new And(asked, { propositions: [who, sequel] });
      input.push(who, sequel, joined);
      among(input, joined, world.root);
    },
  },
  {
    text: "Why did the lion spare the mouse?",
    // Expected changed in Phase 2: the offer is no longer a nominalized
    // Entity but the lion's idea context behind an unasserted believing;
    // the tickled amusement still drives the sparing.
    expected:
      "OK:Tickled(at=Believes(believer=Entity(the lion),content=Context(the Mouse being able to help him)),subject=Entity(the lion))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked, { driver: answer, action: world.spare });
      input.push(why);
      among(input, why, world.root);
    },
  },
  {
    text: "What did the mouse promise to do for the lion?",
    expected: "OK:Help(theme=Entity(the lion))",
    // "for the lion" needs no extra beneficiary cognition: the promised deed
    // is a single instance and helping takes its beneficiary as theme, so
    // the answer itself carries it.
    build(input, asked, world, answer) {
      const promise = new Promises(asked, { actor: world.mouse, deed: answer });
      input.push(promise);
      among(input, promise, world.root);
    },
  },
  {
    text: "Why did the hunters tie the lion to the tree?",
    expected: "OK:Carry(destination=Entity(the king),theme=Entity(the lion))",
    // The tie-up itself, not just its actor, anchors the question.
    build(input, asked, world, answer) {
      const why = new ForPurpose(asked, {
        action: world.tieUp,
        goal: answer,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
];
