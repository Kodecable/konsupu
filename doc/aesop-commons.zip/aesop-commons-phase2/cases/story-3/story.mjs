// BuildStory for "The Lion and the Mouse". Wake and GetTrapped are
// non-agentive events happening to the lion; the sayings are speech-act
// events. The intended and promised doings — eating the mouse, carrying
// the lion, helping — exist without occurring. The offer the lion was
// tickled at is no nominalized Entity (the r2 problem): it is the lion's
// idea, a context holding that the mouse would be able to help him; the
// amusement's `at` names that believing. The Believes itself stays
// unasserted: the text names an idea, not a lion's held belief (P6) — it
// only gives the idea its semantic mention. The sleep holds until the
// waking; freedom holds from the gnawing on; Before is never enumerated.
import {
  Asleep,
  Assert,
  Believes,
  Carry,
  Causes,
  Duration,
  Eat,
  ForPurpose,
  Free,
  GetTrapped,
  Gnaw,
  Goal,
  Help,
  In,
  LocatedAt,
  Motivates,
  Not,
  Occurred,
  PassBy,
  Promises,
  RunUpon,
  SearchFor,
  Seize,
  Speak,
  Spare,
  Tickled,
  TimeAnchor,
  Tie,
  Unable,
  Wake,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const lion = entity(root, "the lion");
  const mouse = entity(root, "the mouse");
  const hunters = entity(root, "the hunters");
  const trap = entity(root, "the trap");
  const tree = entity(root, "the tree");
  const rope = entity(root, "the ropes");
  const king = entity(root, "the king");
  const paw = entity(root, "his huge paw");
  const waggon = entity(root, "a waggon");
  input.push(lion, mouse, hunters, trap, tree, rope, king, paw, waggon);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // Intended or promised only; never written as happened. helpLion comes
  // early because the lion's idea mentions it.
  const eatMouse = new Eat(root, { theme: mouse });
  const carryLion = new Carry(root, { theme: lion, destination: king });
  const helpLion = new Help(root, { theme: lion });
  input.push(eatMouse, carryLion, helpLion);

  // "The idea of the Mouse being able to help him": a context whose
  // content is the mouse's not being unable to help.
  const idea = context(new Situation(), "the Mouse being able to help him");
  input.push(idea);
  const couldNotHelp = new Unable(idea, { actor: mouse, deed: helpLion });
  input.push(couldNotHelp);
  Assert(input, new Not(idea, { proposition: couldNotHelp }), idea);
  // "Tickled at the idea": the Believes is the idea's semantic mention and
  // the amusement's target, never a held belief of its own (P6).
  const hadIdea = new Believes(root, { believer: lion, content: idea });
  input.push(hadIdea);

  const plead = new Speak(root, {
    call:
      "Pardon, O King. Forgive me this time, I shall never forget it: who knows but what I may be able to do you a turn some of these days?",
  });
  const taunt = new Speak(root, { call: "Was I not right?" });

  const runOver = new RunUpon(root, { theme: lion });
  const wake = new Wake(root, { theme: lion });
  const seize = new Seize(root, { theme: mouse, instrument: paw });
  const spare = new Spare(root, { theme: mouse });
  const getTrapped = new GetTrapped(root, { theme: lion, location: trap });
  const tieUp = new Tie(root, { theme: lion, destination: tree });
  const searchWaggon = new SearchFor(root, { theme: waggon });
  const passBy = new PassBy(root);
  const gnaw = new Gnaw(root, { theme: rope });
  const happened = [
    runOver,
    wake,
    seize,
    plead,
    spare,
    getTrapped,
    tieUp,
    searchWaggon,
    passBy,
    gnaw,
    taunt,
  ];
  for (const event of happened) Occurred(input, event);

  for (const [event, actor] of [
    [runOver, mouse],
    [seize, lion],
    [spare, lion],
    [tieUp, hunters],
    [searchWaggon, hunters],
    [passBy, mouse],
    [gnaw, mouse],
    [plead, mouse],
    [taunt, mouse],
    [eatMouse, lion],
    [carryLion, hunters],
    [helpLion, mouse],
  ]) {
    Did(input, event, actor);
  }

  Chain(input, happened);
  Bounds(input, storyStart, runOver, taunt, storyEnd);

  // "This soon wakened the Lion": asleep until the waking, awake after.
  const asleep = new Asleep(root, { subject: lion });
  input.push(asleep);
  Assert(
    input,
    new In(root, {
      proposition: asleep,
      duration: Duration(storyStart, start(wake)),
    }),
  );
  const awake = new Not(root, { proposition: asleep });
  input.push(awake);
  Assert(
    input,
    new In(root, {
      proposition: awake,
      duration: Duration(start(wake), storyEnd),
    }),
  );

  Assert(input, new Causes(root, { cause: runOver, effect: wake }));

  const tickled = new Tickled(root, { subject: lion, at: hadIdea });
  input.push(tickled);
  Assert(input, tickled);
  Assert(input, new Motivates(root, { driver: tickled, action: spare }));

  // Free from the gnawing on.
  const freed = new Free(root, { subject: lion });
  input.push(freed);
  Assert(
    input,
    new In(root, {
      proposition: freed,
      duration: Duration(start(gnaw), storyEnd),
    }),
  );

  Assert(input, new Goal(root, { actor: lion, objective: eatMouse }));
  Assert(input, new Goal(root, { actor: hunters, objective: carryLion }));
  Assert(input, new ForPurpose(root, { action: tieUp, goal: carryLion }));
  Assert(input, new Promises(root, { actor: mouse, deed: helpLion }));

  return {
    root,
    lion,
    mouse,
    hunters,
    spare,
    getTrapped,
    tieUp,
    gnaw,
    idea,
  };
}
