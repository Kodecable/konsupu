// BuildStory for "The Ass's Brains". The message, the lion's orders, and
// the fox's reply are three speech contexts: the proposal lives in the
// message, the prohibition in the orders, the negated possession in the
// reply — the world holds none of them. The world does hold the ass's
// brains from the start until the fox takes them out, so the reply's
// claim is false at the time it is about (the trap-time), and the lion's
// noticing reads the absence that starts at the taking. "Finding that
// his master did not return" is the fox's perception of a negated
// happening, its content never world-held. The lion's away-ness is an
// anchored state the eating lies inside.
import {
  Advise,
  Agent,
  Assert,
  Away,
  ComeBack,
  ComeTo,
  Duration,
  Eat,
  Forbids,
  GoAway,
  Has,
  Hunt,
  In,
  Missing,
  Notice,
  Not,
  Occurred,
  Occurs,
  Overjoyed,
  Proposes,
  Pounce,
  Speak,
  Take,
  TimeAnchor,
  Touch,
  Wait,
  At,
  context,
  end,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, Happened, Virtualize, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const lion = entity(root, "the Lion");
  const fox = entity(root, "the Fox");
  const ass = entity(root, "the Ass");
  const brains = entity(root, "the brains of the Ass");
  const prey = entity(root, "the prey");
  const meetingPlace = entity(root, "the place of meeting");
  input.push(lion, fox, ass, brains, prey, meetingPlace);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The message: an alliance proposed.
  const messageCtx = context(new Situation(), "the message to the Ass");
  input.push(messageCtx);
  const alliance = entity(messageCtx, "an alliance between their two families");
  input.push(alliance);
  Assert(
    input,
    new Proposes(messageCtx, {
      proposer: lion,
      to: ass,
      proposal: alliance,
    }),
    messageCtx,
  );

  // The lion's orders: the prohibition on touching the prey.
  const ordersCtx = context(new Situation(), "the Lion's orders to the Fox");
  input.push(ordersCtx);
  const touchPrey = new Touch(ordersCtx, { theme: prey });
  const forbidden = new Forbids(ordersCtx, {
    authority: lion,
    subject: fox,
    deed: touchPrey,
  });
  input.push(touchPrey, forbidden);
  Assert(input, forbidden, ordersCtx);

  // The fox's reply: the ass had no brains — "or it would never have
  // fallen into your trap", so what he says is about the trap-time, the
  // pounce; the reply holds the claim anchored there.
  const replyCtx = context(new Situation(), "the Fox's reply");
  input.push(replyCtx);
  const lacked = new Has(replyCtx, { holder: ass, thing: brains });
  const noBrains = new Not(replyCtx, { proposition: lacked });
  input.push(lacked, noBrains);

  // The ass had its brains from the start, until they were taken out.
  const hadBrains = new Has(root, { holder: ass, thing: brains });
  input.push(hadBrains);

  const wentHunting = new Hunt(root);
  const message = new Speak(root, {
    to: ass,
    call: "proposing to make an alliance between their two families",
    content: messageCtx,
  });
  // "On the advice of the Fox": advising the lion to send that message.
  const advice = new Advise(root, { to: lion, advised: message });
  const assCame = new ComeTo(root, { destination: meetingPlace });
  const lionPounce = new Pounce(root, { theme: ass });
  const lionSay = new Speak(root, {
    to: fox,
    call:
      "Here is our dinner for to-day. Watch you here while I go and have a nap. Woe betide you if you touch my prey.",
    content: ordersCtx,
  });
  const lionAway = new GoAway(root);
  const foxWaited = new Wait(root);
  // "Finding that his master did not return": the fox's perception of a
  // negated happening, its content never world-held. The perceived
  // content enters the Input before the perceiving that names it.
  const lionBack = new ComeBack(root);
  input.push(lionBack, start(lionBack), end(lionBack));
  const masterBack = new Occurs(root, { event: lionBack });
  const notReturning = new Not(root, { proposition: masterBack });
  input.push(masterBack, notReturning);
  const foxFinding = new Notice(root, { seer: fox, theme: notReturning });
  const takeBrains = new Take(root, { theme: brains, source: ass });
  const ateBrains = new Eat(root, { theme: brains });
  const missing = new Missing(root, { thing: brains });
  // The noticed absence enters the Input before the noticing.
  input.push(missing);
  const lionNotice = new Notice(root, { seer: lion, theme: missing });
  const lionAsk = new Speak(root, {
    to: fox,
    call: "What have you done with the brains?",
  });
  const foxReply = new Speak(root, {
    call:
      "Brains, your Majesty! it had none, or it would never have fallen into your trap.",
    content: replyCtx,
  });
  const happened = [
    wentHunting,
    advice,
    message,
    assCame,
    lionPounce,
    lionSay,
    lionAway,
    foxWaited,
    foxFinding,
    takeBrains,
    ateBrains,
    lionNotice,
    lionAsk,
    foxReply,
  ];
  // The advice names the message, so the message enters the Input
  // before the advice that mentions it; Input order is never time — the
  // chain below is.
  input.push(message);
  for (const [event, actor] of [
    [wentHunting, lion],
    [wentHunting, fox],
    [advice, fox],
    [message, lion],
    [assCame, ass],
    [lionPounce, lion],
    [lionSay, lion],
    [lionAway, lion],
    [foxWaited, fox],
    [foxFinding, fox],
    [takeBrains, fox],
    [ateBrains, fox],
    [lionBack, lion],
    [lionNotice, lion],
    [lionAsk, lion],
    [foxReply, fox],
  ]) {
    Occurred(input, event);
    Did(input, event, actor);
  }
  Chain(input, [...happened.slice(0, 11), lionBack, ...happened.slice(11)]);
  Bounds(input, storyStart, wentHunting, foxReply, storyEnd);

  // The reply's claim, at the time it is about.
  const noBrainsAt = new At(replyCtx, {
    proposition: noBrains,
    anchor: start(lionPounce),
  });
  input.push(noBrainsAt);
  Assert(input, noBrainsAt, replyCtx);

  Assert(
    input,
    new In(root, {
      proposition: hadBrains,
      duration: Duration(storyStart, start(takeBrains)),
    }),
  );

  const glad = new Overjoyed(root, { subject: ass });
  input.push(glad);
  Assert(
    input,
    new In(root, {
      proposition: glad,
      duration: Duration(start(assCame), storyEnd),
    }),
  );

  const gone = new Away(root, { subject: lion });
  input.push(gone);
  Assert(
    input,
    new In(root, {
      proposition: gone,
      duration: Duration(start(lionAway), start(lionBack)),
    }),
  );

  Assert(
    input,
    new In(root, {
      proposition: missing,
      duration: Duration(start(takeBrains), storyEnd),
    }),
  );

  return {
    root,
    lion,
    fox,
    ass,
    brains,
    prey,
    messageCtx,
    ordersCtx,
    replyCtx,
    noBrains,
    noBrainsAt,
    advice,
    assCame,
    lionAway,
    lionBack,
    takeBrains,
    ateBrains,
    missing,
    lionNotice,
  };
}
