// Frozen question texts and semantic expectations for "The Ass's
// Brains" (guide section 6.3, Story 12). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the lion propose to the ass?",
    semantic: "值:两家结盟",
    tests: "言语内容",
  },
  {
    text: "What did the lion forbid the fox to do?",
    semantic: "值:碰他的猎物",
    tests: "禁令(否定的祈使内容)",
  },
  {
    text: "What did the fox eat while the lion was away?",
    semantic: "值:驴的脑子",
    tests: "'while' 区间",
  },
  {
    text: "What did the lion notice when he came back?",
    semantic: "值:脑子不见了",
    tests: "N6 缺失被感知",
  },
  {
    text: "Was the fox telling the truth when he said the ass had no brains?",
    semantic: "否",
    tests: "所说内容关于更早的时间;被持有的拥有反驳",
  },
];

export const Twins = [
  {
    text: "Did the ass have brains when he came to the place of meeting?",
    semantic: "是(脑子一直在,直到狐狸取出)",
  },
  {
    text: "Who advised the lion to send the message?",
    semantic: "the fox",
  },
];

// The five questions. The proposal and the prohibition are read inside
// their speech contexts; the while-eating joins the fox's eating with
// its start inside the away-window; the noticing reads the absence; the
// reply's claim is judged in the world at the time it is about.
import {
  Agent,
  And,
  At,
  Eat,
  Forbids,
  Has,
  Notice,
  Proposes,
  Situation,
  Touch,
  Validity,
  Virtual,
  Within,
  Duration,
  start,
} from "../../space/Interface/Aesop.js";
import { among } from "../helpers.mjs";

function seatIn(input, target, mentions) {
  const seat = new Situation(target);
  input.push(seat);
  mentions.push(seat);
  return seat;
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(an alliance between their two families)",
    build(input, asked, world, answer) {
      const proposed = new Proposes(asked, {
        proposer: world.lion,
        to: world.ass,
        proposal: answer,
      });
      input.push(proposed);
      among(input, proposed, world.messageCtx);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:Touch(theme=Entity(the prey))",
    build(input, asked, world, answer) {
      const forbidden = new Forbids(asked, {
        authority: world.lion,
        subject: world.fox,
        deed: answer,
      });
      input.push(forbidden);
      among(input, forbidden, world.ordersCtx);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:Entity(the brains of the Ass)",
    // "While the lion was away": the eating's start lies inside the
    // away-window, and the eater is the fox; both join on one Virtual
    // eating whose theme is the answer.
    build(input, asked, world, answer) {
      const meal = new Eat(asked, { theme: answer });
      const did = new Agent(asked, { action: meal, actor: world.fox });
      const during = new Within(asked, {
        anchor: start(meal),
        duration: Duration(start(world.lionAway), start(world.lionBack)),
      });
      const joined = new And(asked, { propositions: [did, during] });
      input.push(meal, start(meal), did, during, joined);
      input.push(new Virtual(asked, { node: meal }));
      among(input, joined, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:Missing(thing=Entity(the brains of the Ass))",
    build(input, asked, world, answer) {
      const noticed = new Notice(asked, { seer: world.lion, theme: answer });
      input.push(noticed);
      among(input, noticed, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      input.push(
        new Validity(asked, {
          proposition: world.noBrainsAt,
          variable: answer,
        }),
      );
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    build(input, asked, world, answer) {
      const held = new Has(asked, {
        holder: world.ass,
        thing: world.brains,
      });
      const at = new At(asked, {
        proposition: held,
        anchor: start(world.assCame),
      });
      input.push(held, at);
      input.push(new Validity(asked, { proposition: at, variable: answer }));
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:Entity(the Fox)",
    build(input, asked, world, answer) {
      const who = new Agent(asked, { action: world.advice, actor: answer });
      input.push(who);
      among(input, who, world.root);
    },
  },
];
