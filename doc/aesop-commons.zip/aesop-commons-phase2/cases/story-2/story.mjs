// BuildStory for "The Fox and the Crow". Speaking is a speech-act event
// (Speak) whose content is a speech context — a root Situation holding
// what was said, never the world. The flattery claim is introduced by the
// fox's flattery context, which holds it as said; the crow's belief
// context holds the very same proposition object as believed (holding is
// decided by the Assertion's Situation, not by where the object sits).
// The world never holds the claim: the text only flatters, it never says
// the crow's voice was worse than other birds', so nothing supports it
// (P6). The belief's own topicality — what the belief is about — is an
// About held by the belief context. The cheese's fall is a non-agentive
// Fall with the cheese as theme; the chain asserts adjacent Then only;
// the cheese's two locations hold on their own intervals, each bounded by
// the event that made it so.
import {
  About,
  Assert,
  Believes,
  Causes,
  Duration,
  Fall,
  FlyOff,
  ForPurpose,
  Goal,
  In,
  LocatedAt,
  Motivates,
  Occurred,
  Settle,
  Sing,
  SnapUp,
  Speak,
  TimeAnchor,
  VoiceSurpasses,
  DistrustFlatterers,
  WalkUpTo,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Agent } from "../../space/Interface/Aesop.js";
import { Bounds, Chain, Did, assert, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const fox = entity(root, "the fox");
  const crow = entity(root, "the crow");
  const voice = entity(root, "the crow's voice");
  const cheese = entity(root, "the cheese");
  const branch = entity(root, "a branch of the tree");
  const footOfTree = entity(root, "the foot of the tree");
  const ground = entity(root, "the ground");
  const jaws = entity(root, "the fox's jaws");
  const otherBirds = entity(root, "other birds");
  input.push(
    fox,
    crow,
    voice,
    cheese,
    branch,
    footOfTree,
    ground,
    jaws,
    otherBirds,
  );

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The flattery speech context introduces and holds the claim; the
  // crow's belief context holds the same object; the world holds neither.
  const speech = context(new Situation(), "the fox's flattery");
  input.push(speech);
  const claimVoice = new VoiceSurpasses(speech, {
    subject: crow,
    others: otherBirds,
  });
  Assert(input, claimVoice, speech);

  const adviceSpeech = context(new Situation(), "the fox's advice");
  input.push(adviceSpeech);
  const advice = new DistrustFlatterers(adviceSpeech);
  Assert(input, advice, adviceSpeech);

  const belief = context(new Situation(), "her voice surpasses other birds");
  input.push(belief);
  assert(input, claimVoice, belief);
  // What the belief is about: her voice. Held by the belief context, so a
  // question can read the believed proposition by its topic.
  Assert(
    input,
    new About(belief, { proposition: claimVoice, topic: voice }),
    belief,
  );

  const flyOff = new FlyOff(root, { theme: cheese });
  const settle = new Settle(root, { location: branch });
  const approach = new WalkUpTo(root, { destination: footOfTree });
  const greet = new Speak(root, {
    call: "Good-day, Mistress Crow. How well you are looking to-day.",
  });
  const flatter = new Speak(root, {
    call:
      "How glossy your feathers; how bright your eye; I feel sure your voice must surpass that of other birds.",
    content: speech,
  });
  const request = new Speak(root, {
    call:
      "Let me hear but one song from you, that I may greet you as the Queen of Birds.",
  });
  const sing = new Sing(root, { manner: "her best" });
  const dropCheese = new Fall(root, { theme: cheese, destination: ground });
  const snapUp = new SnapUp(root, { theme: cheese });
  const gloat = new Speak(root, {
    call:
      "That will do. That was all I wanted. In exchange for your cheese I will give you a piece of advice for the future.",
  });
  const advise = new Speak(root, {
    call: "Do not trust flatterers.",
    content: adviceSpeech,
  });
  const chain = [
    flyOff,
    settle,
    approach,
    greet,
    flatter,
    request,
    sing,
    dropCheese,
    snapUp,
    gloat,
    advise,
  ];
  for (const [event, actor] of [
    [flyOff, crow],
    [settle, crow],
    [approach, fox],
    [greet, fox],
    [flatter, fox],
    [request, fox],
    [sing, crow],
    [dropCheese, undefined],
    [snapUp, fox],
    [gloat, fox],
    [advise, fox],
  ]) {
    Occurred(input, event);
    if (actor !== undefined) Did(input, event, actor);
  }
  Chain(input, chain);
  Bounds(input, storyStart, flyOff, advise, storyEnd);

  Assert(input, new Causes(root, { cause: sing, effect: dropCheese }));

  // The cheese's two locations: on the ground from the fall until the
  // snapping up, in the jaws from the snapping up on.
  const cheeseOnGround = new LocatedAt(root, {
    entity: cheese,
    place: ground,
  });
  input.push(cheeseOnGround);
  Assert(
    input,
    new In(root, {
      proposition: cheeseOnGround,
      duration: Duration(start(dropCheese), start(snapUp)),
    }),
  );
  const cheeseInJaws = new LocatedAt(root, { entity: cheese, place: jaws });
  input.push(cheeseInJaws);
  Assert(
    input,
    new In(root, {
      proposition: cheeseInJaws,
      duration: Duration(start(snapUp), storyEnd),
    }),
  );

  Assert(input, new Goal(root, { actor: fox, objective: snapUp }));
  Assert(input, new ForPurpose(root, { action: flatter, goal: sing }));

  const believedPraise = new Believes(root, {
    believer: crow,
    content: belief,
  });
  Assert(input, believedPraise);
  Assert(input, new Motivates(root, { driver: believedPraise, action: sing }));

  return {
    root,
    fox,
    crow,
    voice,
    cheese,
    ground,
    sing,
    dropCheese,
    snapUp,
    speech,
    belief,
    claimVoice,
  };
}
