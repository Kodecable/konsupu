// Five questions over the Fox-and-the-Crow cognition. Every question is
// an explicit declaration — an Among over a description (6.2); multi-part
// constraints join inside one connected pattern (a Virtual position plus
// the propositions mentioning it, 6.4). Expected answers are machine
// projections of the resolved values; the English `text` is for human
// comparison only and never reaches the resolver.
import {
  About,
  Agent,
  Causes,
  Event,
  Fall,
  Get,
  Goal,
  Then,
  Virtual,
} from "../../space/Interface/Aesop.js";
import { among } from "../helpers.mjs";

export const Questions = [
  {
    text: "What fell to the ground?",
    expected: "OK:Entity(the cheese)",
    // "to the ground" constrains the fall's destination; the theme is the
    // unknown, read through the description's own field.
    build(input, asked, world, answer) {
      const f = new Fall(asked, { destination: world.ground, theme: answer });
      input.push(f);
      among(input, f, world.root);
    },
  },
  {
    text: "What happened when the crow began to sing?",
    expected: "OK:Fall(destination=Entity(the ground),theme=Entity(the cheese))",
    // "when" asks what followed the singing at once: the unique holding
    // Then whose earlier side is the singing.
    build(input, asked, world, answer) {
      const when = new Then(asked, { earlier: world.sing, later: answer });
      input.push(when);
      among(input, when, world.root);
    },
  },
  {
    text: "What did the crow believe about her voice?",
    expected:
      "OK:VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))",
    // The belief is a context; an Among over a proposition into it picks
    // among the propositions that hold there. The topic ("about her
    // voice") is the belief's own About, so the description asks for the
    // believed proposition by its topic.
    build(input, asked, world, answer) {
      const held = new About(asked, {
        proposition: answer,
        topic: world.voice,
      });
      input.push(held);
      among(input, held, world.belief);
    },
  },
  {
    text: "What did the fox want to get?",
    expected: "OK:Entity(the cheese)",
    // The wanting is the Goal; its objective is a Virtual getting whose
    // theme is the answer. The open Get class describes the getting
    // without deciding how the story words the seizing.
    build(input, asked, world, answer) {
      const getting = new Get(asked, { theme: answer });
      input.push(getting);
      input.push(new Virtual(asked, { node: getting }));
      const want = new Goal(asked, { actor: world.fox, objective: getting });
      input.push(want);
      among(input, want, world.root);
    },
  },
  {
    text: "Who made the cheese fall?",
    expected: "OK:Entity(the crow)",
    // One connected pattern joins the unknown causing event with its
    // unknown agent: the Agent description is the head, the Virtual event
    // position is the join, and the Causes constraint rides along.
    build(input, asked, world, answer) {
      const deed = new Event(asked);
      input.push(deed);
      input.push(new Virtual(asked, { node: deed }));
      const who = new Agent(asked, { action: deed, actor: answer });
      input.push(who);
      input.push(
        new Causes(asked, { cause: deed, effect: world.dropCheese }),
      );
      among(input, who, world.root);
    },
  },
];
