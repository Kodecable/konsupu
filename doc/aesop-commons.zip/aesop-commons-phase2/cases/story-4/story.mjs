// BuildStory for "The Dog and the Shadow". The dog's belief is a context
// of its own: it holds "another dog carrying another piece of meat" —
// both objects exist only there. The identification "that dog was in
// truth his own shadow" is the narrator's Corresponds, held by the world
// (12.2 of the trial revision: the belief does not know it is a shadow).
// The world can mention the belief-specific object (the dog's goal wants
// it) without corresponding it to anything real. The meat's two
// locations are explicit intervals — in the mouth from the story start
// until the drop, in the water from the drop on — and "never seen more"
// is a NoInstance over a seeing pattern whose start lies in the window
// after the drop. No one deceives the dog, and the story never says so.
import {
  Assert,
  Believes,
  Carrying,
  Causes,
  Corresponds,
  Cross,
  Duration,
  ForPurpose,
  Get,
  Goal,
  In,
  LocatedAt,
  NoInstance,
  Occurs,
  See,
  SnapAt,
  Fall,
  TimeAnchor,
  Within,
  context,
  duration,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import {
  Bounds,
  Chain,
  Did,
  Happened,
  PatternEvent,
  StartsWithin,
  entity,
} from "../helpers.mjs";

export function BuildStory(input, root) {
  const dog = entity(root, "the dog");
  const meat = entity(root, "the piece of meat");
  const mouth = entity(root, "the dog's mouth");
  const plank = entity(root, "a plank lying across a running brook");
  const water = entity(root, "the water beneath");
  const shadow = entity(root, "his own shadow reflected in the water");
  const home = entity(root, "home");
  input.push(dog, meat, mouth, plank, water, shadow, home);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The dog's belief context: another dog carrying another piece of meat.
  // Both objects exist only here.
  const belief = context(
    new Situation(),
    "it was another dog with another piece of meat",
  );
  input.push(belief);
  const otherDog = entity(belief, "another dog");
  const otherMeat = entity(belief, "another piece of meat");
  input.push(otherDog, otherMeat);
  Assert(
    input,
    new Carrying(belief, { carrier: otherDog, theme: otherMeat }),
    belief,
  );

  // "He saw in the water what he took to be another dog ... it was in
  // truth his own shadow": the identification is the narrator's. A
  // Corresponds takes effect by occurring (6.1), never by Assertion.
  input.push(new Corresponds(root, { left: otherDog, right: shadow }));

  // "He made up his mind to have that also": a world goal whose object
  // exists only in the belief. It never happened.
  const getOtherMeat = new Get(root, { theme: otherMeat });
  input.push(getOtherMeat);

  const crossPlank = new Cross(root, { what: plank });
  const seeShadow = new See(root, { theme: shadow, place: water });
  const snapAt = new SnapAt(root, { theme: shadow });
  const dropMeat = new Fall(root, { theme: meat, destination: water });
  const happened = [crossPlank, seeShadow, snapAt, dropMeat];
  for (const [event, actor] of [
    [crossPlank, dog],
    [seeShadow, dog],
    [snapAt, dog],
    [dropMeat, undefined],
  ]) {
    Happened(input, event, actor);
  }
  Chain(input, happened);
  Bounds(input, storyStart, crossPlank, dropMeat, storyEnd);

  const meatInMouth = new LocatedAt(root, { entity: meat, place: mouth });
  input.push(meatInMouth);
  Assert(
    input,
    new In(root, {
      proposition: meatInMouth,
      duration: Duration(storyStart, start(dropMeat)),
    }),
  );
  const meatInWater = new LocatedAt(root, { entity: meat, place: water });
  input.push(meatInWater);
  Assert(
    input,
    new In(root, {
      proposition: meatInWater,
      duration: Duration(start(dropMeat), storyEnd),
    }),
  );

  // "As he opened his mouth the piece of meat fell out": the snap and the
  // opening are one.
  Assert(input, new Causes(root, { cause: snapAt, effect: dropMeat }));

  // "Was carrying it home in his mouth": a carrying state from the
  // story's start until the drop — never an arrived-home event.
  const carrying = new Carrying(root, { carrier: dog, theme: meat });
  input.push(carrying);
  Assert(
    input,
    new In(root, {
      proposition: carrying,
      duration: Duration(storyStart, start(dropMeat)),
    }),
  );

  // "As he crossed, he looked in and saw": the seeing began inside the
  // crossing's own duration, not after it. (A sharing-one-moment Overlaps
  // cannot be edges in the anchor order: overlapping spans do not order
  // their starts, so the containment reading carries the time fact.)
  Assert(
    input,
    new Within(root, { anchor: start(seeShadow), duration: duration(crossPlank) }),
  );

  // The seeing made the dog believe; the belief lasts the story out (the
  // text never corrects it).
  const believed = new Believes(root, { believer: dog, content: belief });
  input.push(believed);
  Assert(
    input,
    new In(root, {
      proposition: believed,
      duration: Duration(start(seeShadow), storyEnd),
    }),
  );
  Assert(input, new Causes(root, { cause: seeShadow, effect: believed }));

  Assert(input, new Goal(root, { actor: dog, objective: getOtherMeat }));
  Assert(
    input,
    new ForPurpose(root, { action: snapAt, goal: getOtherMeat }),
  );

  // "And was never seen more": no seeing of the meat whose start lies in
  // the window from the drop on.
  const seenPattern = new See(root, { theme: meat });
  PatternEvent(input, seenPattern);
  StartsWithin(input, seenPattern, Duration(start(dropMeat), storyEnd));
  Assert(input, new NoInstance(root, { of: seenPattern }));

  return {
    root,
    dog,
    meat,
    mouth,
    water,
    shadow,
    snapAt,
    dropMeat,
    belief,
    otherDog,
    otherMeat,
    getOtherMeat,
    storyStart,
    storyEnd,
  };
}
