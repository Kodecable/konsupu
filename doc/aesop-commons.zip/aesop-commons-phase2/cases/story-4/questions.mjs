// Frozen question texts and semantic expectations for "The Dog and the
// Shadow" (guide section 6.3, Story 4). The English text never changes;
// `semantic` is binding. The machine `expected` is fixed at
// implementation and must agree with `semantic`; later changes need a
// per-question RESULTS note. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the dog think his shadow was?",
    // Guide erratum (confirmed): the question asks what the shadow was
    // taken to be, not what that dog was doing; the carrying stays a
    // characterization held in the belief.
    semantic: "值:另一只狗(信念语境中影子的对应者)",
    tests: "信念语境;同一指称跨语境的不同刻画",
  },
  {
    text: "What did the dog really see in the water?",
    semantic: "值:他自己的影子",
    tests: "world 语境;Q1 的对照",
  },
  {
    text: "Where was the piece of meat before the dog snapped at the shadow?",
    semantic: "值:狗的嘴里",
    tests: "时间锚定的状态",
  },
  {
    text: "Where did the piece of meat end up?",
    semantic: "值:水里",
    tests: "终态;与 Q3 同一实体、不同时间,各自唯一",
  },
  {
    text: "Why did the dog snap at the shadow?",
    semantic: "值:想把另一块肉也弄到手(目标的对象只存在于信念中)",
    tests: "world 中的目标指向信念专有对象",
  },
];

export const Twins = [
  {
    text: "Did the dog get the other piece of meat?",
    semantic: "未确立",
  },
  {
    text: "Did anyone deceive the dog?",
    semantic: "未确立(误信不蕴含欺骗)",
  },
];

// The five questions. Q1 asks through a Corresponds whose other side is
// the shadow: the answer is the belief's counterpart of it (6.3). Q3's
// "before" is the whole pre-snap window (the state held throughout it);
// Q4's "ended up" is the interval from the drop on. Expected answers are
// machine projections of the resolved values.
import {
  Corresponds,
  Deceives,
  Duration,
  ForPurpose,
  Get,
  In,
  LocatedAt,
  Occurs,
  See,
  Validity,
  Virtual,
  duration,
  start,
} from "../../space/Interface/Aesop.js";
import { among, PatternEvent } from "../helpers.mjs";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(another dog)",
    build(input, asked, world, answer) {
      input.push(
        new Corresponds(asked, { left: answer, right: world.shadow }),
      );
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:Entity(his own shadow reflected in the water)",
    build(input, asked, world, answer) {
      const d = new See(asked, { theme: answer, place: world.water });
      input.push(d);
      among(input, d, world.root);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:Entity(the dog's mouth)",
    // "Before the snap" is the whole window from the story start until
    // the snapping: the meat held at every point of it was in the mouth.
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked, {
        entity: world.meat,
        place: answer,
      });
      input.push(where);
      const held = new In(asked, {
        proposition: where,
        duration: Duration(world.storyStart, start(world.snapAt)),
      });
      input.push(held);
      among(input, held, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:Entity(the water beneath)",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked, {
        entity: world.meat,
        place: answer,
      });
      input.push(where);
      const held = new In(asked, {
        proposition: where,
        duration: Duration(start(world.dropMeat), world.storyEnd),
      });
      input.push(held);
      among(input, held, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:Get(theme=Entity(another piece of meat))",
    build(input, asked, world, answer) {
      const why = new ForPurpose(asked, {
        action: world.snapAt,
        goal: answer,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
];

// Guide twins, executable: the same machinery, opposite or different
// answers — a solver that answers "no" to everything fails these. Both
// are yes-no questions over unasserted patterns with no support and no
// refutation: open-world Unknown.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const getting = new Get(asked, { theme: world.otherMeat });
      const happened = PatternEvent(input, getting);
      input.push(
        new Validity(asked, { proposition: happened, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const deceived = new Deceives(asked, { victim: world.dog });
      input.push(deceived);
      input.push(new Validity(asked, { proposition: deceived, variable: answer }));
    },
  },
];
