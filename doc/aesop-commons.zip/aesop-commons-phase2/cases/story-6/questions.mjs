// Frozen question texts and semantic expectations for "The Miser and His
// Gold" (guide section 6.3, Story 6). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Where did the miser use to hide his gold?",
    semantic: "值:花园里一棵树的树脚下",
    tests: "习惯性状态",
  },
  {
    text: "How often did the miser dig up his gold?",
    semantic: "值:每周",
    tests: "习惯的频率",
  },
  {
    text: "Who took the gold?",
    semantic: "值:the robber",
    tests: "单次事件(复用 Agent)",
  },
  {
    text: "What did the miser find when he next came to gloat over his treasures?",
    semantic: "值:那个空洞",
    tests: "习惯的下一次实例;N5 穷尽",
  },
  {
    text: "According to the miser, did he ever take any of the gold out?",
    semantic: "否(在吝啬鬼所说的语境中)",
    tests: "言语语境中的是非问;'Nay' 承接问句内容",
  },
];

export const Twins = [
  {
    text: "Did the miser ever take any of the gold out?",
    semantic: "未确立(world;只有他自己的说法)",
  },
  {
    text: "Was the gold in the hole when the miser next came?",
    semantic: "否",
  },
];

// The five questions. Habits are read through their Virtual deed shapes
// (the Routine's pattern field); the taking through the open Get class;
// the finding through the successor of the habit's next instance joined
// in one pattern; the miser's own "Nay" through a Validity evaluated
// inside his speech context, where his NoInstance negates the taking.
import {
  Agent,
  And,
  At,
  DigUp,
  Duration,
  Find,
  Get,
  Hide,
  In,
  Then,
  Routine,
  Situation,
  Take,
  Validity,
  Virtual,
  duration,
  start,
} from "../../space/Interface/Aesop.js";
import { Occurs } from "../../space/Interface/Aesop.js";
import { among } from "../helpers.mjs";
import { PatternEvent } from "../helpers.mjs";

function seatIn(input, target, mentions) {
  const seat = new Situation(target);
  input.push(seat);
  mentions.push(seat);
  return seat;
}

// The taking-with-actor pattern of the "Nay" questions: one And body
// asking whether the miser ever did such a taking. PatternEvent pushes
// the event, its Virtual anchors and the canonical occurrence
// constraint; the And adds the actor.
function everTook(input, situation, world) {
  const taking = new Take(situation, {
    theme: world.gold,
    source: world.hole,
  });
  PatternEvent(input, taking);
  const did = new Agent(situation, { action: taking, actor: world.miser });
  input.push(did);
  const joined = new And(situation, { propositions: [input[input.length - 2], did] });
  input.push(joined);
  return joined;
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(the foot of a tree in his garden)",
    build(input, asked, world, answer) {
      const deed = new Hide(asked, { theme: world.gold, place: answer });
      input.push(deed);
      input.push(new Virtual(asked, { node: deed }));
      const habit = new Routine(asked, { actor: world.miser, deed });
      input.push(habit);
      among(input, habit, world.root);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "OK:Entity(every week)",
    build(input, asked, world, answer) {
      const deed = new DigUp(asked, { theme: world.gold });
      input.push(deed);
      input.push(new Virtual(asked, { node: deed }));
      const habit = new Routine(asked, {
        actor: world.miser,
        deed,
        frequency: answer,
      });
      input.push(habit);
      among(input, habit, world.root);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:Entity(a robber)",
    build(input, asked, world, answer) {
      const taking = new Get(asked, { theme: world.gold });
      input.push(taking);
      input.push(new Virtual(asked, { node: taking }));
      const who = new Agent(asked, { action: taking, actor: answer });
      input.push(who);
      among(input, who, world.root);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "OK:Entity(the empty hole)",
    // The finding is the miser's, and the immediate successor of the
    // habit's next instance; both constraints share one Virtual event.
    build(input, asked, world, answer) {
      const found = new Find(asked, { theme: answer });
      input.push(found);
      input.push(new Virtual(asked, { node: found }));
      const finder = new Agent(asked, { action: found, actor: world.miser });
      input.push(finder);
      const when = new Then(asked, { earlier: world.miserVisit, later: found });
      input.push(when);
      among(input, finder, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:false",
    open(input, world, mentions) {
      return seatIn(input, world.miserCtx, mentions);
    },
    build(input, seat, world, answer) {
      const joined = everTook(input, seat, world);
      input.push(
        new Validity(seat, { proposition: joined, variable: answer }),
      );
    },
  },
];

// Guide twins, executable: the world-side twin stays Unknown (the Nay's
// NoInstance lives only in the miser's context), and the gold-in-hole
// twin is refuted by the explicit emptiness interval.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const joined = everTook(input, asked, world);
      input.push(
        new Validity(asked, { proposition: joined, variable: answer }),
      );
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "OK:false",
    build(input, asked, world, answer) {
      const held = new At(asked, {
        proposition: world.goldInHole,
        anchor: start(world.miserVisit),
      });
      input.push(held);
      input.push(new Validity(asked, { proposition: held, variable: answer }));
    },
  },
];
