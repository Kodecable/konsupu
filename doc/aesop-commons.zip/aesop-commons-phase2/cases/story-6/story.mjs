// BuildStory for "The Miser and His Gold". Two habits generalize the
// weekly practice without enumerating it; the "next coming" is one event
// tied to the digging habit by an explicit Instance. The robber's taking
// is a Steal, which the open Get class matches. The neighbour's question
// and the miser's "Nay" are speech contexts; the answer context holds a
// NoInstance over any taking of the gold out of the hole — the world
// holds no such negation. The gold leaves the hole at the robber's
// digging: located at the robber from then on, and explicitly not in the
// hole (the empty hole), so "was the gold in the hole" is refuted, not
// merely unstated. No finding of the gold happens from the visit on.
import {
  Agent,
  Assert,
  ComeTo,
  Duration,
  Find,
  ForPurpose,
  Gloat,
  Hide,
  DigUp,
  In,
  Instance,
  LocatedAt,
  NoInstance,
  Not,
  Notice,
  Occurred,
  Occurs,
  Routine,
  See,
  Speak,
  Steal,
  Take,
  TimeAnchor,
  AskAbout,
  context,
  duration,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import {
  Bounds,
  Chain,
  Did,
  PatternEvent,
  StartsWithin,
  entity,
} from "../helpers.mjs";

export function BuildStory(input, root) {
  const miser = entity(root, "the miser");
  const gold = entity(root, "his gold");
  const footOfTree = entity(root, "the foot of a tree in his garden");
  const hole = entity(root, "the empty hole");
  const robber = entity(root, "a robber");
  const neighbours = entity(root, "the neighbours");
  const week = entity(root, "every week");
  input.push(miser, gold, footOfTree, hole, robber, neighbours, week);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // "Used to hide his gold at the foot of a tree; every week he used to
  // go and dig it up and gloat": two habits, no enumerated visits.
  const hideDeed = new Hide(root, { theme: gold, place: footOfTree });
  PatternEvent(input, hideDeed);
  Assert(
    input,
    new Routine(root, { actor: miser, deed: hideDeed }),
  );
  const digDeed = new DigUp(root, { theme: gold });
  PatternEvent(input, digDeed);
  const digHabit = new Routine(root, {
    actor: miser,
    deed: digDeed,
    frequency: week,
  });
  Assert(input, digHabit);

  const goldInHole = new LocatedAt(root, { entity: gold, place: hole });
  input.push(goldInHole);

  // The neighbour's question introduces the taking pattern the "Nay"
  // answers.
  const questionCtx = context(new Situation(), "the neighbour's question");
  input.push(questionCtx);
  const takeOut = new Take(questionCtx, { theme: gold, source: hole });
  PatternEvent(input, takeOut);

  // The miser's answer: no taking of the gold out of the hole, ever. The
  // world holds no such negation — only the miser says it.
  const miserCtx = context(new Situation(), "the miser's answer");
  input.push(miserCtx);
  const deniedTake = new Take(miserCtx, { theme: gold, source: hole });
  PatternEvent(input, deniedTake);
  input.push(new Agent(miserCtx, { action: deniedTake, actor: miser }));
  Assert(input, new NoInstance(miserCtx, { of: deniedTake }), miserCtx);

  const robNotice = new Notice(root, { theme: digHabit });
  const robDig = new DigUp(root, { theme: gold });
  const robSteal = new Steal(root, { theme: gold });
  const miserVisit = new ComeTo(root, { destination: footOfTree });
  const foundHole = new Find(root, { theme: hole });
  const outcry = new Speak(root, { call: "such an outcry" });
  const neighboursCome = new ComeTo(root, { destination: miser });
  const toldThem = new Speak(root, {
    call: "how he used to come and visit his gold",
  });
  const neighbourAsk = new AskAbout(root, {
    to: miser,
    call: "Did you ever take any of it out?",
    content: questionCtx,
  });
  const miserNay = new Speak(root, {
    call: "Nay, I only came to look at it.",
    content: miserCtx,
  });
  const neighbourAdvice = new Speak(root, {
    to: miser,
    call: "Then come again and look at the hole; it will do you just as much good.",
  });
  const happened = [
    robNotice,
    robDig,
    robSteal,
    miserVisit,
    foundHole,
    outcry,
    neighboursCome,
    toldThem,
    neighbourAsk,
    miserNay,
    neighbourAdvice,
  ];
  for (const [event, actor] of [
    [robNotice, robber],
    [robDig, robber],
    [robSteal, robber],
    [miserVisit, miser],
    [foundHole, miser],
    [outcry, miser],
    [neighboursCome, neighbours],
    [toldThem, miser],
    [neighbourAsk, neighbours],
    [miserNay, miser],
    [neighbourAdvice, neighbours],
  ]) {
    Occurred(input, event);
    Did(input, event, actor);
  }
  Chain(input, happened);
  Bounds(input, storyStart, robNotice, neighbourAdvice, storyEnd);

  // The gold stayed in the hole until the robber's digging.
  Assert(
    input,
    new In(root, {
      proposition: goldInHole,
      duration: Duration(storyStart, start(robDig)),
    }),
  );

  // "When the Miser next came to gloat": the coming happened; the
  // gloating is its purpose, never an occurred event. The visit is the
  // weekly practice's next single event.
  const gloatDeed = new Gloat(root, { theme: gold });
  input.push(gloatDeed);
  Assert(
    input,
    new ForPurpose(root, { action: miserVisit, goal: gloatDeed }),
  );
  Assert(input, new Instance(root, { habit: digHabit, event: miserVisit }));

  // "Dug up the gold": out of the hole and with the robber from the
  // digging ("a robber … decamped with it" is the lexical basis); the
  // hole is empty of the gold from then on.
  const goldGone = new LocatedAt(root, { entity: gold, place: robber });
  input.push(goldGone);
  Assert(
    input,
    new In(root, {
      proposition: goldGone,
      duration: Duration(start(robDig), storyEnd),
    }),
  );
  const holeEmptied = new Not(root, { proposition: goldInHole });
  input.push(holeEmptied);
  Assert(
    input,
    new In(root, {
      proposition: holeEmptied,
      duration: Duration(start(robDig), storyEnd),
    }),
  );

  // "He found nothing but the empty hole": no finding of the gold whose
  // start lies in the window from the visit on.
  const findGold = new Find(root, { theme: gold });
  PatternEvent(input, findGold);
  StartsWithin(input, findGold, Duration(start(miserVisit), storyEnd));
  Assert(input, new NoInstance(root, { of: findGold }));

  return {
    root,
    miser,
    gold,
    footOfTree,
    hole,
    robber,
    digHabit,
    robSteal,
    robDig,
    miserVisit,
    foundHole,
    goldInHole,
    miserCtx,
    questionCtx,
  };
}
