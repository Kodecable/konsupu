// Frozen question texts and semantic expectations for "The Fox and the
// Mask" (guide section 6.3, Story 5). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the fox at first take the mask to be?",
    semantic: "值:一张正俯视着瞪着他的脸",
    tests: "较早的信念",
  },
  {
    text: "Why was the fox frightened?",
    semantic: "值:他以为有一张脸在瞪着他(这份误认/信念,不是面具本身)",
    tests: "情绪的原因是信念",
  },
  {
    text: "After looking more closely, did the fox still think a face was glaring down on him?",
    semantic: "否",
    tests: "信念修正;'only a Mask'",
  },
  {
    text: "How did the fox get into the store-room?",
    semantic: "未知('by some means')",
    tests: "事件发生、方式未写",
  },
  {
    text: "What did the fox say the mask did not have?",
    semantic: "值:brains",
    tests: "N4 言语内容中的否定",
  },
];

export const Twins = [
  {
    text: "When the fox first observed it, did he think a face was glaring down on him?",
    semantic: "是",
  },
];

// The five questions. Belief revision is two belief contexts introduced
// by Believes on different intervals; the question translates "at first"
// and "after looking more closely" by referencing the interval that fits
// (the engine has no context-picking question form). Q3 and the twin
// judge inside the belief itself: the seat Situation is a child of the
// belief context, so its knowledge is exactly what the fox then held.
// The unstated way (Means) resolves to Unknown — no fact writes the
// means, and matching demands it.
import {
  Causes,
  Has,
  Means,
  Not,
  SameReferent,
  Situation,
  Validity,
} from "../../space/Interface/Aesop.js";
import { among } from "../helpers.mjs";

function seatIn(input, target, mentions) {
  const seat = new Situation(target);
  input.push(seat);
  mentions.push(seat);
  return seat;
}

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "OK:Entity(a face glaring down on him)",
    build(input, asked, world, answer) {
      const identification = new SameReferent(asked, {
        left: world.mask,
        right: answer,
      });
      input.push(identification);
      among(input, identification, world.firstBeliefCtx);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected:
      "OK:Believes(believer=Entity(the fox),content=Context(a face was glaring down on him))",
    // The fright is a singleton of the story, so the question references
    // the node itself: a Virtual cannot type a proposition position
    // (Virtual modifies contextual objects only, 6.4).
    build(input, asked, world, answer) {
      const why = new Causes(asked, {
        cause: answer,
        effect: world.frightened,
      });
      input.push(why);
      among(input, why, world.root);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "OK:false",
    open(input, world, mentions) {
      return seatIn(input, world.secondBeliefCtx, mentions);
    },
    build(input, seat, world, answer) {
      const stillFace = new SameReferent(seat, {
        left: world.mask,
        right: world.face,
      });
      input.push(stillFace);
      input.push(new Validity(seat, { proposition: stillFace, variable: answer }));
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Unknown",
    build(input, asked, world, answer) {
      const how = new Means(asked, { event: world.enterStore, means: answer });
      input.push(how);
      among(input, how, world.root);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "OK:Entity(brains)",
    build(input, asked, world, answer) {
      const lacking = new Has(asked, { holder: world.mask, thing: answer });
      input.push(lacking);
      const denied = new Not(asked, { proposition: lacking });
      input.push(denied);
      among(input, denied, world.remarkContext);
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "OK:true",
    open(input, world, mentions) {
      return seatIn(input, world.firstBeliefCtx, mentions);
    },
    build(input, seat, world, answer) {
      const asFace = new SameReferent(seat, {
        left: world.mask,
        right: world.face,
      });
      input.push(asFace);
      input.push(new Validity(seat, { proposition: asFace, variable: answer }));
    },
  },
];
