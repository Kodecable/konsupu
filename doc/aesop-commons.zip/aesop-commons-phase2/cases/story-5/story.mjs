// BuildStory for "The Fox and the Mask". The fox's two beliefs are two
// contexts introduced by Believes on different intervals: the mask is a
// glaring face until the closer look, only a mask (a held Not of the
// identification, lexical "only") from then on. The fright is caused by
// the first believing, not by the mask: emotion follows belief, and the
// text never says the fright ended. The fox's remark is a speech context
// holding the negated possession ("you have not got any brains"); the
// world never holds it. How the fox got into the store-room is stated as
// a Means whose means is left unwritten: a way exists, unstated.
import {
  Assert,
  Believes,
  Causes,
  Duration,
  Enter,
  Frightened,
  Has,
  In,
  LookClosely,
  Means,
  Not,
  Occurred,
  See,
  SameReferent,
  Speak,
  TimeAnchor,
  context,
  start,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";
import { Bounds, Chain, Did, entity } from "../helpers.mjs";

export function BuildStory(input, root) {
  const fox = entity(root, "the fox");
  const mask = entity(root, "the Mask");
  const storeRoom = entity(root, "the store-room of a theatre");
  input.push(fox, mask, storeRoom);

  const storyStart = new TimeAnchor(root);
  const storyEnd = new TimeAnchor(root);
  input.push(storyStart, storyEnd);

  // The earlier mistaken belief: the observed thing is a face glaring
  // down. The face exists only in this belief.
  const firstBeliefCtx = context(
    new Situation(),
    "a face was glaring down on him",
  );
  input.push(firstBeliefCtx);
  const face = entity(firstBeliefCtx, "a face glaring down on him");
  input.push(face);
  const tookAsFace = new SameReferent(firstBeliefCtx, {
    left: mask,
    right: face,
  });
  input.push(tookAsFace);
  Assert(input, tookAsFace, firstBeliefCtx);

  // The corrected belief: "only a Mask" — not a face (lexical "only").
  const secondBeliefCtx = context(
    new Situation(),
    "it was only a Mask such as actors use",
  );
  input.push(secondBeliefCtx);
  Assert(
    input,
    new Not(secondBeliefCtx, { proposition: tookAsFace }),
    secondBeliefCtx,
  );

  const believedFace = new Believes(root, {
    believer: fox,
    content: firstBeliefCtx,
  });
  input.push(believedFace);
  const believedMask = new Believes(root, {
    believer: fox,
    content: secondBeliefCtx,
  });
  input.push(believedMask);

  // The fox's remark: a speech context holding the negated possession.
  const remarkCtx = context(new Situation(), "the fox's remark on the mask");
  input.push(remarkCtx);
  const brains = entity(remarkCtx, "brains");
  input.push(brains);
  const lacks = new Has(remarkCtx, { holder: mask, thing: brains });
  input.push(lacks);
  Assert(
    input,
    new Not(remarkCtx, { proposition: lacks }),
    remarkCtx,
  );

  const enterStore = new Enter(root, { place: storeRoom });
  const observe = new See(root, { theme: mask });
  const lookClose = new LookClosely(root, { theme: mask });
  const remark = new Speak(root, {
    call: "Ah, you look very fine; it is a pity you have not got any brains.",
    content: remarkCtx,
  });
  const happened = [enterStore, observe, lookClose, remark];
  for (const [event, actor] of [
    [enterStore, fox],
    [observe, fox],
    [lookClose, fox],
    [remark, fox],
  ]) {
    Occurred(input, event);
    Did(input, event, actor);
  }
  Chain(input, happened);
  Bounds(input, storyStart, enterStore, remark, storyEnd);

  // The two believings and their intervals.
  Assert(
    input,
    new In(root, {
      proposition: believedFace,
      duration: Duration(start(observe), start(lookClose)),
    }),
  );
  Assert(
    input,
    new In(root, {
      proposition: believedMask,
      duration: Duration(start(lookClose), storyEnd),
    }),
  );

  // "Began to be very frightened" at the observation; the text never
  // says the fright ended, so no ending is written (P2 cuts both ways).
  const frightened = new Frightened(root, { subject: fox });
  input.push(frightened);
  Assert(
    input,
    new In(root, {
      proposition: frightened,
      duration: Duration(start(observe), storyEnd),
    }),
  );

  // "By some means": the entering had a way, which the text leaves
  // unstated — an unwritten means, not a missing Means, and no cause at
  // all (a "why" stays unanswered).
  const someMeans = new Means(root, { event: enterStore });
  input.push(someMeans);
  Assert(input, someMeans);

  // The fright is caused by the believing, not by the mask itself.
  Assert(input, new Causes(root, { cause: believedFace, effect: frightened }));

  return {
    root,
    fox,
    mask,
    storeRoom,
    enterStore,
    observe,
    lookClose,
    remark,
    firstBeliefCtx,
    face,
    secondBeliefCtx,
    believedFace,
    frightened,
    remarkContext: remarkCtx,
    brains,
  };
}
