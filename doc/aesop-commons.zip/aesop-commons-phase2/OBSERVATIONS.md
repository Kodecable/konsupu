# 用 Konsupu Commons 重新实现 aesop-phase2 的观察记录

重实现目录：`run/aesop-commons-phase2/`（2026-10-06）。
任务：把 `run/aesop-phase2`（13 故事 65 问 + 回归 + 变异，phase2 自有求解器）
在 `src/commons`（Commons 引擎 + 词表）之上重新实现，过程中检查记录
Commons 是否顺手自然、是否有 bug。

处置约定（用户确认）：**src/commons 只记录不修改**。领域层能绕过的绕过，
绕不过的改用可工作的形状并记录；本语料 65 问 + 20 回归 + 10 变异全部跑绿，
没有因引擎缺口而标红的题，但若干形状是绕行（见 B-1、B-5、B-6）。

基线（初版）：`node run.mjs` → 回归 20/20 + 问题 65/65；`node mutation.mjs` →
10 条定向变异各击穿至少一项检查（更正后的基线见第 6 节）；空间自检（Foundation + Commons 两套
published 自检）在 node 下直接通过。

---

## 0. 总评

**Commons 的求解面（Among / Corresponds / Validity + 开放世界 + 显式时间区间）
足够覆盖 aesop-phase2 全部 65 问的语义，且多数问法的翻译比 phase2 短。**
词表 + 规则的扩展 API（FIELDS / variance / pattern / Judge / Derive / Order）
够用：phase2 求解器的 ~36 个文件（QuerySolver/Search/Verdicts/Negation/
Temporal/Order/Anchors/Covering/Shapes/Reading/…）在 Commons 版整体消失，
领域层只剩 11 个文件 750 行（词表 + 投影 + 祈使入口）。

代价集中在三处：**带时间窗的否定**（B-1，规范自己的示例形状不工作，需
At-moment 绕行形状）、**序数**（B-6，翻译层解决，回归无法移植）、以及
**"多约束 join" 必须显式组形**（B-8，And 或 Virtual 连通分量，phase2 的
字段子集匹配没有对应物）。另有若干隐蔽的方向敏感点（B-2、B-3）没有任何
lint 拦截，只能靠踩坑发现。

---

## 1. Bug 与缺口（按严重度）

### B-1（最重要）：规范 §10.3 的窗口化 Only/NoInstance 示例形状不产生反驳

规范 10.3 自己给出的写法是

```text
e = Action()
Virtual(e)
Agent(action=e, actor=x)
Within(start(e), afterCry)                 // e happened after the child cried
Only(of=e, among=[shutWindow, callHelp])
```

以最小复现验证（nurse/child/cry/shut/call + 上述 Only，问"did the nurse
throw the child"）：**结果是 Unknown，不是 OK:false**。原因链：

- `start(e)`（Virtual 事件的锚点）虽然 `IsVirtual` 为真（Index.js 的
  锚点随事件规则），但它**不是 POINTS 位置**：`Within.POINTS = ["anchor"]`
  枚举的是 Within 自己的 anchor 字段，该字段的值 `start(e)` 经 Deref 到
  PENDING（e 未绑定）就停住，不参与 KnownPoints 枚举；
- 于是模式约束 `Within(start(e), D)` 的 Judge 拿到 PENDING，返回 null，
  嵌入子证明（Embeddings → Solve(PatternItems)）失败，Excludes 不成立。

**规范与实现在此直接冲突**（规范 16.11 只把 Next/Nth 列为未定义，10.3 的
窗口写法是正文示例）。可工作的绕行形状（S8Q4、S10Q5 采用，已验证）：

```text
deed = Virtual Event;  moment = Virtual TimeAnchor
At(And[Agent(deed, actor), Occurs(deed)], moment)   // 整体 At 到时刻
Within(moment, window)                              // 时刻落在窗口内
Only(of=deed, among=[…])        // 或 NoInstance(of=deed)
```

配套注意：被判断体也要带窗口（`In(And[Agent, Occurs], window)`），且模式
里**每个约束都必须继承时间限定**——未修饰项的时间是 AllTime，
`Subset(ALL, 窗口事实)` 为 false，匹配直接失败（见 B-7）。canonical
`In(Occurs(e), duration(e))` 在 Virtual 事件上同样不可用（其锚点无序，
放不进窗口）。

### B-2：显式 Virtual 化事件锚点会静默破坏 canonical 发生约束

`aesop-commons-test` 试验的 `PatternEvent` 把 `start(e)`/`end(e)` 也显式
`Virtual` 声明。在真引擎下这让 canonical `In(Occurs(e), duration(e))` 的
时间修饰退化为 **set 类型的 var**（锚点成为独立逻辑变量），FitTimes 的
set 分支把锚点变量绑到事实的整段时间上而失败——S6Q5 一度 Unknown。
实现备忘第 8 条明确"Virtual 事件的锚点随事件一起是 Virtual，无需另行
声明"；但显式声明**既不报错也不警告**，症状只是下游 Unknown。建议：
lint 增加"事件锚点不得显式 Virtual"或文档在 16.8 下强调。

### B-3：Corresponds 组的代表元方向敏感，类规则只能看到代表元

Corresponds 组的代表元 = Input 中最早的成员（7.3，也是优先答案）。规则经
`api.Value` 读字段时 Deref 到的是**代表元**。S11Q5（"他说的下井理由是真话
吗"→否）依赖 ForPurpose 的类规则识别 action 是 Chance 事件：偶然掉落
（世界事件）与言语中的"跳下"（言语事件）Corresponds 同组，若言语节点
先入 Input，代表元是言语节点，规则看不到 Chance，答案 Unknown。把掉落
**提前 push** 后才 OK。这一顺序依赖完全不可见，建议在文档或 lint 层面
处理（例如规则 API 提供"组的任一成员满足谓词"的读取）。

### B-4：没有"表层文本不参与匹配"规则（phase2 的 SURFACE）

`name` 是普通开放字段，**参与 Fit 字段匹配**：同名节点能被名字约束选中
（回归 `names:` 锁定实际行为 OK:true）。phase2 有 SURFACE 豁免。本语料
靠"描述中永不写 name"避开；规范未置可否，建议明示。

### B-5：Forbids / Mandates 没有否定后果规则

Commons 的 Forbids/Mandates 只有 deed 方向（pattern/variance），没有
Excludes/Fails——"被禁止的不会发生 / 不得"推不出来。S13Q2（"按狐狸的
消息，兽可以伤鸟吗"→否）只能把"许可问句"译为**禁令本身成立性**
（Validity(Forbids)=OK:true 读作"否"），已在 RESULTS 记录映射。备忘
16.3 只提 NoInstance/Only；Forbids 的后果语义建议补。

### B-6：无序数机制（规范 16.11 已缓期，此处记录实际冲击）

S6Q4（"when he next came"）、S10Q1/Q2/Q3/Q5（first/second/third time）
的序数在翻译层解决（直引对应的 cry/visit 节点）。phase2 的回归
"在更早处插入一个匹配事件，序数随之移动"**无法移植**——翻译解析的序数
不会随故事变化移动。这一条是本轮最大的语义能力缺口，若后续语料常有
序数，建议优先实装（模式内"恰有 n−1 个更早匹配"或锚点序上的选择子）。

### B-7：未修饰问题项是 AllTime，匹配不上区间事实

按 14.7 这是规范行为，但对译者的冲击值得记录：问区间化状态必须**自带
时间限定**（`In(P-desc, window)` / `At(P-desc, anchor)`），裸描述（时间
= AllTime）对任何区间事实都是 Subset=false 不匹配 → Unknown。phase2 的
"问题字段 ⊆ 故事字段"匹配更宽容。由此得到的标准问形：
- "P 在 X 之前什么状态" = `In(P-desc, Duration(storyStart, start(X)))`；
- "P 最终在哪" = `In(P-desc, Duration(start(X), storyEnd))`；
- "窗口内发生了 D 吗" = `In(And[Agent, Occurs], window)`（时刻形）。

### B-8：join 必须显式组形；多声明是"值一致"不是"候选交集"

两条相关引擎特性：
1. **Among 只看自己的连通分量**。描述里只有普通 Variable（无 Virtual）
   时，兄弟未断言命题不是约束——phase2 那种"两个 held 约束自然 join"
   不存在。通用 join 写法是 **`And([约束1, 约束2])` 作为描述节点**
   （Flatten 展开成多 item 一起求解，S3Q2/S4Q1/S12Q3 采用），或把类型
   位置做成 Virtual 进连通分量（S2Q5/S3Q2 备选）。常量描述节点可再经
   它自己的 Among 在 Deref 中解析（S1Q1 的两-Among 形状）。
2. **Combine 取最差 status + 值一致**：同一变量的多个声明**不交集**，
   值不同即 Ambiguous。想缩窄候选必须用 1 的单分量 join。

### B-9：语境内看不到世界持有的 Corresponds

对应只在持有者 Situation 及其后代可见（规范 6.3）。S10Q1 的目的命题在
计划语境中、叙述者的 Corresponds(cryPlan, cry1) 在世界——计划语境的 KB
里两者不可互换，只能按内容匹配（Virtual Cry 模式）。符合规范，但与
B-3 叠加时（跨语境 + 代表元）排障成本高。

### B-10：区间触点即冲突（闭区间设计），状态边界要用事件端点分开

`In(P, [a,c])` 与 `In(Not(P), [c,d])` 在 c 处冲突 → Ambiguous（备忘 5.1
"暴露翻译错误"，规范 14.7）。S11Q4 一度 Ambiguous:[true,false]：无能力
区间 `[start(fall), start(goatJump)]` 与恢复区间 `[start(goatJump), …]`
共享端点。解法：恢复区间从 `end(goatJump)` 起（能力在山羊下完之后回来，
语义也更准）。这是每个"状态 + 期后否定"对都要小心的点。

---

## 2. 顺手之处（按证据强度）

1. **是非问一条声明**。`Validity(P, v) + Query(v)` 取代 phase2 的
   AskWhether + verdict 包装 + NotEstablished{constraints, level} 整层；
   未确立从开放世界自然得到 Unknown。全部 20 道是非/未确立题（含 twins）
   无一需要失败分级。
2. **读语境不需要专门机制**。`Among(node=描述, situation=语境)` 直入
   （S5Q1/Q5、S7Q1/Q2、S12Q1/Q2）；"按某人的说法"类问题在语境下开
   seat 子 Situation（question.open），KB 即该语境——S6Q5、S13Q2、S5Q3、
   S10 twin2 四处同一形状，引擎零改动。
3. **Corresponds 问"其实是什么"**。S4Q1（狗以为影子是什么）、S11Q1
   （他其实怎么进的井）都是一条 `Corresponds(left=answer, right=X)`
   声明，7.3 的"优先非问侧成员"正好给出对方。
4. **Virtual + pattern 字段的 Subsume** 让"开放类 + 细化"免费：Get 被
   Take/Steal/SnapUp 细化、GetOut 被 JumpUp 细化，"拿走/逃出"类问题不用
   猜故事的措辞（phase2 同款设计在 Commons 下直接成立）。
5. **类规则 API 够表达**：Next→Before（Derive）、Chance↛ForPurpose
   （Judge + instanceof，经 Corresponds/Rep 读到真实事件类）、Within
   成员判定（Judge+POINTS）。phase2 的 Order/覆盖/形状三套机制全部由
   锚点序 + Fit/Subsume 吸收。
6. **lint 真的有牙且信息可操作**：声明不接受 Assertion、Virtual 不修饰
   命题、Not 不含时间修饰、Query 无声明——每条都有对应负例回归；错误
   信息直接给出规则号和改法。
7. **领域层小**：11 文件 750 行（phase2 求解器+词表 ~90 文件）。字节级
   overlay（foundation 副本 + commons 副本 + Aesop 增量）在 node 下直接
   跑，回归每次运行核对两个副本。

## 3. 不顺手之处

1. **发生样板**：每个发生事件 canonical 写法 6+ 节点（PatternEvent 吸收
   后仍是 6 次 push）；story-1 Q1 全 Input 159 节点 vs phase2 124
   （+28%，与试验 G3 的预测一致）。显式区间状态双写（P + Not(P)）与
   storyStart/storyEnd + Bounds 起手式同样延续试验 G4/G7。
2. **入序纪律**：包装者必须后于被包装者入 Input（In⊃Not⊃状态、锚点
   先于 duration 值、被感知内容先于感知）——Analyze 报错清楚，但整个
   迁移过程最高频的返工就是这类 push 顺序。
3. **FIELDS 继承的开放性陷阱**：子类一旦自带 FIELDS 就成为最近声明者，
   必须重申 `OPEN = true` 否则意外封闭（Speech/ForPurpose/Routine 都踩
   过设计层面的一次）。
4. **命题位置不能 Virtual**（lint 禁止，规范 6.4）：类型化命题位置只能
   直引单例或 And-join，问句翻译时要多想一步（S5Q2 教训）。
5. **don't-care 时刻不可用**：模式里放一个仅作"某时刻"的 Virtual 锚点，
   它会成为 Distinct 的比较维度，多时刻解 → Ambiguous（S4Q3 改用整窗
   In 形状的直接原因）。窗口问形的"整窗成立"与"某刻成立"要按语义挑。

## 4. 与 phase2 的机器答案映射（RESULTS 详表的基础）

| phase2 | Commons 版 |
|---|---|
| `Entity(x)` / `Class(…)` | `OK:Entity(x)` / `OK:Class(…)`（Result 盒带状态） |
| `{result=yes}` / `{result=no}` | `OK:true` / `OK:false` |
| `NotEstablished{constraints,level}` | `Unknown` |
| `{result=conflict}` | `Ambiguous:[true,false]`（闭区间触点等构造） |
| — | `NoMethod`（本轮语料未出现） |

初版有 4 题按补集翻译（S9Q5/S11Q4/S13Q3 "could …?" 问无能力，S13Q2
"may …?" 问禁令，OK:true 读作“否”），已改为按问句极性翻译（第 6 节）。

## 5. 建议给 Commons 的改进清单（按收益排序）

1. 修 B-1（窗口化 Only/NoInstance 的 start(e) 形状）或在规范/实现备忘
   明示 At-moment 形状为 canonical；顺带给 14.10 的"何时"问形一个
   don't-care 时刻的标准解法（第 3.5 条）。
2. 实装或明确缓期序数（B-6）。
3. lint：锚点显式 Virtual 警告（B-2）；可选"描述中出现 name 字段"提示
   （B-4）。
4. Forbids/Mandates 的后果规则或文档明示"许可问题=规范成立性"（B-5）。
5. 文档：Corresponds 代表元对规则 API 的可见性（B-3）；join 的 And 形状
   与 Combine 语义写成 7.2/7.3 的问法指引（B-8）。

---

## 6. 后续处置（2026-10-06，Commons 更新后）

按第 1 节逐条核实后，Commons 侧与本目录各自做了更正。本目录仍是
`src/commons` 的字节级副本（已重新同步）。

| 编号 | 核实结论 | 处置 |
|---|---|---|
| B-1 | **原因判断有误。** 规范 10.3 的 `Within(start(e), D)` 形状本身可用：问句写成“开始于 D”时被正确排除。初版复现中的 Unknown 来自问句与模式的时间窗不一致：“D 的每一点都在做”“D 的某一时刻在做”都推不出“开始于 D”（事可能在 D 之前就开始了），Unknown 是正确结果。“`start(e)` 卡在 PENDING”的机制并不存在 | 规范 13.1 补充时间窗的蕴含规则与对照表；Commons 新增 `TestWindowMatch`；翻译指引第 6 节 |
| B-2 | 属实 | Commons lint：`Virtual` 修饰 Event 锚点即报错 |
| B-3 | 属实，且比记录的更严重：代表元决定组的类与字段，信念或话语中的描述会泄漏进世界，答案随 Input 顺序翻转（违反原则 2） | Commons 修复：组的描述来自判断所在 Situation 链上的全部成员，与顺序无关；规则用 `api.Is` 读类。S11 掉落回到叙事位置；变异 `groups-earliest-member-only` 以 S11Q5 守护 |
| B-4 | 现行为与原则 1、4 一致 | 暂不改（`surface` 字段选项暂缓） |
| B-5 | `Forbids` 不推出“不发生”是正确的。许可问句可直接问 `Not(Forbids)`，能力问句可问 `In(Not(Unable), D)`，补集翻译不必要 | 4 题改为按问句极性翻译（RESULTS） |
| B-6 | — | Commons 新增 `Nth`、`Next`（规范 10.5）：否定无需封闭，成立需同一模式头上的 `Only`/`NoInstance` 封闭。本目录叙事的“然后”改名为 `Then`，避免与 Commons 的 `Next` 冲突；序数题仍由翻译解析，未迁移 |
| B-7、B-8、B-10 | 符合规范 | 收入翻译指引 |
| B-9 | 符合规范 | B-3 修复后跨语境排查成本降低 |

**回归 `chance` 的更正。** 初版在世界中断言了“偶然的掉落是为了有水”，
又在世界中问它，期望规则压过断言得 `OK:false`。这是自相矛盾的输入：
世界同时认定它有目的、又因它是偶然而没有目的。Commons 现按规范 8.4
处理：一般规则与断言矛盾得 `Ambiguous`，并附带矛盾来源；`ForPurpose`
声明为定义性规则后，世界中的这种断言是输入错误，交给翻译返修。回归
现分为两条：不断言时得 `OK:false`；在世界中断言时报输入错误。S11Q5
的目的断言在狐狸的话语语境中，不受影响。

更正后基线：`node run.mjs` → 回归 21/21 + 问题 65/65；`node mutation.mjs`
→ 12 条定向变异各击穿至少一项检查。
