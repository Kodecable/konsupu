// Domain regression tests over the Commons substrate. The phase2 suite's
// solver-internal tests do not carry over (that solver is gone); what
// carries over are the semantic obligations: correspondence, context
// isolation, time-anchored states, negation kinds and windows,
// exhaustion, open-world twins, the reply pipeline, source identity, and
// the lint's teeth. Runnable standalone or imported by run.mjs.
import {
  readdirSync,
  readFileSync,
  statSync,
} from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Agent,
  And,
  Among,
  Assertion,
  At,
  Before,
  Causes,
  Corresponds,
  Cry,
  Declare,
  Deceives,
  Duration,
  Entity,
  Event,
  Fall,
  ForPurpose,
  GetAt,
  In,
  LocatedAt,
  Then,
  NoInstance,
  Not,
  Occurred,
  Occurs,
  Only,
  Person,
  Present,
  Shut,
  Situation,
  Speak,
  Throw,
  TimeAnchor,
  Thing,
  Unable,
  Validity,
  Variable,
  Virtual,
  Within,
  Wolf,
  context,
  duration,
  end,
  start,
} from "./space/Interface/Aesop.js";
import {
  Imperative,
  KonsupuIdentity,
  Situation as FoundationSituation,
  Query,
  Variable as FoundationVariable,
  ref,
} from "./space/Interface/Nodes.js";
import { Reply } from "./space/Interface/Aesop.js";
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";
import { Project } from "./space/Memory/Aesop/Project.js";
import { assert as assertIn } from "./cases/helpers.mjs";

const Cases = [];
for (let id = 1; id <= 13; id += 1) {
  Cases.push(await import(`./cases/story-${id}/cases.mjs`));
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function assertThrows(thunk, fragment, message) {
  try {
    thunk();
  } catch (caught) {
    if (fragment && !String(caught).includes(fragment)) {
      throw new Error(`${message}: wrong error ${caught}`);
    }
    return;
  }
  throw new Error(`${message}: no error thrown`);
}

function normalizeText(text) {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// The bare inputs have no dialogue layer, so the answer is read through
// a reply path appended here.
function answerText(input, situation, answer) {
  const reply = new Reply(situation);
  reply.content = answer;
  input.push(reply);
  input.push(new Imperative(situation, KonsupuIdentity.Ref(), reply));
  // Later asks reuse a grown Input; each ask's reply is the last output.
  return Texts(Evaluate(input)).at(-1);
}

function checkAnswer(question, message) {
  // The case builds its own dialogue and reply path.
  const text = Texts(Evaluate(Cases[question.story - 1].BuildCaseFor(question)))[0];
  assert(
    normalizeText(text) === normalizeText(question.expected),
    `${message}: expected ${question.expected}, got ${text}`,
  );
  return text;
}

function entity(situation, name) {
  const value = new Thing(situation);
  value.name = name;
  return value;
}

function among(input, node, situation) {
  input.push(new Among(node.situated, { node, situation }));
}

// A minimal world for the focused tests: a doer, a deed, an order.
function smallWorld(input) {
  const story = new Situation();
  input.push(story);
  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  const nurse = new Person(story);
  nurse.name = "the nurse";
  const child = new Person(story);
  child.name = "the child";
  const window = new Thing(story);
  window.name = "the window";
  input.push(storyStart, storyEnd, nurse, child, window);
  const cry = new Cry(story, { theme: child });
  const shut = new Shut(story, { theme: window });
  Occurred(input, cry);
  assertIn(input, new Agent(story, { action: cry, actor: child }));
  Occurred(input, shut);
  assertIn(input, new Agent(story, { action: shut, actor: nurse }));
  assertIn(input, new Then(story, { earlier: cry, later: shut }));
  assertIn(
    input,
    new Before(story, { earlier: storyStart, later: start(cry) }),
  );
  assertIn(
    input,
    new Before(story, { earlier: end(shut), later: storyEnd }),
  );
  return { story, storyStart, storyEnd, nurse, child, cry, shut, window };
}

// A focused case: the story is the first Situation, and the question
// cognition and its Query sit directly in it (no asked layer — nothing
// here needs one).
function askedCase(buildWorld, buildAsked) {
  const input = [];
  const world = buildWorld(input);
  const answer = new FoundationVariable(world.story);
  input.push(answer);
  buildAsked(input, world.story, world, answer);
  input.push(new Query(world.story, [answer]));
  return { input, world, asked: world.story, answer };
}

export const Tests = [
  {
    name: "space: the published self-tests pass (Foundation + Commons)",
    run() {
      // Imported lazily to keep this module importable from run.mjs.
      const suite = import("./space/Test.js");
      return suite.then((module) => module.Test());
    },
  },
  {
    name: "source: the Foundation copy is byte-identical to src/foundation",
    run() {
      const here = fileURLToPath(new URL(".", import.meta.url));
      const roots = [
        ["space/Memory/Foundation", "../../src/foundation/Memory/Foundation"],
        ["space/Test", "../../src/foundation/Test", (name) => !name.startsWith("Commons/")],
        ["space/Resolve.js", "../../src/foundation/Resolve.js"],
        ["space/Interface/Nodes.js", "../../src/foundation/Interface/Nodes.js"],
        [
          "space/Interface/Outputs.js",
          "../../src/foundation/Interface/Outputs.js",
        ],
      ];
      compareAll(here, roots);
    },
  },
  {
    name: "source: the Commons copy is byte-identical to src/commons",
    run() {
      const here = fileURLToPath(new URL(".", import.meta.url));
      const roots = [
        ["space/Memory/Commons", "../../src/commons/Memory/Commons"],
        [
          "space/Memory/ValidateInput.js",
          "../../src/commons/Memory/ValidateInput.js",
        ],
        ["space/Memory/ResolveQuery.js", "../../src/commons/Memory/ResolveQuery.js"],
        [
          "space/Memory/ResolveQueryDefer.js",
          "../../src/commons/Memory/ResolveQueryDefer.js",
        ],
        ["space/Test/Commons", "../../src/commons/Test/Commons"],
        ["space/Test.js", "../../src/commons/Test.js"],
        ["space/Interface/Commons.js", "../../src/commons/Interface/Commons.js"],
      ];
      compareAll(here, roots);
    },
  },
  {
    name: "twins: every guide twin answers through the same machinery",
    async run() {
      for (let id = 0; id < Cases.length; id += 1) {
        for (const twin of Cases[id].TwinQuestions ?? []) {
          checkAnswer({ ...twin, story: id + 1 }, `story ${id + 1} twin`);
        }
      }
    },
  },
  {
    name: "among: several candidates are Ambiguous even when they agree",
    run() {
      const input = [];
      const world = smallWorld(input);
      // A second cry of the child: two candidates, one theme value each.
      const cry2 = new Cry(world.story, { theme: world.child });
      Occurred(input, cry2);
      const answer = new FoundationVariable(world.story);
      input.push(answer);
      const anyCry = new Cry(world.story, { theme: answer });
      input.push(anyCry);
      among(input, anyCry, world.story);
      input.push(new Query(world.story, [answer]));
      const text = answerText(input, world.story, answer);
      assert(text.startsWith("Ambiguous"), `expected Ambiguous, got ${text}`);
    },
  },
  {
    name: "among: a pinned constant description binds inside the match",
    run() {
      const built = askedCase(smallWorld, (input, asked, world, answer) => {
        const deed = new Shut(asked, { theme: world.window });
        input.push(deed);
        among(input, deed, world.story);
        const who = new Agent(asked, { action: deed, actor: answer });
        input.push(who);
        among(input, who, world.story);
      });
      const text = answerText(built.input, built.asked, built.answer);
      assert(
        normalizeText(text) === "ok entity the nurse",
        `expected the nurse, got ${text}`,
      );
    },
  },
  {
    name: "join: an And description binds one answer through two constraints",
    run() {
      const built = askedCase(smallWorld, (input, asked, world, answer) => {
        const who = new Agent(asked, { action: answer, actor: world.nurse });
        const sequel = new Then(asked, {
          earlier: world.cry,
          later: answer,
        });
        const joined = new And(asked, { propositions: [who, sequel] });
        input.push(who, sequel, joined);
        among(input, joined, world.story);
      });
      const text = answerText(built.input, built.asked, built.answer);
      assert(
        text.includes("Shut("),
        `expected the shutting, got ${text}`,
      );
    },
  },
  {
    name: "correspondence: what the said doing really was",
    run() {
      const input = [];
      const world = smallWorld(input);
      const said = new Speak(world.story, { call: "I shut it" });
      Occurred(input, said);
      input.push(new Corresponds(world.story, { left: said, right: world.shut }));
      const answer = new FoundationVariable(world.story);
      input.push(answer);
      input.push(
        new Corresponds(world.story, { left: answer, right: said }),
      );
      input.push(new Query(world.story, [answer]));
      const text = answerText(input, world.story, answer);
      assert(text.includes("Shut("), `expected the shutting, got ${text}`);
    },
  },
  {
    name: "correspondence: without the declaration there is no reading",
    run() {
      const input = [];
      const world = smallWorld(input);
      const said = new Speak(world.story, { call: "I shut it" });
      Occurred(input, said);
      const answer = new FoundationVariable(world.story);
      input.push(answer);
      input.push(
        new Corresponds(world.story, { left: answer, right: said }),
      );
      input.push(new Query(world.story, [answer]));
      const text = answerText(input, world.story, answer);
      assert(text === "Unknown", `expected Unknown, got ${text}`);
    },
  },
  {
    name: "states: the same entity answers differently at different times",
    run() {
      const input = [];
      const world = smallWorld(input);
      const meat = entity(world.story, "the meat");
      const mouth = entity(world.story, "the mouth");
      const water = entity(world.story, "the water");
      input.push(meat, mouth, water);
      const inMouth = new LocatedAt(world.story, {
        entity: meat,
        place: mouth,
      });
      const inWater = new LocatedAt(world.story, {
        entity: meat,
        place: water,
      });
      input.push(inMouth, inWater);
      const drop = new Fall(world.story, { theme: meat });
      Occurred(input, drop);
      for (const [state, from, to] of [
        [inMouth, world.storyStart, start(drop)],
        [inWater, start(drop), world.storyEnd],
      ]) {
        const held = new In(world.story, {
          proposition: state,
          duration: Duration(from, to),
        });
        input.push(held);
        input.push(new Assertion(world.story, { proposition: held }));
      }
      const ask = (window) => {
        const place = new FoundationVariable(world.story);
        input.push(place);
        const where = new LocatedAt(world.story, {
          entity: meat,
          place,
        });
        input.push(where);
        const held = new In(world.story, {
          proposition: where,
          duration: window,
        });
        input.push(held);
        among(input, held, world.story);
        input.push(new Query(world.story, [place]));
        return answerText(input, world.story, place);
      };
      assert(
        ask(Duration(world.storyStart, start(drop))).includes("the mouth"),
        "before the drop: the mouth",
      );
      assert(
        ask(Duration(start(drop), world.storyEnd)).includes("the water"),
        "after the drop: the water",
      );
    },
  },
  {
    name: "negation: a NoInstance window refutes inside and not outside",
    run() {
      const input = [];
      const world = smallWorld(input);
      const a = world.storyStart;
      const b = start(world.cry);
      const c = start(world.shut);
      const wolf = new Wolf(world.story);
      wolf.name = "the wolf";
      input.push(wolf);
      const anyWolf = new Wolf(world.story);
      const moment = new TimeAnchor(world.story);
      const presence = new Present(world.story, { subject: anyWolf });
      const at = new At(world.story, {
        proposition: presence,
        anchor: moment,
      });
      input.push(anyWolf, moment, presence, at);
      input.push(new Virtual(world.story, { node: anyWolf }));
      input.push(new Virtual(world.story, { node: moment }));
      input.push(
        new Within(world.story, { anchor: moment, duration: Duration(b, c) }),
      );
      const noWolves = new NoInstance(world.story, { of: anyWolf });
      input.push(noWolves);
      input.push(new Assertion(world.story, { proposition: noWolves }));
      const ask = (anchor) => {
        const answer = new FoundationVariable(world.story);
        input.push(answer);
        const w = new Wolf(world.story);
        const p = new Present(world.story, { subject: w });
        const atW = new At(world.story, { proposition: p, anchor });
        input.push(w, p, atW);
        input.push(new Virtual(world.story, { node: w }));
        input.push(
          new Validity(world.story, { proposition: atW, variable: answer }),
        );
        input.push(new Query(world.story, [answer]));
        return answerText(input, world.story, answer);
      };
      void a;
      const inside = ask(b);
      const outside = ask(world.storyStart);
      assert(inside === "OK:false", `inside the window: ${inside}`);
      assert(outside === "Unknown", `outside the window: ${outside}`);
    },
  },
  {
    name: "exhaustion: Only refutes the unlisted doing and not the listed one",
    async run() {
      const { buildExhaustionWorld } = await import("./regression-worlds.mjs");
      const world = buildExhaustionWorld();
      const texts = world.ask();
      assert(texts.threw === "OK:false", `threw: ${texts.threw}`);
      assert(texts.called === "OK:true", `called: ${texts.called}`);
    },
  },
  {
    name: "chance: a chance happening serves no purpose",
    async run() {
      const { buildChanceWorld } = await import("./regression-worlds.mjs");
      const world = buildChanceWorld();
      const texts = world.ask();
      assert(texts.purposed === "OK:false", `purposed: ${texts.purposed}`);
      assert(texts.happened === "OK:true", `happened: ${texts.happened}`);
    },
  },
  {
    name: "chance: a purpose asserted of it in the world is sent back for repair",
    async run() {
      const { buildChanceWorld } = await import("./regression-worlds.mjs");
      assertThrows(
        () => buildChanceWorld(true),
        "An asserted Proposition contradicts its class's definition",
        "a definitional rule broken in the world must be an Input error",
      );
    },
  },
  {
    name: "open world: unasserted is never false",
    async run() {
      const { buildOpenWorld } = await import("./regression-worlds.mjs");
      const world = buildOpenWorld();
      const texts = world.ask();
      assert(texts.unrelated === "Unknown", `unrelated: ${texts.unrelated}`);
    },
  },
  {
    name: "names: a written name field is an ordinary field (no SURFACE rule)",
    async run() {
      const { buildNameWorld } = await import("./regression-worlds.mjs");
      const world = buildNameWorld();
      const texts = world.ask();
      assert(texts.matched === "OK:true", `matched: ${texts.matched}`);
    },
  },
  {
    name: "reply: the answer travels through ref and projects mechanically",
    run() {
      // The full pipeline on story-1's first question: the answer crosses
      // from the seat to the dialogue through ref and one Imperative
      // output, and plain values project unchanged.
      const text = checkAnswer(
        { ...Cases[0].Questions[0], story: 1 },
        "reply",
      );
      assert(text === "OK:Entity(the crow)", `got ${text}`);
      assert(Project("x") === "x", "plain values project");
    },
  },
  {
    name: "lint: Not refuses a time modifier in its proposition",
    run() {
      assertThrows(
        () => {
          const input = [];
          const world = smallWorld(input);
          const presence = new Present(world.story, {
            subject: world.child,
          });
          input.push(presence);
          const held = new In(world.story, {
            proposition: presence,
            duration: Duration(world.storyStart, world.storyEnd),
          });
          input.push(held);
          const denied = new Not(world.story, { proposition: held });
          input.push(denied);
          assertIn(input, denied);
          const answer = new FoundationVariable(world.story);
          input.push(answer);
          input.push(
            new Validity(world.story, {
              proposition: denied,
              variable: answer,
            }),
          );
          input.push(new Query(world.story, [answer]));
          Evaluate(input);
        },
        "Not does not apply to time",
        "Not over a time modifier must be rejected",
      );
    },
  },
  {
    name: "lint: Virtual refuses to modify a proposition",
    run() {
      assertThrows(
        () => {
          const input = [];
          const world = smallWorld(input);
          const presence = new Present(world.story, {
            subject: world.child,
          });
          input.push(presence);
          input.push(new Virtual(world.story, { node: presence }));
          const answer = new FoundationVariable(world.story);
          input.push(answer);
          input.push(
            new Validity(world.story, {
              proposition: presence,
              variable: answer,
            }),
          );
          input.push(new Query(world.story, [answer]));
          Evaluate(input);
        },
        "Virtual modifies an ordinary contextual Node",
        "Virtual over a proposition must be rejected",
      );
    },
  },
  {
    name: "lint: a declaration takes no Assertion",
    run() {
      assertThrows(
        () => {
          const input = [];
          const world = smallWorld(input);
          const link = new Corresponds(world.story, {
            left: world.child,
            right: world.nurse,
          });
          input.push(link);
          input.push(new Assertion(world.story, { proposition: link }));
          const answer = new FoundationVariable(world.story);
          input.push(answer);
          input.push(new Query(world.story, [answer]));
          Evaluate(input);
        },
        "declaration takes effect without Assertion",
        "Asserting a Corresponds must be rejected",
      );
    },
  },
  {
    name: "query: an undecided Variable is an input error",
    run() {
      assertThrows(
        () => {
          const input = [];
          const world = smallWorld(input);
          const answer = new FoundationVariable(world.story);
          input.push(answer);
          input.push(new Query(world.story, [answer]));
          Evaluate(input);
        },
        "needs a declaration",
        "A queried Variable without a declaration must be rejected",
      );
    },
  },
];

function compareAll(here, roots) {
  for (const entry of roots) {
    const [local, remote, keep = () => true] = entry;
    const from = join(here, local);
    const to = join(here, remote);
    const files = collect(from).filter(keep);
    for (const name of files) {
      const mine = readFileSync(name === "" ? from : join(from, name));
      const theirs = readFileSync(name === "" ? to : join(to, name));
      assert(
        mine.equals(theirs),
        `${local}/${name} differs from ${remote}`,
      );
    }
    const theirs = collect(to).filter(keep);
    for (const name of theirs) {
      assert(
        files.includes(name),
        `${local} is missing ${name} present in ${remote}`,
      );
    }
  }
}

function collect(path) {
  if (!statSync(path).isDirectory()) return [""];
  const names = [];
  const walk = (at, prefix) => {
    for (const entry of readdirSync(at)) {
      const full = join(at, entry);
      if (statSync(full).isDirectory()) walk(full, `${prefix}${entry}/`);
      else names.push(prefix + entry);
    }
  };
  walk(path, "");
  return names.sort();
}

// Standalone runner.
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  let passed = 0;
  const failures = [];
  for (const test of Tests) {
    try {
      await test.run();
      passed += 1;
      console.log(`PASS  ${test.name}`);
    } catch (caught) {
      failures.push({ test, caught });
      console.log(`FAIL  ${test.name}`);
    }
  }
  for (const failure of failures) {
    console.log("");
    console.log(`--- ${failure.test.name}`);
    console.log(failure.caught.stack ?? String(failure.caught));
  }
  console.log(`Regression tests: ${passed}/${Tests.length} passed`);
  process.exit(failures.length === 0 ? 0 : 1);
}
