// Happenings no one does (falling, rising, waking, being trapped), events
// taken as a whole (Series, Get), manner classes (Chance: by accident, so
// never for a purpose), and speech-act events whose `content` names the
// uttered Situation — a root context introduced by the utterance. The
// declared context field keeps the root lint check on the content field.
import { Brand } from "../../Interface/Nodes.js";
import { Event } from "../../Memory/Commons/Vocabulary/Base.js";

class Happening extends Event {
  static BRAND = Brand("aesop:Happening:v1");
}

export class Fall extends Happening {
  static BRAND = Brand("aesop:Fall:v1");
}
export class Rise extends Happening {
  static BRAND = Brand("aesop:Rise:v1");
}
export class Wake extends Happening {
  static BRAND = Brand("aesop:Wake:v1");
}
export class GetTrapped extends Happening {
  static BRAND = Brand("aesop:GetTrapped:v1");
}
// An open getting: the corpus refines it (SnapUp extends Get in deeds) so
// translations need not know the text's most specific word.
export class Get extends Happening {
  static BRAND = Brand("aesop:Get:v1");
}
// Several events as one happening (little by little): the parts keep their
// own occurrence and order; the Series itself is one event.
export class Series extends Happening {
  static BRAND = Brand("aesop:Series:v1");
}
// It came about by chance, not for a purpose (the phase2 ByChance fact
// becomes the event's own kind, so the class-level rule "a chance event is
// done for no purpose" is one instanceof check on the action). The corpus
// chance events are falls: "by an unlucky chance" fell in.
export class Chance extends Fall {
  static BRAND = Brand("aesop:Chance:v1");
}

// A speech-act event (crying, crying out, declaring, advising). Field
// content names the uttered Situation; call is the quoted words (surface
// text of the act, matchable like Says fields).
class Speech extends Happening {
  static BRAND = Brand("aesop:Speech:v1");
  static FIELDS = { content: { context: true } };
  static OPEN = true;
}
export class Cry extends Speech {
  static BRAND = Brand("aesop:Cry:v1");
}
export class CryOut extends Speech {
  static BRAND = Brand("aesop:CryOut:v1");
}
export class Declare extends Speech {
  static BRAND = Brand("aesop:Declare:v1");
}
export class Advise extends Speech {
  static BRAND = Brand("aesop:Advise:v1");
}
// A question asked aloud (the miser's neighbour): content is the asked
// Situation holding the questioned proposition.
export class AskAbout extends Speech {
  static BRAND = Brand("aesop:AskAbout:v1");
}
// A plain speech act (greeting, flattery, gloating): call is the quoted
// words, content the uttered Situation when the act introduces one.
export class Speak extends Speech {
  static BRAND = Brand("aesop:Speak:v1");
}
