// Perception, encounter and errand events: seeing, hearing, noticing,
// harming, crying for help, finding, digging, gloating, dwelling.
import { Brand } from "../../Interface/Nodes.js";
import { Event } from "../../Memory/Commons/Vocabulary/Base.js";

class Meeting extends Event {
  static BRAND = Brand("aesop:Meeting:v1");
}

export class See extends Meeting {
  static BRAND = Brand("aesop:See:v1");
}
export class ComeUpon extends Meeting {
  static BRAND = Brand("aesop:ComeUpon:v1");
}
export class Notice extends Meeting {
  static BRAND = Brand("aesop:Notice:v1");
}
export class Hear extends Meeting {
  static BRAND = Brand("aesop:Hear:v1");
}
export class HeardOf extends Meeting {
  static BRAND = Brand("aesop:HeardOf:v1");
}
export class LookClosely extends Meeting {
  static BRAND = Brand("aesop:LookClosely:v1");
}
export class Pounce extends Meeting {
  static BRAND = Brand("aesop:Pounce:v1");
}
export class Worry extends Meeting {
  static BRAND = Brand("aesop:Worry:v1");
}
export class Hurt extends Meeting {
  static BRAND = Brand("aesop:Hurt:v1");
}
export class CallForHelp extends Meeting {
  static BRAND = Brand("aesop:CallForHelp:v1");
}
export class Sing extends Meeting {
  static BRAND = Brand("aesop:Sing:v1");
}
export class Find extends Meeting {
  static BRAND = Brand("aesop:Find:v1");
}
export class DigUp extends Meeting {
  static BRAND = Brand("aesop:DigUp:v1");
}
export class Gloat extends Meeting {
  static BRAND = Brand("aesop:Gloat:v1");
}
export class Congratulate extends Meeting {
  static BRAND = Brand("aesop:Congratulate:v1");
}
export class Dwell extends Meeting {
  static BRAND = Brand("aesop:Dwell:v1");
}
export class Enter extends Meeting {
  static BRAND = Brand("aesop:Enter:v1");
}
export class Lay extends Meeting {
  static BRAND = Brand("aesop:Lay:v1");
}
