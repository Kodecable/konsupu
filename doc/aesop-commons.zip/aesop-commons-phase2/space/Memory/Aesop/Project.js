// Mechanical projection of a resolved value into deterministic machine
// text: enough to identify exactly what the Query resolved, nothing more.
// No English realization, no tense, no wording choices, and no reading of
// other cognition — only the value's own structure. A Commons result box
// projects with its status spelled out, so yes / no / unknown / ambiguous
// answers stay distinguishable in the machine text.
import { Being } from "./Beings.js";
import { IsResult } from "../Commons/Model/Result.js";
import { IsDuration } from "../Commons/Vocabulary/TimeValues.js";
import { Node, Situation, Variable } from "../../Interface/Nodes.js";

function dataFields(node) {
  return Object.entries(node)
    .filter(([key]) => key !== "situated")
    .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0));
}

export function Project(value) {
  if (IsResult(value)) {
    if (value.status === "OK") return `OK:${Project(value.result)}`;
    if (value.status === "Ambiguous") {
      return `Ambiguous:${Project(value.result.candidates ?? [])}`;
    }
    return String(value.status);
  }
  if (value instanceof Being) return `Entity(${value.name})`;
  if (value instanceof Variable) {
    throw new TypeError("Machine projection of an unresolved Variable");
  }
  // A context Situation projects by its title — surface text it was given
  // at construction, the same status Entity.name has. An untitled context
  // still projects, structurally.
  if (value instanceof Situation) {
    return `Context(${value.title ?? ""})`;
  }
  if (value instanceof Node) {
    const fields = dataFields(value).map(
      ([key, item]) => `${key}=${Project(item)}`,
    );
    return `${value.constructor.name}(${fields.join(",")})`;
  }
  if (Array.isArray(value)) {
    return `[${value.map(Project).join(",")}]`;
  }
  if (IsDuration(value)) {
    const anchors = value.anchors.map(Project).join(",");
    return `Duration(${anchors})`;
  }
  if (value !== null && typeof value === "object") {
    const fields = Object.entries(value)
      .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
      .map(([key, item]) => `${key}=${Project(item)}`);
    return `{${fields.join(",")}}`;
  }
  return String(value);
}
