// The Aesop domain beings: contextual objects with a rigid sort. A kind is
// a subclass (the phase2 Kind constants collapse into class identity), and
// `name` is surface text for projection only — it never participates in
// matching. Quantified readings ("a wolf", "any villager") quantify over
// the subclass, never over the name.
import { Brand } from "../../Interface/Nodes.js";
import { Entity } from "../../Memory/Commons/Vocabulary/Base.js";

export class Being extends Entity {
  static BRAND = Brand("aesop:Being:v1");
}

// A person of the fable world (shepherd, nurse, miser, milkmaid, ...).
export class Person extends Being {
  static BRAND = Brand("aesop:Person:v1");
}

// An animal kind. Wolf, Dog and Sheep exist as their own classes because
// the corpus quantifies over them ("was there a wolf", "no beast").
export class Animal extends Being {
  static BRAND = Brand("aesop:Animal:v1");
}
export class Wolf extends Animal {
  static BRAND = Brand("aesop:Wolf:v1");
}
export class Dog extends Animal {
  static BRAND = Brand("aesop:Dog:v1");
}
export class Sheep extends Animal {
  static BRAND = Brand("aesop:Sheep:v1");
}

// Anything else the stories talk about (a pitcher, a piece of meat, a
// drought, a mask, a pail of milk, ...).
export class Thing extends Being {
  static BRAND = Brand("aesop:Thing:v1");
}

// A titled Situation (a belief, a speech content, a plan, a norm): the
// title is projection surface only. Contexts are separate roots (12); the
// helper only names them.
export function context(situation, title) {
  situation.title = title;
  return situation;
}
