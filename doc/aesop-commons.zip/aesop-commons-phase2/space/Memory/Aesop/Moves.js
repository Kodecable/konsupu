// Movement and posture: going, coming, following, jumping, waiting. A
// motion that does not imply arrival (HeadTo) stays separate from one that
// does (ComeTo); being on the way is not having arrived.
import { Brand } from "../../Interface/Nodes.js";
import { Event } from "../../Memory/Commons/Vocabulary/Base.js";

class Move extends Event {
  static BRAND = Brand("aesop:Move:v1");
}

export class FlyOff extends Move {
  static BRAND = Brand("aesop:FlyOff:v1");
}
export class Settle extends Move {
  static BRAND = Brand("aesop:Settle:v1");
}
export class WalkUpTo extends Move {
  static BRAND = Brand("aesop:WalkUpTo:v1");
}
export class SearchFor extends Move {
  static BRAND = Brand("aesop:SearchFor:v1");
}
export class Carry extends Move {
  static BRAND = Brand("aesop:Carry:v1");
}
export class PassBy extends Move {
  static BRAND = Brand("aesop:PassBy:v1");
}
export class Help extends Move {
  static BRAND = Brand("aesop:Help:v1");
}
export class Cross extends Move {
  static BRAND = Brand("aesop:Cross:v1");
}
export class ComeOut extends Move {
  static BRAND = Brand("aesop:ComeOut:v1");
}
export class ComeTo extends Move {
  static BRAND = Brand("aesop:ComeTo:v1");
}
export class ComeBack extends Move {
  static BRAND = Brand("aesop:ComeBack:v1");
}
export class ComeToHelp extends Move {
  static BRAND = Brand("aesop:ComeToHelp:v1");
}
export class GoAway extends Move {
  static BRAND = Brand("aesop:GoAway:v1");
}
export class TurnAway extends Move {
  static BRAND = Brand("aesop:TurnAway:v1");
}
export class GallopAway extends Move {
  static BRAND = Brand("aesop:GallopAway:v1");
}
export class RushOut extends Move {
  static BRAND = Brand("aesop:RushOut:v1");
}
export class Stroll extends Move {
  static BRAND = Brand("aesop:Stroll:v1");
}
export class Follow extends Move {
  static BRAND = Brand("aesop:Follow:v1");
}
export class Lead extends Move {
  static BRAND = Brand("aesop:Lead:v1");
}
export class JumpDown extends Move {
  static BRAND = Brand("aesop:JumpDown:v1");
}
export class JumpOn extends Move {
  static BRAND = Brand("aesop:JumpOn:v1");
}
// An open getting out: the corpus refines it (JumpUp extends it), so a
// "get out" question matches however the story words the escape.
export class GetOut extends Move {
  static BRAND = Brand("aesop:GetOut:v1");
}

// Jumping up out of somewhere is one way of getting out.
export class JumpUp extends GetOut {
  static BRAND = Brand("aesop:JumpUp:v1");
}
export class Prowl extends Move {
  static BRAND = Brand("aesop:Prowl:v1");
}
export class Crouch extends Move {
  static BRAND = Brand("aesop:Crouch:v1");
}
export class Wait extends Move {
  static BRAND = Brand("aesop:Wait:v1");
}
export class Hunt extends Move {
  static BRAND = Brand("aesop:Hunt:v1");
}
export class GetAt extends Move {
  static BRAND = Brand("aesop:GetAt:v1");
}
export class HeadTo extends Move {
  static BRAND = Brand("aesop:HeadTo:v1");
}
