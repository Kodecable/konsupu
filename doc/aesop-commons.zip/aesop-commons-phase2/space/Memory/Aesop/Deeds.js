// Deeds: events someone does to things (acting on objects, taking, giving,
// contact). Agency is the independent Agent proposition (13.2), so none of
// these classes carries an actor field. Fields stay open; a written field
// is a constraint and an unwritten one says nothing.
import { Brand } from "../../Interface/Nodes.js";
import { Event } from "../../Memory/Commons/Vocabulary/Base.js";
import { Get } from "./Happenings.js";

class Deed extends Event {
  static BRAND = Brand("aesop:Deed:v1");
}

export class Put extends Deed {
  static BRAND = Brand("aesop:Put:v1");
}
export class TryToDrink extends Deed {
  static BRAND = Brand("aesop:TryToDrink:v1");
}
export class ThinkUp extends Deed {
  static BRAND = Brand("aesop:ThinkUp:v1");
}
export class Drop extends Deed {
  static BRAND = Brand("aesop:Drop:v1");
}
export class Quench extends Deed {
  static BRAND = Brand("aesop:Quench:v1");
}
export class Save extends Deed {
  static BRAND = Brand("aesop:Save:v1");
}
// The open getting refined: seizing with the jaws is one way of getting.
export class SnapUp extends Get {
  static BRAND = Brand("aesop:SnapUp:v1");
}
export class RunUpon extends Deed {
  static BRAND = Brand("aesop:RunUpon:v1");
}
export class Seize extends Deed {
  static BRAND = Brand("aesop:Seize:v1");
}
export class Spare extends Deed {
  static BRAND = Brand("aesop:Spare:v1");
}
export class Tie extends Deed {
  static BRAND = Brand("aesop:Tie:v1");
}
export class Gnaw extends Deed {
  static BRAND = Brand("aesop:Gnaw:v1");
}
export class Eat extends Deed {
  static BRAND = Brand("aesop:Eat:v1");
}
// Taking is a getting; the open Get class lets questions match without
// deciding the story's word (took, stole, snapped up).
export class Take extends Get {
  static BRAND = Brand("aesop:Take:v1");
}
export class Hide extends Deed {
  static BRAND = Brand("aesop:Hide:v1");
}
export class Steal extends Get {
  static BRAND = Brand("aesop:Steal:v1");
}
export class Buy extends Deed {
  static BRAND = Brand("aesop:Buy:v1");
}
export class Sell extends Deed {
  static BRAND = Brand("aesop:Sell:v1");
}
export class Shut extends Deed {
  static BRAND = Brand("aesop:Shut:v1");
}
export class Open extends Deed {
  static BRAND = Brand("aesop:Open:v1");
}
export class PutOn extends Deed {
  static BRAND = Brand("aesop:PutOn:v1");
}
export class SnapAt extends Deed {
  static BRAND = Brand("aesop:SnapAt:v1");
}
export class Touch extends Deed {
  static BRAND = Brand("aesop:Touch:v1");
}
export class Throw extends Deed {
  static BRAND = Brand("aesop:Throw:v1");
}
export class Toss extends Deed {
  static BRAND = Brand("aesop:Toss:v1");
}
