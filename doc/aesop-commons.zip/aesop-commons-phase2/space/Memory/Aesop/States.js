// Changeable states and other ordinary conditions of the fable world.
// A state holds only where and when it is asserted (an In over a Duration);
// nothing persists by default and no field reads as absent (2, 14.12).
import { Brand, Proposition, ReportDataMembers } from "../../Interface/Nodes.js";

class State extends Proposition {
  static BRAND = Brand("aesop:State:v1");
  static FIELDS = {};
  static OPEN = true;
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Where something is (entity, place).
export class LocatedAt extends State {
  static BRAND = Brand("aesop:LocatedAt:v1");
}

// Wanting drink (subject).
export class Thirsty extends State {
  static BRAND = Brand("aesop:Thirsty:v1");
}

// Being in the place in question (subject).
export class Present extends State {
  static BRAND = Brand("aesop:Present:v1");
}

// Being elsewhere (subject).
export class Away extends State {
  static BRAND = Brand("aesop:Away:v1");
}

// Sleeping (subject).
export class Asleep extends State {
  static BRAND = Brand("aesop:Asleep:v1");
}

// Free to move (subject).
export class Free extends State {
  static BRAND = Brand("aesop:Free:v1");
}

// Amused (subject, at: what amused them).
export class Tickled extends State {
  static BRAND = Brand("aesop:Tickled:v1");
}

// A voice surpassing others (subject, others).
export class VoiceSurpasses extends State {
  static BRAND = Brand("aesop:VoiceSurpasses:v1");
}

// Distrusting flatterers (subject).
export class DistrustFlatterers extends State {
  static BRAND = Brand("aesop:DistrustFlatterers:v1");
}

// Holding something (holder, thing).
export class Has extends State {
  static BRAND = Brand("aesop:Has:v1");
}

// Belonging to an owner (thing, owner).
export class BelongsTo extends State {
  static BRAND = Brand("aesop:BelongsTo:v1");
}

// Wearing a garment (wearer, garment).
export class Wears extends State {
  static BRAND = Brand("aesop:Wears:v1");
}

// Carrying something (carrier, theme).
export class Carrying extends State {
  static BRAND = Brand("aesop:Carrying:v1");
}

// An absence that can itself be perceived (thing, of: whose having it is
// absent). This is a state about a lacking, not a negation: the lion
// noticed the absence of the brains (N6).
export class Missing extends State {
  static BRAND = Brand("aesop:Missing:v1");
}

// A coming drought, as claimed or as fact ("there is going to be a
// great drought").
export class Drought extends State {
  static BRAND = Brand("aesop:Drought:v1");
}

// Emotions (subject, of: the object of the emotion when the text gives
// one). Their cause is a separate Causes or Motivates cognition.
export class Frightened extends State {
  static BRAND = Brand("aesop:Frightened:v1");
}
export class Jealous extends State {
  static BRAND = Brand("aesop:Jealous:v1");
}
export class Lonely extends State {
  static BRAND = Brand("aesop:Lonely:v1");
}
export class Overjoyed extends State {
  static BRAND = Brand("aesop:Overjoyed:v1");
}
