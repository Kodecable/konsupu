// Dialogue cognition. The asking situation of a dialogue names the story
// world it is about, the asked Situation that refines it, and any further
// evaluation Situation the question reads (a child of a belief or speech
// context); the reply is the requested doing whose content is the
// already-resolved answer value. Reply is deliberately not Says: story
// speech utters a Situation, the reply utters a value, and one relation
// keeps one canonical form.
import {
  Brand,
  Final,
  ReportDataMembers,
  SituatedNode,
} from "../../Interface/Nodes.js";

// Fields story, asked, and (optionally) reading: a list of any further
// Situations the question evaluates in. This is what gives every Situation
// its semantic mention.
export class Asks extends SituatedNode {
  static BRAND = Brand("aesop:Asks:v1");
  static FIELDS = {};
  static OPEN = true;
  constructor(situated) {
    Final(Asks, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// The requested reply of a dialogue: field content (the resolved answer
// value, read through a ref). Being requested does not make it occur, and
// its content is a value, never a held proposition.
export class Reply extends SituatedNode {
  static BRAND = Brand("aesop:Reply:v1");
  static FIELDS = {};
  static OPEN = true;
  constructor(situated) {
    Final(Reply, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
