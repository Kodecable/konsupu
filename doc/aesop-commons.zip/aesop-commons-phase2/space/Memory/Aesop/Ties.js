// Ties between cognitions: narrative order (Then derives Before, the story
// never enumerates Before by hand), enabling, overlap, topicality, motive,
// approval, deception, manner, duration, a habit's concrete instance, and
// the purpose tie with its class-level incompatibility against chance.
import {
  Brand,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Before } from "../Commons/Vocabulary/TimeRelations.js";
import { InOrderTo, Habitual } from "../Commons/Vocabulary/Cognition.js";
import { Chance } from "./Happenings.js";

class Tie extends Proposition {
  static BRAND = Brand("aesop:Tie:v1");
  static FIELDS = {};
  static OPEN = true;
  static TIMELESS = true;
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Narrative succession: the earlier happened and then the later. Before is
// derived (transitive through the anchor order), never asserted by hand.
export class Then extends Tie {
  static BRAND = Brand("aesop:Then:v1");
  static Derive(api, emit) {
    emit(Before, {
      earlier: api.Field("earlier"),
      later: api.Field("later"),
    });
  }
}

// The enabler made the enabled possible (the risen water, the means
// found). It says nothing about cause or purpose.
export class Enables extends Tie {
  static BRAND = Brand("aesop:Enables:v1");
}

// The two events share a moment ("as he crossed, he looked down"): neither
// is before the other, and both keep their order towards everything else.
export class Overlaps extends Tie {
  static BRAND = Brand("aesop:Overlaps:v1");
  static Judge(api) {
    const apart = api.Disjoint(
      api.ToTime(api.Field("first")),
      api.ToTime(api.Field("second")),
    );
    return apart === true ? false : apart === false ? true : null;
  }
  static Order(api, add) {
    const one = api.EventBounds(api.Field("first"));
    const two = api.EventBounds(api.Field("second"));
    if (one === null || two === null) return;
    add(one[0], two[1], false);
    add(two[0], one[1], false);
  }
}

// Topicality: the cognition is about the subject. About(claim, voice) is
// the question's handle on what a claim concerns; it is not predication.
export class About extends Tie {
  static BRAND = Brand("aesop:About:v1");
}

// A mental state or cognition moves someone to act (fear of the face drove
// the fox); the driver is a cognition, not a world fact.
export class Motivates extends Tie {
  static BRAND = Brand("aesop:Motivates:v1");
}

// Someone thinks well of something (the goat approved the fox's advice).
export class Approves extends Tie {
  static BRAND = Brand("aesop:Approves:v1");
}

// One party proposed something to another (an alliance). The proposal
// lives in the speech context that carries it.
export class Proposes extends Tie {
  static BRAND = Brand("aesop:Proposes:v1");
}

// Someone deceived someone, by `by` when the text gives the deed. Held
// only where the text says or lexically implies it; a wrong belief never
// derives it.
export class Deceives extends Tie {
  static BRAND = Brand("aesop:Deceives:v1");
}

// The manner of an event (how it was done). An unwritten means is a means
// that exists but is not stated — "by some means".
export class Means extends Tie {
  static BRAND = Brand("aesop:Means:v1");
}

// How long something lasted. The amount is a plain value; a fuzzy text
// duration ("for some time") is a value, not an Unknown.
export class Lasted extends Tie {
  static BRAND = Brand("aesop:Lasted:v1");
}

// This event is one concrete instance of that habit ("when the Miser next
// came"): the habit stays a general cognition, the instance is an event.
export class Instance extends Tie {
  static BRAND = Brand("aesop:Instance:v1");
}

// In order to: the action was done for the goal. A chance event is done
// for no purpose at all — that exclusion is what the tie means, decided
// from the action's own kind (DEFINITIONAL: asserted of a chance event in
// the world, it is an Input error). Is reads every description of the
// action's correspondence group, so the order of Input does not matter.
export class ForPurpose extends InOrderTo {
  static BRAND = Brand("aesop:ForPurpose:v1");
  static DEFINITIONAL = true;
  static Judge(api) {
    return api.Is("action", Chance) ? false : null;
  }
}

// A habit with its frequency ("used to ... every week"). Frequency is a
// plain value (a Quantity or the text's own phrase).
export class Routine extends Habitual {
  static BRAND = Brand("aesop:Routine:v1");
  static FIELDS = { frequency: {} };
  static OPEN = true;
}
