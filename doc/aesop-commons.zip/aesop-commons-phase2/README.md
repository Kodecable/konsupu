# aesop-commons-phase2

`run/aesop-phase2`（13 篇伊索寓言 × 5 问 + 回归 + 变异验证）在
`src/commons`（Konsupu Commons 引擎）之上的重新实现。过程观察、
Commons 的顺手程度与 bug 记录见 [OBSERVATIONS.md](./OBSERVATIONS.md)；
逐题机器答案与翻译判断见 [RESULTS.md](./RESULTS.md)。

```shell
node run.mjs        # 回归 21/21 + 65 问，应全绿
node regression.mjs # 仅回归
node mutation.mjs   # 12 条定向变异，每条应至少击穿一项检查
```

布局：

- `space/Memory/Foundation/`、`space/Test/`（不含 Commons）、
  `space/Resolve.js`、`space/Interface/Nodes.js`、`space/Outputs.js`
  —— `src/foundation` 的字节级副本（回归每次运行核对）。
- `space/Memory/Commons/`、`space/Test/Commons/`、`space/Test.js`、
  `space/Interface/Commons.js` 与 `Memory/` 下三个入口
  —— `src/commons` 的字节级副本（回归每次运行核对；**本目录不修改
  src/commons**，引擎缺口只记录并绕行）。
- `space/Memory/Aesop/` —— 领域层（叙事的“然后”是 `Then`，与 Commons 的序数 `Next` 区分）：词表（Beings/States/Ties/Deeds/
  Moves/Meetings/Happenings/Dialogue）、投影（Project）、祈使回复链路
  （Speech）。phase2 的求解器整体消失，语义由 Commons 引擎承担。
- `space/Memory/IsKonsupuImperativeApplicable.js`、
  `space/Memory/ResolveImperatives.js` —— Aesop 接管的两个 Foundation
  桩入口（回复链路）。
- `cases/story-1..13/` —— 每故事 `story.mjs`（事实，显式时间区间）、
  `questions.mjs`（冻结题面 + 语义 expected + 机器 expected + 构造）、
  `cases.mjs`；`cases/helpers.mjs` —— 三层组装（dialogue / story /
  seat）与构造糖（Happened、PatternEvent、Chain、Bounds、among）。
- `regression.mjs` + `regression-worlds.mjs` —— 语义回归、全部 guide
  twins、两份字节一致性、lint 负例。
- `mutation.mjs` —— 变异验证（领域规则、lint 规则与引擎行为各若干）。

机器答案带 Result 盒状态前缀（`OK:`/`Unknown`/`Ambiguous:`/`NoMethod`），
与 phase2 投影的映射见 OBSERVATIONS 第 4 节。
