// Focused worlds for the regression suite's rule tests.
import {
  Agent,
  And,
  Among,
  Assertion,
  At,
  Before,
  CallForHelp,
  Chance,
  Cry,
  Duration,
  Event,
  ForPurpose,
  Fall,
  Has,
  In,
  Occurred,
  Occurs,
  Only,
  Person,
  Present,
  Shut,
  Situation,
  Throw,
  Thing,
  TimeAnchor,
  Validity,
  Virtual,
  Within,
  duration,
  end,
  start,
} from "./space/Interface/Aesop.js";
import {
  Imperative,
  KonsupuIdentity,
  Query,
  Variable,
} from "./space/Interface/Nodes.js";
import { Reply } from "./space/Interface/Aesop.js";
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";

// The bare worlds have no dialogue layer, so each ask appends its own
// reply path: a Reply reading the answer directly and a Konsupu
// Imperative, giving Evaluate one output to read.
function say(input, situation, answer) {
  const reply = new Reply(situation);
  reply.content = answer;
  input.push(reply);
  input.push(new Imperative(situation, KonsupuIdentity.Ref(), reply));
  return Texts(Evaluate(input)).at(-1);
}

function askValid(input, situation, proposition) {
  const answer = new Variable(situation);
  input.push(answer);
  input.push(new Validity(situation, { proposition, variable: answer }));
  input.push(new Query(situation, [answer]));
  return say(input, situation, answer);
}

function being(situation, name) {
  const value = new Person(situation);
  value.name = name;
  return value;
}

function thing(situation, name) {
  const value = new Thing(situation);
  value.name = name;
  return value;
}

// The nurse's exhaustion: from a cry on, all she did at any moment was
// shut the window and call for help; throwing the child is refuted,
// calling is not.
export function buildExhaustionWorld() {
  const input = [];
  const story = new Situation();
  input.push(story);
  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  const nurse = being(story, "the nurse");
  const child = being(story, "the child");
  const window = thing(story, "the window");
  input.push(storyStart, storyEnd, nurse, child, window);
  const cry = new Cry(story, { theme: child });
  const shut = new Shut(story, { theme: window });
  const call = new CallForHelp(story);
  for (const [event, actor] of [
    [cry, child],
    [shut, nurse],
    [call, nurse],
  ]) {
    Occurred(input, event);
    input.push(new Agent(story, { action: event, actor }));
    input.push(
      new Assertion(story, { proposition: input[input.length - 1] }),
    );
  }
  const closing = new Before(story, { earlier: end(cry), later: storyEnd });
  input.push(closing);
  input.push(new Assertion(story, { proposition: closing }));
  const window2 = Duration(start(cry), storyEnd);
  const deed = new Event(story);
  const deedOccurs = new Occurs(story, { event: deed });
  const deedAgent = new Agent(story, { action: deed, actor: nurse });
  const deedBody = new And(story, { propositions: [deedAgent, deedOccurs] });
  const moment = new TimeAnchor(story);
  const deedAt = new At(story, { proposition: deedBody, anchor: moment });
  input.push(deed, deedOccurs, deedAgent, deedBody, moment, deedAt);
  input.push(new Virtual(story, { node: deed }));
  input.push(new Virtual(story, { node: moment }));
  input.push(new Within(story, { anchor: moment, duration: window2 }));
  const allSheDid = new Only(story, { of: deed, among: [shut, call] });
  input.push(allSheDid);
  input.push(new Assertion(story, { proposition: allSheDid }));
  // The refuted side asks a doing at some moment of the window; the
  // affirmed side asks the canonical occurrence (its own duration is the
  // fact's own time).
  const didAtWindow = (Deed, fields) => {
    const doing = new Deed(story, fields);
    const occurs = new Occurs(story, { event: doing });
    const did = new Agent(story, { action: doing, actor: nurse });
    const body = new And(story, { propositions: [did, occurs] });
    input.push(doing, occurs, did, body);
    input.push(new Virtual(story, { node: doing }));
    const held = new In(story, { proposition: body, duration: window2 });
    input.push(held);
    return held;
  };
  const didCanonical = (Deed, fields) => {
    const doing = new Deed(story, fields);
    const occurs = new Occurs(story, { event: doing });
    const during = new In(story, {
      proposition: occurs,
      duration: duration(doing),
    });
    const did = new Agent(story, { action: doing, actor: nurse });
    const body = new And(story, { propositions: [did, during] });
    input.push(doing, start(doing), end(doing), occurs, during, did, body);
    input.push(new Virtual(story, { node: doing }));
    return body;
  };
  return {
    ask() {
      const threw = askValid(
        input,
        story,
        didAtWindow(Throw, { theme: child }),
      );
      const called = askValid(
        input,
        story,
        didCanonical(CallForHelp, {}),
      );
      return { threw, called };
    },
  };
}

// A chance happening serves no purpose, and it did happen. Asserting a
// purpose of it in the world is an Input error (`assertedInWorld`).
export function buildChanceWorld(assertedInWorld = false) {
  const input = [];
  const story = new Situation();
  input.push(story);
  const storyStart = new TimeAnchor(story);
  const storyEnd = new TimeAnchor(story);
  const fox = being(story, "the fox");
  const well = thing(story, "the well");
  const water = thing(story, "water");
  input.push(storyStart, storyEnd, fox, well, water);
  const fell = new Chance(story, { theme: fox, destination: well });
  Occurred(input, fell);
  const nearby = new Has(story, { holder: fox, thing: water });
  input.push(nearby);
  if (assertedInWorld) {
    // A translation error: the purpose is asserted of the chance fall in
    // the world, not in what someone says. ForPurpose's rule is
    // definitional, so the Input is sent back for repair.
    const purposedFact = new ForPurpose(story, {
      action: fell,
      goal: nearby,
    });
    input.push(purposedFact);
    input.push(new Assertion(story, { proposition: purposedFact }));
  }
  const purposedBody = new ForPurpose(story, {
    action: fell,
    goal: nearby,
  });
  input.push(purposedBody);
  const purposed = askValid(input, story, purposedBody);
  const happenedOcc = new Occurs(story, { event: fell });
  const happenedBody = new In(story, {
    proposition: happenedOcc,
    duration: duration(fell),
  });
  input.push(happenedOcc, happenedBody);
  const happened = askValid(input, story, happenedBody);
  return { ask: () => ({ purposed, happened }) };
}

// An unrelated yes-no question stays Unknown.
export function buildOpenWorld() {
  const input = [];
  const story = new Situation();
  input.push(story);
  const wolf = being(story, "a wolf");
  input.push(wolf);
  const presence = new Present(story, { subject: wolf });
  input.push(presence);
  const unrelated = askValid(input, story, presence);
  return { ask: () => ({ unrelated }) };
}

// Two things with the same surface name are still two things.
export function buildNameWorld() {
  const input = [];
  const story = new Situation();
  input.push(story);
  const one = thing(story, "a pebble");
  const other = thing(story, "a pebble");
  input.push(one, other);
  const presence = new Present(story, { subject: one });
  input.push(presence);
  input.push(new Assertion(story, { proposition: presence }));
  // Commons has no surface-text exemption: a written name field is an
  // ordinary open field and participates in matching, so an existence
  // question over a named pattern is decided by the name (OBSERVATIONS
  // G-7). The phase2 SURFACE rule does not carry over.
  const named = new Thing(story);
  named.name = "a pebble";
  input.push(named);
  input.push(new Virtual(story, { node: named }));
  const presenceQ = new Present(story, { subject: named });
  input.push(presenceQ);
  return { ask: () => ({ matched: askValid(input, story, presenceQ) }) };
}
