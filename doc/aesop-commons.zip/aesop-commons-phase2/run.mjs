// Runs the domain regression tests and every question case through the
// Foundation Evaluate pipeline over the Commons solver. Each case builds a
// fresh three-layer Input (dialogue root, story facts, the question's seat
// with its declarations and Query, then the dialogue's Asks, re-export
// Query, reply Says, and Imperative) and gets a fresh Resolve state, so no
// runtime object is shared between questions.
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";

const Stories = [
  { id: 1, title: "The Crow and the Pitcher" },
  { id: 2, title: "The Fox and the Crow" },
  { id: 3, title: "The Lion and the Mouse" },
  { id: 4, title: "The Dog and the Shadow" },
  { id: 5, title: "The Fox and the Mask" },
  { id: 6, title: "The Miser and His Gold" },
  { id: 7, title: "The Milkmaid and Her Pail" },
  { id: 8, title: "The Nurse and the Wolf" },
  { id: 9, title: "The Wolf in Sheep's Clothing" },
  { id: 10, title: "The Shepherd's Boy" },
  { id: 11, title: "The Fox and the Goat" },
  { id: 12, title: "The Ass's Brains" },
  { id: 13, title: "The Fox, the Cock, and the Dog" },
];

let Regression = [];
try {
  ({ Tests: Regression } = await import("./regression.mjs"));
} catch {
  Regression = [];
}

const only = process.argv.slice(2).map(Number);

function normalize(text) {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

let regressionsPassed = 0;
const regressionFailures = [];
for (const test of Regression) {
  try {
    await test.run();
    regressionsPassed += 1;
    console.log(`PASS  REG  ${test.name}`);
  } catch (caught) {
    regressionFailures.push({ test, caught });
    console.log(`FAIL  REG  ${test.name}`);
  }
}
for (const failure of regressionFailures) {
  console.log("");
  console.log(`--- REG ${failure.test.name}`);
  console.log(failure.caught.stack ?? String(failure.caught));
}
console.log(
  `Foundation/domain regression tests: ${regressionsPassed}/${Regression.length} passed`,
);

let passed = 0;
let total = 0;
const failures = [];
for (const story of Stories) {
  if (only.length > 0 && !only.includes(story.id)) continue;
  const cases = await import(`./cases/story-${story.id}/cases.mjs`);
  for (const [index, question] of cases.Questions.entries()) {
    total += 1;
    const label = `Story ${story.id} / Q${index + 1}`;
    let actual = null;
    let error = null;
    try {
      const input = cases.BuildCaseFor(question);
      const outputs = Evaluate(input);
      actual = Texts(outputs).join(" | ");
    } catch (caught) {
      error = caught;
    }
    if (error === null && normalize(actual) === normalize(question.expected)) {
      passed += 1;
      console.log(`PASS  ${label}  ${question.text}`);
    } else {
      failures.push({ label, question, actual, error });
      console.log(`FAIL  ${label}  ${question.text}`);
    }
  }
}

for (const failure of failures) {
  console.log("");
  console.log(`--- ${failure.label}: ${failure.question.text}`);
  console.log(`expected: ${failure.question.expected}`);
  if (failure.error !== null) {
    console.log("error:");
    console.log(failure.error.stack ?? String(failure.error));
  } else {
    console.log(`actual:   ${failure.actual}`);
  }
}

console.log("");
console.log(`Aesop questions: ${passed}/${total} passed`);
process.exit(
  passed === total &&
    total > 0 &&
    regressionsPassed === Regression.length
    ? 0
    : 1,
);
