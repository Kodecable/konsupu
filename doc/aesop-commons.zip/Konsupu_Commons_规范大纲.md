# Konsupu Commons 规范大纲（第二稿，已确认）

本文是 `doc/Konsupu_Commons_规范草案.md` 的大纲。C1–C3 已获用户确认
（2026-10-03），规范正文已产出；以正文为准，本文只保留讨论记录。

原型：`run/aesop-phase2/space/Memory/Aesop`（44 个文件，约 4270 行）。
问题来源：`run/Konsupu_Aesop_Phase2_评估.md` 及其后的讨论。

---

## 〇、已确定的事项

**范围与分发**

- Commons 是 Konsupu 项目的一部分，包括世界常识，没有独立版本号，只与同
  版本 Foundation 兼容，不考虑其他兼容性。
- 位置为 `src/commons/`，像 Foundation 一样复制进 space：`Memory/Commons/`
  放实现，`Interface/` 导出 Input Translation 使用的构造。回归时检查复制件
  与源码字节一致。
- Commons 包含参考求解器：语义规范必须可执行、可验证。
- Brand 采用 `commons:<Name>:v1`。其中 `v1` 只是 Brand 格式的一部分，不代表
  Commons 有独立版本。
- 原型中的全部具体词汇都收入 Commons（A1），Aesop 只保留 fixture 与题目
  编码。原有 96 个回归、65 道题、23 个变异作为验收。
- 对话层（用户陈述进入世界、参与者与"现在"、跨轮持久化）第一版只预留
  位置，将来由 Commons 自身包含，不另立库（A5）。

**语义原则**

- 类是否 final 只由本体论决定；`Event`、`Action` 改为 concrete。
- 描述是认知对象，它与什么对应由显式关系表达，绝不由节点身份或所在位置
  决定（r4 原则）。
- 每种开放角色各由一个独立关系表达，彼此正交、可组合（A2，具体设计见
  第六节）。
- 时间锚点统一为一个概念；"紧接 E 之前"与"E 之前任意时刻"分开表达（A3）。
- 问题写错是输入错误，经 `RequireInput` 交回 Input Translation；故事不
  支持才是"未确立"（A4）。

**A4 已实施：Foundation 的输入错误通道**

- Foundation 新增 `RequireInput(condition, reason)`：由 `Interface/Nodes.js`
  导出，经根 `Resolve.js` 转为 `InputObjectInvalidError`。
- 测试：Foundation 自检 `TestFixtureInputInvalid`，Go 集成测试
  `TestFoundationDomainInputErrorRepairsInput`。
- 文档：规范草案 §3.3、使用说明、备忘第 16 节。
- 原因进入诊断（用户授权修改 Runtime）：Runtime 的输入修复诊断由固定指引
  与 `Reason:` 后的认知原因组成，上限 1024 个 code point
  （`javascript/diagnostic.go` 的 `inputRepairText`；v0.9 规范同步）。

---

## 一、定位与原则

1. Commons 是什么：建立在 Foundation 之上的通用认知、世界常识与参考求解器。
2. 与 Foundation 的分工：
   - Foundation 管结构与信息流（Situation、Variable、Query、ref、
     Perspective）；
   - Commons 管认知的含义，包括持有、对应、范围、时间、否定、问题等。
3. 原则：
   - 开放世界：未断言的既不真也不假，没有否定即失败；
   - 一种语义关系只有一种 canonical 表示，故事侧与问题侧都适用；
   - 节点身份从不决定指称；
   - 持有与引入分开；
   - Input 顺序从不表示时间；
   - 不定义英语词的直译概念；
   - final 由本体论决定；
   - 角色只由显式关系声明，求解器不按位置推断；
   - 输入错误与"未确立"严格分开。

## 二、语境与持有

1. 语境布局：
   - 世界根；
   - 语境根：信念、言语、计划等，都是 root，不是细化；
   - 问题 Situation：世界的细化；
   - 范围 Situation：见第六节；
   - 对话根。
2. `Assertion`：一个 Situation 持有一个命题为真；`Assert`、`Hold` 的含义。
3. 持有与引入分开。
4. 读取范围：一个 Situation 读自己的持有与祖先链的持有；从不读其他语境
   的持有，除非经过显式的语境读取。
5. 输入错误：
   - 问题中的节点既未持有、也未被引用；
   - 开放节点没有声明角色；
   - 其他结构性错误。

## 三、对象

`Entity`（可选 `kind`）、`Kind`、`Event`、`Action`、`Condition`。

另需规定：
- 字段约定：语义字段与表面字段，`name`、`title` 不参与匹配；
- 字段未写出与 `Unknown` 的区别；
- 领域如何扩展。

## 四、事件关系

`Occurs`、`Agent`、`Causes`、`Enables`、`ResultsIn`、`Failed`、`Goal`、
`InOrderTo`、`Means`、`ByChance`、`Series`。

每个关系写明：含义、字段、何时被支持，以及类级规则。

## 五、时间

1. 次序：
   - `Next` 由故事断言，`Before` 由它推出；
   - `Overlaps` 表示两件事共享时刻。
2. 状态区间：
   - `Initially`、`ResultsIn`、`Ends`；
   - 惯性：唯一的默认推理；
   - `Lasted`。
3. 时刻：
   - 某事件之时；
   - 紧接某事件之前、之后；
   - 开始、结尾。
4. 窗口：
   - 由两个时刻界定；
   - 某状态持续期间；
   - 第 n 次。
5. 状态在时刻成立、事件在窗口内发生，各用一个条件命题表达。锚点不再有
   "随问题类型而变"的第二种读法。

## 六、开放角色：范围与量化（A2 的设计，待确认）

### 6.1 现状的问题

现在的开放角色有六种来源：
- `Among`；
- 形状字段表 `PATTERN_FIELDS`；
- 内容形状 `withQuestionShapes`；
- 替身 `standIn`；
- 精确匹配表 `markExact`；
- `NoEvent.actor` 与 `NoneSuch.some` 这类专用字段。

后五种都是求解器按位置推断，组合时会失效（S10Q3）。

### 6.2 设计：把"开放项"和"量化方式"拆开

**范围（scope）** 是一个子 Situation，它细化使用它的那个 Situation。

- 它自己引入的 Entity/Event 就是它的开放项（约束变量）。
- 它持有的命题就是对这些开放项的条件。
- 它可以直接引用外层的常量、描述与 Variable，因为它是细化。
- 是否算范围，不看位置，只看它是否被一个量化关系点名。这和 ∃x 约束 x
  的道理相同。

**量化关系** 每种一个，都以范围为参数：

| 关系 | 含义 | 取代 |
|---|---|---|
| `Some{scope}` | 存在一组开放项的取值满足范围的全部条件（被判断的存在） | 内容形状、替身、`AskWhether` 中的不定指 |
| `Not{proposition}`（已有） | 否定；`Not{Some{…}}` 即否定存在 | `NoEvent`、`NoneSuch`（含 `some`、`actor` 字段） |
| `Only{scope, node, are}` | 满足范围的每个取值，`node` 都是 `are` 中之一 | `OnlyDid`（含 `theme` 字段） |
| `Nth{scope, node, index}` | 按时间排列满足范围的取值，取第 n 个的 `node`，作为时间锚 | `Nth.pattern` |
| 类型参数：`Unable`、`Habitual`、`Forbids`、`Conditional` 等的 deed/antecedent 取 `{scope, node}` | 一类行为，不指称任何具体事件 | 形状字段表 |

**`Among{situation, node}` 保留**，专门表达"预设的指称"。它写在问题
Situation 中，点名的节点对应某语境所谈及的恰好一个对象，每个解绑定一次，
找不到就是 correspondence 级"未确立"。这和被判断的存在（`Some`）在语义上
不同，所以各有一种形式。它们的区别正是 P7："那只狐狸"预设失败为"未
确立"，"有没有一只狼"不成立为"否"。

**匹配方向由关系声明，取代精确匹配表**

- 存在性关系（`Some`、持有的事实）：问题条件被故事条件蕴含即支持，即
  故事更具体也行。
- 全称性关系（`Not{Some}`、`Unable`、`Forbids`）：故事的范围必须涵盖问题
  的范围，即故事更一般才行。
- 两种情况都是"范围之间的蕴含"，算法相同（合取查询的包含判定），只是
  方向相反。
- 原 §22 "不能轻易够到"不回答"能否够到"，由方向自然得出；回归
  "an inability of the easy way is not an inability at all" 两个断言都保持。

**结果**

- 求解器不再有任何"字段 → 角色"的登记表。
- 序数、窗口、否定可以任意嵌套，因为每层都是一个显式范围。
- 故事侧也一样："狼来了"的言语内容写成 `Some{…}`，"一只狼"的不定指在
  故事中就是显式的，不再需要替身规则（§26）。

### 6.3 示例

"Was there a wolf when the boy cried 'Wolf' the second time?"

```js
// The second cry: an ordinal over its own scope.
const cries = new Situation(asked);
const c = new CryOut(cries); c.call = "Wolf, Wolf";
const second = new Nth(asked); second.scope = cries; second.node = c;
second.index = 2;
// Judged existence: some wolf present at that cry.
const wolves = new Situation(asked);
const w = new Entity(wolves); w.kind = world.wolfKind;
const present = new Present(wolves); present.subject = w;
Assert(input, holdsAt(wolves, present, at(second)));
const some = new Some(asked); some.scope = wolves;
const q = new AskWhether(asked); q.content = some; q.verdict = answer;
Assert(input, q);
```

故事侧"那时没有狼"写成被 world 持有的 `Not{Some{scope}}`，其中 scope
内是"某只狼在某窗口内在场"。反驳判定就是范围之间的包含：问题的时刻
落在故事的窗口内，且问题条件被故事条件涵盖。

### 6.4 代价

- 题目编码要全部重写，故事中的否定事实也要重写，Input 中的 Situation
  数量会增加。
- 用 Interface 的问题级构造辅助弥补冗长：辅助只生成 canonical 形式，
  不引入新语义。

### 6.5 确认结果（用户已确认 C1–C3）

- **C1**：采用"范围子 Situation + 量化关系 + 保留 `Among` 作预设指称"这一
  结构，替换 `NoEvent`、`NoneSuch`、`OnlyDid` 与全部形状、替身规则。
- **C2**：匹配方向由关系声明（存在性与全称性），取代 `Unable` 的精确匹配
  表。这会新增一种结论：故事说"完全不能做 X"时，"能否轻易做 X"答"否"。
  现在这种情况是"未确立"，现有题目中没有这种情况。
- **C3**：时间改为范围中的条件命题，"状态在时刻成立""事件在窗口内发生"；
  `AskWhether.when` 字段删除。

## 七、问题

1. 问题 Situation：持有的命题就是约束，Variable 就是待求值。
2. 预设指称（`Among`）、被判断的命题（`AskWhether`）、跨语境读取
   （`HoldsIn`）、同一性（`SameReferent`）。
3. 每种问法一种 canonical 写法，在规范正文中逐条列出：
   - 谁做了什么；
   - 为什么，分原因、目的、动机；
   - 怎样；
   - 是否发生、是否成立；
   - 某时刻的状态；
   - 某语境中是否成立；
   - 言语真假。

## 八、否定

开放世界下，"否"的唯一来源是被持有的否定认知：
- `Not`，包括 `Not{Some}`；
- `Only`；
- `Unable`；
- `Missing`；
- 被 `Ends` 结束的状态；
- 类级不相容。

每种否定写明它能反驳什么。

## 九、语境内容与态度

- 言语：`Says`（内容是一个 Situation）；
- 态度：`Believes`、`About`、`Fears`、`Plans`、`Motivates`、`Promise`、
  `Approves`、`Deceives`；
- 规范内容：`Forbids`、`Mandates`、`Conditional`、`Proposes`；
- 习惯：`Habitual`、`Instance`；
- 五种"与事实不符"的判定（说假话、谎言、欺骗、误信、非实际语境）。

## 十、求解语义与结果

1. 支持规则与派生规则。
2. 范围的求值与包含判定（第六节）。
3. 联合求解：同一描述在所有约束中对应同一节点。
4. 是非判定：
   - 结果为 yes / no / conflict / NotEstablished；
   - 指定在哪个语境、哪个时刻求值。
5. 结果值：`Unknown`、`Ambiguous`、`NotEstablished`（三级）。
6. 输入错误清单（A4）。
7. 领域扩展点：新词汇如何声明匹配方向与类级规则，不修改 Commons 的
   求解器。

## 十一、对话与回复

1. `Asks`、`Reply`；四个领域入口如何接入 Commons。
2. 结果如何投影为输出。
3. 对话层的预留位置（A5）。

## 十二、世界常识词汇（A1）

按领域分组，每个类写明字段、Event 或 Action、是否 final 及理由：
- 位置与移动；
- 接触与操作；
- 持有与交换；
- 感知；
- 言语；
- 情绪与状态；
- 天气等。

原型中为凑 160 行而拆开的文件，按语义重新分组。

## 十三、验证

1. Commons 自测：形式对齐 Foundation 的 `Test.js`，用 `konsupu test` 运行，
   覆盖每条语义规则。
2. 验收：Aesop 的回归、题目、变异全部通过。题目编码的改动逐条记录，答案
   不得改变。C2 新增的结论单独记录。
3. 静态检查，作为输入错误实施（A4）：
   - 未持有、未引用的节点；
   - 没有角色的开放节点；
   - 非法的对应目标。

## 附录

- 概念到原型文件的对应表；
- 从 `aesop:*` 到 `commons:*` 的迁移清单。
