# amr-trial

单轮直出 AMR 的探针：对 `../aesop-commons-phase2/cases` 的 13 篇伊索寓言，
每篇把"故事 + 前 5 个问题"放进一个简单提示，让模型一次输出全部句子和问题的
AMR（PENMAN）。仿照 `../commons-trial`，本目录自包含，只依赖标准库
（`analyze.py` 另需 `pip install penman`）。

```shell
./prepare_cases.py                  # 生成 cases.json（13 故事 × 5 问，共 65 问）
./run_trial.py                      # 全部故事，并发 3；--only 1 4 --runs 2 可选
./run_trial.py --dry-run --only 1   # 只打印请求体
python3 analyze.py out/<folder>     # 用 penman 解析每个 AMR 块并汇总问题
```

API 设置读 `../opencode-go-dsv4.1f.json`（deepseek-v4.1-flash，thinking 开启，
reasoning_effort=low，temperature 0.8，max_tokens 取 max_output_tokens）。
密钥不复制进本目录。

提示（见 `run_trial.py`）：system 一句"AMR 专家"；user 给故事和 5 个问题，
要求逐句写 AMR，问题里用 `amr-unknown` 表示被问的东西，每项一个标题
（S1…/Q1…Q5）加一个 ```amr 代码块，不要别的文字。

输出：`out/<model>-<time>/story-N.md|json`（md 含 reasoning，json 是原始响应）。

## 第一轮结果（out/deepseek-v4.1-flash-20261008-170715）

13/13 个故事最终都有结果（story-3 前两次连接被远端关闭，之后补跑了两次都成功，
后一次覆盖前一次；被覆盖的那次有 1 个括号不平衡块），每次 40–120 秒。
每篇输出的 token 都由 reasoning 占大头：completion 共约 16.7 万，其中
reasoning 约 14.9 万（约 89%），可见内容只占一成。

用 penman 解析：112 个故事 AMR、65 个问题 AMR，无一解析失败，但有 20 处问题：

- 变量重复定义 19 处。最典型的是同一变量名既给根（`a / and`）又给
  内部概念（`a / another`）：story-1 S5–S10、story-10 S1–S8 几乎整篇如此（其余零星见 story-6/12/13）；
  这是真正的 AMR 错误，不是脚本误报。
- 问题缺 `amr-unknown` 1 处（story-11 Q4，"Could the fox get out…"：
  是非问句用了 `:mode interrogative` 而没有 `:polarity amr-unknown`）。

语义和风格上看到的：

- 问题的 `amr-unknown` 位置大多合理（Who → `:ARG0 amr-unknown`，Why →
  `:cause`，What → `:ARG1`）。是非问句写法不统一：有的用
  `:polarity amr-unknown`（story-10 Q4/Q5），有的用 `:mode interrogative`
  （story-11 全部），story-10 Q2 把 `:polarity amr-unknown` 挂在 `wolf`
  这个名词上，不是 AMR 的写法。
- 谓词常常没带 PropBank 框架编号（`take`、`drop`、`want-01` 混用），
  `then` 被写成概念。没有做 SMATCH，因为没有金标准；这些只是目测。
- 故事句数：每篇 4–13 个块不等（story-5、story-9 只有 4 块），模型常把
  多句合并成一个 `and`，所以块数不等于原文句数。

## 第二轮：关闭思考（out/deepseek-v4.1-flash-20261008-172940-nothink）

命令：`./run_trial.py --tag nothink --extra-body '{"thinking": {"type": "disabled"}}'`
（`--extra-body` 是在配置的 body 之上合并，`reasoning_effort` 等其余设置不变；
`--parallel` 默认改为 1，不并发）。返回的 reasoning_tokens 为 0，确认已关闭。

第一次并发 3 路跑，有 4 个故事（5、7、11、12）被 SSL 连接断开，之后串行补跑，都成功。

| | 开思考 | 关思考 |
|---|---|---|
| 每个故事耗时 | 40–120 秒 | 8–15 秒 |
| completion token 合计 | 约 16.7 万（reasoning 约 14.9 万） | 约 1.9 万（reasoning 0） |
| 故事 AMR / 问题 AMR | 112 / 65 | 117 / 65 |
| penman 检出问题 | 20 | 25 |

关思考后的问题构成（25 处）：

- **解析失败 11 处**（story-3 S4/S5、story-4 S5、story-6 S5/S6/S8、story-9 S2、
  story-10 S6、story-13 S7/S11/S13），抽查的几处都是括号没配平。开思考时是 0 处解析失败，
  这是两轮最大的差别：关思考后长句、多从句的句子容易写丢右括号。
- **变量重复定义 7 处**（开思考 19 处），story-13 最多。
- **问题缺 `amr-unknown` 7 处**（开思考 1 处）：story-10 Q1 把 `why` 当概念
  `(w / why :ARG0-of ...)`、story-2 Q2 用 `:time (w / when)` 代替，是非问句
  （story-7 Q3 "Did Patty buy any fowls?"）常常直接写成陈述式，没有标出被问的部分。
- 其余风格问题同开思考：多数谓词不带 PropBank 编号，`the`、`so` 之类被写成概念。

story-1、8、11、12 四个故事没有检出任何问题。

小结：关思考快 8 倍左右、便宜 9 成，故事句的 AMR 在内容上差别不大，但括号和变量这类格式细节变差，
问题里 `amr-unknown` 的标注明显退化。没做 SMATCH，语义优劣仍是目测。

## 第三轮：逐句请求（out/deepseek-v4.1-flash-20261008-180336-sentences-nothink）

```shell
./prepare_sentences.py          # cases.json -> items.json：109 个故事句 + 65 个问题
./run_sentences.py --tag nothink \
  --extra-body '{"thinking":{"type":"disabled"},"reasoning_effort":"none"}'
python3 check_sentences.py out/<folder>   # 程序检查，写 check.txt
```

- 切分：按 `. ! ?`（可带收尾引号）+ 空白 + 大写字母/开引号切，段落先分开，末尾寓意句也算一句。
  每个故事 4–13 句。三处"…said the mother,"与下一段引语被原文换行拆开（story-7 S9、story-8 S9、
  story-11 S7）。
- 每项一个请求，串行，没有故事上下文，提示只说"写这个句子（或问题）的 AMR，只输出一个代码块；
  问题里用 `amr-unknown`"。结果追加到 `results.jsonl`，同一个 `--out` 重跑会跳过已完成项。
- 174 项全部成功，共 526 秒，约 1.95 万 completion token，reasoning 为 0。

**关思考的坑**：第一次只用 `thinking: disabled` 跑，前 31 项 reasoning 为 0，从 story-2/Q5 起服务端
开始忽略它，每项思考几千 token、耗时涨到 20–100 秒（同样的请求，早先的整篇一轮也没这个问题）。
该次已中止，数据留在 `out/aborted-sentences-nothink-thinking-leaked/`，不要使用。
实测 `reasoning_effort: "none"` 能稳定关掉（0 token，约 3 秒），最终这一轮同时带上两者。
以后关思考都应检查返回的 reasoning_tokens。

### 程序检查（check_sentences.py）

174 项中 72 项（41%）没有任何硬问题（`omitted` 只算警告；数字按后来修正过的检查器重算，见第四轮）。各类别的项数：

| 类别 | 项数 | 说明 |
|---|---|---|
| parse | 14 | penman 解析失败（括号等） |
| novar | 31 | 节点没写变量，如 `(crow)`、`(happen-01 …)`，不是合法 AMR |
| dup-var | 4 | 同一变量引入两次 |
| dangling | 9 | 用了从未引入的变量 |
| unknown | 8 | 问题的 `amr-unknown` 不是恰好一个，或不含 `?` 的陈述句里出现了它 |
| polarity | 6 | 是非问句的 `amr-unknown` 没放在 `:polarity` 下，或特殊疑问句放了 |
| negation | 21 | `:polarity -` 与原文有无否定词不一致 |
| duprole | 14 | 同一节点上同一个单值角色出现两次（`:polarity`、`:mode`、`:name`、`:ARGn`） |
| relation | 38 | 非常规角色：`:conj`、`:tense`、`:agent`、`:theme`、小写 `:arg0`、`:instance-of` 等 |
| omitted | 41（警告） | 原文实词在图里找不到对应概念；词形还原很粗，噪声较大 |

`novar` 和 `negation` 是看了原始输出之后才补的检查（`duprole` 在第四轮补）；一开始没有 `novar`，
这些节点被误归到 "0 amr-unknown" 和 "dangling" 里。
与整篇一轮（关思考）相比：解析失败 14/174 对 11/182，重复变量 4 对 7，
`amr-unknown` 问题 8 对 7，数量相近，逐句请求没有明显改善这几类，
并且新暴露了无变量节点和多余的 `:polarity -`（整篇一轮没有查这两项）。

### 人工抽查

从 83 项"当时没有硬问题"的项里按固定种子随机抽 12 项（后来才加的 `negation` 又标出了
其中 story-12/S1），逐个看 AMR 是否对得上原文：

- 基本正确 4：story-1/Q1、story-8/S5、story-12/Q4、story-5/Q1（还带有少量多余的 `:time`）。
- 有瑕疵但可接受 4：story-3/S7（漏了 may）、story-12/S7（"ate them up"被放进了 `:purpose`）、
  story-2/S3（凭空加了 `:time now` 和 `hearer`，`Crow` 被当成人名）、story-1/Q4
  （`after` 没有 `:op1`，`amr-unknown` 放在 `:ARG2`，语义牵强）。
- 结构或意思错误 4：story-7/S6（`and` 被放进 `:time`，`just` 成了并列项）、
  story-9/S4（把 "deceptive" 写成 `appear-01 :ARG1 deceptive`，没有 deceive）、
  story-2/S6（`:op2` 挂在非 `and` 节点上，"only to be snapped up" 写成 `:purpose`）、
  story-12/S1（凭空多出 `:polarity -` 和 `:location unknown`，意思变成"没有一起去打猎"）。

也抽看了 `negation` 标出的几条：story-10/S1、story-11/S5、story-7/Q4 都是真的凭空多出 `:polarity -`
（"Did Patty buy any fowls?" 之类的是非问句里尤其常见）；story-6/S3 的 "nothing but" 是误报。

结论：逐句请求能保证"一个句子一个图"，但格式错误仍不少：8% 解析失败，18% 有无变量节点，
并且最麻烦的是**格式合法但意思错**的图：抽查的 12 项里有 4 项如此，程序只能靠 `negation`、
`polarity` 这类专项检查抓到其中一部分。以上都只是 12 个样本的目测，没有金标准，也没做 SMATCH。

## 第四轮：三个定向实验（均串行，`run_experiments.py`）

```shell
./run_experiments.py exp1    # 10 个长句，开思考
./run_experiments.py exp2    # 50 个句子，AMR 说明 + 预注入示例，关思考
./run_experiments.py exp3    # 15 个句子，各带前后各一句上下文，关思考
python3 compare_runs.py out/<实验目录> out/<基线目录>   # 与第三轮同一批句子配对对比
```

句子取自 `items.json` 的故事句，固定随机种子，所选 id 记在每个目录的 `selection.json`。
基线是第三轮（关思考、最简提示、无上下文）里**同一批句子**的结果。关思考的实验用
`thinking: disabled` + `reasoning_effort: none`，并且一旦发现 reasoning_tokens 非 0 就停止。
本轮 3 个实验共 75 个请求全部成功。这一轮顺手修了检查器：本身是疑问句的故事句（含 `?`）
不再因为有 `amr-unknown` 被标出，补了 `duprole`，`:vocative` 列入允许角色；
第三轮的计数已按新检查器重算。

### 实验 1：10 个长句，开思考（out/…-exp1）

从最长的 25%（≥ 116 字符）里抽 10 句，配置原样（thinking 开，reasoning_effort=low）。

| | 开思考 | 关思考（基线） |
|---|---|---|
| 有硬问题的句子 | 7/10 | 7/10 |
| 解析失败 / 无变量 | 1 / 1 | 1 / 1 |
| 否定不一致 / 重复角色 | 0 / 0 | 2 / 2 |
| completion token | 5.0 万（reasoning 4.8 万） | 1.9 千 |
| 耗时 | 736 秒 | 36 秒 |

人工看了 7 句（story-3/S1、12/S7、2/S6、4/S5、2/S5、12/S2、8/S7）：
- 开思考明显更好 2 句：story-4/S5 基线是垃圾输出 `(m :snt1 …)`，开思考给出结构完整的图；
  story-2/S6 用 `contrast-01` + `and` 把两个分句分开，基线则硬塞 `:op2` 给 `lift`。
- 差不多 / 都不理想 3 句：story-3/S1 开思考更整洁但丢了分句之间的并列；story-2/S5 内容更全，
  但把 `must` 写成 `:mod`、"just as" 处理错；story-8/S7 开思考基本合理（我没有逐项核对基线）。
- 开思考更差 1 句：story-12/S7 通篇用非 AMR 角色 `:agent`，还用了 `:contrast`、`:cause`，
  基线反而更接近正确。
- story-12/S2 开思考有两个节点没写变量、用了 `:content`、`:possessor`，解析失败。

结论：开思考能避开关思考时偶发的"垃圾输出"，但格式规范性没有变好（仍然会发明角色、漏变量），
代价是 token 约 26 倍、时间约 20 倍。10 个样本的差别不大，不能说开思考对长句有明确收益。

### 实验 2：50 句 + 定向的 AMR 说明 + 预注入示例，关思考（out/…-exp2）

系统提示是 `prompts/amr_guide_v1.md`（约 1.5k token，每个请求连同示例共约 1.9k 输入 token）：
针对前几轮暴露的问题写了：每个节点必须有变量、变量不重名、复用变量表示同指、不要裸词作关系值、
不编码时态/冠词/助动词、列出允许的角色并明确禁用 `:agent :patient :theme :recipient :speaker
:content :conj :tense :root :instance-of` 和小写 `:arg0`、并列/对比/时间/原因的结构写法、
`:polarity -` 只在有明确否定词时使用、情态、言语/思想动词、什么时候用 `:name`、疑问句里
`amr-unknown` 的位置，以及一个与语料无关的小例子。
历史里预注入一轮问答：句子 "The Hare laughed at the Tortoise and said, “You will never win
this race.”" 及其手写 AMR（均不在语料中）。其余与第三轮相同。

| 类别 | 说明+示例 | 基线（同 50 句） |
|---|---|---|
| 有硬问题的句子 | 10/50 | 25/50 |
| parse | 0 | 4 |
| novar | 0 | 3 |
| dangling | 0 | 5 |
| dup-var | 2 | 2 |
| duprole | 3 | 2 |
| negation | 1 | 5 |
| relation（非常规角色） | 2 | 12 |
| unknown | 3 | 0 |
| omitted（警告） | 16 | 18 |

格式类问题几乎被消除（解析失败、无变量、悬空引用全部为 0，非常规角色 12→2，否定不一致 5→1）。
`unknown` 增加了：3 项里 story-7/S2 是 "what she would do" 里合理的 `amr-unknown`（检查器的误报），
story-12/S10 "Wit has always an answer ready." 把 `amr-unknown` 用在了陈述句上（提示里的疑问句规则被
错用了），story-7/S9（被切开的半句 "“Ah, my child,” said the mother,"）用 `amr-unknown` 占位被省略的引语，
也不对。重复变量 2 项：story-8/S1 把已有的 child 又写成 `(c / child)`，应该复用变量；story-4/S5 的 `m3` 同理。

人工抽查：随机抽 8 个"程序无异议"的句子（5 个有基线对照）。语义基本对 2 个，有瑕疵 3 个，
明显错 3 个：story-3/S6 "Was I not right?" 同一节点上有两个 `:polarity`；story-13/S3
"Why, what is that?" 是疑问句却没有 `amr-unknown`；story-3/S2 把引语和旁白并列。
与基线配对看的 5 个里：更好 3（story-1/S5、story-2/S8 基线语法就错、story-12/S5 基线凭空重复 `have-03`），
相当 2。

结论：说明书+示例大幅改善**格式和规范性**（程序可检测的部分），这部分基本归零；
但"格式合法而意思有误"这一类（结构挂错位置、缺逻辑关系、疑问句处理）没有明显减少，
抽查里程序无异议的句子仍有 3/8 明显错。因此 10/50 对 25/50 夸大了实际的语义提升。
这是 8 个样本的目测，没有金标准。

### 实验 3：每句带前后各一句上下文，只解析中间句，关思考（out/…-exp3）

从有前后邻句的 15 句里随机抽（邻句限于同一故事）。提示："三个连续的句子，只写中间句的 AMR，
其余仅用于消解代词和指代，不要写进 AMR"。系统提示、关思考设置与基线相同。

| | 带上下文 | 基线 |
|---|---|---|
| 有硬问题的句子 | 10/15 | 5/15 |
| parse / unknown / duprole | 1 / 1 / 1 | 0 / 0 / 0 |
| negation / relation | 3 / 5 | 3 / 4 |

人工看了 7 句（story-6/S4、12/S7、2/S10、6/S7、1/S3、13/S7、13/S5）：更好 1（13/S7）、
相当 2（6/S4、6/S7）、更差 4：story-12/S7 把 `wait` 的 `:ARG1` 写成 lion、`:time` 挂 `but`，还少了一个右括号；
story-2/S10 "Do not trust flatterers." 被写成 `amr-unknown :domain …`（陈述句被当成问句）；
story-13/S5 用了小写 `:arg0` 和 `may :polarity -`；story-1/S3 用 `then` 做根节点。
指代消解没有发生：文本含代词的 10 句里，图中仍作为概念出现的代词（he/she/it/they…）合计 10 个，
基线 12 个（story-12/S7 解析失败，不计入带上下文一侧），几乎一样；"he" 没有被替换成前文的 Miser、Crow 等，而且同一句里还会反复引入
`(h / he)`、`(h2 / he)` 而不复用变量。注意提示只说了"用于消解指代"，没有明确要求把代词写成先行词，
所以这只是这条提示下的结果，不等于模型做不到。

结论：在这条最简提示下，带上下文没有带来可见收益，格式上反而略差
（10/15 对 5/15，样本很小，但方向一致），也没有改善指代。

### 小结

| 做法 | 相对"关思考、最简提示、单句"基线 |
|---|---|
| 开思考（长句） | 去掉偶发的垃圾输出，格式规范性不变，成本约 20–26 倍 |
| AMR 说明 + 示例 | 格式类问题几乎清零（硬问题 25/50→10/50），语义错误仍在 |
| 带前后文 | 无明显收益，指代没有被解决，格式略差 |

三者互不叠加，也没有设重复；每个实验都是单次采样（temperature 0.8），差异在小样本下有噪声。

## 第五轮：补全 AMR 说明（v2）并重跑实验 2

```shell
./run_experiments.py exp2 --version v2   # prompts/amr_guide_v2.md + prompts/example_v2.json
```

**v2 提示词**：指南 + 预注入示例共 2390 个输入 token（服务端 prompt_tokens，含约 60 的用户消息外壳），
在 2.5k 预算内（v1 为 1941）。在 v1 基础上补进了此前各轮见过的错误类型，每条都配了正确写法：
变量规则（复用同指、同一句内也复用、不重名）、`-of` 与关系从句、被动、非 AMR 角色的**替换对照**
（speaker/hearer/content/result/contrast/between/possessor…）、并列/对比/时间/原因/目的/让步的结构、
`so…that`、控制动词、副词与小品词（`:mod`/`:time`）、"X is Y" 与存在句、方位与部分、所有格与数量、
人名与普通名词、否定与情态（"could not" 把否定放在情态节点上；一个节点最多一个 `:polarity`）、
言语/思想与祈使、残句只编码写出来的部分、疑问句（引语里的问句同样标 `amr-unknown`；
其他 wh 词对应的角色；陈述句不出现 `amr-unknown`）、格言按字面编码。

**否定的是非问句的约定（我选的，需要你确认）**：一个节点只有一个 `:polarity`，所以 "Was I not right?"
写成 `:polarity (a / amr-unknown)`，不写 "not"。这样会丢失否定所表达的倾向。检查器按此约定
不再要求这类句子里有 `:polarity -`。

**预注入历史**：一轮问答，句子是语料之外的
"The Goat, who was grazing at the foot of a hill, could not find the gate, so he began to call for the
Farmer, and the Farmer said, “Wait here until I come.”"，手写 AMR，经 penman 解析且通过检查器。
用程序核对它确实用到了这些高频易错写法：每个节点有变量且不重名、同指复用变量（有 4 处以上）、
`and` 在根、否定只出现一次且放在 `possible-01` 上、`so` → `cause-01`、控制动词 `begin-01` 复用主语、
`say-01` 的 ARG0/ARG1/ARG2（说者/内容/听者）、祈使 `:mode imperative`、关系从句 `:ARG0-of`、
`:part-of` 与 `:location`、大写动物名按普通名词、没有时态/冠词/助动词概念、没有非 AMR 角色。
没有覆盖到的（只在指南文字里讲）：疑问句、残句、人名、数量、`never`/`ever`。

**结果**（同样的 50 句，关思考，更新后的检查器重算了三方）：

| 类别 | 基线 | v1 | v2 |
|---|---|---|---|
| 有硬问题的句子 | 25/50 | 10/50 | 8/50 |
| parse | 4 | 0 | 1 |
| novar | 3 | 0 | 0 |
| dup-var | 2 | 2 | 0 |
| dangling | 5 | 0 | 0 |
| unknown | 0 | 3 | 3 |
| negation | 5 | 1 | 0 |
| duprole | 2 | 3 | 3 |
| relation（非常规角色） | 12 | 2 | 2 |
| omitted（警告） | 18 | 16 | 15 |

v2 的 8 个硬问题句子：story-4/S3 解析失败（缺右括号）、story-10/S3/12/S2/8/S10 同一节点重复 `:ARGn`、
story-7/S2（"what she would do" 里合理的 `amr-unknown`，误报）、story-8/S9、story-7/S9（残句里仍然
编出了 `amr-unknown`）、story-10/S8（`:modal` 不是 AMR 角色）。

**人工看了的项**：
- 此前点名的 6 个典型失败项：story-3/S6（只剩一个 `:polarity`）、story-12/S10（陈述句不再有 `amr-unknown`）、
  story-8/S1（不再把 child 引入两次，用上了 `:mode imperative`）已改好；
  story-13/S3 引语里的问句有了 `amr-unknown`，但 `what-01 :cause amr-unknown` 的结构仍然别扭；
  story-12/S5 祈使对了，但把 "here" 写成了 `:ARG1`；
  story-7/S9 仍然没改好：残句 "“Ah, my child,” said the mother," 仍写了 `amr-unknown`，
  说明 "残句只编码写出来的部分" 这条没起作用。
- 随机再抽 8 个程序无异议的项，与 v1 配对：更好 4（story-10/S2 用上了 `cause-01`、story-5/S1、
  story-9/S3 结构明显更好、story-11/S4）、相同 3、更差 1（story-2/S11 把整个 `rob-01` 写了两遍）。
- 指南里的一处缺口：story-8/S9 "“Ah,” said the Wolf as he galloped away," 的引语本身就是感叹词，
  而指南说 "丢掉感叹词"，模型于是用 `amr-unknown` 占位。应补一句：整个引语就是感叹词时写成
  `(a / ah :mode expressive)`。这次没有改，以免和已跑的结果不一致。

**小结**：v2 把重复变量（2→0）和否定不一致（1→0）清零，其他格式类问题保持在低位，
硬问题 10/50 → 8/50，差距很小（小样本，噪声同量级）。比 v1 好的主要是结构选择
（`cause-01`、并列放根、祈使、引语问句），人工配对抽查的方向一致但样本只有 14 项；
残句、引语中的问句、"here" 这类角色错位仍有残留。耗时 248 秒对 v1 的 133 秒，应是服务端波动，
没有深究。

## 第六轮：自然语言理解对照（不涉及 AMR，out/deepseek-v4.1-flash-20261008-190633-nlu）

目的：确认前几轮 AMR 里的错误不是模型读不懂句子。取第五轮之前人工抽查过的那些"程序无异议"的句子
（v1 抽查 8 个、v2 抽查 8 个，共 15 个不同的句子），每句我手写一个自然语言问题和参考答案
（`nlu_items.json`，先定稿再跑），只给模型原句和问题，不出现 AMR，关思考，串行，用平常语言回答。
`./run_nlu.py` 运行，我对照参考答案逐条批改（不是盲评）。

结果：**15/15 答对**，reasoning 全为 0，每个请求约 1.5–2.5 秒。问题刻意问到了前几轮 AMR 出错的地方：

| 句子 | 问题考察的点 | 同一句 AMR 里出现过的错误 |
|---|---|---|
| story-3/S6 | 反问句想表达什么 | v1 同一节点两个 `:polarity` |
| story-13/S3 | 是陈述还是提问、问什么 | v1 没有 `amr-unknown` |
| story-12/S5 | 谁睡觉、谁被叫去看守 | v1 把角色写反（`:ARG1 i`） |
| story-3/S3 | 狮子为什么放了老鼠 | 因果挂错位置 |
| story-9/S3 | 谁吃了羊羔、穿谁的皮 | 子句并列/因果结构错误 |
| story-5/S1 | 原文有没有说怎么进去的 | 不要凭空补内容 |
| story-1/S5 | 是不是第一块石子 | "another" 的处理 |
| story-11/S4 | 是在邀请吗 | `polarity -` 与疑问句的关系 |

其余 7 个（story-10/S2、2/S8、3/S2、3/S7、4/S1、2/S11、13/S8）同样答对。两处细微差别，我没有算错：
story-3/S7 把 "may" 说成 "can"；story-12/S5 的回答没提 "here"。

局限：每句只有一个问题，问题都能由单句回答，且是我自己写的、自己批改的，难度偏低，
不能代表整篇故事的推理或跨句指代。结论只限于：在这些句子上，模型的自然语言理解没有问题，
AMR 里的错误来自形式化（格式、角色选择、结构挂接），不是读不懂原文。

## 第七轮：v2 仍然犯的错对语义影响多大？（`v2_review.json`）

把 v2 的 50 条输出（`out/*-exp2-v2`）逐条对照原句过了一遍，分三档（单人判断，不是盲评）：

- **ok**：意思与原句一致，图是合理的 AMR；
- **minor**：写法不规范或结构错位，但原句里的事实都还在、没有被写成别的意思，读者能还原；
- **major**：原句中的某个事实被写丢、写反或写成别的东西（角色错位、连接关系被换成另一种、
  情态丢失、引语内容丢失、疑问变成陈述等），针对这句话提一个合理的问题就可能得到错误答案。
  规则：连接词退化成中性的 `and` 算 minor；被换成另一种断言的关系（如 `contrast-01`）算 major。

结果：**ok 18、minor 19、major 13**（26% 的句子有事实层面的错误）。

13 个 major 的原因：

| 类型 | 句子 |
|---|---|
| 连接关系错（时间/并列被换成 `contrast-01`，因果丢失或反向，从句挂错） | story-4/S5、9/S2、12/S4、11/S3（`cause-01` 方向反了）、7/S3（`sell-01` 挂到了"下蛋"上，"they" 没指回 fowls） |
| 习语、引语、残句被写乱 | story-2/S2、12/S9、8/S9（"Ah" 被写成 `amr-unknown`）、10/S5 |
| 角色或对象写错 | story-12/S10（wit 成了被回答的对象）、13/S3（问成了 why 而不是 what）、6/S3（"nothing but the empty hole" 变成"什么也没找到"） |
| 情态丢失 | story-3/S7（"may prove" 变成事实） |

minor 的典型：重复写一个事件、`but` 写成 `and`、`here` 当成 `:ARG1`、"used to" 写成 `:mod used`、
同一个实体被引入两次（story-3/S1 的 mouse）、`mean-01` 包住引语动词（story-3/S2）、
按约定丢掉否定的是非问句（story-3/S6）。

**程序检查几乎看不见这些语义错误**：

| | 程序标出硬问题 | 程序没标出 |
|---|---|---|
| ok（18） | 0 | 18 |
| minor（19） | 7 | 12 |
| major（13） | 1 | **12** |

13 个 major 里只有 1 个（story-8/S9）被程序标出；被标出的 8 个里有 7 个只是 minor
（重复 `:ARGn`、`:modal`、残句的 `amr-unknown` 占位等）。也就是说检查器抓的是形式问题，
和语义严重程度基本不相关，"硬问题 8/50" 不能当作语义错误率。

另外，第六轮显示模型对这些句子的自然语言理解没有问题，所以这些 major 是形式化时丢掉或写错的，
不是读不懂。

**忽略"逐句、无上下文"造成的错误后**（`v2_review.json` 里的 `context_related` 与
`verdict_without_context`）：只有依赖前后句才能写对的错误才算这一类，共 2 句——
story-12/S4（句首 "But" 被写成了本句两个分句之间的 `contrast-01`，其余部分没问题，降为 ok）、
story-9/S2（同样的句首 "But"；句内丢掉的 "so" 只剩中性的 `and`，降为 minor）。
结果：**ok 19、minor 20、major 11**（22%）。

一处更正：上一版文字曾把 story-4/S5 和 story-8/S9 也归为上下文问题，这不对。
story-4/S5 的主要错误在句内（"but as he opened his mouth" 被写成 `contrast-01`），
story-8/S9 的引语 "Ah" 就在本句里，错在指南"丢掉感叹词"那条的缺口（见第五轮），所以都保留为 major。

剩下的 11 个 major：

| 类型 | 句子 |
|---|---|
| 连接关系错（时间被换成 `contrast-01`、因果方向反了、从句挂错） | story-4/S5、11/S3、7/S3 |
| 习语、引语被写乱 | story-2/S2、12/S9、8/S9、10/S5 |
| 角色或对象写错 | story-12/S10、13/S3、6/S3 |
| 情态丢失 | story-3/S7 |

其中被程序检查标出的仍然只有 story-8/S9 一个。

没有测的：这些错误对下游使用（比如编码成 Commons 并求解）的实际影响，以及 minor 里
"实体被引入两次"在需要同指的推理中是否会变成 major。

### 第七轮补：这些 major 有多少是程序原则上判断不了的？集中在哪些结构上？

**方法**：把能想到的机械规则真的写出来（`check_extra.py`），在 v2 的 50 条上跑，再与手工判定对照。
规则只依赖文本与图本身，不需要理解句子：情态词（may/can/could/must/able）对应 `possible-01`/`obligate-01`；
含 `?` 的句子必须有 `amr-unknown`；介词/连词（for、but、on…）被写成概念；`cause-01`/`contrast-01`
缺论元、`say-01` 缺 `:ARG0`；`after`/`before`/`until` 没有 `:op1`。
（还试了"同一名词概念出现两个变量"，误报很多、命中多是巧合，已弃用。）

| 判定 | ok（19） | minor（20） | major（11） |
|---|---|---|---|
| 新规则命中 | 0 | 4 | 6 |
| 原检查器命中 | 0 | 7 | 1 |
| 二者之一命中 | 0 | 10 | 7 |

**11 个 major 的可检测性**：
- 原检查器已经抓到：1 个（story-8/S9，句子里的 `amr-unknown`）。
- 一条简单规则能直接抓到违规本身：story-3/S7（"may" 却没有 `possible-01`）；
  story-11/S3 的"疑问句没有 `amr-unknown`"（该句另有因果方向反了，规则抓不到）。
- 规则只能抓到副作用、不能抓到错误本身：story-2/S2（`for` 当概念、`cause-01` 缺论元）、
  story-12/S9（`say-01` 没有 `:ARG0`）、story-10/S5（`after`/`before` 悬空）、story-6/S3（`but` 当概念）。
  这些命中是因为模型写乱时碰巧留下了形式上的破绽，修掉破绽并不保证意思对。
- **程序原则上判断不了：4 个**——story-4/S5（两个分句该用什么关系、哪个是 `:time`）、
  story-13/S3（"Why," 是感叹词还是问因）、story-12/S10（wit 是 `answer-01` 的哪个论元）、
  story-7/S3（`sell-01` 该挂在蛋上还是下蛋上）。再加 story-11/S3 里"因果方向"那一半，
  共 4 个整句 + 1 个半句。这类错误图是合法的，也没有形式破绽，只有理解了句子才能判断。

规则在 ok 上没有误报（0/19），在 minor 上命中 4 个，那些 minor 本身确有缺陷。
**但这些规则是看过这 50 条的错误之后才写的，所以上面的"能抓到"是偏乐观的上限**，对新句子能抓到多少不清楚。

**结构集中度**（`verdict_without_context`，n=50，major 共 11 个）：

| 特征 | 有该特征的句子 major 率 | 其余 | 单侧 Fisher p |
|---|---|---|---|
| 图中有 `say-01`（言语/引语内容） | 6/12 = 50% | 5/38 = 13% | 0.01 |
| 句子含引号 | 7/22 = 32% | 4/28 = 14% | 0.13 |
| 含引号且含连接词 | 4/9 = 44% | 7/41 = 17% | 0.09 |
| 图中有 `cause-01`/`contrast-01` | 4/11 = 36% | 7/39 = 18% | 0.18 |
| 图中有 `:polarity -` | 4/10 = 40% | 7/40 = 18% | 0.13 |
| 句长 > 120 字符 | 4/11 = 36% | 7/39 = 18% | 0.18 |
| 关系从句（`:ARG0-of`/`:ARG1-of`） | 1/13 = 8% | 10/37 = 27% | 0.98 |
| 情态（`possible-01`/`obligate-01`） | 1/5 = 20% | 10/45 = 22% | 0.73 |

读法：最明显的集中是**言语/引语的内容**（图中有 `say-01` 的句子一半是 major），
其次是**句内的因果/对比/时间连接**（story-4/S5、11/S3、7/S3）和**否定**。
关系从句、情态没有集中，关系从句反而更好（指南里专门写了写法）。
但样本很小（11 个 major），特征是看过结果后选的，做了约 10 次比较而没有校正，
`say-01` 的 p=0.01 校正后不显著；"图中有 say-01" 是模型写出来的结构，不是独立于结果的输入特征，
有一定循环。所以这只能当作线索：引语内容与句内连接关系是最值得单独设计提示或检查的两处。

## 第八轮：mimo-v2.6-pro 对照（`out/mimo-v2.6-pro-*-exp2-v2`，`mimo_v2_review.json`）

`./run_experiments.py exp2 --version v2 --model mimo-v2.6-pro`：与 deepseek v2 相同的 50 句、相同的提示词和 API 设置
（关思考，reasoning 为 0），50/50 完成，约 6.1k completion token，282 秒（deepseek 为 6.1k、248 秒）。
`--model` 只替换模型 id，其余设置不变。

**glm-5.3-flash 未完成**（13/50 后被你终止，数据不可比，不使用）：网关拒绝 `thinking` 字段（HTTP 400），
只能用 `reasoning_effort: none`（用 `--drop-body thinking`）；它把分析文字写在 content 里，13 条全部
在代码块前有文字、9 条有多个 ```amr 块，平均 42 秒、约 2.4k token；不带开关时 `reasoning_tokens`
显示 0 但返回里有 reasoning 文本，所以保护检查现在同时看 reasoning 文本。

**程序检查**：有硬问题的句子 4/50（deepseek v2 为 8/50）。

**人工逐条判断**（标准同第七轮：ok/minor/major，单人，非盲评；我在读 mimo 的每一条时旁边列着
deepseek 的判定，可能有锚定偏差）：

| | ok | minor | major |
|---|---|---|---|
| mimo | 27 | 17 | **6** |
| deepseek（忽略上下文后） | 19 | 20 | 11 |

逐句对照（行 = deepseek，列 = mimo）：

| | ok | minor | major |
|---|---|---|---|
| ok | 15 | 3 | 1 |
| minor | 7 | 11 | 2 |
| major | 5 | 3 | 3 |

- 两边都 major：story-2/S2、12/S9、6/S3（同一类错误：习语/引语写乱，"nothing but" 写成"什么也没找到"）。
- 只有 mimo major（3）：story-2/S11（wit and wealth 写成 `victim :consist-of`）、
  story-11/S4（"don't" 的否定丢了，且有两个 `amr-unknown`）、story-12/S5（"Watch" 写成 `wait-01`）。
- 只有 deepseek major（8）：story-4/S5、3/S7、13/S3、10/S5、8/S9、12/S10、7/S3、11/S3。
  mimo 在这些句子里正确处理了连接关系（but → `contrast-01` 且论元对、so → `cause-01`、as → `:time`、
  因果方向正确）、情态（`possible-01`）、引语里的问句、`have-03`、"Ah" 作内容。
- mimo 的新毛病：给没有 "said" 的引语凭空加 `say-01` 外壳（story-13/S9、2/S8、8/S2）、
  把 "he" 写成 "dog" 这种从寓言常识补出来的指称、story-4/S2 括号不平衡。
- mimo 的 6 个 major 里只有 1 个被程序标出（story-12/S9 的悬空变量），新规则一个都没命中，
  且在 ok 上有 2 个误报（`among`/`by` 作为带 `:op1` 的概念，story-9/S2、11/S3）。
  即程序检查对 mimo 的语义错误同样几乎看不见（1/6）。

小结：在这 50 句上，mimo 的严重语义错误约为 deepseek 的一半（6 对 11），主要优势在句内连接关系和情态；
两者的剩余错误仍集中在习语/引语的内容与否定。样本是 50 条，判定是我一个人做的，差距不算大，
不宜当作两个模型的稳定排名。

## 第九轮：更新检查与提示词，并把检查接入调用流程（重试）

**组成**

- `amr_checks.py`：调用时用的检查器。每个问题带"错在哪、怎么改"的说明，因为清单会原样作为下一轮用户消息发回。
  代码：format、parse（给出括号数或 penman 报错的行与那一行文字）、novar、dup-var、dangling、duprole
  （提示 `:ARGn-of` 会让子节点多一个 `:ARGn`）、relation（非 AMR 角色及替换写法）、unknown、polarity、negation、
  modal、say-invented、arity、funcword、leaf-rel。只放精度足够高、值得触发一次重试的规则；
  "漏译词"这类噪声大的启发式不在其中。
- `run_pipeline.py`：每个句子发请求 → `check_amr` → 有问题则把回答和问题清单作为新一轮用户消息追加到同一上下文，
  最多重试 3 次（每个句子至多 4 次请求）；采用第一个无问题的回答，若始终有问题则采用问题最少的那次（并列取最早）。
  串行，deepseek 关思考（`thinking: disabled` + `reasoning_effort: none`，reasoning 非 0 就停止）。
  需要 `pip install penman`。`--set dev50`（调规则和提示词时用过的 50 句）或 `--set held59`
  （其余 59 句，调的时候没看过），`--version v1|v2|v3`，`--max-retries 0` 即不重试。
- `prompts/amr_guide_v3.md` + `prompts/examples_v3.json`：指南加 4 个预注入问答共 2316 token（含约 60 的外壳，
  v2 为 2390），在 2.5k 预算内。相对 v2：补了连接关系的论元顺序（but → `contrast-01` 前句为 `:ARG1`；so →
  `cause-01` 原因为 `:ARG0`、结果为 `:ARG1`；when/as → 挂 `:time`）、只有出现言语动词才用 `say-01`/`ask-01`、
  代词不要换成常识里的名词、整句引语是感叹词时写 `(a / ah :mode expressive)`、"nothing but X" = only X、
  "Why don't you X" 保留否定并用 `:cause amr-unknown`、动词保持原样（watch ≠ wait）、情态必须写出、
  最多一个 amr-unknown 和一个 `:polarity`、整个答案会被程序检查。
- **预注入历史（4 个，均不在语料中，且通过 `check_amr`）**：①Goat（关系从句、`could not`、`so`、控制动词、
  引语的说者/内容/听者、祈使）；②Crab/Heron（`when` → `:time`、`but` → `contrast-01` 论元顺序、同指复用）；
  ③"Why don’t you stay for dinner?" asked the Stork（引语中的 wh 问句、`ask-01`、否定、`:cause amr-unknown`）；
  ④Ox（`may` → `possible-01`、"nothing but" → `:mod only`）。用程序核对了这些写法确实都出现在示例里：
  变量不重名、同指复用、`and` 在根、`contrast-01` 与 `:time`、`cause-01`、`possible-01`、否定只在需要处且每节点一个、
  `only`、`say-01`/`ask-01`、wh 问句、祈使、关系从句、控制动词、`:part-of`/`:location`。
  示例没有覆盖：是非问句、整句感叹词、残句、人名、数量（这些只在指南文字里）。

**检查器的精度**（在已有的 100 条人工判定上，deepseek v2 50 + mimo v2 50，其中 ok 46、minor 37、major 17）：
对 ok 的误报 0/46；命中 minor 19/37、major 12/17（修复后，见下）。命中不等于语义正确，反过来也一样。
这 100 条也是调规则时看过的，所以这些数字偏乐观。

**结果（deepseek，关思考，重试上限 3）**

| | dev50（调过） | held59（没调过） |
|---|---|---|
| 首次回答通过检查 | 38/50（v2 无重试：32/50） | 39/59（v2 无重试：34/59） |
| 重试后最终通过 | 49/50（story-10/S2：重复 `:ARG1`） | 58/59（story-10/S7：介词当概念） |
| 触发重试的句子 | 12（请求次数：2 次的 7 句、3 次的 2 句、4 次的 3 句） | 20 |
| completion token | 9.9k（v2：6.1k） | 11.4k（v2 无重试：8.0k，+41%） |
| 输入 token | 173k（v2：120k） | 201k（v2 无重试：142k，+41%） |
| 耗时 | 270 秒 | 347 秒（v2 无重试：210 秒） |

**人工判断（同第七轮的 ok/minor/major 标准，忽略上下文造成的错误）**

- **dev50**：v3 最终 ok 25 / minor 19 / **major 6**（deepseek v2 为 19/20/11，mimo 为 27/17/6）。
  这 50 句调过规则和提示词，且采样有随机性（temperature 0.8）：v3 修好了 4/S5、3/S7、8/S9、12/S10、6/S3、7/S3、
  11/S3、13/S3 的 major，但也新冒出 3/S2（"forgive me" 的方向反了）、12/S5（"Watch" 又写成 `wait-01`）、
  9/S3（"began to follow" 丢了）、8/S2（凭空的 `threaten-01`，施事写错）。
- **held59，盲评**（每句随机把 v3 和 v2 标成 X/Y，我先判再揭晓）：
  v3+重试 ok 29 / minor 24 / **major 6**，v2 无重试 ok 20 / minor 31 / **major 8**。
  逐句：v3 更好 19、更差 11、相同 29（符号检验单侧 p=0.10、双侧 0.20，不显著）。
  触发重试的 20 句：更好 7、更差 5、相同 8；没重试的 39 句：更好 12、更差 6、相同 21。
  结论：方向上有改进，但差距小，样本小，不能说显著。

**检查器自己造成的退步（留出集上发现的）**：v3 的 6 个 major 里有 3 个和检查器有关——
① story-6/S6 "“Nay,” said he, “I only came to look at it.”"：我把 `nay` 算作否定词，第一次回答没有
`:polarity -` 就要求补上，模型照做，把 "I only came" 改成了否定；② story-7/S4 "…won’t all the young men
come up and speak to me!"：反问式感叹被当作否定，同样被迫补 `:polarity -`，意思反了；
③ story-13/S11 的 `ask-01` 无言语动词却凭空出现（"asker" 还写成了 you），因为"凭空 say"检查只管 `say-01`。
另外 3 个是模型自己的错：story-2/S5（"let me hear" 施事写成 you）、6/S1（丢了 hide、foot、tree、garden）、
12/S8（`amr-unknown` 放在 `:manner`，问成了 how）。

**跑完后做的修复（没有整体重跑）**：`nay`/`lest` 只用于"允许出现 `:polarity -`"、不再用于"必须有 `:polarity -`"；
含 `!` 不含 `?` 的 "n't + 主语" 反问式感叹不要求否定；`ask-01`、`tell-01`、`reply-01`、`answer-01`、
`exclaim-01`、`shout-01`、`whisper-01` 同样适用"无言语动词则为凭空添加"。
在 100 条标注数据上对 ok 仍零误报，多抓到 1 个 major（12/17）。只重跑了上面 3 个句子
（`out/rerun-fixed-checker-3items`）：6/S6 一次通过且没有 `:polarity -`；7/S4 重试 2 次后写成了
"men come … and speak"，没有否定；13/S11 重试 1 次后去掉了 `ask-01`。**所以上面 held59 的数字是修复前的**，
而且这 59 句现在已经看过，不能再当作干净的留出集。

**小结**
- 检查流程把"形式错误"基本清零（最终通过 49/50 和 58/59，每次至多 4 次请求，输入输出 token 约 +41%），
  但语义上的 major 只从 8 降到 6（留出集，盲评），差距不显著。
- 重试能修好的是形式问题；语义错误（施事、连接关系的方向、引语内容、问句的目标）基本不在检查器的能力范围内，
  重试也不会修好它们（它们的图是合法的，没有可反馈的信息）。
- 检查规则本身有风险：规则的"必须有……"一旦误判，重试会把对的答案改错（本轮的 2 个例子），
  所以每条"必须有"的规则都需要先在标注数据上量误报。
