#!/usr/bin/env python3
"""Paired comparison of an experiment folder against a baseline folder on the
items the experiment contains (needs `pip install penman`).

  ./compare_runs.py out/<experiment> out/<baseline>

Prints, per check category, how many items each side has flagged, and the
per-item categories. `omitted` is a warning and is left out of the hard count.
"""

import json
import sys
from collections import Counter
from pathlib import Path

from check_sentences import check

CATEGORIES = ("parse", "novar", "dup-var", "dangling", "unknown", "polarity",
              "negation", "duprole", "relation", "omitted")


def load(folder):
    path = Path(folder) / "results.jsonl"
    return {r["id"]: r for r in map(json.loads, path.read_text(encoding="utf-8").splitlines())}


def main():
    exp, base = load(sys.argv[1]), load(sys.argv[2])
    ids = [i for i in exp if i in base]
    flags = {side: {i: sorted({c for c, _ in check(recs[i])}) for i in ids}
             for side, recs in (("exp", exp), ("base", base))}
    print(f"{len(ids)} paired items\n")
    print(f"{'category':10} {'exp':>4} {'base':>5}")
    for cat in CATEGORIES:
        counts = [sum(cat in flags[s][i] for i in ids) for s in ("exp", "base")]
        print(f"{cat:10} {counts[0]:4} {counts[1]:5}")
    hard = {s: sum(bool(set(flags[s][i]) - {"omitted"}) for i in ids) for s in flags}
    print(f"\nitems with a hard issue: exp {hard['exp']}/{len(ids)}, base {hard['base']}/{len(ids)}\n")
    for i in ids:
        print(f"{i:14} exp={','.join(flags['exp'][i]) or '-':36} base={','.join(flags['base'][i]) or '-'}")
    for side, recs in (("exp", exp), ("base", base)):
        usage = [r["usage"] for r in recs.values() if r["id"] in ids and r.get("usage")]
        print(f"\n{side}: completion {sum(u['completion_tokens'] for u in usage)}, "
              f"prompt {sum(u['prompt_tokens'] for u in usage)}, "
              f"reasoning {sum(u['completion_tokens_details']['reasoning_tokens'] for u in usage)}, "
              f"elapsed {sum(r['elapsed'] for r in recs.values() if r['id'] in ids):.0f}s")


if __name__ == "__main__":
    main()
