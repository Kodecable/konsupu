#!/usr/bin/env python3
"""Candidate mechanical rules that go beyond check_sentences.py, run against a
results.jsonl and cross-tabulated with the hand verdicts in v2_review.json.
These are rules a program can evaluate without understanding the sentence:

  modal      text has may/might/can/could/must/have to/able but the graph has no
             possible-01 / obligate-01 / able
  qmark      text has '?' but the graph has no amr-unknown
  funcword   a preposition or conjunction written as a concept (for, but, on ...)
  arity      cause-01 without :ARG0 or :ARG1; contrast-01 without :ARG1 or :ARG2;
             say-01 without :ARG0
  leaf-rel   after / before / until / between without :op1
  dupconcept two different variables for the same plain noun concept

  ./check_extra.py out/<run> v2_review.json
"""

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import penman

from run_trial import extract_amr_blocks

MODAL = re.compile(r"\b(may|might|can|could|must|able|have to|had to|has to)\b", re.I)
FUNCWORDS = {"for", "of", "by", "on", "at", "in", "to", "from", "with", "but", "as",
             "if", "when", "because", "than", "over", "into", "upon", "among", "through", "under"}
NOT_NOUNS = {"and", "or", "name", "person", "thing", "he", "she", "it", "they", "i", "you", "we",
             "this", "that", "another", "some", "all", "more", "ever", "then", "now", "here", "there"}


def rules(record):
    blocks = extract_amr_blocks(record["content"])
    try:
        g = penman.decode(blocks[0])
    except Exception:
        return {"unparseable"}
    inst = {t[0]: t[2] for t in g.triples if t[1] == ":instance" and t[2]}
    out_roles = defaultdict(set)
    for s, r, t in g.triples:
        if r != ":instance":
            out_roles[s].add(r)
    concepts = Counter(inst.values())
    flags = set()
    text = record["text"]
    if MODAL.search(text) and not {"possible-01", "obligate-01"} & set(inst.values()) \
            and "able" not in inst.values():
        flags.add("modal")
    if "?" in text and "amr-unknown" not in blocks[0]:
        flags.add("qmark")
    if any(c in FUNCWORDS for c in concepts):
        flags.add("funcword")
    for v, c in inst.items():
        r = out_roles[v]
        if (c == "cause-01" and not {":ARG0", ":ARG1"} <= r) \
                or (c == "contrast-01" and not {":ARG1", ":ARG2"} <= r) \
                or (c == "say-01" and ":ARG0" not in r):
            flags.add("arity")
        if c in {"after", "before", "until"} and ":op1" not in r:
            flags.add("leaf-rel")
    plain = [c for c in concepts if c not in NOT_NOUNS and not re.search(r"-\d+$", c)]
    if any(concepts[c] > 1 for c in plain):
        flags.add("dupconcept")
    return flags


def main():
    run = Path(sys.argv[1])
    rev = {r["id"]: r for r in json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))}
    recs = {r["id"]: r for r in map(json.loads, (run / "results.jsonl").read_text(encoding="utf-8").splitlines())}
    table = defaultdict(Counter)
    caught = {}
    for i, rec in recs.items():
        v = rev[i]["verdict_without_context"]
        f = rules(rec)
        caught[i] = f
        for name in f:
            table[name][v] += 1
        table["ANY"][v] += bool(f)
    print(f"{'rule':12} {'ok':>3} {'minor':>6} {'major':>6}   (items flagged by verdict)")
    for name in ("modal", "qmark", "funcword", "arity", "leaf-rel", "dupconcept", "unparseable", "ANY"):
        t = table[name]
        print(f"{name:12} {t['ok']:>3} {t['minor']:>6} {t['major']:>6}")
    print("\nmajors:")
    for i, r in rev.items():
        if r["verdict_without_context"] == "major":
            print(f"  {i:13} caught_by={sorted(caught[i]) or '-'}")


if __name__ == "__main__":
    main()
