#!/usr/bin/env python3
"""Natural-language comprehension probe, no AMR: each item of nlu_items.json
is a story sentence plus one hand-written question. The model answers in plain
language with thinking off, one request at a time. Output:
out/<model>-<time>-nlu/results.jsonl (answers are graded by hand against `gold`).

  ./run_nlu.py
"""

import json
import sys
import time
from pathlib import Path

from run_experiments import NO_THINKING
from run_trial import load_config, post

HERE = Path(__file__).resolve().parent
SYSTEM_PROMPT = ("You are a careful reader. Answer the question about the "
                 "given sentence in one or two plain sentences.")
USER_TEMPLATE = "Sentence: {text}\n\nQuestion: {question}\n"


def main():
    cfg = load_config(HERE.parent / "opencode-go-dsv4.1f.json")
    cfg["body"].update(NO_THINKING)
    items = json.loads((HERE / "nlu_items.json").read_text(encoding="utf-8"))
    folder = HERE / "out" / f"{cfg['model']}-{time.strftime('%Y%m%d-%H%M%S')}-nlu"
    folder.mkdir(parents=True)
    for n, item in enumerate(items, 1):
        body = {"model": cfg["model"],
                "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                             {"role": "user", "content": USER_TEMPLATE.format(**item)}]}
        if cfg["max_tokens"]:
            body["max_tokens"] = cfg["max_tokens"]
        body.update(cfg["body"])
        started = time.time()
        reply = post(cfg, body, 300)
        choice = reply["choices"][0]
        reasoning = (reply["usage"].get("completion_tokens_details") or {}).get("reasoning_tokens", 0)
        record = {**item, "answer": choice["message"].get("content") or "",
                  "finish_reason": choice.get("finish_reason"), "usage": reply["usage"],
                  "elapsed": round(time.time() - started, 1)}
        with (folder / "results.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(f"[{n}/{len(items)}] {item['id']}: {record['elapsed']}s, reasoning {reasoning}", flush=True)
        if reasoning:
            sys.exit(f"thinking is not off (reasoning_tokens={reasoning}); stopped")
    print(f"done -> {folder}")


if __name__ == "__main__":
    main()
