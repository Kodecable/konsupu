#!/usr/bin/env python3
"""Single-sentence AMR with a check-and-retry loop (needs `pip install penman`).

For each sentence: send the request, run amr_checks.check_amr on the answer; if
it reports problems, append the answer and the problem list to the same
conversation as a new user turn and ask again, up to --max-retries times. The
answer kept is the first one without problems, else the one with the fewest
problems (earliest on ties). Requests are sent one at a time, thinking off.

  ./run_pipeline.py --set dev50 --version v3            # retry loop, 3 retries
  ./run_pipeline.py --set held59 --version v2 --max-retries 0   # control
  ./run_pipeline.py --set dev50 --version v3 --dry-run

Sets: dev50 = the 50 sentences of exp2 (used to tune prompts and checks);
held59 = every other story sentence, never used for tuning.
Output: out/<model>-<time>-pipe-<set>-<version>-r<N>/results.jsonl, the format
check_sentences.py reads, plus per-attempt details in "attempts".
"""

import argparse
import json
import sys
import time
from pathlib import Path

from amr_checks import check_amr
from run_experiments import EXAMPLE_AMR, EXAMPLE_SENTENCE, NO_THINKING, select
from run_sentences import PROMPTS
from run_trial import load_config, post

HERE = Path(__file__).resolve().parent

FEEDBACK = ("The program found these problems in your graph:\n{items}\n\n"
            "Fix them and resend the complete corrected graph as one ```amr block, nothing else.")


def guide_and_examples(version):
    """Return (system prompt, [(example sentence, example AMR), ...])."""
    guide = (HERE / "prompts" / f"amr_guide_{version}.md").read_text(encoding="utf-8")
    if version == "v1":
        return guide, [(EXAMPLE_SENTENCE, EXAMPLE_AMR)]
    if version == "v2":
        ex = json.loads((HERE / "prompts" / "example_v2.json").read_text(encoding="utf-8"))
        return guide, [(ex["sentence"], ex["amr"])]
    exs = json.loads((HERE / "prompts" / f"examples_{version}.json").read_text(encoding="utf-8"))
    return guide, [(e["sentence"], e["amr"]) for e in exs]


def base_messages(version, sentence):
    guide, examples = guide_and_examples(version)
    messages = [{"role": "system", "content": guide}]
    for text, amr in examples:
        messages.append({"role": "user", "content": PROMPTS["sentence"].format(text=text)})
        messages.append({"role": "assistant", "content": f"```amr\n{amr}\n```"})
    messages.append({"role": "user", "content": PROMPTS["sentence"].format(text=sentence)})
    return messages


def pick_set(name):
    items = json.loads((HERE / "items.json").read_text(encoding="utf-8"))
    sentences = [it for it in items if it["kind"] == "sentence"]
    dev = select("exp2", sentences)
    if name == "dev50":
        return dev
    taken = {it["id"] for it in dev}
    return [it for it in sentences if it["id"] not in taken]


def reasoning_of(reply):
    return (reply["usage"].get("completion_tokens_details") or {}).get("reasoning_tokens", 0)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--set", choices=["dev50", "held59"], required=True)
    p.add_argument("--version", choices=["v1", "v2", "v3"], default="v3")
    p.add_argument("--max-retries", type=int, default=3)
    p.add_argument("--only", nargs="+", metavar="ID", help="restrict to these item ids")
    p.add_argument("--config", type=Path, default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--model", default=None)
    p.add_argument("--timeout", type=float, default=600)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    cfg = load_config(args.config)
    if args.model:
        cfg["model"] = args.model
    cfg["body"].update(NO_THINKING)
    items = pick_set(args.set)
    if args.only:
        items = [it for it in items if it["id"] in set(args.only)]

    def body_for(messages):
        body = {"model": cfg["model"], "messages": messages}
        if cfg["max_tokens"]:
            body["max_tokens"] = cfg["max_tokens"]
        body.update(cfg["body"])
        return body

    if args.dry_run:
        print(json.dumps(body_for(base_messages(args.version, items[0]["text"])),
                         ensure_ascii=False, indent=2)[:3000])
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = args.out or HERE / "out" / (
        f"{cfg['model']}-{stamp}-pipe-{args.set}-{args.version}-r{args.max_retries}")
    folder.mkdir(parents=True, exist_ok=True)
    results = folder / "results.jsonl"
    done = set()
    if results.exists():
        done = {json.loads(l)["id"] for l in results.read_text(encoding="utf-8").splitlines() if l}

    for n, item in enumerate(items, 1):
        if item["id"] in done:
            continue
        messages = base_messages(args.version, item["text"])
        attempts = []
        for attempt in range(args.max_retries + 1):
            started = time.time()
            try:
                reply = post(cfg, body_for(messages), args.timeout)
            except Exception as error:  # a re-run retries the missing items
                print(f"[{n}/{len(items)}] {item['id']} failed: {error}", file=sys.stderr, flush=True)
                break
            choice = reply["choices"][0]
            message = choice["message"]
            content = message.get("content") or ""
            reasoning_text = message.get("reasoning_content") or message.get("reasoning") or ""
            if reasoning_of(reply) or reasoning_text:
                sys.exit(f"thinking is not off (reasoning_tokens={reasoning_of(reply)}); stopped")
            issues = check_amr(item["text"], content, choice.get("finish_reason"))
            attempts.append({"content": content, "issues": [{"code": c, "message": m} for c, m in issues],
                             "finish_reason": choice.get("finish_reason"), "usage": reply["usage"],
                             "elapsed": round(time.time() - started, 1)})
            if not issues or attempt == args.max_retries:
                break
            messages.append({"role": "assistant", "content": content})
            messages.append({"role": "user", "content": FEEDBACK.format(
                items="\n".join(f"- {m}" for _, m in issues))})
        if not attempts:
            continue
        passed = [i for i, a in enumerate(attempts) if not a["issues"]]
        best = passed[0] if passed else min(range(len(attempts)), key=lambda i: (len(attempts[i]["issues"]), i))
        usage = {"prompt_tokens": sum(a["usage"]["prompt_tokens"] for a in attempts),
                 "completion_tokens": sum(a["usage"]["completion_tokens"] for a in attempts),
                 "completion_tokens_details": {"reasoning_tokens": 0}}
        record = {**item, "content": attempts[best]["content"], "reasoning": "",
                  "finish_reason": attempts[best]["finish_reason"], "usage": usage,
                  "elapsed": round(sum(a["elapsed"] for a in attempts), 1),
                  "n_attempts": len(attempts), "passed": bool(passed), "final_attempt": best,
                  "first_content": attempts[0]["content"], "attempts": attempts}
        with results.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(f"[{n}/{len(items)}] {item['id']}: {len(attempts)} attempt(s), "
              f"{'passed' if passed else 'STILL FAILING'}, {record['elapsed']}s", flush=True)
    print(f"done -> {folder}")


if __name__ == "__main__":
    main()
