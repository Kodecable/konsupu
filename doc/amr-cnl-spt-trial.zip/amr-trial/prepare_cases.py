#!/usr/bin/env python3
"""Extract the 13 Aesop stories and their first 5 plain-text questions from
../aesop-commons-phase2/cases into cases.json (the only input of run_trial.py).
"""

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "aesop-commons-phase2" / "cases"
QUESTIONS_PER_STORY = 5

# `text: "..."` entries with a string literal; Frozen[i].text / Twins[i].text
# entries are not literals and are skipped.
TEXT_RE = re.compile(r'^\s+text:\s*("(?:[^"\\]|\\.)*"),\s*$', re.M)


def main():
    cases = []
    for n in range(1, 14):
        folder = SRC / f"story-{n}"
        source = (folder / "source.txt").read_text(encoding="utf-8").strip()
        title, _, story = source.partition("\n")
        questions = [json.loads(m) for m in TEXT_RE.findall(
            (folder / "questions.mjs").read_text(encoding="utf-8"))]
        questions = questions[:QUESTIONS_PER_STORY]
        assert len(questions) == QUESTIONS_PER_STORY, (n, questions)
        cases.append({"id": f"story-{n}", "title": title.strip(),
                      "story": story.strip(), "questions": questions})
    (HERE / "cases.json").write_text(
        json.dumps(cases, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote cases.json: {len(cases)} stories, "
          f"{sum(len(c['questions']) for c in cases)} questions")


if __name__ == "__main__":
    main()
