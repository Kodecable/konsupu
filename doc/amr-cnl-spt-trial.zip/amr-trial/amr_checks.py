"""Call-time checks for one AMR answer, used by run_pipeline.py.

check_amr(text, content, finish_reason) returns a list of (code, message).
Every message says what is wrong and how to fix it, because the list is sent
back to the model as the next user turn. Only rules that are precise enough to
justify a retry are here; "omitted word" style heuristics are not.

Codes: format, parse, novar, dup-var, dangling, duprole, relation, unknown,
polarity, negation, modal, say-invented, arity, funcword, leaf-rel.
"""

import re
from collections import Counter

import penman

from run_trial import extract_amr_blocks

VAR_DEF = re.compile(r"\(\s*([^\s()/]+)\s*/")
NODE_OPEN = re.compile(r"\(\s*([^\s()/]+)(\s*/)?")

ALLOWED_ROLES = {
    "mod", "poss", "domain", "name", "polarity", "mode", "time", "duration",
    "frequency", "location", "destination", "source", "direction", "path",
    "manner", "instrument", "purpose", "cause", "condition", "concession",
    "degree", "quant", "unit", "topic", "beneficiary", "accompanier", "part",
    "part-of", "ord", "vocative", "li", "wiki", "consist-of", "compared-to",
    "medium", "subevent", "example", "age", "extent", "range", "scale",
    "year", "month", "day", "weekday", "decade", "century", "era", "season",
    "polite", "snt", "op", "ARG", "prep",
}
ROLE_FIXES = {
    "agent": ":ARG0", "patient": ":ARG1", "theme": ":ARG1", "recipient": ":ARG2 (the hearer of say-01)",
    "experiencer": ":ARG0 or :ARG1 by meaning", "speaker": ":ARG0 of say-01", "content": ":ARG1 of say-01",
    "message": ":ARG1", "result": "cause-01 with :ARG0 = cause and :ARG1 = effect",
    "contrast": "a contrast-01 node with :ARG1 and :ARG2", "conj": "an `and` / `or` / contrast-01 node with :op1 :op2",
    "between": "a node (b / between :op1 X :op2 Y)", "possessor": ":poss", "subj": ":ARG0",
    "root": "nothing (delete it)", "tense": "nothing (delete it)", "aspect": "nothing (delete it)",
    "modal": "a possible-01 / obligate-01 node", "quote": "say-01 with :ARG1", "instance-of": "nothing (delete it)",
}
CONSTANTS = {"-", "+", "interrogative", "imperative", "expressive"}
FUNCWORDS = {"for", "of", "by", "on", "at", "in", "to", "from", "with", "but", "as", "if",
             "when", "because", "than", "over", "into", "upon", "among", "through", "under"}
# A negative the graph must express, and the larger set under which `:polarity -` is allowed.
NEGATION = re.compile(r"\b(not|no|never|nothing|nobody|none|neither|nor|cannot|without|\w+n['’]t)\b", re.I)
NEGATION_ALLOWED = re.compile(NEGATION.pattern[:-3] + r"|nay|lest)\b", re.I)
# "won't all the young men come up and speak to me!": a rhetorical exclamation, not a negation.
INVERTED_NEG = re.compile(r"\b\w+n['’]t\s+(all|you|they|he|she|it|we|i|the|that|this|there)\b", re.I)
SPEECH_FRAMES = {"say-01", "ask-01", "tell-01", "reply-01", "answer-01", "exclaim-01", "shout-01", "whisper-01"}
MODAL = re.compile(r"\b(may|might|can|could|must|able|have to|had to|has to)\b", re.I)
SPEECH = re.compile(r"\b(said|says|say|saying|asked|ask|asks|cried|replied|answered|called|shouted|"
                    r"exclaimed|whispered|thought|told|tell|declared|promised|spoke|speak)\b", re.I)
INTERJECTIONS = {"oh", "ah", "alas", "well", "ha", "hey", "nay", "yes"}
YES_NO_START = {"did", "do", "does", "was", "were", "is", "are", "could", "can", "would",
                "will", "should", "had", "has", "have"}


def words(text):
    return [w.lower() for w in re.findall(r"[A-Za-z]+", text.replace("’", "'"))]


def role_ok(role):
    role = role.lstrip(":")
    if role.endswith("-of"):
        role = role[:-3]
    return bool(re.fullmatch(r"ARG\d|op\d+|snt\d+|prep-.+", role)) or role in ALLOWED_ROLES


def check_amr(text, content, finish_reason=None):
    issues = []
    blocks = extract_amr_blocks(content)
    if finish_reason == "length":
        issues.append(("format", "The answer was cut off; write a shorter graph."))
    if len(blocks) != 1:
        issues.append(("format", f"The answer has {len(blocks)} code blocks; output exactly one ```amr block."))
    outside = re.sub(r"```.*?```", "", content, flags=re.S).strip()
    if outside:
        issues.append(("format", "There is text outside the code block; output only the ```amr block."))
    if not blocks:
        return issues
    amr = blocks[0]

    bare = re.sub(r'"[^"]*"', "", amr)  # parentheses inside name strings do not count
    opens, closes = bare.count("("), bare.count(")")
    try:
        if opens != closes:
            raise ValueError("unbalanced")
        graph = penman.decode(amr)
    except Exception as error:
        if opens != closes:
            detail = (f"{opens - closes} unclosed '(' - add the missing ')'" if opens > closes
                      else f"{closes - opens} extra ')' - remove it")
        elif getattr(error, "lineno", None):
            detail = (f"at line {error.lineno}: `{(error.text or '').strip()}` - {str(error).splitlines()[-1].strip()}. "
                      "Every relation (`:role`) takes exactly one value, and every value after the first needs its own `:role`")
        else:
            detail = "check relation names and node syntax"
        issues.append(("parse", f"The graph cannot be parsed as PENMAN ({detail})."))
        return issues

    defined = VAR_DEF.findall(amr)
    variables = set(defined)
    for name, slash in NODE_OPEN.findall(amr):
        if not slash:
            if name in variables:
                issues.append(("novar", f"`({name})` is a parenthesised reuse; write the bare variable `{name}` without parentheses."))
            else:
                issues.append(("novar", f"The node `({name} ...)` has no variable; write `(x / {name} ...)`."))
    for v, n in Counter(defined).items():
        if n > 1:
            issues.append(("dup-var", f"Variable `{v}` is introduced {n} times with `/`. Reuse it without `/` for the same entity, or give each different node its own letter."))

    triples = graph.triples
    known = variables | {t[0] for t in triples}
    for _, role, target in triples:
        t = str(target)
        if role == ":instance" or t.startswith('"') or t in CONSTANTS or re.fullmatch(r"[-+]?[\d.,]+", t):
            continue
        if t not in known and role not in {":li", ":wiki"}:
            issues.append(("dangling", f"`{role} {t}` uses `{t}` as a value, but no node `({t} / ...)` exists. Write a node `(x / {t})` or reuse a defined variable."))
    seen = Counter((s, r) for s, r, _ in triples
                   if r in {":polarity", ":mode", ":name"} or re.fullmatch(r":ARG\d", r))
    for (s, r), n in seen.items():
        if n > 1:
            issues.append(("duprole", f"Node `{s}` has {n} `{r}` relations; a node takes at most one `{r}`. "
                           f"Note that `{r}-of` on a child node counts as `{r}` of that child, so "
                           f"`(x / ... {r}-of (y / ... {r} Z))` gives y two `{r}`; drop or change one."))
    for role in sorted({r for _, r, _ in triples if r != ":instance" and not role_ok(r)}):
        key = role.lstrip(":")
        fix = ROLE_FIXES.get(key.lower())
        if fix is None and key.lower() == key and re.fullmatch(r"arg\d", key):
            fix = ":" + key.upper()
        issues.append(("relation", f"`{role}` is not an AMR role." + (f" Use {fix} instead." if fix else " Use only the allowed roles.")))

    inst = {t[0]: t[2] for t in triples if t[1] == ":instance" and t[2]}
    roles_of = {}
    for s, r, _ in triples:
        if r != ":instance":
            roles_of.setdefault(s, set()).add(r)

    n_unknown = len(re.findall(r"amr-unknown", amr))
    asks = "?" in text
    if asks and n_unknown == 0:
        issues.append(("unknown", "The text is a question: put exactly one `(a / amr-unknown)` where the answer goes."))
    elif n_unknown > 1:
        issues.append(("unknown", f"The graph has {n_unknown} amr-unknown nodes; use exactly one."))
    elif n_unknown and not asks:
        issues.append(("unknown", "The text is not a question; do not use amr-unknown (an interjection quote is `(a / ah :mode expressive)`)."))
    on_polarity = bool(re.search(r":polarity\s*\(?\s*(?:[^\s()/]+\s*/\s*)?amr-unknown", amr))
    first = next((w for w in words(text) if w not in INTERJECTIONS), "")
    yes_no = asks and first in YES_NO_START
    if n_unknown == 1:
        if yes_no and not on_polarity:
            issues.append(("polarity", "A yes/no question puts `:polarity (a / amr-unknown)` on the main predicate."))
        if asks and not yes_no and on_polarity:
            issues.append(("polarity", "A wh-question puts amr-unknown in the role being asked (:cause for why, :location for where, ...), not under :polarity."))

    negated = re.sub(r"\b(nothing|no one|none|nobody) but\b", "only", text, flags=re.I)
    has_neg_text = bool(NEGATION.search(negated))
    has_neg_amr = bool(re.search(r":polarity\s+-", amr))
    rhetorical = "!" in text and "?" not in text and bool(INVERTED_NEG.search(text))
    if has_neg_amr and not NEGATION_ALLOWED.search(negated):
        issues.append(("negation", "`:polarity -` appears but the sentence has no negative word; remove it."))
    if has_neg_text and not has_neg_amr and not (yes_no and on_polarity) and not rhetorical:
        issues.append(("negation", "The sentence has an explicit negative (not, n't, never, nothing, no ...) but the graph has no `:polarity -`."))
    if MODAL.search(text) and not {"possible-01", "obligate-01", "able"} & set(inst.values()):
        issues.append(("modal", "The sentence has a modal (may / can / could / must / able / had to); express it with possible-01 or obligate-01."))
    invented = sorted(SPEECH_FRAMES & set(inst.values()))
    if invented and not SPEECH.search(text):
        issues.append(("say-invented", f"The sentence has no speech verb, so {invented[0]} is invented. Write the quoted clause itself as the graph."))
    for v, c in inst.items():
        r = roles_of.get(v, set())
        if c == "cause-01" and not {":ARG0", ":ARG1"} <= r:
            issues.append(("arity", "cause-01 needs both :ARG0 (the cause) and :ARG1 (the effect)."))
        if c == "contrast-01" and not {":ARG1", ":ARG2"} <= r:
            issues.append(("arity", "contrast-01 needs both :ARG1 and :ARG2."))
        if c == "say-01" and ":ARG0" not in r and SPEECH.search(text):
            issues.append(("arity", "say-01 needs :ARG0 (the speaker) when the sentence names one."))
        if c in FUNCWORDS and ":op1" not in r:
            issues.append(("funcword", f"`{c}` is a function word, not a concept; use the proper relation or concept instead."))
        if c in {"after", "before", "until"} and ":op1" not in r:
            issues.append(("leaf-rel", f"`{c}` needs an :op1 (the event or time it is relative to)."))
    return issues
