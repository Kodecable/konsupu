#!/usr/bin/env python3
"""Three single-sentence AMR experiments, all sent one request at a time.

  exp1  10 long sentences, thinking ON (config default).
  exp2  50 sentences, system prompt = prompts/amr_guide_<version>.md, one example
        exchange pre-injected as history, thinking OFF.
  exp3  15 sentences, each sent with the previous and next sentence of the
        story as context, only the middle one is to be parsed, thinking OFF.

Samples are drawn with a fixed seed from the sentences of items.json (the
selection is saved as selection.json). Output goes to
out/<model>-<time>-<exp>/results.jsonl, the format check_sentences.py reads;
re-running with the same --out resumes.

  ./run_experiments.py exp1
  ./run_experiments.py exp2 --version v2 --dry-run
"""

import argparse
import json
import random
import sys
import time
from pathlib import Path

from run_sentences import PROMPTS, SYSTEM_PROMPT
from run_trial import load_config, post

HERE = Path(__file__).resolve().parent
NO_THINKING = {"thinking": {"type": "disabled"}, "reasoning_effort": "none"}

# One worked example for exp2. The sentence is not in the corpus and is not
# one of the sampled sentences.
EXAMPLE_SENTENCE = ("The Hare laughed at the Tortoise and said, "
                    "“You will never win this race.”")
EXAMPLE_AMR = """\
(a / and
   :op1 (l / laugh-01
           :ARG0 (h / hare)
           :ARG2 (t / tortoise))
   :op2 (s / say-01
           :ARG0 h
           :ARG1 (w / win-01
                    :ARG0 (y / you)
                    :ARG1 (r / race
                             :mod (t2 / this))
                    :polarity -
                    :time (e / ever))
           :ARG2 t))"""

CONTEXT_PROMPT = (
    "Below are three consecutive sentences from a story. Write the AMR "
    "(PENMAN notation) of the MIDDLE sentence only. The other two sentences "
    "are context for resolving pronouns and references; do not put them in "
    "the AMR. Output only one ```amr code block.\n\n"
    "Previous: {prev}\nMiddle (parse this): {text}\nNext: {next}\n")


def sentences():
    items = json.loads((HERE / "items.json").read_text(encoding="utf-8"))
    return [it for it in items if it["kind"] == "sentence"]


def select(exp, pool):
    """Return the list of items for an experiment (with neighbours for exp3)."""
    if exp == "exp1":
        lengths = sorted(len(it["text"]) for it in pool)
        cutoff = lengths[int(len(lengths) * 0.75)]
        longest = [it for it in pool if len(it["text"]) >= cutoff]
        return random.Random(1).sample(longest, 10)
    if exp == "exp2":
        return random.Random(2).sample(pool, 50)
    # exp3: sentences that have both a previous and a next sentence in the story
    by_story = {}
    for it in pool:
        by_story.setdefault(it["story"], []).append(it)
    interior = []
    for story_items in by_story.values():
        for i in range(1, len(story_items) - 1):
            it = dict(story_items[i])
            it["prev"] = story_items[i - 1]["text"]
            it["next"] = story_items[i + 1]["text"]
            interior.append(it)
    return random.Random(3).sample(interior, 15)


def guide_and_example(version):
    """Return (guide text, example sentence, example AMR) for exp2."""
    guide = (HERE / "prompts" / f"amr_guide_{version}.md").read_text(encoding="utf-8")
    if version == "v1":
        return guide, EXAMPLE_SENTENCE, EXAMPLE_AMR
    example = json.loads((HERE / "prompts" / f"example_{version}.json").read_text(encoding="utf-8"))
    return guide, example["sentence"], example["amr"]


def build_messages(exp, item, version="v1"):
    user = PROMPTS["sentence"].format(text=item["text"])
    if exp == "exp2":
        guide, sentence, amr = guide_and_example(version)
        return [
            {"role": "system", "content": guide},
            {"role": "user", "content": PROMPTS["sentence"].format(text=sentence)},
            {"role": "assistant", "content": f"```amr\n{amr}\n```"},
            {"role": "user", "content": user},
        ]
    if exp == "exp3":
        user = CONTEXT_PROMPT.format(prev=item["prev"], text=item["text"], next=item["next"])
    return [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}]


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("exp", choices=["exp1", "exp2", "exp3"])
    p.add_argument("--version", choices=["v1", "v2"], default="v1",
                   help="exp2 only: which prompts/amr_guide_<v>.md and example to use")
    p.add_argument("--model", default=None,
                   help="override llm.model of the config; every other API setting is kept")
    p.add_argument("--drop-body", action="append", default=[], metavar="KEY",
                   help="remove KEY from the request body (e.g. thinking, which some models reject)")
    p.add_argument("--config", type=Path, default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--timeout", type=float, default=900, help="seconds")
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true",
                   help="print the first request body and exit")
    args = p.parse_args()

    cfg = load_config(args.config)
    if args.model:
        cfg["model"] = args.model
    thinking_off = args.exp != "exp1"
    if thinking_off:
        cfg["body"].update(NO_THINKING)
    for key in args.drop_body:
        cfg["body"].pop(key, None)
    items = select(args.exp, sentences())

    def body_for(item):
        body = {"model": cfg["model"], "messages": build_messages(args.exp, item, args.version)}
        if cfg["max_tokens"]:
            body["max_tokens"] = cfg["max_tokens"]
        body.update(cfg["body"])
        return body

    if args.dry_run:
        print(json.dumps(body_for(items[0]), ensure_ascii=False, indent=2)[:6000])
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    suffix = f"-{args.version}" if args.exp == "exp2" and args.version != "v1" else ""
    folder = args.out or HERE / "out" / f"{cfg['model']}-{stamp}-{args.exp}{suffix}"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "selection.json").write_text(
        json.dumps([it["id"] for it in items], indent=2) + "\n", encoding="utf-8")
    results = folder / "results.jsonl"
    done = set()
    if results.exists():
        done = {json.loads(l)["id"] for l in results.read_text(encoding="utf-8").splitlines() if l}

    for n, item in enumerate(items, 1):
        if item["id"] in done:
            continue
        started = time.time()
        try:
            reply = post(cfg, body_for(item), args.timeout)
        except Exception as error:  # a re-run retries the missing ones
            print(f"[{n}/{len(items)}] {item['id']} failed: {error}", file=sys.stderr, flush=True)
            continue
        choice = (reply.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        record = {**item,
                  "content": message.get("content") or "",
                  "reasoning": message.get("reasoning_content") or message.get("reasoning") or "",
                  "finish_reason": choice.get("finish_reason"),
                  "usage": reply.get("usage"),
                  "elapsed": round(time.time() - started, 1)}
        with results.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        reasoning = ((record["usage"] or {}).get("completion_tokens_details") or {}).get("reasoning_tokens", 0)
        print(f"[{n}/{len(items)}] {item['id']}: {record['elapsed']}s, reasoning {reasoning}", flush=True)
        if thinking_off and (reasoning or record["reasoning"]):
            # The endpoint has ignored the switch before; stop rather than
            # collect results under a different condition.
            sys.exit(f"thinking is not off (reasoning_tokens={reasoning}, "
                     f"reasoning text {len(record['reasoning'])} chars); stopped")
    print(f"done -> {folder}")


if __name__ == "__main__":
    main()
