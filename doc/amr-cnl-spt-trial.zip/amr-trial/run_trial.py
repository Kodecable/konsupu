#!/usr/bin/env python3
"""Single-turn AMR probe: for each Aesop story, send the story and its five
questions to an OpenAI-compatible chat completion endpoint and ask for AMR.

Only the standard library is used. The API settings come from a Konsupu
config file (llm.openai_completion.*), by default ../opencode-go-dsv4.1f.json.

  ./run_trial.py                      # all 13 stories, one request at a time
  ./run_trial.py --only 1 4 --runs 2  # selected stories, repeated
  ./run_trial.py --dry-run --only 1   # print the request body and exit
  ./run_trial.py --tag nothink --extra-body '{"thinking": {"type": "disabled"}}'

Run ./prepare_cases.py first if cases.json is missing.
"""

import argparse
import http.client
import json
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONNECT_ATTEMPTS = 3

SYSTEM_PROMPT = "You are an expert in Abstract Meaning Representation (AMR)."

USER_TEMPLATE = """\
Below is a short story followed by five questions.

Write the AMR (PENMAN notation) of every sentence of the story, then of every
question. In a question, represent the thing being asked with `amr-unknown`.

Format: for each item, a heading line (`S1`, `S2`, ... for story sentences,
`Q1` ... `Q5` for questions) followed by one ```amr code block. No other text.

# {title}

{story}

# Questions

{questions}
"""


def load_config(path):
    config = json.loads(path.read_text(encoding="utf-8"))
    llm = config["llm"]
    api = llm["openai_completion"]
    return {
        "model": llm["model"],
        "base_url": api["base_url"],
        "api_key": api.get("api_key"),
        "headers": api.get("headers") or {},
        "body": api.get("body") or {},
        "max_tokens": llm.get("max_output_tokens"),
    }


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", type=Path,
                   default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--extra-body", default=None,
                   help='JSON object merged over the config body, e.g. '
                        '\'{"thinking": {"type": "disabled"}}\'')
    p.add_argument("--tag", default="",
                   help="suffix for the default output folder name")
    p.add_argument("--cases", type=Path, default=HERE / "cases.json")
    p.add_argument("--only", type=int, nargs="+", metavar="N",
                   help="story numbers to run (default: all)")
    p.add_argument("--runs", type=int, default=1,
                   help="send each story's request this many times")
    p.add_argument("--parallel", type=int, default=1,
                   help="number of requests in flight at once")
    p.add_argument("--timeout", type=float, default=900, help="seconds")
    p.add_argument("--out", type=Path, default=None,
                   help="output folder (default: out/<model>-<time>)")
    p.add_argument("--dry-run", action="store_true",
                   help="print the first request body and exit")
    args = p.parse_args()
    if args.runs < 1 or args.parallel < 1:
        p.error("--runs and --parallel must be at least 1")
    return args


def build_body(cfg, case):
    questions = "\n".join(f"{i}. {q}" for i, q in enumerate(case["questions"], 1))
    user = USER_TEMPLATE.format(title=case["title"], story=case["story"],
                                questions=questions)
    body = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    }
    if cfg["max_tokens"]:
        body["max_tokens"] = cfg["max_tokens"]
    body.update(cfg["body"])
    return body


def post(cfg, body, timeout):
    url = cfg["base_url"].rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json", **cfg["headers"]}
    if cfg["api_key"]:
        headers["Authorization"] = "Bearer " + cfg["api_key"]
    request = urllib.request.Request(
        url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers, method="POST")
    for attempt in range(1, CONNECT_ATTEMPTS + 1):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {error.code} from {url}:\n{detail}") from None
        except (urllib.error.URLError, ConnectionError, http.client.HTTPException):
            # The endpoint sometimes drops the connection before replying.
            if attempt == CONNECT_ATTEMPTS:
                raise
            time.sleep(2 * attempt)


def run_once(cfg, case, timeout, out):
    """Send one request, write <out>.md and <out>.json, return a status line."""
    started = time.time()
    reply = post(cfg, build_body(cfg, case), timeout)
    elapsed = time.time() - started

    choices = reply.get("choices") or []
    if not choices:
        raise RuntimeError("no choices in response:\n"
                           + json.dumps(reply, ensure_ascii=False, indent=2))
    message = choices[0].get("message") or {}
    content = message.get("content") or ""
    reasoning = message.get("reasoning_content") or message.get("reasoning") or ""
    finish = choices[0].get("finish_reason")

    parts = [
        f"<!-- {case['id']}; model: {cfg['model']}; finish_reason: {finish}; "
        f"elapsed: {elapsed:.1f}s; usage: {json.dumps(reply.get('usage'), ensure_ascii=False)} -->",
        "", content,
    ]
    if reasoning:
        parts += ["", "---", "", "## reasoning", "", reasoning]
    out.with_suffix(".md").write_text("\n".join(parts) + "\n", encoding="utf-8")
    out.with_suffix(".json").write_text(
        json.dumps(reply, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    blocks = extract_amr_blocks(content)
    bad = [i for i, b in enumerate(blocks, 1) if not balanced(b)]
    status = (f"{out.name}: {len(blocks)} amr blocks, "
              f"{len(bad)} unbalanced, {elapsed:.1f}s")
    if reasoning:
        status += f", {len(reasoning)} chars reasoning"
    if finish == "length":
        status += ", WARNING: cut by max_tokens"
    return status


def extract_amr_blocks(text):
    """Return the contents of every fenced code block."""
    blocks, current = [], None
    for line in text.splitlines():
        if line.strip().startswith("```"):
            if current is None:
                current = []
            else:
                blocks.append("\n".join(current))
                current = None
        elif current is not None:
            current.append(line)
    return blocks


def balanced(amr):
    """Cheap well-formedness check: parentheses balance, ignoring string literals."""
    depth, in_string = 0, False
    for ch in amr:
        if ch == '"':
            in_string = not in_string
        elif not in_string:
            depth += ch == "("
            depth -= ch == ")"
            if depth < 0:
                return False
    return depth == 0 and amr.count("(") > 0


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.extra_body:
        extra = json.loads(args.extra_body)
        if not isinstance(extra, dict):
            sys.exit("--extra-body must be a JSON object")
        cfg["body"].update(extra)
    cases = json.loads(args.cases.read_text(encoding="utf-8"))
    if args.only:
        wanted = {f"story-{n}" for n in args.only}
        cases = [c for c in cases if c["id"] in wanted]
    if not cases:
        sys.exit("no stories selected")

    if args.dry_run:
        print(json.dumps(build_body(cfg, cases[0]), ensure_ascii=False, indent=2))
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = args.out or HERE / "out" / (f"{cfg['model']}-{stamp}" + (f"-{args.tag}" if args.tag else ""))
    folder.mkdir(parents=True, exist_ok=True)

    jobs = []
    for case in cases:
        for run in range(1, args.runs + 1):
            name = case["id"] if args.runs == 1 else f"{case['id']}-run{run:02d}"
            jobs.append((case, folder / name))

    def attempt(job):
        case, out = job
        try:
            return True, run_once(cfg, case, args.timeout, out)
        except Exception as error:  # one failed request must not stop the others
            return False, f"{out.name} failed: {error}"

    failures = 0
    with ThreadPoolExecutor(max_workers=min(args.parallel, len(jobs))) as pool:
        for ok, status in pool.map(attempt, jobs):
            print(status, file=sys.stdout if ok else sys.stderr, flush=True)
            failures += not ok
    print(f"{len(jobs) - failures}/{len(jobs)} requests succeeded -> {folder}")
    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
