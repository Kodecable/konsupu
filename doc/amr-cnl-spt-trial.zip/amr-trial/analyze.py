#!/usr/bin/env python3
"""Summarise a run folder: parse every AMR block with `penman` (pip install
penman) and report parse failures, missing amr-unknown in questions, and
question/sentence counts.

  ./analyze.py out/<run-folder>
"""

import re
import sys
from pathlib import Path

import penman

HEADING = re.compile(r"^\s*(?:#+\s*)?\**([SQ]\d+)\**\s*$")


def items(text):
    """Yield (heading, amr) pairs: a heading line followed by a fenced block."""
    heading, current = None, None
    for line in text.splitlines():
        if line.strip().startswith("```"):
            if current is None:
                current = []
            else:
                yield heading, "\n".join(current)
                heading, current = None, None
        elif current is not None:
            current.append(line)
        elif (m := HEADING.match(line)):
            heading = m.group(1)


def check(heading, amr):
    """Return a list of problems for one block."""
    try:
        graph = penman.decode(amr)
    except Exception as error:  # penman raises several parse error types
        return [f"parse error: {str(error).splitlines()[0]}"]
    problems = []
    if heading and heading.startswith("Q") and "amr-unknown" not in amr:
        problems.append("no amr-unknown")
    variables = [t.source for t in graph.instances()]
    if len(variables) != len(set(variables)):
        problems.append("variable defined twice")
    return problems


def main():
    folder = Path(sys.argv[1])
    total = {"S": 0, "Q": 0, "bad": 0}
    for path in sorted(folder.glob("story-*.md"), key=lambda p: int(re.findall(r"\d+", p.name)[0])):
        text = path.read_text(encoding="utf-8").split("\n---\n\n## reasoning")[0]
        blocks = list(items(text))
        s = sum(1 for h, _ in blocks if h and h.startswith("S"))
        q = sum(1 for h, _ in blocks if h and h.startswith("Q"))
        issues = [(h, p) for h, a in blocks for p in check(h, a)]
        print(f"{path.stem:10} S={s:2} Q={q} issues={len(issues)}"
              + "".join(f"\n    {h}: {p}" for h, p in issues))
        total["S"] += s; total["Q"] += q; total["bad"] += len(issues)
    print(f"total: {total['S']} sentences, {total['Q']} questions, {total['bad']} issues")


if __name__ == "__main__":
    main()
