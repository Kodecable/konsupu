#!/usr/bin/env python3
"""Split every story in cases.json into sentences (a simple punctuation rule)
and list each question as its own item, writing items.json: one entry per
request of run_sentences.py.
"""

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent

# A sentence ends at . ! ? (plus an optional closing quote) followed by white
# space and a capital letter or an opening quote. "?” said the Mouse" does not
# split because the next word is lower case.
BOUNDARY = re.compile(r'([.!?][”"]?)\s+(?=[“"A-Z])')


def split_sentences(paragraph):
    parts, last = [], 0
    for m in BOUNDARY.finditer(paragraph):
        parts.append(paragraph[last:m.end(1)])
        last = m.end()
    parts.append(paragraph[last:])
    return [p.strip() for p in parts if p.strip()]


def main():
    cases = json.loads((HERE / "cases.json").read_text(encoding="utf-8"))
    items = []
    for case in cases:
        sentences = []
        # Paragraphs are separated by blank lines; the last one is the moral.
        for paragraph in case["story"].split("\n\n"):
            sentences += split_sentences(" ".join(paragraph.split()))
        for i, text in enumerate(sentences, 1):
            items.append({"id": f"{case['id']}/S{i}", "story": case["id"],
                          "kind": "sentence", "text": text})
        for i, text in enumerate(case["questions"], 1):
            items.append({"id": f"{case['id']}/Q{i}", "story": case["id"],
                          "kind": "question", "text": text})
    (HERE / "items.json").write_text(
        json.dumps(items, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    n = sum(1 for it in items if it["kind"] == "sentence")
    print(f"wrote items.json: {n} sentences + {len(items) - n} questions")


if __name__ == "__main__":
    main()
