#!/usr/bin/env python3
"""One request per item of items.json (a story sentence or a question): ask
for its AMR with no other context. Requests are sent one at a time.

Results are appended to <out>/results.jsonl as they arrive; re-running with the
same --out skips the items already done, so an interrupted run can be resumed.

  ./run_sentences.py --tag nothink --extra-body '{"thinking": {"type": "disabled"}}'
  ./run_sentences.py --only 1 --limit 3 --dry-run
"""

import argparse
import json
import sys
import time
from pathlib import Path

from run_trial import extract_amr_blocks, load_config, post

HERE = Path(__file__).resolve().parent

SYSTEM_PROMPT = "You are an expert in Abstract Meaning Representation (AMR)."

PROMPTS = {
    "sentence": "Write the AMR (PENMAN notation) of the following sentence. "
                "Output only one ```amr code block.\n\n{text}\n",
    "question": "Write the AMR (PENMAN notation) of the following question. "
                "Represent the thing being asked with `amr-unknown`. "
                "Output only one ```amr code block.\n\n{text}\n",
}


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", type=Path,
                   default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--items", type=Path, default=HERE / "items.json")
    p.add_argument("--extra-body", default=None,
                   help="JSON object merged over the config body")
    p.add_argument("--tag", default="", help="suffix for the default output folder")
    p.add_argument("--only", type=int, nargs="+", metavar="N",
                   help="story numbers to run (default: all)")
    p.add_argument("--limit", type=int, default=None, help="stop after N items")
    p.add_argument("--timeout", type=float, default=300, help="seconds")
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true",
                   help="print the first request body and exit")
    return p.parse_args()


def build_body(cfg, item):
    body = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": PROMPTS[item["kind"]].format(text=item["text"])},
        ],
    }
    if cfg["max_tokens"]:
        body["max_tokens"] = cfg["max_tokens"]
    body.update(cfg["body"])
    return body


def main():
    args = parse_args()
    cfg = load_config(args.config)
    if args.extra_body:
        extra = json.loads(args.extra_body)
        if not isinstance(extra, dict):
            sys.exit("--extra-body must be a JSON object")
        cfg["body"].update(extra)

    items = json.loads(args.items.read_text(encoding="utf-8"))
    if args.only:
        wanted = {f"story-{n}" for n in args.only}
        items = [it for it in items if it["story"] in wanted]
    if args.limit:
        items = items[:args.limit]
    if not items:
        sys.exit("no items selected")

    if args.dry_run:
        print(json.dumps(build_body(cfg, items[0]), ensure_ascii=False, indent=2))
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = args.out or HERE / "out" / (
        f"{cfg['model']}-{stamp}-sentences" + (f"-{args.tag}" if args.tag else ""))
    folder.mkdir(parents=True, exist_ok=True)
    results = folder / "results.jsonl"
    done = set()
    if results.exists():
        done = {json.loads(line)["id"] for line in results.read_text(encoding="utf-8").splitlines() if line}

    failures = 0
    for n, item in enumerate(items, 1):
        if item["id"] in done:
            continue
        started = time.time()
        try:
            reply = post(cfg, build_body(cfg, item), args.timeout)
            choice = (reply.get("choices") or [{}])[0]
            message = choice.get("message") or {}
            record = {**item,
                      "content": message.get("content") or "",
                      "reasoning": message.get("reasoning_content") or message.get("reasoning") or "",
                      "finish_reason": choice.get("finish_reason"),
                      "usage": reply.get("usage"),
                      "elapsed": round(time.time() - started, 1)}
            status = f"{len(extract_amr_blocks(record['content']))} blocks"
        except Exception as error:  # keep going; a re-run retries the missing ones
            failures += 1
            print(f"[{n}/{len(items)}] {item['id']} failed: {error}", file=sys.stderr, flush=True)
            continue
        with results.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(f"[{n}/{len(items)}] {item['id']}: {status}, {record['elapsed']}s", flush=True)
    print(f"done, {failures} failed -> {folder}")
    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
