#!/usr/bin/env python3
"""Program checks for a run_sentences.py folder (needs `pip install penman`).

  ./check_sentences.py out/<folder>

Writes <folder>/check.txt and prints it. Per item it reports:
  format       not exactly one amr block / cut by max_tokens
  parse        penman cannot parse the block
  novar        a node written without a variable, e.g. (crow) instead of (c / crow)
  dup-var      a variable is introduced twice
  dangling     a bare symbol is used as a variable reference but never introduced
  unknown      a question without exactly one amr-unknown (counted as text, so
               a node written without a variable still counts), or a statement (no ? in the text) with one
  polarity     yes/no question whose amr-unknown is not the :polarity value, or a
               wh-question whose amr-unknown is the :polarity value
  negation     :polarity - without any negation word in the text, or the reverse
  duprole      a node with the same single-valued role twice (:polarity, :mode,
               :name, :ARGn)
  relation     a role outside the usual AMR role inventory
  omitted      (warning) a content word of the text has no matching concept
These are mechanical checks only; they say nothing about whether the meaning is
right, which is what the spot check is for.
"""

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import penman

from run_trial import extract_amr_blocks

CORE_ROLES = {
    "mod", "poss", "domain", "name", "polarity", "mode", "time", "duration",
    "location", "manner", "purpose", "cause", "condition", "concession",
    "degree", "quant", "unit", "topic", "beneficiary", "instrument",
    "accompanier", "source", "destination", "direction", "path", "medium",
    "extent", "frequency", "ord", "part", "consist", "subevent", "age",
    "example", "li", "value", "wiki", "year", "month", "day", "weekday",
    "decade", "century", "era", "season", "polite", "range", "scale",
    "compared-to", "vocative", "conj-as-if", "snt", "op", "ARG", "prep", "employed-by",
    "subset", "superset", "mod", "direction", "ord", "medium",
}
CONSTANTS = {"-", "+", "interrogative", "expressive", "imperative", "you",
             "i", "we"}
STOPWORDS = set("""a an the of to in on at by for with from and or but so as if
that this these those it its he him his she her they them their you your i me my
we our us is are was were be been being am do does did not no nor than then too
very just also had has have having will would shall should can could may might
must who whom whose which what when where why how there here up down out off
over into onto upon about after before while until till each every some any
all one more most such only own same other another again once ever never""".split())
YES_NO_START = {"did", "do", "does", "was", "were", "is", "are", "could",
                "can", "would", "will", "should", "had", "has", "have"}

NEGATION = re.compile(r"\b(not|no|never|nothing|nobody|none|neither|nor|nay|cannot|without|"
                      r"\w+n['’]t|don['’]t|haven['’]t|hasn['’]t|lest)\b", re.I)

VAR_DEF = re.compile(r"\(\s*([^\s()/]+)\s*/")


def role_ok(role):
    role = role.lstrip(":")
    if role.endswith("-of"):
        role = role[:-3]
    if re.fullmatch(r"ARG\d", role) or re.fullmatch(r"op\d+", role) \
            or re.fullmatch(r"snt\d+", role) or role.startswith("prep-"):
        return True
    return role in CORE_ROLES


def words(text):
    return [w.lower() for w in re.findall(r"[A-Za-z]+", text.replace("’", "'"))]


IRREGULAR = {"took": "take", "came": "come", "said": "say", "fell": "fall",
             "went": "go", "found": "find", "began": "begin", "told": "tell",
             "thought": "think", "made": "make", "caught": "catch", "tied": "tie",
             "bound": "bind", "cried": "cry", "tried": "try", "sent": "send",
             "saw": "see", "seen": "see", "ate": "eat", "gave": "give",
             "got": "get", "held": "hold", "lay": "lie", "lying": "lie",
             "wore": "wear", "stood": "stand", "spoke": "speak", "broken": "break",
             "ran": "run", "running": "run", "was": "be", "were": "be"}


def stem(word):
    """Crude lemma: irregular table, then strip a common suffix, keep 4 letters."""
    word = IRREGULAR.get(word, word)
    for suffix in ("ing", "ed", "es", "ly", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            word = word[:-len(suffix)]
            break
    return word[:4]


def omitted(text, graph):
    """Content words with no concept/constant sharing a stem."""
    pool = []
    for t in graph.triples:
        if t[1] == ":instance" and t[2]:
            pool.append(re.sub(r"-\d+$", "", t[2].lower()))
        elif t[1] != ":instance":
            pool.append(str(t[2]).strip('"').lower())
        pool.append(t[0].lower())  # a node written without a variable is its own name
    out = []
    for w in words(text):
        if w in STOPWORDS or len(w) < 4:
            continue
        st = stem(w)
        if not any(st in p or stem(p) == st for p in pool):
            out.append(w)
    return sorted(set(out))


def check(record):
    """Return a list of (category, detail)."""
    issues = []
    blocks = extract_amr_blocks(record["content"])
    if record.get("finish_reason") == "length":
        issues.append(("format", "cut by max_tokens"))
    if len(blocks) != 1:
        issues.append(("format", f"{len(blocks)} blocks"))
    if not blocks:
        return issues
    amr = blocks[0]
    try:
        graph = penman.decode(amr)
    except Exception as error:
        issues.append(("parse", (str(error).splitlines() or ["?"])[0] or type(error).__name__))
        return issues

    novar = [m.group(1) for m in re.finditer(r"\(\s*([^\s()/]+)(\s*/)?", amr) if not m.group(2)]
    novar = [v for v in novar if v not in set(VAR_DEF.findall(amr))]
    if novar:
        issues.append(("novar", ",".join(novar)))
    defined = VAR_DEF.findall(amr)
    dups = [v for v, n in Counter(defined).items() if n > 1]
    if dups:
        issues.append(("dup-var", ",".join(dups)))
    variables = set(defined) | {t[0] for t in graph.triples}
    dangling = set()
    for src, role, target in graph.triples:
        if role == ":instance":
            continue
        t = str(target)
        if t.startswith('"') or t in CONSTANTS or re.fullmatch(r"[-+]?[\d.,]+", t):
            continue
        if t not in variables and role.lstrip(":") not in {"mode", "polarity", "aspect", "li", "value", "wiki"}:
            if re.fullmatch(r"[a-z][a-z0-9]{0,3}", t):
                dangling.add(t)
    if dangling:
        issues.append(("dangling", ",".join(sorted(dangling))))

    n_unknown = len(re.findall(r"amr-unknown", amr))
    if record["kind"] == "question":
        if n_unknown != 1:
            issues.append(("unknown", f"{n_unknown} amr-unknown"))
        else:
            on_polarity = bool(re.search(r":polarity\s*\(?\s*(?:[^\s()/]+\s*/\s*)?amr-unknown", amr))
            yes_no = words(record["text"])[0] in YES_NO_START
            if yes_no and not on_polarity:
                issues.append(("polarity", "yes/no question, amr-unknown not under :polarity"))
            if not yes_no and on_polarity:
                issues.append(("polarity", "wh-question, amr-unknown under :polarity"))
    elif n_unknown and "?" not in record["text"]:
        # A story sentence that is itself a question may carry amr-unknown.
        issues.append(("unknown", "amr-unknown in a sentence"))

    has_neg_text = bool(NEGATION.search(record["text"]))
    has_neg_amr = bool(re.search(r":polarity\s+-", amr))
    # By the prompt's convention a negative yes/no question drops its "not".
    yes_no_polarity = "?" in record["text"] and re.search(r":polarity\s*\(?\s*(?:[^\s()/]+\s*/\s*)?amr-unknown", amr)
    if has_neg_amr != has_neg_text and not (has_neg_text and yes_no_polarity):
        issues.append(("negation", "polarity - but no negation word" if has_neg_amr
                       else "negation word in text but no :polarity -"))
    seen = Counter((src, role) for src, role, _ in graph.triples
                   if role == ":polarity" or role == ":mode" or role == ":name"
                   or re.fullmatch(r":ARG\d", role))
    dup_roles = sorted({role for (_, role), n in seen.items() if n > 1})
    if dup_roles:
        issues.append(("duprole", ",".join(dup_roles)))
    bad = sorted({r for _, r, _ in graph.triples if r != ":instance" and not role_ok(r)})
    if bad:
        issues.append(("relation", ",".join(bad)))
    om = omitted(record["text"], graph)
    if om:
        issues.append(("omitted", ",".join(om)))
    return issues


def main():
    folder = Path(sys.argv[1])
    records = [json.loads(l) for l in (folder / "results.jsonl").read_text(encoding="utf-8").splitlines() if l]
    per_cat = defaultdict(list)
    lines = []
    clean = 0
    for r in records:
        issues = check(r)
        if not [i for i in issues if i[0] != "omitted"]:
            clean += 1
        for cat, detail in issues:
            per_cat[cat].append(r["id"])
            lines.append(f"{r['id']:16} {cat:9} {detail}")
    n = len(records)
    out = [f"{n} items ({sum(r['kind'] == 'sentence' for r in records)} sentences, "
           f"{sum(r['kind'] == 'question' for r in records)} questions); "
           f"{clean} without any hard issue (omitted is only a warning)", ""]
    for cat in ("format", "parse", "novar", "dup-var", "dangling", "unknown", "polarity", "negation", "duprole", "relation", "omitted"):
        out.append(f"{cat:9} {len(per_cat[cat]):3} items")
    out += ["", *lines]
    usage = [r["usage"] for r in records if r.get("usage")]
    out += ["", f"completion tokens: {sum(u['completion_tokens'] for u in usage)}, "
                f"reasoning: {sum(u['completion_tokens_details']['reasoning_tokens'] for u in usage)}, "
                f"elapsed: {sum(r['elapsed'] for r in records):.0f}s"]
    text = "\n".join(out) + "\n"
    (folder / "check.txt").write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
