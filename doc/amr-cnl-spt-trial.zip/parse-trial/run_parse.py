#!/usr/bin/env python3
"""Constituency parsing probe: one request per sentence, thinking off.

Same 50 sentences as ../cnl-proto (dev50: seed 2 over amr-trial's sentence
items). The model writes a Penn Treebank style bracketed tree; check_tree()
only verifies structure (balanced, leaves equal the sentence tokens), it does
not judge the linguistics -- that is reviewed by hand.

  ./run_parse.py --dry-run
  ./run_parse.py                 # 50 sentences, one at a time
  ./run_parse.py --only story-2/S2

Output: out/<model>-<time>-dev50/results.jsonl and trees.txt.
"""

import argparse
import json
import random
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "cnl-proto"))
from run_pipeline import NO_THINKING, extract_blocks, load_config, post  # noqa: E402

HERE = Path(__file__).resolve().parent
AMR_TRIAL = HERE.parent / "amr-trial"

SYSTEM = (
    "You are an expert in English syntax. Parse the sentence into a constituency "
    "tree in Penn Treebank bracketed notation: (S (NP (DT The) (NN dog)) (VP (VBD barked)) (. .)). "
    "Use PTB phrase labels (S, SBAR, SBARQ, NP, VP, PP, ADJP, ADVP, PRN, ...) and POS tags "
    "on every word, and function-free labels (no -SBJ etc.). Keep every token of the "
    "sentence exactly as written, split punctuation and clitics (n't, 's) as PTB does, "
    "and put no words that are not in the sentence. Output only one ```tree code block "
    "with the tree, which may span several lines."
)
USER = "Parse this sentence:\n\n{text}\n"


def dev50():
    items = json.loads((AMR_TRIAL / "items.json").read_text(encoding="utf-8"))
    pool = [it for it in items if it["kind"] == "sentence"]
    return random.Random(2).sample(pool, 50)


def read_tree(text):
    """Parse bracketed text to nested lists; return (tree, error)."""
    tokens = re.findall(r"\(|\)|[^\s()]+", text)
    pos = 0

    def node():
        nonlocal pos
        if tokens[pos] != "(":
            raise ValueError(f"expected '(' at token {pos}: {tokens[pos]!r}")
        pos += 1
        children = []
        while pos < len(tokens) and tokens[pos] != ")":
            if tokens[pos] == "(":
                children.append(node())
            else:
                children.append(tokens[pos])
                pos += 1
        if pos >= len(tokens):
            raise ValueError("unbalanced: missing ')'")
        pos += 1
        return children

    try:
        if not tokens:
            return None, "empty"
        tree = node()
        if pos != len(tokens):
            return None, "extra text after the tree"
        return tree, None
    except (ValueError, IndexError) as e:
        return None, str(e)


def leaves(tree):
    if isinstance(tree, str):
        return [tree]
    out = []
    for c in tree[1:]:
        out += leaves(c)
    return out


NORM = {"-LRB-": "(", "-RRB-": ")", "``": '"', "''": '"', "“": '"', "”": '"', "‘": "'", "’": "'"}


def norm(w):
    return NORM.get(w, w)


def check_tree(content, sentence):
    """Return a list of structural problems (empty = ok)."""
    blocks = extract_blocks(content)
    if len(blocks) != 1:
        return [f"expected 1 code block, found {len(blocks)}"]
    tree, err = read_tree(blocks[0])
    if err:
        return [err]
    got = "".join(norm(w) for w in leaves(tree))
    want = "".join(norm(c) for c in sentence if not c.isspace())
    if got != want:
        return ["leaves differ from the sentence"]
    return []


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--only", nargs="+", metavar="ID")
    p.add_argument("--config", type=Path, default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--timeout", type=float, default=300)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    cfg = load_config(args.config)
    cfg["body"].update(NO_THINKING)
    items = dev50()
    if args.only:
        items = [it for it in items if it["id"] in set(args.only)]

    def body_for(text):
        body = {"model": cfg["model"], "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": USER.format(text=text)}]}
        if cfg["max_tokens"]:
            body["max_tokens"] = cfg["max_tokens"]
        body.update(cfg["body"])
        return body

    if args.dry_run:
        print(json.dumps(body_for(items[0]["text"]), ensure_ascii=False, indent=2))
        return

    folder = args.out or HERE / "out" / f"{cfg['model']}-{time.strftime('%Y%m%d-%H%M%S')}-dev50"
    folder.mkdir(parents=True, exist_ok=True)
    results = folder / "results.jsonl"
    done = set()
    if results.exists():
        done = {json.loads(l)["id"] for l in results.read_text(encoding="utf-8").splitlines() if l}

    for n, item in enumerate(items, 1):
        if item["id"] in done:
            continue
        started = time.time()
        try:
            reply = post(cfg, body_for(item["text"]), args.timeout)
        except Exception as error:
            print(f"[{n}/{len(items)}] {item['id']} failed: {error}", file=sys.stderr, flush=True)
            continue
        choice = reply["choices"][0]
        message = choice["message"]
        content = message.get("content") or ""
        reasoning = (reply["usage"].get("completion_tokens_details") or {}).get("reasoning_tokens", 0)
        if reasoning or message.get("reasoning_content") or message.get("reasoning"):
            sys.exit(f"thinking is not off (reasoning_tokens={reasoning}); stopped")
        problems = check_tree(content, item["text"])
        record = {**item, "content": content, "problems": problems,
                  "finish_reason": choice.get("finish_reason"), "usage": reply["usage"],
                  "elapsed": round(time.time() - started, 1)}
        with results.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(f"[{n}/{len(items)}] {item['id']}: {'ok' if not problems else problems}, "
              f"{record['elapsed']}s", flush=True)

    with (folder / "trees.txt").open("w", encoding="utf-8") as f:
        for l in results.read_text(encoding="utf-8").splitlines():
            r = json.loads(l)
            f.write(f"## {r['id']}  {r['problems'] or ''}\n{r['text']}\n{r['content']}\n\n")
    print(f"done -> {folder}")


if __name__ == "__main__":
    main()
