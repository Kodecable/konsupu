# parse-trial

单句成分句法树探针，仿照 `../cnl-proto/run_pipeline.py`：同一批 dev50（amr-trial exp2，seed 2）50 句，
deepseek-v4.1-flash **无思考**（thinking disabled，reasoning_effort none，temperature 0.8），一句一请求，
要求输出 PTB 括号树（```tree 代码块）。无重试、无反馈。

```shell
./run_parse.py --dry-run
./run_parse.py                 # 输出 out/deepseek-v4.1-flash-20261009-135812-dev50/results.jsonl、trees.txt
```

`run_parse.py` 的 `check_tree` 只查括号是否平衡、叶子是否等于原句，不评判语言学正确性；质量靠人工读树。

## 结果（out/deepseek-v4.1-flash-20261009-135812-dev50）

自动检查（括号 + 叶子，忽略引号/撇号差异后）：34 通过；7 叶子不一致（模型丢字或加字）；
7 多出右括号；2 缺右括号。（该检查对 `(0)`、`*?*` 这类伪叶子不敏感，漏了 story-3/S3 的丢词。）

逐条人工读 50 棵树：

- 基本正确 20：短句和中等长度、单层从句的句子（story-13/S13、11/S8、6/S2、5/S1、9/S4、8/S4、10/S2、8/S2、3/S6 等）。
- 小毛病但可用 12：括号多/少一个（12/S5、4/S2、4/S1）、用了 `NP-SBJ`（12/S2，违反提示）、
  `AUX` 非 PTB 标签（7/S10）、关系从句挂成 NP+VP 而非 SBAR（2/S8）、引语句的 S 结构被摊平（2/S2、8/S9、7/S3、7/S9、13/S8）。
- 明显错误 18：
  - 改动文字：7/S1 凭空多出 "that was"；13/S3 丢 "what"；11/S4 丢 "n't"（否定丢失）；8/S10 丢 "promises"；
    3/S3 丢 "help"；4/S3 多出 `*?*`。
  - 结构错：3/S1、4/S5、9/S2 的主句主语/动词被并进从句或 VP；3/S7 把 VP 放进 NP；10/S3 把两个分句当 NP 并列；
    6/S4 把并列的 "he told them" 挂进 that 从句；10/S5 ADVP 里塞 IN/DT；
    3/S2、9/S3、11/S3 是长句/引语句，括号和结构一起崩（9/S3 还颠倒词序、用了 `WHNP-1`）。
- 通病：几乎总丢掉引号（PTB 里应是 ``` / `''`）；VP 并列常摊平成 `(VP V NP CC VP)` 而不是 `(VP (VP..) CC (VP..))`；
  句越长越容易括号数错，错误集中在 >25 词的句子和带引语的句子。

结论：无思考单次直出对短/中等句可用（约 4 成直接可用，6 成含小毛病），长句和引语句不可靠，
且"丢字/加字/丢否定"这类静默改文字的错不被括号检查完全抓住。要用的话需要：更严格的叶子检查
（逐词序列比对，含伪叶子）+ 括号错误的重试反馈（同 cnl-proto），或开思考。
