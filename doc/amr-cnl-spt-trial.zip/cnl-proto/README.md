# cnl-proto

类英语的可嵌套符号语言的解析器原型。只做词法、语法与静态检查，不求值，也不以 Commons 为后端。
只依赖 Python 标准库（3.10+，用到了 `match`）。

```shell
./cnl.py examples/story-2.cnl         # 检查，打印规范化后的程序；有错误时退出码为 1
./cnl.py --json examples/story-5.cnl  # 打印 AST（JSON）
./cnl.py -                            # 从 stdin 读
python3 -m unittest                   # 测试
```

报错面向模型：每条给出 `文件:行:列`、错在哪，以及 `fix:` 一行改法，可以原样作为重试的反馈。
一条语句出错不影响其他语句的检查（按顶层的 `.`、`?` 切分后逐条解析）。规范化输出保留原写法（包括 do/does/did），
可以再次解析得到同样的结果。

## 翻译原则

**只写字面意思。** 原文用词直接给出的才写：有 so/because 才写 `because`，有 as/when 才写 `when`，
有 no longer 才写 `was not`，有过去完成时才写 `, earlier`。没写的时间关系、状态的起止、因果，后端一律当作未知。

**写法建议**（不强制，解析器最多给警告）：

- see、hear、notice、find 这类动词的补语确实发生了，写成带标签的语句再引用：`fox1 "see" fly1. fly1: crow1 "fly off"`；
  不确定是否发生（imagine、dream）才用描述 `{…}`。
- 定指的东西（the gate、her mouth）给标识符，不要藏进引号里的词：宾语位置的词以 the、his、her、its、their 等开头时给警告；
  动词那个词本身不查（"open her mouth" 照样合法，这是写法建议）。
- 一个词只装一个动作。词里出现 and、but、then、so、because、when 等连接词会得到警告，提示拆成两条语句；
  只连接两个名词（"of wit and wealth"）时忽略即可。

## 词法

- **关键字**：不加引号，保留字（见 `cnl.py` 的 `KEYWORDS`）。
- **标识符**：其余不加引号的词，`[A-Za-z_][A-Za-z0-9_]*`，不要求数字结尾。
- **词**：开放词表，一律用直双引号 `"..."`，内部空白合并为一个空格。动词写原形（`"praise"`）。
- `//` 到行尾是注释。

## 语句

```text
fox1 is "fox".                                     定义：它是什么。全局、唯一、只在顶层，形状恰好如此
p1: fox1 "praise" crow1.                           事件；标签命名它，并表示它发生了
fox1 "give" meat1 "to" crow1.                      谓词是以词开头的骨架，标识符和不定指填在槽里
fox1 did not "praise" crow1.                       没有这样的事件（do / does / did 等价，按原文写）
crow1 was "holding" meat1.                         状态（叙事层用 was）
crow1 was not "holding" meat1.                     否定的状态
a "fox" is "cunning".                              一般陈述：叙事层的 is 不带时间，主语不能是标识符
a "flatterer" usually "rob" a "victim".            一般事件：always / usually / never 放在动词前
fox1 cannot "get out of" well1, until s1.          情态：can / cannot / may / must，后接谓词
fox1 say crow1 {crow1 is "looking well"}.          态度：say ask tell promise believe think know want hope fear plan，可带对象
fox1 will "give" crow1 advice1.                    将来（在内容里相对于说话时）
face1 is really mask1.                             对应：两者是同一个东西
c3 was true.                                       某段言语或信念的内容在当前语境成立
there was a "wolf". there was no "wolf".           存在与不存在
g1 happened.
```

**内容 `{…}`** 里可以有多条语句（最后的 `.` 可省），还可以有：

```text
"let" fox1 "hear one song".                        祈使：以词开头、没有主语，主语是听者
do not "trust" a "flatterer".  do "wait".          否定祈使；单个词的祈使要加 do
"ah".  "good-day".                                 单独一个词：感叹、问候
why did fox1 "stay"?                               问句（以 ? 结尾）
```

祈使和感叹也可以出现在顶层（说给读者）。内容里的时态相对于说话或相信的时刻：`is` 是当时，`was` 是更早，`will` 是之后。

`{ sentence }` 不能带标签，不能是问句或祈使。它是否断言发生，照英语从句的预设：

- **陈述的子句**（`when`、`after`、`because`、`by` 等）里的 `{X}` 表示 X 发生了：
  `crab1 "hide in" mud1, when {crab1 "see" heron1}` 同时说了螃蟹看见了鹭。否定的陈述也一样（“他看见鹭时没有躲”仍预设看见了）。
  同一件事不要再单独写一条语句；两处都要引用时，写一次带标签的语句，用标签引用。
- **祈使、将来（will）、情态、一般陈述**的子句不预设（“wait until I come”“a fox runs when it sees a dog”），`{X}` 只是描述。
- **问句里**、以及作为谓词里的东西（`fox1 "see" {…}`、`fox1 "feel sure" {…}`）时，`{X}` 只是描述。

检查器把结果记在 JSON 的 `Ref.asserted` 上。

**子句**接在主句后，用 `,` 隔开，只修饰同一层的主句，不能再带子句：

```text
, before X  , after X  , during X  , while X  , when X  , until X  , since X  , from X   X 是标签、{描述} 或 what
, because X  , by X  , in order to {…}  , at start  , at end  , third time  , earlier  , among others
```

## 问句

以 `?` 结尾。没有疑问词就是是非问；每个问句至多一个疑问词。

```text
did fox1 "praise" crow1?                           是非：did / does / do + 事件或态度
was crow1 "holding" meat1, when p1?                是非：was / is + 状态；was c3 true?  is face1 really mask1?
can fox1 "get out of" well1?   was there a "wolf"?   will boy1 "come"?
fox1 "praise" crow1?                               陈述语序加 ? 也是是非问
who "praise" crow1?   which "bird" "sing"?         问主语
what happened, after p1?
what did cheese1 "fall to"?                        前置疑问词：问句末的空位（介词悬空）
what did crow1 believe?   what is face1 really?    态度的内容、really 的另一侧
fox1 "give" what "to" crow1?                       空位在中间时，疑问词留在原处
why did fox1 "praise" crow1?   when did ...?   how did ...?   how many times did ...?
```

`who did not "sing"?`（主语后直接跟谓词）与 `who did fox1 "praise"?`（助动词后跟主语）靠助动词后面是不是主语区分。

## 语义约定（后端尚未实现，这里只是记录）

- **标识符**：全局，与顺序无关，各定义恰好一次（`is` 或标签）。`is` 本身不断言存在；实体在哪些语境里有关于它的语句，就在哪些语境里被谈论。
  标签写在语境内容里时，事件只在那个语境里发生；在别处引用它时只是描述。
- **时间**：同一语境中顶层语句的先后是唯一保留的默认：后一个事件**不早于**前一个开始，是否在其结束之后、是否重叠都未知。
  状态只在被叙述的位置成立，何时开始、何时结束都未知，没有持续推理。
- **否定**：`did not` 是这个语境中没有符合它（连同子句）的事件；`was not` 是一个否定的状态。
- **不定指** `a "x"`：始终是存在量化，作用范围是所在语句或 `{}`；在否定、`cannot`、问句下分别成为“没有”“一类行为”“有没有”。
- **`know`** 是事实性的：知道的内容在世界中成立。
- **封闭**（计数、序数、“接下来”）：按模式封闭，一个模式被叙述过就以叙述到的为全部；`among others` 打开封闭。

## 静态检查

| 检查 | 例子 |
|---|---|
| 未定义的标识符（给出相近名字；提示若是普通词应加引号） | `crow1 "drink" water.` |
| 重复定义（`is` 与标签共用一个名字空间） | `crow1 is "proud".`（提示状态用 `was`） |
| 叙事层的 `is` 不能以标识符为主语 | `fox1 is "proud", at start.` |
| 不能带标签：否定的事件、一般陈述、`really`、`true`、`there was`、`happened`、祈使、感叹；问句及其内容；描述 | `n1: crow1 did not "sing".` |
| 时间、`because`、`by`、`happened` 要事件（标签、描述或 `what`），不能是实体或不定指 | `, after fox1` |
| 问句形式（助动词前置、疑问词）必须以 `?` 结尾；一个问句至多一个疑问词；祈使和感叹不能是问句 | `did crow1 "sing".` |
| 问句、祈使不能出现在描述或子句里 | `, after {did fox1 "x"}` |
| 态度的内容必须是 `{...}`（问句中可为 `what` 或空位） | `fox1 want meat1.` |
| `true` 要有内容的标签（言语、信念等）或描述；`really` 两侧同为实体或同为事件 | `p1 was true.` |
| `there was` 只接不定指 | `there was fox1.` |
| 谓词以词开头；逗号不能连接两个主句；关键字不能混进谓词；频度副词要放在动词前 | `crow1 meat1 "have".` |
| 词法：弯引号、未闭合的引号、空词、括号不配对 | `fox1 “praise” crow1.` |
| 英语虚词裸写（the、him、would、could、had、and、of……）：按词给出专门的改法，不给“是不是指某个标识符”的猜测 | `fox1 would "stay".` |
| 警告：定义了但没用的实体；一个词里有连接词；宾语位置的词像定指的东西 | `"fly off and settle on"`、`"the gate"` |

表示事件或状态、又没有标签的语句会得到隐式 id `_1`、`_2`……（JSON 中的 `id`）。

## 翻译提示词（`prompts/`）

仿照 `../amr-trial` 的 v3：

- `cnl_guide_v1.md`：系统提示，英文，内容是上面这些规则的面向模型版本（字面原则、词法、实体、语句表、子句、言语与感知、问句表）。
- `examples_v1.json`：
  - `user.sentence` / `user.question`：每项请求的用户消息模板（`{text}` 处放原句）；
  - `feedback`：重试时附上检查结果的用户消息模板（`{items}` 处放报错清单）；
  - `examples`：预注入的 6 组问答，按顺序作为 user / assistant 消息放在系统提示之后，assistant 一侧是 ```` ```cnl ```` 代码块。

示例句子都不在语料中，覆盖：关系从句、could not、so → `because {…}`、引语与祈使、不预设的 `until`（Goat）；`when {…}`、but 不写、同指复用（Crab）；
感知动词的标签、引语里的现在时与将来、感叹词、内容里的标签引用（Wolf）；引语中的 wh 问句与否定、没有指称的代词、
过去完成时 → `earlier`（Stork）；带描述的 why 问句、前置疑问词问内容（两个问句）。
没有覆盖（只在指南文字里）：是非问句、一般陈述、`really`、`there was`、序数、`in order to`。

系统提示加 6 组示例约 7.9k 字符，比 amr-trial v3 的 7.4k 略多（v3 实测约 2.3k 输入 token，按比例估计约 2.4k，仍在 2.5k 预算内）。
`test_prompt_examples_are_clean` 保证每个示例都能无诊断地通过 `cnl.py`；指南正文里的写法也逐条解析过（占位的 `...`、`Y` 除外）。

## 示例与剩余问题

`examples/story-2.cnl`（The Fox and the Crow）、`story-5.cnl`（The Fox and the Mask）是手写的字面翻译，各带语料中的 5 个问题，
注释里写了按字面原则预期的答案，多数是“未知”，这是字面原则的代价。

还没解决的：

1. 连接词警告会误报名词并列（story-2 的寓意就有一条）。要在批量试验上量误报率再决定要不要收紧。
2. “That will do” 这类习语只能整句当感叹写；它其实有命题内容。
3. 前置疑问词的空位只能在句末；更深的位置（内容里、中间）要用原位疑问词，读起来像回声问。
4. 代词与称呼（he、Master Reynard → fox1）的同指仍由模型完成，语法无从检查。
