#!/usr/bin/env python3
"""Single-sentence CNL translation with a check-and-retry loop, thinking off.

The CNL counterpart of ../amr-trial/run_pipeline.py. For each sentence: send
the request, run cnl.check on the answer; if it reports errors, append the
answer and the diagnostics to the same conversation as a new user turn and ask
again, up to --max-retries times. The answer kept is the first one without
errors, else the one with the fewest errors (earliest on ties). Requests are
sent one at a time. Warnings are recorded but never trigger a retry.

The 50 sentences are the dev50 set of ../amr-trial (exp2: seed 2 over the story
sentences of its items.json), so the two experiments are paired.

  ./run_pipeline.py --dry-run
  ./run_pipeline.py                      # 50 sentences, up to 3 retries
  ./run_pipeline.py --max-retries 0      # control: no feedback
  ./run_pipeline.py --only story-2/S2 story-5/S1

Output: out/<model>-<time>-cnl-dev50-r<N>/results.jsonl (one record per
sentence, with every attempt); re-running with the same --out resumes.
"""

import argparse
import http.client
import json
import random
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from cnl import check

HERE = Path(__file__).resolve().parent
AMR_TRIAL = HERE.parent / "amr-trial"
NO_THINKING = {"thinking": {"type": "disabled"}, "reasoning_effort": "none"}
CONNECT_ATTEMPTS = 3


def load_config(path):
    llm = json.loads(path.read_text(encoding="utf-8"))["llm"]
    api = llm["openai_completion"]
    return {"model": llm["model"], "base_url": api["base_url"], "api_key": api.get("api_key"),
            "headers": api.get("headers") or {}, "body": api.get("body") or {},
            "max_tokens": llm.get("max_output_tokens")}


def post(cfg, body, timeout):
    url = cfg["base_url"].rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json", **cfg["headers"]}
    if cfg["api_key"]:
        headers["Authorization"] = "Bearer " + cfg["api_key"]
    request = urllib.request.Request(
        url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers, method="POST")
    for attempt in range(1, CONNECT_ATTEMPTS + 1):
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {error.code} from {url}:\n{detail}") from None
        except (urllib.error.URLError, ConnectionError, http.client.HTTPException):
            # The endpoint sometimes drops the connection before replying.
            if attempt == CONNECT_ATTEMPTS:
                raise
            time.sleep(2 * attempt)


def dev50():
    """The 50 sentences of amr-trial's exp2, same seed and pool."""
    items = json.loads((AMR_TRIAL / "items.json").read_text(encoding="utf-8"))
    pool = [it for it in items if it["kind"] == "sentence"]
    return random.Random(2).sample(pool, 50)


def load_prompts():
    guide = (HERE / "prompts" / "cnl_guide_v1.md").read_text(encoding="utf-8")
    spec = json.loads((HERE / "prompts" / "examples_v1.json").read_text(encoding="utf-8"))
    return guide, spec


def base_messages(guide, spec, sentence):
    template = spec["user"]["sentence"]
    messages = [{"role": "system", "content": guide}]
    for ex in spec["examples"]:
        if ex["kind"] != "sentence":
            continue
        messages.append({"role": "user", "content": template.format(text=ex["text"])})
        messages.append({"role": "assistant", "content": f"```cnl\n{ex['cnl']}\n```"})
    messages.append({"role": "user", "content": template.format(text=sentence)})
    return messages


def extract_blocks(text):
    """Return the contents of every fenced code block."""
    blocks, current = [], None
    for line in text.splitlines():
        if line.strip().startswith("```"):
            if current is None:
                current = []
            else:
                blocks.append("\n".join(current))
                current = None
        elif current is not None:
            current.append(line)
    return blocks


def check_answer(content, finish_reason):
    """Return (errors, warnings): lists of formatted diagnostics."""
    if finish_reason == "length":
        return ["the answer was cut off; write a shorter translation"], []
    blocks = extract_blocks(content)
    if len(blocks) != 1:
        return [f"expected exactly one ```cnl code block, found {len(blocks)}"], []
    _, diags = check(blocks[0])
    errors = [d.format("answer") for d in diags if d.severity == "error"]
    warnings = [d.format("answer") for d in diags if d.severity == "warning"]
    return errors, warnings


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--max-retries", type=int, default=3)
    p.add_argument("--only", nargs="+", metavar="ID", help="restrict to these item ids")
    p.add_argument("--config", type=Path, default=HERE.parent / "opencode-go-dsv4.1f.json")
    p.add_argument("--model", default=None)
    p.add_argument("--timeout", type=float, default=600)
    p.add_argument("--out", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true", help="print the first request body and exit")
    args = p.parse_args()

    cfg = load_config(args.config)
    if args.model:
        cfg["model"] = args.model
    cfg["body"].update(NO_THINKING)
    guide, spec = load_prompts()
    items = dev50()
    selection = AMR_TRIAL.glob("out/*-exp2-v2/selection.json")
    for path in selection:
        assert json.loads(path.read_text()) == [it["id"] for it in items], f"selection differs from {path}"
    if args.only:
        items = [it for it in items if it["id"] in set(args.only)]

    def body_for(messages):
        body = {"model": cfg["model"], "messages": messages}
        if cfg["max_tokens"]:
            body["max_tokens"] = cfg["max_tokens"]
        body.update(cfg["body"])
        return body

    if args.dry_run:
        print(json.dumps(body_for(base_messages(guide, spec, items[0]["text"])),
                         ensure_ascii=False, indent=2)[:3000])
        return

    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = args.out or HERE / "out" / f"{cfg['model']}-{stamp}-cnl-dev50-r{args.max_retries}"
    folder.mkdir(parents=True, exist_ok=True)
    results = folder / "results.jsonl"
    done = set()
    if results.exists():
        done = {json.loads(l)["id"] for l in results.read_text(encoding="utf-8").splitlines() if l}

    for n, item in enumerate(items, 1):
        if item["id"] in done:
            continue
        messages = base_messages(guide, spec, item["text"])
        attempts = []
        for attempt in range(args.max_retries + 1):
            started = time.time()
            try:
                reply = post(cfg, body_for(messages), args.timeout)
            except Exception as error:  # a re-run retries the missing items
                print(f"[{n}/{len(items)}] {item['id']} failed: {error}", file=sys.stderr, flush=True)
                break
            choice = reply["choices"][0]
            message = choice["message"]
            content = message.get("content") or ""
            reasoning_text = message.get("reasoning_content") or message.get("reasoning") or ""
            reasoning = (reply["usage"].get("completion_tokens_details") or {}).get("reasoning_tokens", 0)
            if reasoning or reasoning_text:
                # The endpoint has ignored the switch before; stop rather than
                # collect results under a different condition.
                sys.exit(f"thinking is not off (reasoning_tokens={reasoning}); stopped")
            errors, warnings = check_answer(content, choice.get("finish_reason"))
            attempts.append({"content": content, "errors": errors, "warnings": warnings,
                             "finish_reason": choice.get("finish_reason"), "usage": reply["usage"],
                             "elapsed": round(time.time() - started, 1)})
            if not errors or attempt == args.max_retries:
                break
            messages.append({"role": "assistant", "content": content})
            messages.append({"role": "user", "content": spec["feedback"].format(
                items="\n".join(errors))})
        if not attempts:
            continue
        passed = [i for i, a in enumerate(attempts) if not a["errors"]]
        best = passed[0] if passed else min(range(len(attempts)), key=lambda i: (len(attempts[i]["errors"]), i))
        usage = {"prompt_tokens": sum(a["usage"]["prompt_tokens"] for a in attempts),
                 "completion_tokens": sum(a["usage"]["completion_tokens"] for a in attempts)}
        record = {**item, "content": attempts[best]["content"], "usage": usage,
                  "elapsed": round(sum(a["elapsed"] for a in attempts), 1),
                  "n_attempts": len(attempts), "passed": bool(passed), "final_attempt": best,
                  "first_content": attempts[0]["content"], "attempts": attempts}
        with results.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(f"[{n}/{len(items)}] {item['id']}: {len(attempts)} attempt(s), "
              f"{'passed' if passed else 'STILL FAILING'}, {record['elapsed']}s", flush=True)
    print(f"done -> {folder}")


if __name__ == "__main__":
    main()
