#!/usr/bin/env python3
"""Tests for cnl.py:  python3 -m unittest  (from this directory)."""

import json
import unittest
from dataclasses import fields, is_dataclass
from pathlib import Path

from cnl import Question, Ref, WhFront, check, fmt

HERE = Path(__file__).parent
HEADER = 'fox1 is "fox". crow1 is "crow". meat1 is "meat".\n'

ACCEPTED = """
p1: fox1 "praise" crow1, in order to {g1: fox1 "get" meat1}.
crow1 was "holding" meat1.
h2: crow1 was not "holding" meat1, after p1.
s1: crow1 "sing", because p1, when {fox1 "praise" crow1}.
boy1 is "boy".
c3: boy1 say {w1: a "wolf" "come". a "wolf" will "eat" a "sheep"}, third time.
boy1 ask fox1 {why did fox1 "praise" crow1?}.
boy1 say fox1 {"ah". do not "trust" a "flatterer". "wait here", until s1. do "go". fox1 is "looking well"}.
fox1 cannot "get out", until s1.
crow1 is really fox1.
there was no "wolf", during c3.
c3 was true.
g1 happened, at end.
a "fox" usually "eat" a "grape".
a "fox" is always "hungry".
a "flatterer" never "tell" a "truth".
fox1 did not "praise" crow1, earlier.
fox1 did not believe {crow1 "sing"}.
who "praise" crow1?
who did not "sing"?
which "bird" "sing"?
what happened, after p1?
who was "holding" meat1, at end?
how many times did boy1 say {a "wolf" "come"}?
what did boy1 say, third time?
did fox1 "praise" crow1, among others?
does fox1 believe {crow1 "sing"}?
was crow1 "holding" meat1, when p1?
was c3 true?
what is crow1 really?
was there a "wolf", during c3?
can fox1 "get out"?
cannot fox1 "get out"?
will boy1 "come"?
what did crow1 "hold"?
what was crow1 "holding"?
what did fox1 believe?
when did crow1 "sing"?
why was crow1 "holding" meat1?
fox1 "give" what "to" crow1?
fox1 "praise" crow1?
"""


def diags_of(src, header=True):
    _, diags = check((HEADER if header else "") + src)
    return diags


def errors_of(src, header=True):
    """Each error as 'message | hint', so tests can look for a fragment of either."""
    return [f"{d.message} | {d.hint}" for d in diags_of(src, header) if d.severity == "error"]


def normalized(src):
    program, diags = check(src)
    return "\n".join(fmt(i) for i in program.items), diags


class Examples(unittest.TestCase):
    def test_examples_have_no_errors(self):
        for path in sorted((HERE / "examples").glob("*.cnl")):
            with self.subTest(path=path.name):
                _, diags = check(path.read_text(encoding="utf-8"))
                self.assertEqual([d.format(path.name) for d in diags if d.severity == "error"], [])

    def test_prompt_examples_are_clean(self):
        data = json.loads((HERE / "prompts" / "examples_v1.json").read_text(encoding="utf-8"))
        for i, ex in enumerate(data["examples"]):
            with self.subTest(example=i):
                program, diags = check(ex["cnl"])
                self.assertEqual([d.format(f"example {i}") for d in diags], [])
                has_question = any(isinstance(it, Question) for it in program.items)
                self.assertEqual(has_question, ex["kind"] == "question")

    def test_normalized_output_round_trips(self):
        sources = [p.read_text(encoding="utf-8") for p in sorted((HERE / "examples").glob("*.cnl"))]
        for src in sources + [HEADER + ACCEPTED]:
            once, _ = normalized(src)
            again, diags = normalized(once)
            self.assertEqual([d for d in diags if d.severity == "error"], [])
            self.assertEqual(again, once)

    def test_implicit_ids(self):
        program, _ = check(HEADER + 'crow1 "sing". p1: fox1 "praise" crow1. crow1 did not "sing". fox1 is really crow1.')
        self.assertEqual([i.id for i in program.items[3:]], ["_1", "p1", "", ""])


class Accepted(unittest.TestCase):
    def test_forms(self):
        self.assertEqual(diags_of(ACCEPTED), [])

    def test_order_free_definitions(self):
        self.assertEqual(errors_of('crow1 "sing", after p1. p1: fox1 "praise" crow1.'), [])
        self.assertEqual(errors_of('dog2 "bark". dog2 is "dog".', header=False), [])

    def test_fronted_question_fills_the_end(self):
        program, _ = check(HEADER + 'what did fox1 "give" "to"?')
        clause = program.items[-1].sentence.clause
        self.assertIsInstance(clause, WhFront)
        self.assertEqual(type(clause.clause.words[-1]).__name__, "Gap")

    def test_terminator_decides_question(self):
        program, _ = check(HEADER + 'fox1 "praise" crow1?')
        self.assertIsInstance(program.items[-1], Question)

    def test_written_auxiliary_is_kept(self):
        once, _ = normalized(HEADER + 'fox1 say {crow1 does not "sing"}. does fox1 "sing"?')
        self.assertIn('crow1 does not "sing"', once)
        self.assertIn('does fox1 "sing"?', once)


def refs(node, out=None):
    """Every {description} under node, as (text, asserted)."""
    out = [] if out is None else out
    if isinstance(node, Ref):
        out.append((fmt(node), node.asserted))
    if isinstance(node, list):
        for x in node:
            refs(x, out)
    elif is_dataclass(node):
        for f in fields(node):
            refs(getattr(node, f.name), out)
    return out


class Presupposition(unittest.TestCase):
    """{X} after a modifier states that X happened only where English presupposes it."""

    def asserted(self, src):
        program, diags = check(HEADER + 'heron1 is "heron". ' + src)
        self.assertEqual([d for d in diags if d.severity == "error"], [])
        return [a for _, a in refs(program.items[-1])]

    def test_report_presupposes(self):
        self.assertEqual(self.asserted('crow1 "hide", when {crow1 "see" heron1}.'), [True])
        self.assertEqual(self.asserted('crow1 did not "hide", when {crow1 "see" heron1}.'), [True])
        self.assertEqual(self.asserted('crow1 "hide", because {crow1 "see" heron1, after {fox1 "come"}}.'), [True, True])
        self.assertEqual(self.asserted('fox1 say {crow1 "hide", when {crow1 "see" heron1}}.'), [True])

    def test_hypothetical_does_not(self):
        self.assertEqual(self.asserted('fox1 say {"wait", until {fox1 "come"}}.'), [False])
        self.assertEqual(self.asserted('fox1 will "come", after {crow1 "sing"}.'), [False])
        self.assertEqual(self.asserted('fox1 can "run", when {fox1 "see" heron1}.'), [False])
        self.assertEqual(self.asserted('a "fox" usually "run", when {a "fox" "see" a "dog"}.'), [False])

    def test_descriptions_and_questions_do_not(self):
        self.assertEqual(self.asserted('fox1 "see" {crow1 "hide", after {crow1 "see" heron1}}.'), [False, False])
        self.assertEqual(self.asserted('did crow1 "hide", when {crow1 "see" heron1}?'), [False])

    def test_lone_word_with_a_modifier_is_a_command(self):
        program, _ = check(HEADER + 'fox1 say {"wait here", until {fox1 "come"}. "ah". do "go"}.')
        kinds = [type(i.sentence.clause).__name__ for i in program.items[-1].sentence.clause.content.items]
        self.assertEqual(kinds, ["Imperative", "Expressive", "Imperative"])


class Rejected(unittest.TestCase):
    def assertError(self, src, fragment, header=True):
        errors = errors_of(src, header)
        self.assertTrue(any(fragment in e for e in errors), f"{fragment!r} not in {errors}")

    def test_undefined_with_suggestion(self):
        errors = errors_of('fox1 "praise" crow2.')
        self.assertEqual(len(errors), 1)
        self.assertIn("'crow2' is not defined", errors[0])
        self.assertIn("did you mean 'crow1'", errors[0])

    def test_unquoted_word(self):
        self.assertError('crow1 "drink" water.', 'quote it if it is a plain word: "water"')

    def test_defined_twice(self):
        self.assertError('fox1 is "dog".', "already defined")
        self.assertError('p1: crow1 "sing". p1: crow1 "sing".', "already defined")
        self.assertError('fox1: crow1 "sing".', "already defined")
        self.assertError('crow1 is "proud".', 'x was "..."')

    def test_timeless_is_about_an_identifier(self):
        self.assertError('fox1 is "proud", at start.', "'is' states something timeless")

    def test_labels(self):
        self.assertError('n1: crow1 did not "sing".', "no event or state of its own")
        self.assertError('r1: crow1 is really fox1.', "no event or state of its own")
        self.assertError('g1: a "fox" usually "eat" a "grape".', "no event or state of its own")
        self.assertError('i1: "let" fox1 "sing".', "no event or state of its own")
        self.assertError('q1: did crow1 "sing"?', "cannot name anything")
        self.assertError('did fox1 say {e1: crow1 "sing"}?', "cannot name anything")
        self.assertError('crow1 "sing", after {e1: fox1 "praise" crow1}.', "description cannot name")

    def test_event_slots(self):
        self.assertError('crow1 "sing", after fox1.', "needs an event")
        self.assertError('crow1 "sing", because a "wind".', "needs an event")
        self.assertError('meat1 happened.', "needs an event")

    def test_question_forms_need_a_question_mark(self):
        self.assertError('who "praise" crow1.', "only be used in a question")
        self.assertError('did crow1 "sing".', "end it with '?'")
        self.assertError('why did crow1 "sing".', "end it with '?'")
        self.assertError('what did crow1 "hold".', "end it with '?'")
        self.assertError('who "give" what "to" crow1?', "at most one thing")

    def test_commands_are_not_questions(self):
        self.assertError('"let" fox1 "sing"?', "cannot be a question")
        self.assertError('"ah"?', "cannot be a question")

    def test_content(self):
        self.assertError('fox1 want meat1.', "content is written in braces")
        self.assertError('fox1 "praise" crow1. fox1 was true.', "'true' is said of")
        self.assertError('p1: fox1 "praise" crow1. p1 was true.', "has no content")

    def test_really_kinds(self):
        self.assertError('p1: fox1 "praise" crow1. fox1 is really p1.', "entity with an event")

    def test_existence(self):
        self.assertError("there was fox1.", "takes an indefinite")

    def test_predicate_shape(self):
        self.assertError("crow1 meat1.", "starts with a quoted word")
        self.assertError("crow1.", "expected a predicate")
        self.assertError('crow1 "go" to fox1.', "expected '.' or '?'")
        self.assertError('fox1 say {did crow1 "sing"}.', "end it with '?'")  # a question inside content
        self.assertError('crow1 "sing", after {did fox1 "praise" crow1}.', "must stand on its own")

    def test_comma_cannot_join_clauses(self):
        self.assertError('crow1 "sing", fox1 "praise" crow1.', "start a new one")

    def test_adverb_goes_before_the_verb(self):
        self.assertError('a "fox" "eat" a "grape", always.', "goes before the verb")

    def test_lexical(self):
        self.assertError("fox1 “praise” crow1.", "unexpected character")
        self.assertError('fox1 "praise crow1.', "unterminated")
        self.assertError('fox1 "" crow1.', "empty quoted word")

    def test_braces(self):
        self.assertError('fox1 say {crow1 "sing".', "never closed", header=False)
        self.assertError('fox1 "sing"}.', "without a matching", header=False)

    def test_function_words_get_specific_hints(self):
        self.assertError('fox1 "praise" the crow1.', "write the thing's identifier")  # checker path
        self.assertError('fox1 would "stay".', "would: will")  # parser path: predicate start
        self.assertError('crow1 "sing", and fox1 "laugh".', "two clauses")  # parser path: after a comma
        self.assertError('fox1 "praise" him.', "a pronoun")
        self.assertError('fox1 "walk" of crow1.', "inside the quoted word")
        errors = errors_of('fox1 "see" the.')
        self.assertNotIn("did you mean", errors[0])

    def test_one_bad_item_does_not_hide_others(self):
        errors = errors_of('crow1 meat1. fox1 "praise" crow2. crow1 "sing", after fox1.')
        self.assertEqual(len(errors), 3)


class Warnings(unittest.TestCase):
    def warnings_of(self, src):
        return [d.message for d in diags_of(src) if d.severity == "warning"]

    def test_unused_entity(self):
        self.assertEqual(self.warnings_of('dog1 is "dog". fox1 "praise" crow1. crow1 "have" meat1.'),
                         ["'dog1' is defined but never used"])

    def test_packed_predicate(self):
        warnings = self.warnings_of('fox1 "fly off and settle on" crow1. crow1 "have" meat1.')
        self.assertEqual(warnings, ['the word "fly off and settle on" contains \'and\''])

    def test_definite_thing_in_a_quoted_word(self):
        self.assertEqual(self.warnings_of('fox1 "open" "the gate". crow1 "have" meat1.'),
                         ['"the gate" looks like a definite thing'])
        # The verb itself is not checked ("open her mouth"), nor indefinites.
        self.assertEqual(self.warnings_of('fox1 "open her mouth". crow1 "have" meat1. fox1 "eat" a "the".'), [])


if __name__ == "__main__":
    unittest.main()
