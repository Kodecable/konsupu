#!/usr/bin/env python3
"""Prototype parser and checker for the controlled English of run/cnl-proto.

  ./cnl.py FILE...          check each FILE, print the normalized program
  ./cnl.py --json FILE      print the AST as JSON instead
  ./cnl.py -                read from stdin

Only syntax and static rules are checked here (see README.md); nothing is
evaluated. Exit status is 1 when any error is reported. Messages are written
for a model to act on: each gives the position, what is wrong and how to fix it.
"""

import bisect
import difflib
import json
import re
import sys
from contextlib import contextmanager
from dataclasses import dataclass, field, fields, is_dataclass

ATTITUDES = {"say", "ask", "tell", "promise", "believe", "think", "know", "want", "hope", "fear", "plan"}
MODALS = {"can", "cannot", "may", "must"}
DO = {"do", "does", "did"}
BE = {"was", "is"}
AUXILIARIES = DO | BE | MODALS | {"will"}
ADVERBS = {"always", "usually", "never"}
TIME_MODS = {"before", "after", "during", "while", "when", "until", "since", "from"}
FLAG_MODS = {"earlier"}
ORDINALS = {
    "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5,
    "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10, "last": -1,
}
WH_TERMS = {"who", "what", "where", "which"}
KEYWORDS = (
    {"not", "no", "there", "true", "really", "happened", "a", "an", "why", "how", "many", "times"}
    | {"because", "in", "order", "to", "by", "at", "start", "end", "time", "among", "others"}
    | ATTITUDES | AUXILIARIES | ADVERBS | TIME_MODS | FLAG_MODS | set(ORDINALS) | WH_TERMS
)
# Clause connectives inside one quoted word suggest two actions packed into one predicate.
CONNECTIVES = {"and", "but", "then", "so", "because", "when", "while", "after", "before", "until", "if", "or"}
CURLY_QUOTES = "“”„‟«»‘’"
# A quoted word in an object slot starting with one of these is probably a definite thing that deserves an identifier.
DEFINITE = {"the", "this", "that", "these", "those", "his", "her", "its", "their", "my", "your", "our"}


def _hints(words, hint):
    return dict.fromkeys(words.split(), hint)


# English function words have no bare form in the CNL. Written bare they parse as undefined identifiers;
# these hints say what to write instead.
FUNCTION_WORDS = {
    **_hints("the this that these those", "write the thing's identifier (crow1), defined once with crow1 is \"crow\""),
    **_hints("he she it they him them me us we i", "a pronoun: reuse the identifier of the thing it refers to, "
             "or define one (he1 is \"he\") if the sentence does not name it"),
    **_hints("his its their my our", "a possessive: use the owner's identifier, or keep the phrase in one quoted word"),
    **_hints("her you your", "a pronoun or possessive: reuse the identifier of the person (define you1 is \"you\" "
             "if the sentence does not name them), or keep the phrase in one quoted word"),
    **_hints("and but then or so", "two clauses: end the statement with '.' and write the next one; "
             "'X, so Y' is Y, because {X}; two nouns go together in one quoted word"),
    "would": "would: will \"...\" inside speech, otherwise did / did not",
    "could": "could: can / cannot",
    "should": "should: must",
    "might": "might: may",
    **_hints("had has have", "had + past participle: the verb in quotes plus ', earlier'; the verb have: \"have\""),
    **_hints("are am were be been being", "states use was (story) or is (timeless, or now inside speech)"),
    **_hints("of with for on into onto up down off out over under about as than like",
             "a preposition inside a predicate goes inside the quoted word: \"walk up to\""),
}


# ---------------------------------------------------------------- diagnostics


@dataclass
class Diag:
    severity: str  # "error" or "warning"
    line: int
    col: int
    message: str
    hint: str = ""

    def format(self, name):
        text = f"{name}:{self.line}:{self.col}: {self.severity}: {self.message}"
        return text + (f"\n    fix: {self.hint}" if self.hint else "")


class ParseError(Exception):
    def __init__(self, tok, message, hint=""):
        super().__init__(message)
        self.tok, self.message, self.hint = tok, message, hint


# ---------------------------------------------------------------- lexer


@dataclass
class Tok:
    kind: str  # "kw", "id", "str", "p" (punctuation), "eof"
    text: str
    line: int
    col: int

    def is_kw(self, *words):
        return self.kind == "kw" and (not words or self.text in words)

    def is_p(self, *chars):
        return self.kind == "p" and self.text in chars

    def show(self):
        return "end of statement" if self.kind == "eof" else repr(self.text)


TOKEN_RE = re.compile(
    r"""(?P<ws>\s+)
      | (?P<comment>//[^\n]*)
      | (?P<str>"(?:[^"\\\n]|\\.)*")
      | (?P<badstr>"[^\n]*)
      | (?P<word>[A-Za-z_][A-Za-z0-9_]*)
      | (?P<p>[.,:?{}])""",
    re.X,
)


def lex(src, diags):
    starts = [0] + [m.end() for m in re.finditer("\n", src)]

    def where(offset):
        line = bisect.bisect_right(starts, offset)
        return line, offset - starts[line - 1] + 1

    toks, pos = [], 0
    while pos < len(src):
        m = TOKEN_RE.match(src, pos)
        line, col = where(pos)
        if not m:
            ch = src[pos]
            hint = 'use straight double quotes "..." for words' if ch in CURLY_QUOTES else (
                'put numbers and other text inside a quoted word, e.g. "3 grapes"')
            diags.append(Diag("error", line, col, f"unexpected character {ch!r}", hint))
            pos += 1
            continue
        kind, text = m.lastgroup, m.group()
        pos = m.end()
        if kind in ("ws", "comment"):
            continue
        if kind == "badstr":
            diags.append(Diag("error", line, col, "unterminated quoted word", 'close it with " on the same line'))
            continue
        if kind == "str":
            text = " ".join(re.sub(r"\\(.)", r"\1", text[1:-1]).split())
            if not text:
                diags.append(Diag("error", line, col, "empty quoted word", "write the word inside the quotes"))
                continue
        elif kind == "word":
            kind = "kw" if text in KEYWORDS else "id"
        toks.append(Tok(kind, text, line, col))
    return toks


# ---------------------------------------------------------------- AST


@dataclass
class Node:
    line: int
    col: int


@dataclass
class Ident(Node):
    name: str


@dataclass
class Word(Node):  # a quoted open-vocabulary word
    text: str


@dataclass
class Indef(Node):  # a "sheep": some sheep, scoped by the enclosing statement
    article: str
    text: str


@dataclass
class Wh(Node):  # who / what / where / which "x"
    word: str
    text: str = ""


@dataclass
class Gap(Node):  # the place a fronted question word asks about: what did crow1 "hold" _?
    pass


@dataclass
class Ref(Node):  # {sentence} used as a description of an event or proposition
    sentence: "Sentence"
    # Set by the checker: a {X} after a time, cause or means modifier of a statement states that X
    # happened, as an English subordinate clause does. Elsewhere (questions, things in a predicate) it only describes.
    asserted: bool = False


@dataclass
class Block(Node):  # {a. b. c} holding the content of an attitude or a purpose
    items: list


@dataclass
class Event(Node):
    subject: Node
    words: list
    negated: bool  # did not
    aux: str | None  # do / does / did / will as written; only "will" changes the meaning (future)
    adverb: str | None  # always / usually / never


@dataclass
class State(Node):
    subject: Node
    tense: str  # "was" or "is"
    negated: bool
    adverb: str | None
    words: list


@dataclass
class Attitude(Node):
    subject: Node
    negated: bool
    aux: str | None  # do / does / did, as written
    verb: str
    addressee: Node | None
    content: Node  # Block; Wh "what" or Gap in a question


@dataclass
class Modal(Node):
    subject: Node
    modal: str  # can / may / must; "cannot" is can + negated
    negated: bool
    words: list


@dataclass
class Really(Node):  # x is really y
    left: Node
    tense: str
    right: Node


@dataclass
class Truth(Node):  # c3 was true
    term: Node
    tense: str
    negated: bool


@dataclass
class Exist(Node):  # there was a "wolf" / there was no "wolf"
    tense: str
    negated: bool
    term: Node


@dataclass
class Happened(Node):
    subject: Node


@dataclass
class Imperative(Node):  # "let" fox1 "hear one song" / do not "trust" a "flatterer"
    negated: bool
    do: bool  # written with do: required for a one-word command, which would otherwise be an exclamation
    words: list


@dataclass
class Expressive(Node):  # a lone word: "ah", "good-day"
    text: str


@dataclass
class WhLead(Node):  # why / how / when / how many times, in front of a clause
    word: str
    clause: Node
    inverted: bool


@dataclass
class WhFront(Node):  # what did crow1 believe: the question word fills the Gap in the clause
    wh: Wh
    clause: Node


@dataclass
class Modifier(Node):
    kind: str  # a time keyword, "at", "because", "by", "in order to", "ordinal", "earlier", "among others"
    arg: Node | str | int | None = None


@dataclass
class Sentence(Node):
    clause: Node
    modifiers: list
    inverted: bool  # did fox1 ...? / was crow1 ...?


@dataclass
class Definition(Node):
    name: str
    text: str


@dataclass
class Statement(Node):
    label: str | None
    sentence: Sentence
    id: str = ""  # the label, or an implicit id assigned by the checker


@dataclass
class Question(Node):
    sentence: Sentence


@dataclass
class Program:
    items: list = field(default_factory=list)


# ---------------------------------------------------------------- parser


def split_items(toks, diags):
    """Split the token stream at top-level terminators so one bad item cannot spoil the rest."""
    items, cur, opens = [], [], []
    bad = False
    for t in toks:
        cur.append(t)
        if t.is_p("{"):
            opens.append(t)
        elif t.is_p("}"):
            if opens:
                opens.pop()
            else:
                diags.append(Diag("error", t.line, t.col, "'}' without a matching '{'", "remove it or add the '{'"))
                bad = True
        elif not opens and t.is_p(".", "?"):
            items.append((cur, bad))
            cur, bad = [], False
    if opens:
        t = opens[0]
        diags.append(Diag("error", t.line, t.col, "'{' is never closed", "add the matching '}'"))
        items.append((cur, True))
    elif cur:
        items.append((cur, bad))
    return items


class Parser:
    def __init__(self, toks):
        last = toks[-1]
        self.toks = toks + [Tok("eof", "", last.line, last.col + len(last.text))]
        self.i = 0

    def peek(self, k=0):
        return self.toks[min(self.i + k, len(self.toks) - 1)]

    def next(self):
        t = self.peek()
        self.i += 1
        return t

    def accept_kw(self, *words):
        if self.peek().is_kw(*words):
            return self.next()
        return None

    def expect_kw(self, word, hint=""):
        t = self.next()
        if not t.is_kw(word):
            raise ParseError(t, f"expected '{word}', found {t.show()}", hint)
        return t

    def expect_p(self, ch, hint=""):
        t = self.next()
        if not t.is_p(ch):
            raise ParseError(t, f"expected '{ch}', found {t.show()}", hint)
        return t

    def at_end(self, k=0):
        t = self.peek(k)
        return t.kind == "eof" or t.is_p(",", ".", "?", "}")

    def end_hint(self):
        t = self.peek()
        if t.kind == "kw":
            return f"'{t.text}' is a keyword; inside a predicate write it as a quoted word: \"{t.text}\""
        return "end the statement with '.' (or '?' for a question); add information with ', <modifier>' or a new statement"

    # items

    def item(self):
        t = self.peek()
        if t.kind == "id" and self.peek(1).is_kw("is") and self.peek(2).kind == "str" and self.peek(3).is_p("."):
            self.i += 4
            node = Definition(t.line, t.col, t.text, self.toks[self.i - 2].text)
        else:
            node = self.entry(in_block=False)
        if self.peek().kind != "eof":
            raise ParseError(self.peek(), f"unexpected {self.peek().show()} after the end of the statement")
        return node

    def entry(self, in_block):
        """A statement or question; the terminator decides which. In a block the last '.' may be left out."""
        t = self.peek()
        label = None
        if t.kind == "id" and self.peek(1).is_p(":"):
            label = t.text
            self.i += 2
        sentence = self.sentence(entry=True)
        end = self.peek()
        if end.is_p("?"):
            self.next()
            if label:
                raise ParseError(t, "a question cannot name anything", f"remove the label '{label}:'")
            return Question(t.line, t.col, sentence)
        if end.is_p("."):
            self.next()
        elif not (in_block and end.is_p("}")):
            raise ParseError(end, f"expected '.' or '?', found {end.show()}", self.end_hint())
        return Statement(t.line, t.col, label, sentence)

    def block(self):
        open_ = self.expect_p("{", "content is written in braces: {...}")
        items = []
        while not self.peek().is_p("}"):
            if self.peek().kind == "eof":
                raise ParseError(self.peek(), "content is not closed", "add '}'")
            items.append(self.entry(in_block=True))
        self.next()
        return Block(open_.line, open_.col, items)

    # sentences and clauses

    def sentence(self, entry=False):
        t = self.peek()
        clause, inverted = self.entry_clause() if entry else (self.clause(), False)
        mods = []
        while self.peek().is_p(","):
            self.next()
            mods.append(self.modifier())
        return Sentence(t.line, t.col, clause, mods, inverted)

    def entry_clause(self):
        """Forms that only start a statement or question: questions, commands, exclamations."""
        t = self.peek()
        if t.is_kw("why", "when", "how"):
            self.next()
            word = t.text
            if t.text == "how" and self.accept_kw("many"):
                self.expect_kw("times", "write 'how many times'")
                word = "how many times"
            inverted = self.peek().kind == "kw" and self.peek().text in AUXILIARIES
            clause = self.inverted(gap=False) if inverted else self.clause()
            return WhLead(t.line, t.col, word, clause, inverted), False
        if t.kind == "str" or (t.is_kw("do") and self.word_after_not(1)):
            return self.imperative(), False
        if t.kind == "kw" and t.text in AUXILIARIES:
            return self.inverted(gap=False), True
        if t.kind == "kw" and t.text in WH_TERMS and self.fronted():
            wh = self.term()
            return WhFront(t.line, t.col, wh, self.inverted(gap=True)), False
        return self.clause(), False

    def word_after_not(self, k):
        if self.peek(k).is_kw("not"):
            k += 1
        return self.peek(k).kind == "str"

    def fronted(self):
        """who/what ... followed by an inverted clause (what did crow1 "hold"), not a subject (who "sing")."""
        k = 2 if self.peek().is_kw("which") else 1
        aux = self.peek(k)
        if not (aux.kind == "kw" and aux.text in AUXILIARIES):
            return False
        k += 1
        if self.peek(k).is_kw("not"):
            k += 1
        return self.term_start(self.peek(k))

    def imperative(self):
        t = self.peek()
        do = bool(self.accept_kw("do"))
        negated = do and bool(self.accept_kw("not"))
        if not do and (self.peek(1).kind == "eof" or self.peek(1).is_p(".", "?", "}")):
            self.next()
            return Expressive(t.line, t.col, t.text)
        return Imperative(t.line, t.col, negated, do, self.words())

    def inverted(self, gap):
        """The clause after a fronted auxiliary: did fox1 ..., was crow1 ..., can fox1 ..., was there ..."""
        aux = self.next()
        if not (aux.kind == "kw" and aux.text in AUXILIARIES):
            raise ParseError(aux, f"expected did, was, is, can, will ..., found {aux.show()}")
        if aux.text in BE and self.accept_kw("there"):
            negated = bool(self.accept_kw("no"))
            return Exist(aux.line, aux.col, aux.text, negated, self.indefinite(negated))
        negated = bool(self.accept_kw("not")) or aux.text == "cannot"
        if not self.term_start(self.peek()):
            raise ParseError(self.peek(), f"expected the subject after '{aux.text}', found {self.peek().show()}")
        subject = self.term()
        v = self.peek()
        if aux.text in DO:
            if v.kind == "kw" and v.text in ATTITUDES:
                return self.attitude(subject, negated, aux.text, gap)
            return Event(aux.line, aux.col, subject, self.words(gap), negated, aux.text, None)
        if aux.text == "will":
            return Event(aux.line, aux.col, subject, self.words(gap), negated, "will", None)
        if aux.text in BE:
            if self.accept_kw("true"):
                return Truth(aux.line, aux.col, subject, aux.text, negated)
            if self.accept_kw("really"):
                right = Gap(self.peek().line, self.peek().col) if gap and self.at_end() else self.term()
                return Really(aux.line, aux.col, subject, aux.text, right)
            adverb = self.adverb()
            return State(aux.line, aux.col, subject, aux.text, negated, adverb, self.words(gap))
        modal = "can" if aux.text == "cannot" else aux.text
        return Modal(aux.line, aux.col, subject, modal, negated, self.words(gap))

    def clause(self):
        t = self.peek()
        if t.is_kw("there"):
            self.next()
            tense = self.next()
            if not tense.is_kw("was", "is"):
                raise ParseError(tense, f"expected 'was' after 'there', found {tense.show()}")
            negated = bool(self.accept_kw("no"))
            return Exist(t.line, t.col, tense.text, negated, self.indefinite(negated))
        if not self.term_start(t):
            hint = "start with an identifier, an indefinite (a \"...\"), {...} or a question word"
            if t.kind == "kw" and t.text in AUXILIARIES | {"why", "how"}:
                hint = "a question or command must stand on its own, not inside {...} or after a modifier"
            raise ParseError(t, f"expected a subject, found {t.show()}", hint)
        subject = self.term()
        v = self.peek()
        if v.is_kw(*DO):
            self.next()
            negated = bool(self.accept_kw("not"))
            if self.peek().kind == "kw" and self.peek().text in ATTITUDES:
                return self.attitude(subject, negated, v.text, gap=False)
            return Event(t.line, t.col, subject, self.words(), negated, v.text, None)
        if v.is_kw(*BE):
            self.next()
            negated = bool(self.accept_kw("not"))
            if self.accept_kw("true"):
                return Truth(t.line, t.col, subject, v.text, negated)
            if self.accept_kw("really"):
                return Really(t.line, t.col, subject, v.text, self.term())
            adverb = self.adverb()
            return State(t.line, t.col, subject, v.text, negated, adverb, self.words())
        if v.is_kw("will"):
            self.next()
            negated = bool(self.accept_kw("not"))
            return Event(t.line, t.col, subject, self.words(), negated, "will", None)
        if v.is_kw(*MODALS):
            self.next()
            negated = bool(self.accept_kw("not")) or v.text == "cannot"
            modal = "can" if v.text == "cannot" else v.text
            return Modal(t.line, t.col, subject, modal, negated, self.words())
        if v.is_kw(*ADVERBS):
            self.next()
            return Event(t.line, t.col, subject, self.words(), False, None, v.text)
        if v.kind == "kw" and v.text in ATTITUDES:
            return self.attitude(subject, False, None, gap=False)
        if v.is_kw("happened"):
            self.next()
            return Happened(t.line, t.col, subject)
        return Event(t.line, t.col, subject, self.words(), False, None, None)

    def adverb(self):
        t = self.accept_kw(*ADVERBS)
        return t.text if t else None

    def attitude(self, subject, negated, aux, gap):
        v = self.next()
        addressee = None
        if self.peek().kind == "id" or self.peek().is_kw("who"):
            addressee = self.term()
        if gap and self.at_end():
            content = Gap(self.peek().line, self.peek().col)
        elif self.peek().is_kw("what"):
            t = self.next()
            content = Wh(t.line, t.col, "what")
        else:
            content = self.block()
        return Attitude(subject.line, subject.col, subject, negated, aux, v.text, addressee, content)

    def indefinite(self, negated):
        if negated:
            w = self.next()
            if w.kind != "str":
                raise ParseError(w, f"expected a quoted word after 'no', found {w.show()}", 'there was no "wolf"')
            return Indef(w.line, w.col, "a", w.text)
        return self.term()

    def words(self, gap=False):
        items = []
        while True:
            t = self.peek()
            if t.kind == "str":
                self.next()
                items.append(Word(t.line, t.col, t.text))
            elif self.term_start(t):
                items.append(self.term())
            else:
                break
        if not items:
            raise ParseError(self.peek(), f"expected a predicate, found {self.peek().show()}",
                             'write the verb as a quoted word: subject "verb" object')
        if not isinstance(items[0], Word):
            first = items[0]
            hint = 'put the verb right after the subject: subject "verb" object'
            if isinstance(first, Ident) and first.name.lower() in FUNCTION_WORDS:
                hint = f"'{first.name}' is not a word of the language; {FUNCTION_WORDS[first.name.lower()]}"
            raise ParseError(Tok("", "", first.line, first.col), "a predicate starts with a quoted word", hint)
        if gap:
            items.append(Gap(self.peek().line, self.peek().col))
        return items

    @staticmethod
    def term_start(t):
        return t.kind == "id" or t.is_p("{") or t.is_kw("a", "an") or (t.kind == "kw" and t.text in WH_TERMS)

    def term(self):
        t = self.next()
        if t.kind == "id":
            return Ident(t.line, t.col, t.text)
        if t.is_kw("a", "an"):
            w = self.next()
            if w.kind != "str":
                raise ParseError(w, f"expected a quoted word after '{t.text}', found {w.show()}", f'{t.text} "sheep"')
            return Indef(t.line, t.col, t.text, w.text)
        if t.is_kw("which"):
            w = self.next()
            if w.kind != "str":
                raise ParseError(w, f"expected a quoted word after 'which', found {w.show()}", 'which "bird"')
            return Wh(t.line, t.col, "which", w.text)
        if t.kind == "kw" and t.text in WH_TERMS:
            return Wh(t.line, t.col, t.text)
        if t.is_p("{"):
            if self.peek().kind == "id" and self.peek(1).is_p(":"):
                raise ParseError(self.peek(), "a description cannot name anything",
                                 "remove the label, or name the event in its own statement")
            sentence = self.sentence()
            self.expect_p("}", "a description holds one sentence; close it with '}'")
            return Ref(t.line, t.col, sentence)
        raise ParseError(t, f"expected an identifier, a word or a description, found {t.show()}",
                         'open-vocabulary words must be quoted: "word"')

    def modifier(self):
        t = self.next()
        if t.kind == "kw" and t.text in TIME_MODS | {"because", "by"}:
            return Modifier(t.line, t.col, t.text, self.term())
        if t.is_kw("at"):
            w = self.next()
            if not w.is_kw("start", "end"):
                raise ParseError(w, f"expected 'start' or 'end' after 'at', found {w.show()}")
            return Modifier(t.line, t.col, "at", w.text)
        if t.is_kw("in"):
            self.expect_kw("order", "write 'in order to {...}'")
            self.expect_kw("to", "write 'in order to {...}'")
            return Modifier(t.line, t.col, "in order to", self.block())
        if t.kind == "kw" and t.text in ORDINALS:
            self.expect_kw("time", f"write ', {t.text} time'")
            return Modifier(t.line, t.col, "ordinal", ORDINALS[t.text])
        if t.kind == "kw" and t.text in FLAG_MODS:
            return Modifier(t.line, t.col, t.text)
        if t.is_kw("among"):
            self.expect_kw("others", "write 'among others'")
            return Modifier(t.line, t.col, "among others")
        known = ", ".join(sorted(TIME_MODS | FLAG_MODS | {"because", "by", "at start", "at end", "in order to"}))
        hint = (f"modifiers are: {known}, '<ordinal> time', 'among others'. "
                "Two clauses cannot be joined with ','; end the statement with '.' and start a new one")
        if t.is_kw(*ADVERBS):
            hint = f"'{t.text}' goes before the verb: a \"fox\" {t.text} \"eat\" a \"grape\""
        elif t.kind == "id" and t.text.lower() in FUNCTION_WORDS:
            hint = f"'{t.text}' is not a word of the language; {FUNCTION_WORDS[t.text.lower()]}"
        raise ParseError(t, f"expected a modifier after ',', found {t.show()}", hint)


def parse(src, diags):
    program = Program()
    for toks, bad in split_items(lex(src, diags), diags):
        if bad:
            continue
        try:
            program.items.append(Parser(toks).item())
        except ParseError as e:
            diags.append(Diag("error", e.tok.line, e.tok.col, e.message, e.hint))
    return program


# ---------------------------------------------------------------- checker


def children(node):
    if isinstance(node, list):
        for x in node:
            yield from children(x)
    elif is_dataclass(node):
        yield node


def sub_nodes(node):
    for f in fields(node):
        yield from children(getattr(node, f.name))


def eventuality(clause, top):
    """Why a statement of this clause asserts no event or state of its own, or None when it does."""
    match clause:
        case Event(negated=True):
            return "a negated event"
        case Event(adverb=a) if a:
            return f"a general statement ('{a}')"
        case State(tense="is") if top:
            return "a timeless statement ('is')"
        case State(adverb=a) if a:
            return f"a general statement ('{a}')"
        case Attitude(negated=True):
            return "a negated statement"
        case Really() | Truth() | Exist() | Happened() | Imperative() | Expressive():
            return {Really: "'really'", Truth: "'true'", Exist: "'there was'", Happened: "'happened'",
                    Imperative: "a command", Expressive: "an exclamation"}[type(clause)]
    return None


def presupposes(clause, top):
    """Whether {X} after a modifier of this statement states that X happened. English presupposes the
    subordinate clause of a report ("he hid when he saw it"), negated or not, but not of a command, a future,
    a modal or a general statement ("wait until I come", "a fox runs when it sees a dog")."""
    match clause:
        case Imperative() | Modal() | Event(aux="will") | Event(adverb=str()) | State(adverb=str()):
            return False
        case State(tense="is") if top:
            return False
    return True


class Checker:
    """Static rules: one definition per identifier, no undefined names, slot kinds, labels, question forms."""

    def __init__(self, diags):
        self.diags = diags
        self.defs = {}  # name -> Definition or Statement
        self.used = set()
        self.implicit = 0
        self.asserting = False  # inside a statement (not a question, not a thing in a predicate)

    def error(self, node, message, hint=""):
        self.diags.append(Diag("error", node.line, node.col, message, hint))

    @contextmanager
    def mode(self, asserting):
        saved, self.asserting = self.asserting, asserting
        try:
            yield
        finally:
            self.asserting = saved

    def warn(self, node, message, hint=""):
        self.diags.append(Diag("warning", node.line, node.col, message, hint))

    def check(self, program):
        for item in program.items:
            self.collect(item, top=True)
        for item in program.items:
            if isinstance(item, Statement):
                self.statement(item, in_question=False, top=True)
            elif isinstance(item, Question):
                self.question(item)
        for name, d in self.defs.items():
            if isinstance(d, Definition) and name not in self.used:
                self.warn(d, f"'{name}' is defined but never used")

    def collect(self, node, top):
        name = node.name if isinstance(node, Definition) else node.label if isinstance(node, Statement) else None
        if name:
            if name in self.defs:
                self.error(node, f"'{name}' is already defined at line {self.defs[name].line}",
                           "every identifier is defined exactly once: by 'x is \"...\"' or as a statement label; "
                           "a state at some time is written x was \"...\"")
            else:
                self.defs[name] = node
        if isinstance(node, Statement):
            if node.label:
                node.id = node.label
            elif eventuality(node.sentence.clause, top) is None:
                self.implicit += 1
                node.id = f"_{self.implicit}"
        if isinstance(node, Question):
            return  # labels in questions are rejected; nothing to collect
        if is_dataclass(node):
            for c in sub_nodes(node):
                self.collect(c, top=False)

    def kind_of(self, ident):
        d = self.defs.get(ident.name)
        if d is None:
            return None
        return "entity" if isinstance(d, Definition) else "event"

    def ident(self, ident):
        self.used.add(ident.name)
        if ident.name in self.defs:
            return
        if ident.name.lower() in FUNCTION_WORDS:
            self.error(ident, f"'{ident.name}' is not a word of the language", FUNCTION_WORDS[ident.name.lower()])
            return
        close = difflib.get_close_matches(ident.name, list(self.defs), n=1)
        hint = f"did you mean '{close[0]}'? " if close else ""
        hint += f"define it with {ident.name} is \"...\", or quote it if it is a plain word: \"{ident.name}\""
        self.error(ident, f"'{ident.name}' is not defined", hint)

    # walking

    def statement(self, st, in_question, top):
        s = st.sentence
        if s.inverted or isinstance(s.clause, WhLead | WhFront):
            self.error(st, "this is a question; end it with '?'")
        why = eventuality(s.clause, top)
        if st.label and why:
            self.error(st, f"{why} has no event or state of its own to name", f"remove the label '{st.label}:'")
        if in_question and st.label:
            self.error(st, "a question cannot name anything", f"remove the label '{st.label}:'")
        if top and isinstance(s.clause, State) and s.clause.tense == "is" and isinstance(s.clause.subject, Ident):
            name = s.clause.subject.name
            self.error(s.clause, f"in the story, 'is' states something timeless about '{name}'",
                       f"put what {name} always is into its definition ({name} is \"...\"), "
                       f"or write a state at some time with was: {name} was \"...\"")
        with self.mode(not in_question and presupposes(s.clause, top)):
            self.sentence(s, in_question)

    def question(self, q):
        whs = list(self.wh_nodes(q.sentence))
        if len(whs) > 1:
            self.error(whs[1], "a question asks for at most one thing",
                       "split it into several questions, each with one question word")
        if isinstance(q.sentence.clause, Imperative | Expressive):
            self.error(q, "a command or exclamation cannot be a question", "end it with '.'")
        with self.mode(False):
            self.sentence(q.sentence, in_question=True)

    def wh_nodes(self, node):
        if isinstance(node, Wh | WhLead):
            yield node
        if isinstance(node, Question) or not is_dataclass(node):
            return
        for c in sub_nodes(node):
            if not isinstance(c, Question):
                yield from self.wh_nodes(c)

    def sentence(self, s, in_question):
        self.clause(s.clause, in_question)
        for m in s.modifiers:
            if m.kind in TIME_MODS or m.kind in ("because", "by"):
                self.event_ref(m.arg, f"'{m.kind}'", in_question)
            elif m.kind == "in order to":
                self.block(m.arg, in_question)

    def clause(self, c, in_question):
        match c:
            case WhLead() | WhFront():
                self.clause(c.clause, in_question)  # outside a question, statement() reports it
            case Event() | State() | Modal() | Imperative():
                for t in ([] if isinstance(c, Imperative) else [c.subject]) + c.words:
                    self.term(t, in_question)
                self.word_checks(c.words)
            case Attitude():
                self.term(c.subject, in_question)
                if c.addressee:
                    self.term(c.addressee, in_question)
                if isinstance(c.content, Block):
                    self.block(c.content, in_question)
                else:
                    self.term(c.content, in_question)
            case Really():
                kinds = []
                for t in (c.left, c.right):
                    self.term(t, in_question)
                    kinds.append(self.kind_of(t) if isinstance(t, Ident) else None)
                if None not in kinds and kinds[0] != kinds[1]:
                    self.error(c, "'really' joins an entity with an event",
                               "both sides of 'really' must be things, or both events")
            case Happened():
                if isinstance(c.subject, Ident | Ref | Wh):
                    self.event_ref(c.subject, "'happened'", in_question)
                else:
                    self.term(c.subject, in_question)
            case Exist():
                if not isinstance(c.term, Indef | Wh):
                    self.error(c.term, "'there was' takes an indefinite: there was a \"wolf\"",
                               "for a known thing, state what it did or was instead")
                self.term(c.term, in_question)
            case Truth():
                self.term(c.term, in_question)
                if isinstance(c.term, Ident) and self.kind_of(c.term) == "event":
                    target = self.defs[c.term.name].sentence.clause
                    if not isinstance(target, Attitude) or not isinstance(target.content, Block):
                        self.error(c.term, f"'true' needs something said or believed; '{c.term.name}' has no content",
                                   "label the statement whose content is judged, e.g. c3: boy1 say {...}")
                elif isinstance(c.term, Ident | Indef):
                    self.error(c.term, "'true' is said of a labeled statement with content, or of a {description}")

    def term(self, t, in_question):
        match t:
            case Ident():
                self.ident(t)
            case Wh() | Gap():
                if not in_question:
                    self.error(t, "a question word can only be used in a question", "end it with '?', or name the thing")
            case Ref():
                with self.mode(False):  # a thing in a predicate is only described
                    self.sentence(t.sentence, in_question)
            case Block():
                self.block(t, in_question)

    def block(self, b, in_question):
        for item in b.items:
            if isinstance(item, Question):
                self.question(item)
            else:
                self.statement(item, in_question, top=False)

    def event_ref(self, t, owner, in_question):
        """Slots that take an event: time and cause modifiers, 'by', 'happened'."""
        if isinstance(t, Ident):
            self.ident(t)
            if self.kind_of(t) == "entity":
                self.error(t, f"{owner} needs an event, but '{t.name}' is a thing",
                           "use the label of a statement (e.g. f1: ...), or a {description} of the event")
        elif isinstance(t, Wh) and t.word == "what":
            self.term(t, in_question)
        elif isinstance(t, Ref):
            t.asserted = self.asserting
            self.sentence(t.sentence, in_question)
        else:
            self.error(t, f"{owner} needs an event", "use the label of a statement, or a {description} of the event")

    def word_checks(self, words):
        """Warnings on quoted words: two actions packed into one, or a definite thing left without an identifier."""
        for i, w in enumerate(words):
            if not isinstance(w, Word):
                continue
            tokens = w.text.lower().split()
            if hit := CONNECTIVES & set(tokens):
                self.warn(w, f"the word \"{w.text}\" contains '{sorted(hit)[0]}'",
                          "if it joins two actions or clauses, write two statements, or use a {description}; "
                          "ignore this if it only joins two nouns")
            if i > 0 and tokens[0] in DEFINITE:
                self.warn(w, f"\"{w.text}\" looks like a definite thing",
                          "give it an identifier (define it once, e.g. mouth1 is \"mouth\") so other mentions can "
                          "reuse it; ignore this if it is not a thing")


def check(src):
    diags = []
    program = parse(src, diags)
    Checker(diags).check(program)
    diags.sort(key=lambda d: (d.line, d.col))
    return program, diags


# ---------------------------------------------------------------- output


def q(text):
    return json.dumps(text, ensure_ascii=False)


def join(*parts):
    return " ".join(p for p in parts if p)


def fmt_words(words):
    return join(*(fmt(w) for w in words))


def fmt_inverted(c):
    """A clause in question order: did fox1 "praise" crow1 / was crow1 "holding" meat1."""
    neg = "not" if getattr(c, "negated", False) else ""
    match c:
        case Event():
            return join(c.aux or "did", neg, fmt(c.subject), c.adverb, fmt_words(c.words))
        case Attitude():
            return join(c.aux or "did", neg, fmt(c.subject), c.verb, c.addressee and fmt(c.addressee), fmt(c.content))
        case State():
            return join(c.tense, neg, fmt(c.subject), c.adverb, fmt_words(c.words))
        case Modal():
            aux = "cannot" if c.modal == "can" and c.negated else join(c.modal, neg)
            return join(aux, fmt(c.subject), fmt_words(c.words))
        case Truth():
            return join(c.tense, neg, fmt(c.term), "true")
        case Really():
            return join(c.tense, fmt(c.left), "really", fmt(c.right))
        case Exist():
            return join(c.tense, "there", f"no {q(c.term.text)}" if c.negated else fmt(c.term))
    return fmt(c)


def fmt(n):
    match n:
        case Ident():
            return n.name
        case Word():
            return q(n.text)
        case Indef():
            return f"{n.article} {q(n.text)}"
        case Wh():
            return f"which {q(n.text)}" if n.word == "which" else n.word
        case Gap():
            return ""
        case Ref():
            return "{" + fmt(n.sentence) + "}"
        case Block():
            return "{" + " ".join(fmt(i) for i in n.items).removesuffix(".") + "}"
        case Event():
            return join(fmt(n.subject), n.aux, "not" if n.negated else "", n.adverb, fmt_words(n.words))
        case State():
            return join(fmt(n.subject), n.tense, "not" if n.negated else "", n.adverb, fmt_words(n.words))
        case Attitude():
            return join(fmt(n.subject), n.aux, "not" if n.negated else "", n.verb,
                        n.addressee and fmt(n.addressee), fmt(n.content))
        case Modal():
            aux = "cannot" if n.modal == "can" and n.negated else join(n.modal, "not" if n.negated else "")
            return join(fmt(n.subject), aux, fmt_words(n.words))
        case Really():
            return join(fmt(n.left), n.tense, "really", fmt(n.right))
        case Truth():
            return join(fmt(n.term), n.tense, "not" if n.negated else "", "true")
        case Exist():
            return join("there", n.tense, f"no {q(n.term.text)}" if n.negated else fmt(n.term))
        case Happened():
            return f"{fmt(n.subject)} happened"
        case Imperative():
            return join("do" if n.do else "", "not" if n.negated else "", fmt_words(n.words))
        case Expressive():
            return q(n.text)
        case WhLead():
            return join(n.word, fmt_inverted(n.clause) if n.inverted else fmt(n.clause))
        case WhFront():
            return join(fmt(n.wh), fmt_inverted(n.clause))
        case Modifier():
            if n.kind == "ordinal":
                return next(k for k, v in ORDINALS.items() if v == n.arg) + " time"
            if n.kind == "at":
                return f"at {n.arg}"
            return n.kind + (f" {fmt(n.arg)}" if n.arg is not None else "")
        case Sentence():
            head = fmt_inverted(n.clause) if n.inverted else fmt(n.clause)
            return ", ".join([head, *(fmt(m) for m in n.modifiers)])
        case Definition():
            return f"{n.name} is {q(n.text)}."
        case Statement():
            return (f"{n.label}: " if n.label else "") + fmt(n.sentence) + "."
        case Question():
            return fmt(n.sentence) + "?"
    raise TypeError(type(n))


def to_json(n):
    if isinstance(n, list):
        return [to_json(x) for x in n]
    if is_dataclass(n):
        out = {"type": type(n).__name__}
        for f in fields(n):
            if f.name not in ("line", "col"):
                out[f.name] = to_json(getattr(n, f.name))
        if isinstance(n, Node):
            out["at"] = f"{n.line}:{n.col}"
        return out
    return n


def main(argv):
    as_json = "--json" in argv
    paths = [a for a in argv if a != "--json"] or ["-"]
    failed = False
    for path in paths:
        name = "<stdin>" if path == "-" else path
        src = sys.stdin.read() if path == "-" else open(path, encoding="utf-8").read()
        program, diags = check(src)
        for d in diags:
            print(d.format(name), file=sys.stderr)
        failed |= any(d.severity == "error" for d in diags)
        if as_json:
            print(json.dumps(to_json(program.items), ensure_ascii=False, indent=1))
        else:
            for item in program.items:
                print(fmt(item))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
