# Konsupu Aesop Phase 1r3 — Foundation 使用体验观察

本轮第一次让正常回答路径真正依赖 `KonsupuIdentity.Ref()`、Imperative
discovery、`IsKonsupuImperativeApplicable`、`ResolveImperatives`、
Imperative Perspective 与 `Output[]`/`TextOutput`。以下观察按指导 §十分类：

- **A** — 领域代码自己的设计问题
- **B** — Foundation API ergonomics
- **C** — Foundation semantic limitation / correctness issue

结论先行：**未发现 C 类问题，本轮无 Foundation change candidate**；Foundation
零修改。

## KonsupuIdentity

1. `KonsupuIdentity.Ref()` 作为 addressee 很自然（无摩擦）。一次调用、无
   boilerplate；ref 代理通过 `getPrototypeOf` 陷阱使 Foundation 的
   `addressee instanceof KonsupuIdentity` 筛选透明成立，领域代码无需理解
   代理机制。
2. **领域代码中不需要任何 addressee 判断**。Foundation 先筛 KonsupuIdentity
   再调 applicability 的分工，使 `SayApplicable` 只剩一行领域判断
   （`content instanceof Says`）。没有出现"必须绕过 global identity 才能
   表达当前 Konsupu"的情况。
3. cross-context/global BRAND 语义无意外摩擦。回归中用一个自有 BRAND 的
   第二个 GlobalNode 身份（`SomeoneElse`）作 addressee：构造零成本、
   `RefProblem` 对任意 global 引用直接放行、ImperativeLoop 正确将其排除
   （`imperatives: a foreign addressee never reaches this Konsupu`）。
   这同时说明 global 身份机制天然支持多受话者，不是 Konsupu 特例。
   （B，轻微）global 是 per-class 单例，域上读不出"是哪一个 Konsupu"的
   实例信息——本 Demo 无此需求，仅记录。

## Imperative

1. `Imperative(situated, addressee, content)` 适合"让 Konsupu 执行一个
   已有 Action Node"。content 放 `Says` Node 自然：`ReportReferences`
   沿 addressee/content 走引用，Says 再报告其 content（answer Variable），
   mention 索引随之建立，无额外接线。
2. `IsKonsupuImperativeApplicable` 与 `ResolveImperatives` 的职责边界清楚：
   前者答"这个请求我接不接"（纯领域判断，返回 boolean），后者答"接了的
   怎么完成"（读取、投影、产出 Output、交回 resolved 子集）。两者签名
   都拿到完整 `state`，但本轮 Resolve 侧完全不需要重查任何 Query。
3. Imperative Perspective 读取 Query 已 resolved 的 Variable 顺手：
   `view.RequireValue(says.content, reason)` 一行读到值；reason 路径把
   "Query 未完成就读 content"变成带领域说明的 InputStructureError，
   语义清晰且不触发任何重解。`Value`/`Readable`/`RequireValue` 三档
   够用。
4. （B）`resolveImperatives(input, imperatives, remaining, state)` 的批量
   协议（全量 + 本轮待办 + 返回 resolved 子集 + 外层 while 收敛）在只有
   一个 Says 时是四行仪式；多个互相独立的祈使时也必须自行决定批次。
   该协议换来了"部分完成、依赖排序"的表达力（本轮未用到），是合理的
   通用形状，但对简单场景略重。不建议改语义；若未来出现常见简单用法，
   一个 per-imperative 的便捷包装即可（领域侧可自建，无需 Foundation 动）。
5. `Output[]` 与 Imperative 无一一对应：本轮无摩擦。每条 TextOutput
   自含全部信息，无序合同与"机械投影一个值"的输出形态互相匹配。仅记录
   一个潜在边界：若未来输出需要与祈使关联（谁被要求说什么），Output 上
   没有 marker——Phase 1 不需要，未构成问题。

## 本轮最重要的观察（A，附带 B 色彩）

**回复 Says 会 mention answer Variable，从而进入 Query 的邻接视野。**
指导要求的形态（`Says(content = answer)` 与 Query 同 Situation）使
"请求执行的回复"与"询问世界的 question"在 mention 结构上不可区分——
r2 的 solver 会把回复 Says 当作"哪个已发生的 Says 有此 content"的问题
去解释，join 后矛盾或答错（变异实测：禁用排除后 1/15）。

判断与处理：

- 这不是 Foundation 缺陷：`Bindings` 如实回答"谁直接提到了这个
  reference"，这正是它该做的；邻接不定义含义。
- 也不是可由 Foundation 修复而不引入语义越权的问题：把"Imperative
  content 的 mention 视为某种特殊角色"若做进 Foundation，就等于让结构层
  替领域预判了请求语用。
- 因此本轮以**领域语义规则**处理：`QuerySolver` 排除"作为某 Imperative
  content 的 Node"（requested content 是回复形式，永不参与 question
  解释），并有专门回归 + 变异验证锁定。

值得留给后续轮次的真问题：当故事世界里也存在"被请求/被命令执行"的
cognition（而不只是 Konsupu 回复）时，这条排除规则的表述应从"回复 Says"
上升为"请求类关系的 content 不构成其所 mention 变量的 question 语义"，
届时的证据会告诉我们它是 Aesop 领域规则还是应当沉淀为更通用的领域
模式（仍不必进 Foundation）。

## 其余

- `TextOutput` 要求 string：`Project` 恒返回 string，天然匹配
  OutputContract 的 "text is already decided by cognition"。
- `Evaluate` 的固定 Memory/ 入口（ResolveQuery / ResolveImperatives /
   IsKonsupuImperativeApplicable 可整体替换）使领域接线只发生在 space
   副本的两个薄文件里，主链路零改动——本轮再次受益。
- 未使用的 API（`Readable`、`ResolutionSituation`、`Exported` 等）在回复
  链路中不需要，未强行纳入。
