# Konsupu Aesop Phase 1r3 — 结果记录

以 `run/aesop-phase1r2/`（r2）为直接基线的回答链路重构轮。运行方式：

```sh
node regression.mjs   # 27/27 passed
node run.mjs          # Foundation/domain regression tests: 27/27 passed
                      # Aesop questions: 15/15 passed
```

不经过 Konsupu Runtime / Translation / Learning；Foundation 为冻结 substrate
（`space/Memory/Foundation/`、`space/Test*`、`space/Resolve.js` 与
`src/foundation/` 逐字节一致，零修改）。r2 目录原样保留且仍为 19/19 + 15/15。

## 答案形态变更（本轮唯一的 expected 变化）

回答链路从专用 `{kind:"answer", answer, form}` 协议改为
`Says(content = answer)` + `Imperative(KonsupuIdentity.Ref(), says)`；输出从
英语 realization 改为机械投影。因此 15 个 expected answer 全部从英文句子改为
machine text（`Entity(the crow)`、`Fall(destination=...,theme=...)` 形态），
与 actual 逐字符一致（run.mjs 归一化之外另行做了严格 `===` 核对：15/15）。
问题文本、question cognition（build 函数）、三篇故事 cognition 均未改动。

## 两个 r2 correctness 修复（均含独立回归 + 变异验证）

1. **`ResultsIn(E, P)` 不再让未发生事件的结果自动成立**（Search.js
   `heldOf`）：`ResultsIn` 的内容计入 held 候选前，必须先确认
   `Occurs(E)` 已被断言。回归 `resultsin: an unoccurred event's result is
   not held`（含正向对照）。变异验证：换回 r2 的 Search.js 后恰好该测试
   失败（25/27）。既有故事中所有 `ResultsIn` 的事件均已 `AssertOccurs`，
   15 个答案不受影响。
2. **`BindFields(exact)` 不再依赖字段赋值顺序**（Match.js）：exact 匹配改为
   "字段名集合相同 + 逐字段值匹配"，不再逐位置比较 `Object.entries()` 顺序。
   回归 `exact: field assignment order does not affect matching`。变异验证：
   换回 r2 的 Match.js 后恰好该测试失败。

## 新增领域规则：requested content 不是 question cognition

r3 的 answer 形态使 `Says(content = answerVariable)` 成为 answer Variable 的
一个 Event mentioner。若无处理，solver 会把它当作"哪个已发生的 Says 有此
content"的问题（与真问题 join 后矛盾或直接答错）。`QuerySolver` 新增一条
领域语义：**Imperative 的 content 是被请求执行的 doing（回复形式），永不
参与 question 解释**。变异验证：禁用该排除后 7 项回归失败、问题仅 1/15
通过——排除是 load-bearing 的。

## Regression 结果（27 项）

| 组 | 测试 | 结果 |
|---|---|---|
| 正确性继承 | identity: identical declarations are distinct Nodes | PASS |
| 正确性继承 | identity: repeated Variable must not unify distinct Nodes | PASS |
| 正确性继承 | undefined: a bound undefined conflicts with later bindings | PASS |
| 正确性继承 | undefined: Map keeps [X, undefined] as a binding | PASS |
| 分层 | world objects, events, and propositions separate | PASS |
| 分层 | Event and Action are abstract | PASS |
| 发生 | an event without asserted Occurs did not happen | PASS |
| 发生 | an asserted Occurs answers what happened | PASS |
| 断言 | an unasserted Causes is not a story fact | PASS |
| 断言 | an asserted Causes satisfies the same question | PASS |
| 言语事件 | a speech event is a first-class event argument | PASS |
| 未发生事件 | a goal objective is discussable, not occurred | PASS |
| 模式 | a question proposition is never a story fact | PASS |
| 字段真源 | a question event reads the occurred event's field | PASS |
| Agent join | an unknown action and its agent join through Agent | PASS |
| 无上溯 | a nested question solves by its own class | PASS |
| 无上溯 | a wrapper rescues nothing by itself | PASS |
| 邻接语义 | same mention, three different meanings | PASS |
| r2 bug 1 | resultsin: an unoccurred event's result is not held | PASS |
| r2 bug 2 | exact: field assignment order does not affect matching | PASS |
| 回复链路 | reply: Says.content reads a resolved Entity | PASS |
| 回复链路 | reply: Says.content reads a resolved Event | PASS |
| 回复链路 | reply: Says.content reads a resolved Proposition | PASS |
| 回复链路 | reply: a requested Says is not question cognition | PASS |
| 祈使 | imperatives: a foreign addressee never reaches this Konsupu | PASS |
| 祈使 | imperatives: a requested Says never occurs | PASS |
| 投影 | project: machine output is structural, not English | PASS |

r2 的 "realize: only asserted Agents shape an event's wording" 随英语
realization 层一并删除，由 "project: machine output is structural, not
English" 接替（断言输出对 asserted/unasserted Agent 完全不敏感）。

## 15 个问题结果

全部 PASS，求解机制与 r2 相同（question cognition 未变），仅答案经
`Says.content` 读出并机械投影：

- Q1 类（S1Q1/S3Q1）：question `Agent{action: 事件, actor: V}` → Entity 答案。
- Q2/Q4 类（时序）：question `Before{earlier: 事件, later: V}` → Event 答案。
- Q3 类（因果）：question `Causes{cause: V, effect: 事件}` → Event 答案。
- S1Q5：question `LocatedAt{entity: pebble, place: V}`，held 候选来自已
  发生的 `dropFirst` 的 `ResultsIn` 内容（现受 Occurs 前置约束）。
- S2Q1：未发生的 `Fall{theme: V}` 直读 occurred Fall 的字段。
- S2Q3：question `Believes{...proposition: V}` → `VoiceSurpasses` 命题答案。
- S2Q4/S3Q4/S3Q5：`Goal`/`Promise` objective/deed → Event 答案（不再有
  to-infinitive 形态；`form` 字段删除）。
- S2Q5：`Causes{cause: E, effect: dropCheese}` + `Agent{action: E, actor: V}`
  在同一 Query 内 join。

## 本轮模块变化

### 删除

- `Realize.js`、`Lexicon.js`、`Phrases.js`、`Wording.js`（英语 realization
  层整体删除：时态选择、past/to-infinitive form、动词词形、English
  phrase 生成）；
- `Answers.js` 的专用 answer 协议（`kind === "answer"`、`AnswerApplicable`、
  `AnswerImperatives`、`Realize(view, value, form)`）；
- question 上的 `form` 字段与 `{kind, answer, form}` Imperative content。

### 新增 / 重写

- `Project.js`：唯一、集中、机械的 value→文本投影器。`Entity` →
  `Entity(<name>)`；其他 Node → `Class(field=..., ...)`，字段按名称排序
  （属性插入顺序是构造细节，非声明语义，与 bug 2 同理）；纯数据值按
  `String`/结构化规则。投影只读 value 自身结构，不读其他 cognition。
- `Speech.js`：祈使处理。`SayApplicable`：content 是 `Says`（addressee 已由
  Foundation 按 KonsupuIdentity 预筛，不重复实现）；`SayImperatives`：经
  Imperative Perspective `RequireValue` 读 `says.content`（Query 已完成的
  resolution；失败即 InputStructureError，不重新求解）→ `Project` →
  `TextOutput`，标记 imperative 完成。
- `cases.mjs`（三篇共用形态）：story cognition → answer Variable →
  question cognition → `Query` → `Says(content = answer)` →
  `Imperative(KonsupuIdentity.Ref(), say)`。不添加
  `Assertion(Occurs(answerSay))`——被请求 ≠ 已发生。
- `QuerySolver.js`：requested-content 排除（见上）。

### 语义类

认知类集合与 r2 完全一致（世界对象 / Event / Action / 关系 / 条件命题均未
增删）；`Says.content` 的文档语义从"a Proposition"放宽为"任意 semantic
content（故事言语是 Proposition；回复 Says 说 resolved answer value）"。

## 完成标准对照（指导 §十二）

- Foundation source unchanged ✓（diff 逐字节一致；src/、doc/ git 干净）
- framework/domain regression 全通过 ✓（27/27）
- 原 15 个问题全部通过（expected 改为 machine output 后）✓
- 两个 r2 correctness bug 有独立 regression ✓（且经变异验证 load-bearing）
- 不再存在 topLevelPattern ✓；不存在 answer kind/form 协议 ✓（grep 零命中）
- 正常回答路径实际使用 `KonsupuIdentity.Ref()` ✓（cases.mjs ×3 + 回复回归）
- 正常回答路径实际使用 Says Action 作为 Imperative content ✓
- ResolveImperatives 只读取已求解 semantic content ✓（RequireValue，无重解）
- English Lexicon/Realize 被删除，缩减为纯机械 projector ✓（Project.js）
- FRAMEWORK_NOTES 更新为当前 canonical semantics ✓
- FOUNDATION_NOTES 新增 KonsupuIdentity / Imperative ergonomics 观察 ✓
