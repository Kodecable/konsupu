import { SayImperatives } from "./Aesop/Speech.js";
export function ResolveImperatives(input, imperatives, remaining, state) {
  return SayImperatives(input, imperatives, remaining, state);
}
