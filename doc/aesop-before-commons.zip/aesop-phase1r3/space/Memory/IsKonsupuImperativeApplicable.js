import { SayApplicable } from "./Aesop/Speech.js";
export function IsKonsupuImperativeApplicable(input, imperative, state) {
  return SayApplicable(input, imperative);
}
