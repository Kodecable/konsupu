// Low-level mechanical helpers only. Nothing here decides what any
// semantic class means; Search.js owns the per-class interpretations.
// Node identity rule: a Node's semantic identity is object identity, so
// plain-data comparison never equates two distinct Nodes. "Bound to
// undefined" is a binding (Map.has), never a free slot.
import { Node, Variable } from "../../Interface/Nodes.js";

export function fieldsOf(node) {
  return Object.entries(node).filter(([key]) => key !== "situated");
}

// Equality for non-Variable values: identity first, then plain data.
export function sameValue(left, right) {
  if (left === right) return true;
  if (Array.isArray(left) && Array.isArray(right)) {
    return (
      left.length === right.length &&
      left.every((item, index) => sameValue(item, right[index]))
    );
  }
  if (isPlainObject(left) && isPlainObject(right)) {
    const leftKeys = Object.keys(left).sort();
    const rightKeys = Object.keys(right).sort();
    return (
      leftKeys.length === rightKeys.length &&
      leftKeys.every(
        (key, index) =>
          key === rightKeys[index] && sameValue(left[key], right[key]),
      )
    );
  }
  return false;
}

function isPlainObject(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    !(value instanceof Node) &&
    !Array.isArray(value)
  );
}

// Compare a question's declared fields against a candidate's. Variables
// bind (consistently; has-based); every other field compares by identity or
// plain equality. With `exact`, the candidate must declare exactly the same
// fields — for relations, which are fully fielded. Field identity is a set
// comparison: JS property insertion order is a construction detail, never
// declaration order, so two Nodes with the same fields assigned in
// different orders still match. Without `exact`, undeclared candidate
// fields are unconstrained — for question events, which specify only what
// they ask about.
export function BindFields(question, candidate, bindings, exact) {
  const questionFields = fieldsOf(question);
  if (exact) {
    const candidateFields = fieldsOf(candidate);
    if (questionFields.length !== candidateFields.length) return false;
    const candidateKeys = new Set(candidateFields.map(([key]) => key));
    if (questionFields.some(([key]) => !candidateKeys.has(key))) return false;
  }
  for (const [key, value] of questionFields) {
    const candidateValue = Object.getOwnPropertyDescriptor(candidate, key)?.value;
    if (value instanceof Variable) {
      if (
        bindings.has(value) &&
        !sameValue(bindings.get(value), candidateValue)
      ) {
        return false;
      }
      bindings.set(value, candidateValue);
      continue;
    }
    if (!sameValue(value, candidateValue)) return false;
  }
  return true;
}

// Join binding tuples on shared variables; contradictory values drop out.
export function join(leftTuples, rightTuples) {
  const merged = [];
  for (const left of leftTuples) {
    for (const right of rightTuples) {
      const tuple = new Map(left);
      let consistent = true;
      for (const [variable, value] of right) {
        if (tuple.has(variable) && !sameValue(tuple.get(variable), value)) {
          consistent = false;
          break;
        }
        tuple.set(variable, value);
      }
      if (consistent) merged.push(tuple);
    }
  }
  return merged;
}
