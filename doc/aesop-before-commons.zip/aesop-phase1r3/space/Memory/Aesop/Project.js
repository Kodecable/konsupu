// Mechanical projection of a resolved value into deterministic machine
// text: enough to identify exactly what the Query resolved, nothing more.
// No English realization, no tense, no wording choices, and no reading of
// other cognition — only the value's own structure. Field names sort
// alphabetically because property insertion order is a construction
// detail, not declaration semantics.
import { Entity } from "./Objects.js";
import { Node, Variable } from "../../Interface/Nodes.js";

function dataFields(node) {
  return Object.entries(node)
    .filter(([key]) => key !== "situated")
    .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0));
}

export function Project(value) {
  if (value instanceof Entity) return `Entity(${value.name})`;
  if (value instanceof Variable) {
    throw new TypeError("Machine projection of an unresolved Variable");
  }
  if (value instanceof Node) {
    const fields = dataFields(value).map(
      ([key, item]) => `${key}=${Project(item)}`,
    );
    return `${value.constructor.name}(${fields.join(",")})`;
  }
  if (Array.isArray(value)) {
    return `[${value.map(Project).join(",")}]`;
  }
  if (value !== null && typeof value === "object") {
    const fields = Object.entries(value)
      .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
      .map(([key, item]) => `${key}=${Project(item)}`);
    return `{${fields.join(",")}}`;
  }
  return String(value);
}
