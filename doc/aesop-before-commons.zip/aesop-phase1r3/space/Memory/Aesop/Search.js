// Domain-semantic search: how each kind of question cognition finds its
// evidence in the visible Situation. The structure only supplies adjacency
// (Bindings, Node fields); the meaning of each class is decided here.
//
// - A question Event (never occurring, fields holding Variables) asks about
//   happened events of the same class; occurrence means an asserted Occurs.
// - A question Relation (Agent, Causes, ...) matches asserted instances of
//   the same class.
// - A question Condition (LocatedAt, ...) matches held instances: directly
//   asserted, or carried as the result content of an asserted ResultsIn.
//   Says.content is never held.
import { Event } from "./Objects.js";
import { Assertion, IsAsserted } from "./Assertion.js";
import { BindFields } from "./Match.js";
import {
  Occurs,
  Agent,
  Before,
  Causes,
  ResultsIn,
  Failed,
  Goal,
  InOrderTo,
} from "./Relations.js";
import { Motivates, Promise, Believes, Veracity } from "./Attitudes.js";
import {
  LocatedAt,
  Thirsty,
  OutOfReach,
  Asleep,
  Free,
  Tickled,
  VoiceSurpasses,
  DistrustFlatterers,
} from "./Conditions.js";

function isRelation(proposition) {
  return (
    proposition instanceof Occurs ||
    proposition instanceof Agent ||
    proposition instanceof Before ||
    proposition instanceof Causes ||
    proposition instanceof ResultsIn ||
    proposition instanceof Failed ||
    proposition instanceof Goal ||
    proposition instanceof InOrderTo ||
    proposition instanceof Motivates ||
    proposition instanceof Promise ||
    proposition instanceof Believes ||
    proposition instanceof Veracity
  );
}

function isCondition(proposition) {
  return (
    proposition instanceof LocatedAt ||
    proposition instanceof Thirsty ||
    proposition instanceof OutOfReach ||
    proposition instanceof Asleep ||
    proposition instanceof Free ||
    proposition instanceof Tickled ||
    proposition instanceof VoiceSurpasses ||
    proposition instanceof DistrustFlatterers
  );
}

// Whether an event's occurrence is asserted in the visible cognition.
export function Occurred(view, event) {
  return view.Bindings(event).some((node) => {
    return (
      node instanceof Occurs && node.event === event && IsAsserted(view, node)
    );
  });
}

function tuplesFrom(view, question, candidates, exact) {
  const tuples = [];
  for (const candidate of candidates) {
    if (candidate === question) continue;
    const bindings = new Map();
    if (BindFields(question, candidate, bindings, exact)) tuples.push(bindings);
  }
  return tuples;
}

// Held conditions come from direct Assertions, plus the result contents of
// asserted ResultsIn — but a ResultsIn hands its content over only when the
// resulting event actually occurred. Asserting ResultsIn(E, P) alone never
// makes P currently held.
function* heldOf(view, condition) {
  for (const node of view.Nodes()) {
    if (!(node instanceof Assertion)) continue;
    const proposition = node.proposition;
    if (proposition instanceof condition.constructor) {
      yield proposition;
      continue;
    }
    if (
      proposition instanceof ResultsIn &&
      proposition.proposition instanceof condition.constructor &&
      Occurred(view, proposition.event)
    ) {
      yield proposition.proposition;
    }
  }
}

export function QuestionTuples(view, question) {
  if (question instanceof Event) {
    const occurred = view.Nodes().filter((node) => {
      return (
        node instanceof question.constructor &&
        node !== question &&
        Occurred(view, node)
      );
    });
    return tuplesFrom(view, question, occurred, false);
  }
  if (isCondition(question)) {
    return tuplesFrom(view, question, heldOf(view, question), true);
  }
  if (isRelation(question)) {
    const asserted = view.Nodes().filter((node) => {
      return (
        node instanceof question.constructor && IsAsserted(view, node)
      );
    });
    return tuplesFrom(view, question, asserted, true);
  }
  throw new Error(`No question semantics for a ${question.constructor?.name}`);
}
