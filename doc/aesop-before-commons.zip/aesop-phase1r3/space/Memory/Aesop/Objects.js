// World objects. An Entity or Event occurrence says "this object is part of
// the cognition", never "something is true" and never "it happened".
// Occurrence is the asserted Occurs proposition. Events without an agent
// are plain Events; agentive doings extend Action; Says is an Action
// because speaking is something the speaker does.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

// A discourse individual, identified by object identity; `name` is surface
// text for realization only.
export class Entity extends SituatedNode {
  static BRAND = Brand("aesop:Entity:v1");
  constructor(situated) {
    Final(Entity, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// A referable happening with an occurred / not-occurred distinction. No
// agent is implied. Fields are declared per concrete class as intrinsic
// structure (theme, destination, ...) via explicit assignment.
export class Event extends SituatedNode {
  static BRAND = Brand("aesop:Event:v1");
  constructor(situated) {
    if (new.target === Event) throw new TypeError("Event is abstract");
    super(situated);
  }
}

// An Event modeled as carried out by some Entity. The only added meaning
// is agentivity; intention, success, or responsibility are separate
// cognitions. The agent itself is the reified Agent proposition (see
// Relations.js), never a field here.
export class Action extends Event {
  static BRAND = Brand("aesop:Action:v1");
  constructor(situated) {
    if (new.target === Action) throw new TypeError("Action is abstract");
    super(situated);
  }
}

// Speaking: fields `content` (the semantic content being said) and `text`
// (surface string). Story speech says Propositions; the reply Says that an
// Imperative requests says the resolved answer value — an Entity, an
// Event, or any other semantic content. Says.content is speech content:
// the Situation does not hold it true just because it was said.
export class Says extends Action {
  static BRAND = Brand("aesop:Says:v1");
  constructor(situated) {
    Final(Says, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled downward motion: fields theme, destination.
export class Fall extends Event {
  static BRAND = Brand("aesop:Fall:v1");
  constructor(situated) {
    Final(Fall, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled upward motion: field theme.
export class Rise extends Event {
  static BRAND = Brand("aesop:Rise:v1");
  constructor(situated) {
    Final(Rise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Coming out of sleep, happening to the sleeper: field theme.
export class Wake extends Event {
  static BRAND = Brand("aesop:Wake:v1");
  constructor(situated) {
    Final(Wake, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Being caught in a trap, happening to the trapped: fields theme, location.
export class GetTrapped extends Event {
  static BRAND = Brand("aesop:GetTrapped:v1");
  constructor(situated) {
    Final(GetTrapped, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
