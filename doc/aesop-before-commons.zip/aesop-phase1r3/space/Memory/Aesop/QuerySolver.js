// Generic entry, domain semantics inside. A Query names its unknowns; the
// whole visible cognition of the Situation is the solving environment.
// Every Node that directly mentions a Variable and has question semantics
// (a relation proposition, a condition proposition, or an event with
// Variable fields) contributes candidate tuples; tuples join on shared
// variables; each remaining variable must end with one unique value. No
// climbing through mentioners: a mentioner is interpreted by its own
// semantic class or not at all. One class is exempt by domain semantics:
// a Node presented as an Imperative's content is a requested doing — the
// reply Says that carries the answer — never question cognition, even
// though it mentions the answer Variable. This entry holds no state
// between calls.
import { Perspective } from "../Foundation/Perspective.js";
import { Imperative, Proposition } from "../../Interface/Nodes.js";
import { Event } from "./Objects.js";
import { QuestionTuples } from "./Search.js";
import { join, sameValue } from "./Match.js";

// Whether some Imperative in the visible Situation requests this Node as
// its content. Requested content is performance material, not a question.
function requested(view, node) {
  return view.Nodes().some((item) => {
    return item instanceof Imperative && item.content === node;
  });
}

export function SolveQuery(input, query, remaining, state) {
  const view = new Perspective(query, state);
  let tuples = null;
  const seen = new Set();
  for (const variable of remaining) {
    for (const mentioner of view.Bindings(variable)) {
      if (seen.has(mentioner)) continue;
      if (!(mentioner instanceof Event || mentioner instanceof Proposition)) {
        continue;
      }
      if (requested(view, mentioner)) {
        seen.add(mentioner);
        continue;
      }
      seen.add(mentioner);
      const found = QuestionTuples(view, mentioner);
      if (found.length === 0) {
        throw new Error(
          `No story fact matches the ${mentioner.constructor.name} question`,
        );
      }
      tuples = tuples === null ? found : join(tuples, found);
      if (tuples.length === 0) {
        throw new Error("Question constraints contradict each other");
      }
    }
  }
  const result = new Map();
  if (tuples === null) return result;
  for (const variable of remaining) {
    const unique = [];
    for (const tuple of tuples) {
      if (!tuple.has(variable)) continue;
      const value = tuple.get(variable);
      if (!unique.some((item) => sameValue(item, value))) unique.push(value);
    }
    if (unique.length > 1) {
      throw new Error("Question has more than one answer");
    }
    if (unique.length === 1) result.set(variable, unique[0]);
  }
  return result;
}
