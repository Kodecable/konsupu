// Five questions over the Lion-and-the-Mouse cognition. Expected answers
// are machine projections of the resolved values (see Project.js); the
// English `text` is for human comparison only and never reaches the
// resolver.
import {
  Agent,
  Before,
  Goal,
  Motivates,
  Promise,
} from "../../space/Interface/Aesop.js";

export const Questions = [
  {
    text: "Who gnawed away the ropes?",
    expected: "Entity(the mouse)",
    build(input, root, story, answer) {
      const who = new Agent(root);
      who.action = story.gnaw;
      who.actor = answer;
      input.push(who);
    },
  },
  {
    text: "What did the hunters do after the lion got caught in the trap?",
    expected: "Tie(destination=Entity(the tree),theme=Entity(the lion))",
    build(input, root, story, answer) {
      const next = new Before(root);
      next.earlier = story.getTrapped;
      next.later = answer;
      input.push(next);
    },
  },
  {
    text: "Why did the lion spare the mouse?",
    expected: "Tickled(at=Entity(the mouse's offer),subject=Entity(the lion))",
    build(input, root, story, answer) {
      const why = new Motivates(root);
      why.driver = answer;
      why.action = story.spare;
      input.push(why);
    },
  },
  {
    text: "What did the mouse promise to do for the lion?",
    expected: "Help(theme=Entity(the lion))",
    build(input, root, story, answer) {
      const promise = new Promise(root);
      promise.promiser = story.mouse;
      promise.deed = answer;
      input.push(promise);
    },
  },
  {
    text: "Why did the hunters tie the lion to the tree?",
    expected: "Carry(destination=Entity(the king),theme=Entity(the lion))",
    build(input, root, story, answer) {
      const want = new Goal(root);
      want.actor = story.hunters;
      want.objective = answer;
      input.push(want);
    },
  },
];
