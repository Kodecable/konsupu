// Five questions over the Crow-and-the-Pitcher cognition. Questions are
// unasserted propositions with Variables (or, for Q5, a condition whose
// place is unknown); none of them is a story fact. Expected answers are
// machine projections of the resolved values (see Project.js); the English
// `text` is for human comparison only and never reaches the resolver.
import {
  Agent,
  Before,
  Causes,
  LocatedAt,
} from "../../space/Interface/Aesop.js";

export const Questions = [
  {
    text: "Who dropped a pebble into the pitcher?",
    expected: "Entity(the crow)",
    build(input, root, story, answer) {
      const who = new Agent(root);
      who.action = story.dropFirst;
      who.actor = answer;
      input.push(who);
    },
  },
  {
    text: "What happened after the crow put its beak into the pitcher?",
    expected: "TryToDrink(theme=Entity(the water))",
    build(input, root, story, answer) {
      const next = new Before(root);
      next.earlier = story.putBeak;
      next.later = answer;
      input.push(next);
    },
  },
  {
    text: "Why did the water mount up?",
    expected: "Drop(destination=Entity(the pitcher),theme=Entity(a pebble))",
    build(input, root, story, answer) {
      const why = new Causes(root);
      why.cause = answer;
      why.effect = story.waterRise;
      input.push(why);
    },
  },
  {
    text: "What was the crow able to do after the water mounted up?",
    expected: "Quench(theme=Entity(its thirst))",
    build(input, root, story, answer) {
      const next = new Before(root);
      next.earlier = story.waterRise;
      next.later = answer;
      input.push(next);
    },
  },
  {
    text: "Where did the pebble end up after the crow dropped it?",
    expected: "Entity(the pitcher)",
    build(input, root, story, answer) {
      const where = new LocatedAt(root);
      where.entity = story.pebble;
      where.place = answer;
      input.push(where);
    },
  },
];
