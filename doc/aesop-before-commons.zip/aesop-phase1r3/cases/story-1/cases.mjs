// Builds the complete Input for one question: Situation, full story
// cognition, question cognition, Query, and the reply Imperative. A fresh
// graph is constructed per call; nothing is shared between questions.
import {
  Imperative,
  KonsupuIdentity,
  Query,
  Situation,
  Variable,
} from "../../space/Interface/Nodes.js";
import { Says } from "../../space/Interface/Aesop.js";
import { BuildStory } from "./story.mjs";
import { Questions } from "./questions.mjs";

export { Questions };

export function BuildCase(question) {
  const root = new Situation();
  const input = [root];
  const story = BuildStory(input, root);
  const answer = new Variable(root);
  input.push(answer);
  const extra = question.build(input, root, story, answer) ?? [];
  input.push(new Query(root, [answer, ...extra]));
  const say = new Says(root);
  say.content = answer;
  input.push(say);
  input.push(new Imperative(root, KonsupuIdentity.Ref(), say));
  return input;
}
