// Five questions over the Fox-and-the-Crow cognition. Q1 asks through a
// question Fall event with an unknown theme — no EventTheme relation
// exists; the theme field is the canonical representation. Q5 joins an
// unknown causing event with its unknown agent. Expected answers are
// machine projections of the resolved values (see Project.js); the English
// `text` is for human comparison only and never reaches the resolver.
import {
  Agent,
  Believes,
  Causes,
  Fall,
  Goal,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: "What fell to the ground?",
    expected: "Entity(the cheese)",
    build(input, root, story, answer) {
      const what = new Fall(root);
      what.theme = answer;
      input.push(what);
    },
  },
  {
    text: "What happened when the crow began to sing?",
    expected: "Fall(destination=Entity(the ground),theme=Entity(the cheese))",
    build(input, root, story, answer) {
      const result = new Causes(root);
      result.cause = story.sing;
      result.effect = answer;
      input.push(result);
    },
  },
  {
    text: "What did the crow believe about her voice?",
    expected: "VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))",
    build(input, root, story, answer) {
      const belief = new Believes(root);
      belief.believer = story.crow;
      belief.proposition = answer;
      input.push(belief);
    },
  },
  {
    text: "What did the fox want to get?",
    expected: "SnapUp(theme=Entity(the cheese))",
    build(input, root, story, answer) {
      const want = new Goal(root);
      want.actor = story.fox;
      want.objective = answer;
      input.push(want);
    },
  },
  {
    text: "Who made the cheese fall?",
    expected: "Entity(the crow)",
    build(input, root, story, answer) {
      const event = new Variable(root);
      const cause = new Causes(root);
      cause.cause = event;
      cause.effect = story.dropCheese;
      const who = new Agent(root);
      who.action = event;
      who.actor = answer;
      input.push(event, cause, who);
      return [event];
    },
  },
];
