# Konsupu Aesop Phase 1r2 — Framework 观察

按指导第 20 节逐题回答；文末为额外的 friction 与自然之处记录。基线：
`node regression.mjs` → 19/19；`node run.mjs` → 19/19 + 15/15（答案与
r1 逐字符一致）。

---

## 指导要求的 11 个回答

### 1. Event / Action 最终采用了什么严格语义？

- `Event`（abstract SituatedNode）：可指称、可讨论、具有"发生/未发生"
  区别的世界事件。Event 对象存在 ≠ `Occurs(event)` 成立；发生只由
  `Assertion(Occurs(E))` 表达。Event 不要求施事者。
- `Action extends Event`（abstract）：被建模为由某 Entity 实施的事件。
  唯一附加语义是 agentivity；intention / goal / success / responsibility
  一律不进类型，由 `Goal`、`Failed`、`Motivates` 等独立命题表达。
- 施事关系本身被 reify 为 `Agent(action, actor)` 命题（见第 3、9 条），
  因此 Action 类上没有任何 agent 字段。

### 2. 哪些旧 Action 被重新分类为非 Action Event，为什么？

| r1 事件 | r2 分类 | 理由 |
|---|---|---|
| `waterRise`（水升高） | `Rise`（Event） | 无施事者：水位上升不由任何 Entity 实施 |
| `dropCheese`（奶酪掉落） | `Fall`（Event） | 奶酪是 theme 不是 agent；r1 的 `Role(dropCheese,"actor",cheese)` 是明确错误表示，r2 结构上不可能复现（Fall 无 agent 通道） |
| `wake`（狮被弄醒） | `Wake`（Event） | "被弄醒"发生在睡眠者身上，非狮的施为 |
| `getTrapped`（落入陷阱） | `GetTrapped`（Event） | 被困是遭遇，不是施为 |

判定一律按世界语义，不按英语动词形态（如 `Spare`/`TryToDrink` 仍是
Action）。回归测试锁定 `Fall instanceof Event && !(Fall instanceof Action)`。

### 3. 哪些关系保留为 field，哪些升级成独立 Node，为什么？

- **保留字段**：theme、destination、instrument、location、source、
  manner——它们只作为"事件内在结构"被读取；15 问中没有任何一问需要
  在两个 Variable 之间 join 这些关系（S2Q1 只需要把 theme 当作最终答案
  读出，question-Fall 机制足够，见第 9 条）。
- **升级为 Node**：`Agent(action, actor)`。证据（指导 §14 预告的压力
  测试，见第 9 条）：S2Q5 需要表达"未知事件 E 的施事是 V"——两个
  Variable 之间的可引用、可 join 关系。字段表示在 E 是 Variable 时根本
  无法写出这个连接；这不是实现困难，是表达力缺失。升级后全局删除
  agent 字段（包括指导 §4 草图里的 `says.agent = fox`，Says 的施事同样
  走 `Agent(says, fox)`），保持唯一 canonical representation。
- 其余全部是命题间关系（Before/Causes/ResultsIn/Goal/...），不涉及
  field-vs-Node 抉择。

### 4. 是否存在任何 field + relation Node 双重表示？

**否。**已核查：事件类上无 agent 字段（grep 验证）；不存在
`EventTheme`/`EventAgent` 之类的镜像类；反过来 theme/destination 等没有
对应关系 Node。指导 §4 的 `says.agent` 草图与 §14 的升级要求冲突时，
按 §14 的证据结论执行。

### 5. Role / State / Claim 如何被替代？

- `Role(event, role:string, filler)` → 参与者语义回到具体事件类的
  intrinsic 字段；施事单独 reify 为 `Agent`。generic Role 整体删除。
- `State(holder, attribute:string, value)` → 每个真实状态一个具体条件
  命题：`LocatedAt`、`Thirsty`、`OutOfReach`、`Asleep`、`Free`、
  `Tickled`；r1 的 `State(x,"location",y)` 即 `LocatedAt(x, y)`。
- `Claim(subject, attribute:string, value:string)` → 真命题子类：
  `VoiceSurpasses{subject, others}`（乌鸦嗓音胜过其他鸟）、
  `DistrustFlatterers`（狐狸的忠告内容）。`Says.content` 与
  `Believes.proposition` 直接引用这些对象。

### 6. Initially / Becomes 如何按真实语义拆解？

未机械套换，逐条判断：

- r1 `Initially(State(crow, condition, "half-dead with thirst"))` →
  `Thirsty(crow)` 直接 assert：这是世界状态，不是叙事相对概念。
- r1 `Initially(State(water, amount, "very little"))` → `OutOfReach(water)`
  （叙事中的操作语义："够不着"）；不保留"量很少"的抄写性事实。
- r1 `Initially(State(cheese, location, beak))` → 删除独立状态，改为
  `FlyOff{theme: cheese}` 的 intrinsic 结构（叼着奶酪飞走）。
- r1 `Becomes(dropFirst, State(pebble, location, pitcher))` →
  `ResultsIn(dropFirst, LocatedAt(pebble, pitcher))`：投石的结果。
- r1 `Becomes(dropCheese/gnaw/snapUp, ...)` → 同上 `ResultsIn`。
- r1 `Becomes(waterRise, State(water, level, "near the top"))`、
  `Becomes(drink, State(crow, thirst, "quenched"))` → 删除：水位上升
  与解渴分别是 `Rise`/`Quench` 事件本身的内涵，再挂结果命题是同义反复。
- r1 `Becomes(plead, State(lion, mood, tickled))` → `Tickled(lion, offer)`
  直接 assert（叙事时点起成立）+ `Motivates(tickled, spare)`。

约定：**plain assertion = 从其叙事位置起成立且无后续反例；ResultsIn =
明确由事件导致**。未引入 HoldsBefore/HoldsAfter——现有三篇没有需要
"在事件 X 之前成立"的真实表达。

### 7. 删除 topLevelPattern 后 resolver 如何寻找证据？

从 `Bindings(variable)` 的**直接 mentioner** 出发，按 mentioner 自身的
语义类解释（`Search.QuestionTuples` 分派）：

- question Event（未发生、字段含 Variable）→ 扫描 occurred 同类事件，
  按"question 声明的字段子集"匹配（未声明字段即通配）；
- question 关系命题 → 扫描被 assert 的同类命题，字段全集匹配；
- question 条件命题 → 扫描 held 同类命题（直接被 assert，或为被 assert
  的 `ResultsIn` 的内容），字段全集匹配。

S1Q5 证明了不需要上溯：问题 `LocatedAt{pebble, place: V}` 的直接
mentioner 就是它自己；"held" 候选集合包含被 assert 的
`ResultsIn(dropFirst, LocatedAt(pebble, pitcher))` 的内容，因此直接命中。
回归 "no-climb" 两例锁定：外层未 assert wrapper 既不参与匹配也救不了
无匹配的问题。§11 指出的"mentioner ≠ 可透明穿透的包装层"在此成为
solver 的结构性质而非纪律约定。

### 8. Bindings() 在新 solver 中具体只承担了什么？

三个纯索引用途，无一携带推理含义：

1. `Bindings(variable)`：找直接提到该 Variable 的 question cognition；
2. `Bindings(event)`（`Occurred` 与 `agentName` 内）：确认某 `Occurs(e)`
   被断言、读出被断言的 `Agent`；
3. `Bindings(proposition)`（`IsAsserted` 内）：确认某命题被断言。

"X mentions P ⇒ P 如何参与求解"由 mentioner 的语义类决定：回归
"adjacency: same mention, three different meanings" 用同一个
`LocatedAt` 被三种节点提及展示差异——`Says.content`（说了 ≠ 成立）、
`Assertion`（成立）、`ResultsIn` 的内容（作为结果成立）。

### 9. Story 2 Q5 如何联合求解；对 field-vs-Node 边界提供了什么证据？

求解：同一 Query 含 `E`、`V` 两变量；question `Causes{cause: E,
effect: dropCheese}` 给出 E 的候选 {sing}，question
`Agent{action: E, actor: V}` 给出全部 (action, actor) 对；join 后唯一
幸存 {E: sing, V: crow}。

**结论（按指导要求明确记录，不模糊处理）**：

> field-only 的施事关系无法表达"未知事件的施事"——当 E 还是 Variable
> 时，不存在任何 cognition 能写出 agent(E)=V 这个连接。这构成施事关系
> 必须作为变量之间可引用、可 join 的独立语义对象的真实证据；因此
> `Agent` 升级为 Node，且全局删除 agent 字段，无双真源。

反向证据同样成立：theme 从未出现在变量间 join 中（S2Q1 的 theme 只是
最终答案槽），question-Fall + occurred 匹配机制足以及时求解，因此 theme
留在字段。**边界判据 = 该关系是否需要以变量对变量的身份参与推理**，
而不是"是否被查询"。

### 10. 哪些仍是 framework friction，哪些只是 vocabulary 未成熟？

- **Framework friction**：① 声明字段只能整体出现在 Object.entries 可见
  的位置——situation-only 构造 + 赋值风格可行，但字段成为普通可写属性，
  "Resolve 期间不改 Declaration" 从 Foundation 的 writable:false 约定退化
  为纯纪律（Foundation 原文即说这本来就只是约定）；② `Bindings` 的
  "直接 mention" 语义让嵌套问题（r1 的 S1Q5 形态）必须由**内层** cognition
  自带完整求解语义，外层锚定信息（"after the drop"）只能作为冗余语境
  存在或干脆不写——信息没有被利用，问题答案恰好无歧义所以成立；若
  出现多个 ResultsIn 时代的 LocatedAt，需要更强的时序条件，届时应引入
  真正的时序条件命题而不是恢复上溯。
- **Vocabulary 未成熟**：`Veracity{proposition, truth:boolean}` 仍是
  布尔开关（指导允许保留的观察点）；`Tickled{subject, at}` 的 `at` 指向
  一个名义化实体 "the mouse's offer"——叙事把承诺说成物，模型跟随叙事，
  但 offer 的本体（事件？命题？）未定；`Sing.manner` 是表层串挂在事件上。

### 11. Foundation 是否保持零修改？

**是。**`diff -r src/foundation/Memory/Foundation run/.../space/Memory/Foundation`
及 Test/Test.js/Resolve.js 逐字节一致；`src/`、`doc/` git 干净；space 副本
自检通过。领域层只使用了 Perspective / Bindings / Value / Evaluate 这些
公开面。

---

## 额外记录

### 自然之处

1. **situation-only 构造 + 字段赋值显著改善了 story source 可读性**：
   `const fall = new Fall(root); fall.theme = cheese;` 比 r1 的
   fields-object 一步到位更接近叙事书写顺序，新增字段不破坏任何调用点。
2. **语义子类消解了 stringly 判断**：solver 不再解析 "actor"/"location"
   字符串；每个类的含义在 Search/Realize 的 instanceof 分派里一眼可读。
3. **Fall/Rise/Wake/GetTrapped 非 Action 化后，"谁做了什么"与"什么发生
   了"自然分家**：realization 对无 agent 事件自动以 theme 作表层主语，
   cheese-fall 的错误表示（cheese 当 actor）在类型层面不可复现。
4. **question-Event 机制**（未发生、含 Variable 字段的同类事件）让
   "What fell?" 这类存在性问题无需任何关系 Node 即可求解，直接验证了
   §14 前半命题。

### Friction

1. **注册副作用的隐式性**：lexicon 拆成两个文件后，action 词条模块必须
   被副作用导入（`import "./Lexicon.js"`）才生效——漏导入在运行期才以
   "No realization" 暴露。ESM 无更优雅的聚合点，记为实现脆弱点。
2. **字段可选性 vs 全集匹配**：关系命题的字段全集匹配依赖"该类字段
   必填"的约定（Says 的 content/text 可选，故 Says 不做 question 类）。
   该约定目前只存在于类注释，Analyze 不检查。
3. **行数预算迫使词表按故事拆文件**（Actions.js / Deeds.js、Lexicon.js /
   Phrases.js），拆分纯为 160 行门禁，无语义含义——词汇量继续增长时
   需要更好的组织维度。
4. **本轮真值语义仍未开始**：Veracity 布尔、offer 名义化、belief 未
   Situation 化——均为指导 §11 明确留到下一轮的问题。

### 实现过程中修正的两个自身 bug（均有回归锁定）

- `sameValue` 重写时丢失 `instanceof Node` 排除，两个同形 Entity 一度
  被判等（identity 回归抓住；agent-join 回归连带验证了它对 join 的污染：
  两个无字段 Fall 被结构误判相等导致 Causes 多匹配）；
- story 迁移中对同一命题先手工 push 又 `Assert`（Assert 自身会 push），
  被 Analyze 的 Duplicate Node occurrence 当场拦截。
