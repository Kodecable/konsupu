// Five questions over the Lion-and-the-Mouse cognition.
import {
  Agent,
  Before,
  Goal,
  Motivates,
  Promise,
} from "../../space/Interface/Aesop.js";

export const Questions = [
  {
    text: "Who gnawed away the ropes?",
    expected: "the mouse",
    build(input, root, story, answer) {
      const who = new Agent(root);
      who.action = story.gnaw;
      who.actor = answer;
      input.push(who);
    },
  },
  {
    text: "What did the hunters do after the lion got caught in the trap?",
    expected: "the hunters tied the lion to the tree",
    build(input, root, story, answer) {
      const next = new Before(root);
      next.earlier = story.getTrapped;
      next.later = answer;
      input.push(next);
    },
  },
  {
    text: "Why did the lion spare the mouse?",
    expected: "the lion was tickled at the mouse's offer",
    build(input, root, story, answer) {
      const why = new Motivates(root);
      why.driver = answer;
      why.action = story.spare;
      input.push(why);
    },
  },
  {
    text: "What did the mouse promise to do for the lion?",
    expected: "to help the lion",
    form: "to-infinitive",
    build(input, root, story, answer) {
      const promise = new Promise(root);
      promise.promiser = story.mouse;
      promise.deed = answer;
      input.push(promise);
    },
  },
  {
    text: "Why did the hunters tie the lion to the tree?",
    expected: "to carry the lion to the king",
    form: "to-infinitive",
    build(input, root, story, answer) {
      const want = new Goal(root);
      want.actor = story.hunters;
      want.objective = answer;
      input.push(want);
    },
  },
];
