// BuildStory for "The Crow and the Pitcher". Every narration event —
// including the non-agentive Rise — occurs; the crow is the agent of its
// doings through reified Agent propositions; conditions hold as asserted
// propositions, and the pebble's resting place is the result of the drop.
import {
  Action,
  Agent,
  Assert,
  AssertOccurs,
  Before,
  Causes,
  Drop,
  Entity,
  Failed,
  FlyOff,
  Goal,
  InOrderTo,
  LocatedAt,
  OutOfReach,
  Put,
  Quench,
  ResultsIn,
  Rise,
  Save,
  Thirsty,
  ThinkUp,
  TryToDrink,
  ComeUpon,
} from "../../space/Interface/Aesop.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function before(root, input, earlier, later) {
  const relation = new Before(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const crow = entity(root, "the crow");
  const pitcher = entity(root, "the pitcher");
  const water = entity(root, "the water");
  const pebble = entity(root, "a pebble");
  const morePebbles = entity(root, "a few more pebbles");
  const beak = entity(root, "its beak");
  const thirst = entity(root, "its thirst");
  const life = entity(root, "its life");
  input.push(
    crow,
    pitcher,
    water,
    pebble,
    morePebbles,
    beak,
    thirst,
    life,
  );

  const thirsty = new Thirsty(root);
  thirsty.subject = crow;
  Assert(input, thirsty);
  const unreachable = new OutOfReach(root);
  unreachable.subject = water;
  Assert(input, unreachable);

  const comeUpon = new ComeUpon(root);
  comeUpon.theme = pitcher;
  const putBeak = new Put(root);
  putBeak.theme = beak;
  putBeak.destination = pitcher;
  const tryDrink = new TryToDrink(root);
  tryDrink.theme = water;
  const think = new ThinkUp(root);
  const dropFirst = new Drop(root);
  dropFirst.theme = pebble;
  dropFirst.destination = pitcher;
  const dropMore = new Drop(root);
  dropMore.theme = morePebbles;
  dropMore.destination = pitcher;
  const waterRise = new Rise(root);
  waterRise.theme = water;
  const drink = new Quench(root);
  drink.theme = thirst;
  const saveLife = new Save(root);
  saveLife.theme = life;
  const happened = [
    comeUpon,
    putBeak,
    tryDrink,
    think,
    dropFirst,
    dropMore,
    waterRise,
    drink,
    saveLife,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, comeUpon, crow);
  agent(root, input, putBeak, crow);
  agent(root, input, tryDrink, crow);
  agent(root, input, think, crow);
  agent(root, input, dropFirst, crow);
  agent(root, input, dropMore, crow);
  agent(root, input, drink, crow);
  agent(root, input, saveLife, crow);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    before(root, input, happened[index], happened[index + 1]);
  }

  const failed = new Failed(root);
  failed.action = tryDrink;
  Assert(input, failed);
  const pebbleDropped = new Causes(root);
  pebbleDropped.cause = dropFirst;
  pebbleDropped.effect = waterRise;
  Assert(input, pebbleDropped);
  const riseLetDrink = new Causes(root);
  riseLetDrink.cause = waterRise;
  riseLetDrink.effect = drink;
  Assert(input, riseLetDrink);
  const drinkSaved = new Causes(root);
  drinkSaved.cause = drink;
  drinkSaved.effect = saveLife;
  Assert(input, drinkSaved);

  const pebbleRests = new LocatedAt(root);
  pebbleRests.entity = pebble;
  pebbleRests.place = pitcher;
  input.push(pebbleRests);
  const pebbleResult = new ResultsIn(root);
  pebbleResult.event = dropFirst;
  pebbleResult.proposition = pebbleRests;
  Assert(input, pebbleResult);

  const goal = new Goal(root);
  goal.actor = crow;
  goal.objective = drink;
  Assert(input, goal);
  const dropAimed = new InOrderTo(root);
  dropAimed.action = dropFirst;
  dropAimed.goal = waterRise;
  Assert(input, dropAimed);

  return { crow, water, pebble, putBeak, tryDrink, dropFirst, waterRise, drink };
}
