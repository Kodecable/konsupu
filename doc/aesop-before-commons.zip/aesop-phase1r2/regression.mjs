// Domain-level regression tests for the r2 world framework. They run the
// domain solver and Evaluate directly against the copied Foundation.
// Story facts are built with the explicit Assert helpers. Runnable both
// ways: `node regression.mjs` standalone, or imported by run.mjs.
import { pathToFileURL } from "node:url";
import {
  Action,
  Agent,
  Assert,
  AssertOccurs,
  Before,
  Believes,
  Causes,
  Entity,
  Event,
  Fall,
  Goal,
  Gnaw,
  LocatedAt,
  Occurs,
  ResultsIn,
  Says,
  Sing,
} from "./space/Interface/Aesop.js";
import {
  Imperative,
  KonsupuIdentity,
  Proposition,
  Query,
  Situation,
  Variable,
} from "./space/Interface/Nodes.js";
import { Assertion } from "./space/Memory/Aesop/Assertion.js";
import { sameValue } from "./space/Memory/Aesop/Match.js";
import { SolveQuery } from "./space/Memory/Aesop/QuerySolver.js";
import { Analyze } from "./space/Memory/Foundation/Analyze.js";
import { CreateState } from "./space/Memory/Foundation/ResolveState.js";
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";

function assert(condition, message) {
  if (!condition) throw new Error(`assert failed: ${message}`);
}

function assertThrows(thunk, fragment, message) {
  try {
    thunk();
  } catch (caught) {
    assert(
      String(caught.message).includes(fragment),
      `${message}: expected "${fragment}" in "${caught.message}"`,
    );
    return;
  }
  throw new Error(`${message}: expected an error containing "${fragment}"`);
}

// SolveQuery with a state built the way Evaluate builds it; remaining is
// the full variable list, as QueryLoop passes it for a root-local Query.
function solve(input, query) {
  const state = CreateState(Analyze(input));
  return SolveQuery(input, query, [...query.variables], state);
}

function crowPair() {
  const root = new Situation();
  const a = new Entity(root);
  a.name = "the crow";
  const b = new Entity(root);
  b.name = "the crow";
  const input = [root, a, b];
  return { root, a, b, input };
}

function makeAgent(root, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  return relation;
}

export const Tests = [
  {
    name: "identity: identical declarations are distinct Nodes",
    run() {
      const { a, b } = crowPair();
      assert(a !== b, "two constructions are two objects");
      assert(sameValue(a, b) === false, "sameValue must not unify them");
      assert(sameValue(a, a), "a Node equals itself");
    },
  },
  {
    name: "identity: repeated Variable must not unify distinct Nodes",
    run() {
      const { root, a, b, input } = crowPair();
      Assert(input, BeforeOf(root, a, b));
      const x = new Variable(root);
      input.push(x, BeforeOf(root, x, x));
      const query = new Query(root, [x]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "No story fact matches",
        "question (X, X) must not match (a, b) with a !== b",
      );
    },
  },
  {
    name: "undefined: a bound undefined conflicts with later bindings",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      crow.name = "the crow";
      const first = new Sing(root);
      const second = new Sing(root);
      const input = [root, crow, first, second];
      Assert(input, makeAgent(root, first, undefined));
      Assert(input, makeAgent(root, second, crow));
      const x = new Variable(root);
      input.push(x, makeAgent(root, first, x), makeAgent(root, second, x));
      const query = new Query(root, [x]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "contradict",
        "undefined then crow is a conflict, not an overwrite",
      );
    },
  },
  {
    name: "undefined: Map keeps [X, undefined] as a binding",
    run() {
      const root = new Situation();
      const act = new Sing(root);
      const input = [root, act];
      Assert(input, makeAgent(root, act, undefined));
      const x = new Variable(root);
      input.push(x, makeAgent(root, act, x));
      const query = new Query(root, [x]);
      input.push(query);
      const result = solve(input, query);
      assert(result.has(x), "undefined binding must stay in the Map");
      assert(result.get(x) === undefined, "the bound value is undefined");
    },
  },
  {
    name: "layering: world objects, events, and propositions separate",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      const sing = new Sing(root);
      const says = new Says(root);
      const fall = new Fall(root);
      const occurs = new Occurs(root);
      const before = new Before(root);
      const causes = new Causes(root);
      const assertion = new Assertion(root);
      assert(!(crow instanceof Proposition), "Entity is not a Proposition");
      assert(!(says instanceof Proposition), "Says is not a Proposition");
      assert(says instanceof Action, "Says is an Action");
      assert(
        fall instanceof Event && !(fall instanceof Action),
        "Fall is an Event but not an Action",
      );
      assert(
        occurs instanceof Proposition &&
          before instanceof Proposition &&
          causes instanceof Proposition,
        "Occurs, Before, and Causes are Propositions",
      );
      assert(
        !(assertion instanceof Proposition),
        "Assertion is not a Proposition",
      );
    },
  },
  {
    name: "layering: Event and Action are abstract",
    run() {
      const root = new Situation();
      assertThrows(
        () => new Event(root),
        "abstract",
        "Event cannot be constructed",
      );
      assertThrows(
        () => new Action(root),
        "abstract",
        "Action cannot be constructed",
      );
    },
  },
  {
    name: "occurrence: an event without asserted Occurs did not happen",
    run() {
      const root = new Situation();
      const sing = new Sing(root);
      const input = [root, sing];
      const v = new Variable(root);
      const occurs = new Occurs(root);
      occurs.event = v;
      input.push(v, occurs);
      const query = new Query(root, [v]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "No story fact matches",
        "an existing event with no Occurs assertion is not an occurrence",
      );
    },
  },
  {
    name: "occurrence: an asserted Occurs answers what happened",
    run() {
      const root = new Situation();
      const sing = new Sing(root);
      const input = [root, sing];
      AssertOccurs(input, sing);
      const v = new Variable(root);
      const occurs = new Occurs(root);
      occurs.event = v;
      input.push(v, occurs);
      const query = new Query(root, [v]);
      input.push(query);
      const result = solve(input, query);
      assert(result.get(v) === sing, "the occurred event is the answer");
    },
  },
  {
    name: "assertion: an unasserted Causes is not a story fact",
    run() {
      const root = new Situation();
      const a = new Sing(root);
      const b = new Fall(root);
      const input = [root, a, b];
      input.push(CausesOf(root, a, b));
      const v = new Variable(root);
      input.push(v, CausesOf(root, v, b));
      const query = new Query(root, [v]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "No story fact matches",
        "a Causes object that exists is not yet a fact",
      );
    },
  },
  {
    name: "assertion: an asserted Causes satisfies the same question",
    run() {
      const root = new Situation();
      const a = new Sing(root);
      const b = new Fall(root);
      const input = [root, a, b];
      Assert(input, CausesOf(root, a, b));
      const v = new Variable(root);
      input.push(v, CausesOf(root, v, b));
      const query = new Query(root, [v]);
      input.push(query);
      const result = solve(input, query);
      assert(result.get(v) === a, "the asserted cause is the answer");
    },
  },
  {
    name: "says: a speech event is a first-class event argument",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      crow.name = "the crow";
      const says = new Says(root);
      says.text = "Spare me!";
      const other = new Fall(root);
      const input = [root, crow, says, other];
      Assert(input, BeforeOf(root, says, other));
      AssertOccurs(input, says);
      const v1 = new Variable(root);
      const v2 = new Variable(root);
      input.push(v1, v2, BeforeOf(root, v1, other));
      const occurs = new Occurs(root);
      occurs.event = v2;
      input.push(occurs);
      const query = new Query(root, [v1, v2]);
      input.push(query);
      const result = solve(input, query);
      assert(result.get(v1) === says, "Says serves as a Before argument");
      assert(result.get(v2) === says, "Says can occur");
    },
  },
  {
    name: "future events: a goal objective is discussable, not occurred",
    run() {
      const root = new Situation();
      const fox = new Entity(root);
      fox.name = "the fox";
      const help = new Gnaw(root);
      const input = [root, fox, help];
      const goal = new Goal(root);
      goal.actor = fox;
      goal.objective = help;
      Assert(input, goal);
      const what = new Variable(root);
      const askedGoal = new Goal(root);
      askedGoal.actor = fox;
      askedGoal.objective = what;
      input.push(what, askedGoal);
      const query = new Query(root, [what]);
      input.push(query);
      const result = solve(input, query);
      assert(result.get(what) === help, "the goal's event is discussable");

      const happenedInput = [root, fox, help];
      Assert(happenedInput, goal);
      const v = new Variable(root);
      const occurs = new Occurs(root);
      occurs.event = v;
      happenedInput.push(v, occurs);
      const happenedQuery = new Query(root, [v]);
      happenedInput.push(happenedQuery);
      assertThrows(
        () => solve(happenedInput, happenedQuery),
        "No story fact matches",
        "a goal objective never occurred just by being wanted",
      );
    },
  },
  {
    name: "patterns: a question proposition is never a story fact",
    run() {
      const root = new Situation();
      const drop = new Fall(root);
      const sing = new Sing(root);
      const input = [root, drop, sing];
      const v1 = new Variable(root);
      const v2 = new Variable(root);
      input.push(v1, v2, CausesOf(root, v1, drop), CausesOf(root, v2, drop));
      const query = new Query(root, [v1, v2]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "No story fact matches",
        "two unasserted questions must not satisfy each other",
      );
    },
  },
  {
    name: "field-canonical: a question event reads the occurred event's field",
    run() {
      const root = new Situation();
      const cheese = new Entity(root);
      cheese.name = "the cheese";
      const ground = new Entity(root);
      ground.name = "the ground";
      const fall = new Fall(root);
      fall.theme = cheese;
      fall.destination = ground;
      const input = [root, cheese, ground, fall];
      AssertOccurs(input, fall);
      const v = new Variable(root);
      const question = new Fall(root);
      question.theme = v;
      input.push(v, question);
      const query = new Query(root, [v]);
      input.push(query);
      const result = solve(input, query);
      assert(
        result.get(v) === cheese,
        "the theme field answers without any EventTheme relation",
      );
    },
  },
  {
    name: "agent-join: an unknown action and its agent join through Agent",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      crow.name = "the crow";
      const fox = new Entity(root);
      fox.name = "the fox";
      const sing = new Sing(root);
      const taunt = new Says(root);
      taunt.text = "Was I not right?";
      const fallA = new Fall(root);
      const fallB = new Fall(root);
      const input = [root, crow, fox, sing, taunt, fallA, fallB];
      Assert(input, CausesOf(root, sing, fallA));
      Assert(input, CausesOf(root, taunt, fallB));
      Assert(input, makeAgent(root, sing, crow));
      Assert(input, makeAgent(root, taunt, fox));
      const event = new Variable(root);
      const v = new Variable(root);
      input.push(event, v, CausesOf(root, event, fallA), makeAgent(root, event, v));
      const query = new Query(root, [v, event]);
      input.push(query);
      const result = solve(input, query);
      assert(result.get(v) === crow, "the agent of the causing event wins");
      assert(result.get(event) === sing, "the causing event is identified");
    },
  },
  {
    name: "no-climb: a nested question solves by its own class",
    run() {
      const root = new Situation();
      const pebble = new Entity(root);
      pebble.name = "a pebble";
      const pitcher = new Entity(root);
      pitcher.name = "the pitcher";
      const drop = new Gnaw(root);
      const input = [root, pebble, pitcher, drop];
      const rests = new LocatedAt(root);
      rests.entity = pebble;
      rests.place = pitcher;
      input.push(rests);
      const result = new ResultsIn(root);
      result.event = drop;
      result.proposition = rests;
      Assert(input, result);
      const v = new Variable(root);
      const where = new LocatedAt(root);
      where.entity = pebble;
      where.place = v;
      // An unasserted wrapper mentioning the question: never consulted.
      const wrapper = new Believes(root);
      wrapper.believer = pebble;
      wrapper.proposition = where;
      input.push(v, where, wrapper);
      const query = new Query(root, [v]);
      input.push(query);
      const solved = solve(input, query);
      assert(
        solved.get(v) === pitcher,
        "the inner condition is interpreted by its own semantics",
      );
    },
  },
  {
    name: "no-climb: a wrapper rescues nothing by itself",
    run() {
      const root = new Situation();
      const a = new Sing(root);
      const b = new Fall(root);
      const crow = new Entity(root);
      crow.name = "the crow";
      const input = [root, crow, a, b];
      const v = new Variable(root);
      const question = new Causes(root);
      question.cause = v;
      question.effect = b;
      const wrapper = new Believes(root);
      wrapper.believer = crow;
      wrapper.proposition = question;
      input.push(v, question, wrapper);
      const query = new Query(root, [v]);
      input.push(query);
      assertThrows(
        () => solve(input, query),
        "No story fact matches",
        "climbing to the wrapper must not conjure a match",
      );
    },
  },
  {
    name: "adjacency: same mention, three different meanings",
    run() {
      const root = new Situation();
      const cheese = new Entity(root);
      cheese.name = "the cheese";
      const ground = new Entity(root);
      ground.name = "the ground";
      const fox = new Entity(root);
      fox.name = "the fox";
      const fall = new Fall(root);
      fall.theme = cheese;
      fall.destination = ground;
      const located = new LocatedAt(root);
      located.entity = cheese;
      located.place = ground;
      const says = new Says(root);
      says.text = "it is on the ground";
      says.content = located;

      const ask = (input) => {
        const v = new Variable(root);
        const where = new LocatedAt(root);
        where.entity = cheese;
        where.place = v;
        input.push(v, where);
        const query = new Query(root, [v]);
        input.push(query);
        return solve(input, query).get(v);
      };

      const speechOnly = [root, cheese, ground, fox, fall, located, says];
      AssertOccurs(speechOnly, says);
      assertThrows(
        () => ask(speechOnly),
        "No story fact matches",
        "Says.content does not hold the proposition",
      );

      const asserted = [root, cheese, ground, fox, fall];
      Assert(asserted, located);
      assert(
        ask(asserted) === ground,
        "an Assertion holds the proposition",
      );

      const asResult = [root, cheese, ground, fox, fall, located];
      const result = new ResultsIn(root);
      result.event = fall;
      result.proposition = located;
      Assert(asResult, result);
      assert(
        ask(asResult) === ground,
        "an asserted ResultsIn holds its result content",
      );
    },
  },
  {
    name: "realize: only asserted Agents shape an event's wording",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      crow.name = "the crow";
      const fox = new Entity(root);
      fox.name = "the fox";
      const sing = new Sing(root);
      sing.manner = "her best";
      const input = [root, crow, fox, sing];
      Assert(input, makeAgent(root, sing, crow));
      input.push(makeAgent(root, sing, fox));
      AssertOccurs(input, sing);
      const answer = new Variable(root);
      const occurs = new Occurs(root);
      occurs.event = answer;
      input.push(answer, occurs);
      input.push(new Query(root, [answer]));
      input.push(
        new Imperative(root, KonsupuIdentity.Ref(), {
          kind: "answer",
          answer,
        }),
      );
      const [text] = Texts(Evaluate(input));
      assert(
        text === "the crow cawed her best",
        `unasserted Agent must not shape the wording, got "${text}"`,
      );
    },
  },
];

function BeforeOf(root, earlier, later) {
  const relation = new Before(root);
  relation.earlier = earlier;
  relation.later = later;
  return relation;
}

function CausesOf(root, cause, effect) {
  const relation = new Causes(root);
  relation.cause = cause;
  relation.effect = effect;
  return relation;
}

async function main() {
  let passed = 0;
  for (const test of Tests) {
    try {
      test.run();
      passed += 1;
      console.log(`PASS  ${test.name}`);
    } catch (caught) {
      console.log(`FAIL  ${test.name}`);
      console.log(caught.stack ?? String(caught));
    }
  }
  console.log(`Foundation/domain regression tests: ${passed}/${Tests.length} passed`);
  process.exit(passed === Tests.length ? 0 : 1);
}

const invokedDirectly =
  process.argv[1] !== undefined &&
  import.meta.url === pathToFileURL(process.argv[1]).href;
if (invokedDirectly) await main();
