import { SolveQuery } from "./Aesop/QuerySolver.js";
export function ResolveQuery(input, query, remaining, state) {
  return SolveQuery(input, query, remaining, state);
}
