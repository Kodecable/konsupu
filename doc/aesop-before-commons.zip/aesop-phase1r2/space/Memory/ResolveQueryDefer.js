export function ResolveQueryDefer(input, query, remaining, state) {
  // The story-world solver either produces bindings from visible structure
  // or throws a domain error naming the broken question. Nothing is left
  // for a deferred pass, so this entry stays a legal no-op.
  return new Map();
}
