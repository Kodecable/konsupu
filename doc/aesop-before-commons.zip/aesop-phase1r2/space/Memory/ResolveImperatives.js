import { AnswerImperatives } from "./Aesop/Answers.js";
export function ResolveImperatives(input, imperatives, remaining, state) {
  return AnswerImperatives(input, imperatives, remaining, state);
}
