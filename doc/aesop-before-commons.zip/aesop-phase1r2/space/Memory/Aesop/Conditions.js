// Condition propositions: states and claim contents that can hold in the
// world. They participate in Queries through "held" semantics: directly
// asserted, or carried as the result content of an asserted ResultsIn.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Where something is: fields entity, place.
export class LocatedAt extends Proposition {
  static BRAND = Brand("aesop:LocatedAt:v1");
  constructor(situated) {
    Final(LocatedAt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Suffering thirst: field subject.
export class Thirsty extends Proposition {
  static BRAND = Brand("aesop:Thirsty:v1");
  constructor(situated) {
    Final(Thirsty, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Not reachable by the story's actor: field subject.
export class OutOfReach extends Proposition {
  static BRAND = Brand("aesop:OutOfReach:v1");
  constructor(situated) {
    Final(OutOfReach, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Sleeping: field subject.
export class Asleep extends Proposition {
  static BRAND = Brand("aesop:Asleep:v1");
  constructor(situated) {
    Final(Asleep, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// No longer bound: field subject.
export class Free extends Proposition {
  static BRAND = Brand("aesop:Free:v1");
  constructor(situated) {
    Final(Free, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Amused by something: fields subject, at.
export class Tickled extends Proposition {
  static BRAND = Brand("aesop:Tickled:v1");
  constructor(situated) {
    Final(Tickled, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The flattery claim — voice outshining others: fields subject, others.
export class VoiceSurpasses extends Proposition {
  static BRAND = Brand("aesop:VoiceSurpasses:v1");
  constructor(situated) {
    Final(VoiceSurpasses, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The advice content — flatterers must not be trusted.
export class DistrustFlatterers extends Proposition {
  static BRAND = Brand("aesop:DistrustFlatterers:v1");
  constructor(situated) {
    Final(DistrustFlatterers, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
