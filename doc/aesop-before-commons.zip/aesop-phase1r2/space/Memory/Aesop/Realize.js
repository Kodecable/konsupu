// Realization: canonical English wording for answer values, composed from
// the lexicon and the value's own fields. Surface only — no world
// reasoning reads these strings, and the Query solver never consults it.
import { Entity } from "./Objects.js";
import "./Lexicon.js";
import { PhraseOf } from "./Phrases.js";

export function Realize(view, value, form = "past") {
  if (value instanceof Entity) return value.name;
  const phrase = PhraseOf(view, value);
  if (phrase === undefined) {
    throw new Error(`No realization for a ${value.constructor?.name}`);
  }
  if (form === "to-infinitive") {
    if (phrase.infinitive === null || phrase.infinitive === undefined) {
      throw new Error(`No infinitive for a ${value.constructor?.name}`);
    }
    return `to ${phrase.infinitive}`;
  }
  return [phrase.subject, phrase.past].filter(Boolean).join(" ");
}
