// Concrete agentive doings used by the lion and mouse story. Same kind of
// vocabulary as Actions.js; separate file only for the line budget.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Running over someone: field theme.
export class RunUpon extends Action {
  static BRAND = Brand("aesop:RunUpon:v1");
  constructor(situated) {
    Final(RunUpon, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Taking hold of: fields theme, instrument.
export class Seize extends Action {
  static BRAND = Brand("aesop:Seize:v1");
  constructor(situated) {
    Final(Seize, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Refraining from harming: field theme.
export class Spare extends Action {
  static BRAND = Brand("aesop:Spare:v1");
  constructor(situated) {
    Final(Spare, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Fastening with cords: fields theme, destination.
export class Tie extends Action {
  static BRAND = Brand("aesop:Tie:v1");
  constructor(situated) {
    Final(Tie, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Looking for something: field theme.
export class SearchFor extends Action {
  static BRAND = Brand("aesop:SearchFor:v1");
  constructor(situated) {
    Final(SearchFor, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Conveying: fields theme, destination.
export class Carry extends Action {
  static BRAND = Brand("aesop:Carry:v1");
  constructor(situated) {
    Final(Carry, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Happening to go past.
export class PassBy extends Action {
  static BRAND = Brand("aesop:PassBy:v1");
  constructor(situated) {
    Final(PassBy, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Biting through persistently: field theme.
export class Gnaw extends Action {
  static BRAND = Brand("aesop:Gnaw:v1");
  constructor(situated) {
    Final(Gnaw, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Assisting: field theme.
export class Help extends Action {
  static BRAND = Brand("aesop:Help:v1");
  constructor(situated) {
    Final(Help, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Consuming: field theme.
export class Eat extends Action {
  static BRAND = Brand("aesop:Eat:v1");
  constructor(situated) {
    Final(Eat, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
