// The Assertion layer: separates a Proposition object from a Situation
// treating it as holding. An Assertion is itself not a Proposition, so
// there is no regress; it is world content, like an Entity or an Event.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Occurs } from "./Relations.js";

// One occurrence means: the owning Situation holds `proposition` true.
export class Assertion extends SituatedNode {
  static BRAND = Brand("aesop:Assertion:v1");
  constructor(situated) {
    Final(Assertion, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Explicit fixture helper: push the proposition and its Assertion. Call
// sites must show that an assertion is being made; nothing asserts quietly.
export function Assert(input, proposition) {
  input.push(proposition);
  const assertion = new Assertion(proposition.situated);
  assertion.proposition = proposition;
  input.push(assertion);
  return proposition;
}

// Assert that an event actually happened. Events referenced only by goals,
// promises, or hypotheses never pass through here.
export function AssertOccurs(input, event) {
  const occurs = new Occurs(event.situated);
  occurs.event = event;
  return Assert(input, occurs);
}

// Whether `proposition` is held true in the perspective's visible
// cognition. Semantically: some visible Assertion names exactly this
// proposition object.
export function IsAsserted(view, proposition) {
  return view.Bindings(proposition).some((node) => {
    return node instanceof Assertion && node.proposition === proposition;
  });
}
