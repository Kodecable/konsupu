// Shared wording helper: the asserted agent's name for an event, used by
// both lexicon files. Reads only asserted Agent propositions.
import { IsAsserted } from "./Assertion.js";
import { Agent } from "./Relations.js";
import { Entity } from "./Objects.js";

export function agentName(view, event) {
  for (const node of view.Bindings(event)) {
    if (node instanceof Agent && node.action === event && IsAsserted(view, node)) {
      return node.actor instanceof Entity ? node.actor.name : undefined;
    }
  }
  return undefined;
}
