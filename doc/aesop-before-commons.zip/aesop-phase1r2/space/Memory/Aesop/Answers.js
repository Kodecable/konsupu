// Imperative handling: an answer Imperative carries
// { kind: "answer", answer: Variable, form: "past" | "to-infinitive" };
// the resolved value is realized from asserted story cognition and
// returned as one TextOutput per Imperative.
import { Perspective } from "../Foundation/Perspective.js";
import { Variable } from "../../Interface/Nodes.js";
import { TextOutput } from "../../Interface/Outputs.js";
import { Realize } from "./Realize.js";

export function AnswerApplicable(input, imperative) {
  const content = imperative.content;
  return (
    content !== null &&
    typeof content === "object" &&
    content.kind === "answer" &&
    content.answer instanceof Variable
  );
}

export function AnswerImperatives(input, imperatives, remaining, state) {
  const resolved = new Set();
  const outputs = [];
  for (const imperative of remaining) {
    const view = new Perspective(imperative, state);
    const value = view.Value(imperative.content.answer);
    outputs.push(
      new TextOutput(Realize(view, value, imperative.content.form ?? "past")),
    );
    resolved.add(imperative);
  }
  return { resolved, outputs };
}
