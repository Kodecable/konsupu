// The non-action realization lexicon: wording for conditions, claims, and
// events without agents. Surface only. This module owns the shared Lexicon
// map that Lexicon.js also registers into.
import {
  LocatedAt,
  Thirsty,
  OutOfReach,
  Asleep,
  Free,
  Tickled,
  VoiceSurpasses,
} from "./Conditions.js";
import { Says, Fall, Rise, Wake, GetTrapped } from "./Objects.js";
import { agentName } from "./Wording.js";

const Lexicon = new Map();

export function register(Type, make) {
  Lexicon.set(Type, make);
}

export function PhraseOf(view, value) {
  const make = Lexicon.get(value.constructor);
  if (make === undefined) return undefined;
  return make(view, value);
}

function entry(Type, make) {
  register(Type, make);
}

entry(LocatedAt, (v, n) => ({
  subject: null,
  past: `${n.entity.name} was in ${n.place.name}`,
  infinitive: null,
}));
entry(Thirsty, (v, n) => ({
  subject: null,
  past: `${n.subject.name} was thirsty`,
  infinitive: null,
}));
entry(OutOfReach, (v, n) => ({
  subject: null,
  past: `${n.subject.name} was out of reach`,
  infinitive: null,
}));
entry(Asleep, (v, n) => ({
  subject: null,
  past: `${n.subject.name} was asleep`,
  infinitive: null,
}));
entry(Free, (v, n) => ({
  subject: null,
  past: `${n.subject.name} was free`,
  infinitive: null,
}));
entry(Tickled, (v, n) => ({
  subject: null,
  past: `${n.subject.name} was tickled at ${n.at.name}`,
  infinitive: null,
}));
entry(VoiceSurpasses, (v, n) => ({
  subject: null,
  past: `${n.subject.name}'s voice surpassed that of ${n.others.name}`,
  infinitive: null,
}));
entry(Says, (v, n) => ({
  subject: agentName(v, n),
  past: `said: "${n.text}"`,
  infinitive: null,
}));
entry(Fall, (v, n) => ({
  subject: n.theme.name,
  past: `fell to ${n.destination.name}`,
  infinitive: `fall to ${n.destination.name}`,
}));
entry(Rise, (v, n) => ({
  subject: n.theme.name,
  past: "mounted up",
  infinitive: "mount up",
}));
entry(Wake, (v, n) => ({
  subject: n.theme.name,
  past: "wakened",
  infinitive: "waken",
}));
entry(GetTrapped, (v, n) => ({
  subject: n.theme.name,
  past: `got caught in ${n.location.name}`,
  infinitive: `get caught in ${n.location.name}`,
}));
