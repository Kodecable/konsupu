// The action realization lexicon. Surface only — the Query solver never
// reads these strings. Conditions and non-agentive events live in
// Phrases.js; both register into one Lexicon map.
import {
  ComeUpon,
  Put,
  TryToDrink,
  ThinkUp,
  Drop,
  Quench,
  Save,
  FlyOff,
  Settle,
  WalkUpTo,
  Sing,
  SnapUp,
} from "./Actions.js";
import {
  RunUpon,
  Seize,
  Spare,
  Tie,
  SearchFor,
  Carry,
  PassBy,
  Gnaw,
  Help,
  Eat,
} from "./Deeds.js";
import { register } from "./Phrases.js";
import { agentName } from "./Wording.js";

function entry(Type, make) {
  register(Type, make);
}

entry(ComeUpon, (v, n) => ({
  subject: agentName(v, n),
  past: `came upon ${n.theme.name}`,
  infinitive: `come upon ${n.theme.name}`,
}));
entry(Put, (v, n) => ({
  subject: agentName(v, n),
  past: `put ${n.theme.name} into ${n.destination.name}`,
  infinitive: `put ${n.theme.name} into ${n.destination.name}`,
}));
entry(TryToDrink, (v, n) => ({
  subject: agentName(v, n),
  past: `tried to drink ${n.theme.name}`,
  infinitive: `try to drink ${n.theme.name}`,
}));
entry(ThinkUp, (v, n) => ({
  subject: agentName(v, n),
  past: "hit upon a thought",
  infinitive: "hit upon a thought",
}));
entry(Drop, (v, n) => ({
  subject: agentName(v, n),
  past: `dropped ${n.theme.name} into ${n.destination.name}`,
  infinitive: `drop ${n.theme.name} into ${n.destination.name}`,
}));
entry(Quench, (v, n) => ({
  subject: agentName(v, n),
  past: `quenched ${n.theme.name}`,
  infinitive: `quench ${n.theme.name}`,
}));
entry(Save, (v, n) => ({
  subject: agentName(v, n),
  past: `saved ${n.theme.name}`,
  infinitive: `save ${n.theme.name}`,
}));
entry(FlyOff, (v, n) => ({
  subject: agentName(v, n),
  past: `flew off with ${n.theme.name}`,
  infinitive: `fly off with ${n.theme.name}`,
}));
entry(Settle, (v, n) => ({
  subject: agentName(v, n),
  past: `settled on ${n.location.name}`,
  infinitive: `settle on ${n.location.name}`,
}));
entry(WalkUpTo, (v, n) => ({
  subject: agentName(v, n),
  past: `walked up to ${n.destination.name}`,
  infinitive: `walk up to ${n.destination.name}`,
}));
entry(Sing, (v, n) => ({
  subject: agentName(v, n),
  past: `cawed ${n.manner ?? "her best"}`,
  infinitive: `caw ${n.manner ?? "her best"}`,
}));
entry(SnapUp, (v, n) => ({
  subject: agentName(v, n),
  past: `snapped up ${n.theme.name}`,
  infinitive: `snap up ${n.theme.name}`,
}));
entry(RunUpon, (v, n) => ({
  subject: agentName(v, n),
  past: `ran up and down upon ${n.theme.name}`,
  infinitive: `run up and down upon ${n.theme.name}`,
}));
entry(Seize, (v, n) => ({
  subject: agentName(v, n),
  past: `seized ${n.theme.name} with ${n.instrument.name}`,
  infinitive: `seize ${n.theme.name} with ${n.instrument.name}`,
}));
entry(Spare, (v, n) => ({
  subject: agentName(v, n),
  past: `spared ${n.theme.name}`,
  infinitive: `spare ${n.theme.name}`,
}));
entry(Tie, (v, n) => ({
  subject: agentName(v, n),
  past: `tied ${n.theme.name} to ${n.destination.name}`,
  infinitive: `tie ${n.theme.name} to ${n.destination.name}`,
}));
entry(SearchFor, (v, n) => ({
  subject: agentName(v, n),
  past: `went in search of ${n.theme.name}`,
  infinitive: `go in search of ${n.theme.name}`,
}));
entry(Carry, (v, n) => ({
  subject: agentName(v, n),
  past: `carried ${n.theme.name} to ${n.destination.name}`,
  infinitive: `carry ${n.theme.name} to ${n.destination.name}`,
}));
entry(PassBy, (v, n) => ({
  subject: agentName(v, n),
  past: "passed by",
  infinitive: "pass by",
}));
entry(Gnaw, (v, n) => ({
  subject: agentName(v, n),
  past: `gnawed away ${n.theme.name}`,
  infinitive: `gnaw away ${n.theme.name}`,
}));
entry(Help, (v, n) => ({
  subject: agentName(v, n),
  past: `helped ${n.theme.name}`,
  infinitive: `help ${n.theme.name}`,
}));
entry(Eat, (v, n) => ({
  subject: agentName(v, n),
  past: `ate ${n.theme.name}`,
  infinitive: `eat ${n.theme.name}`,
}));
