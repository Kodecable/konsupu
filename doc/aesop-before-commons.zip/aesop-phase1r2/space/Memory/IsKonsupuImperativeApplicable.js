import { AnswerApplicable } from "./Aesop/Answers.js";
export function IsKonsupuImperativeApplicable(input, imperative, state) {
  return AnswerApplicable(input, imperative);
}
