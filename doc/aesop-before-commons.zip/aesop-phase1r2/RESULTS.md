# Konsupu Aesop Phase 1r2 — 结果记录

以 `run/aesop-phase1/`（r1）为基线的语义框架重构轮。运行方式：

```sh
node regression.mjs   # 19/19 passed
node run.mjs          # Foundation/domain regression tests: 19/19 passed
                      # Aesop questions: 15/15 passed
```

不经过 Konsupu Runtime / Translation / Learning；Foundation 为冻结 substrate
（`space/Memory/Foundation/`、`space/Test*`、`space/Resolve.js` 与
`src/foundation/` 逐字节一致，零修改）。

## 答案一致性

原 15 个问题的 **expected answer 与 actual 逐字符一致**（在
`run.mjs` 归一化比较之外，另行做了严格 `===` 核对：15/15 byte-identical）。
问题文本、expected answer、三篇故事选择均未改动。

## Regression 结果（19 项）

| 组 | 测试 | 结果 |
|---|---|---|
| 正确性继承 | identity: identical declarations are distinct Nodes | PASS |
| 正确性继承 | identity: repeated Variable must not unify distinct Nodes | PASS |
| 正确性继承 | undefined: a bound undefined conflicts with later bindings | PASS |
| 正确性继承 | undefined: Map keeps [X, undefined] as a binding | PASS |
| 分层 | world objects, events, and propositions separate | PASS |
| 分层 | Event and Action are abstract | PASS |
| 发生 | an event without asserted Occurs did not happen | PASS |
| 发生 | an asserted Occurs answers what happened | PASS |
| 断言 | an unasserted Causes is not a story fact | PASS |
| 断言 | an asserted Causes satisfies the same question | PASS |
| 言语事件 | a speech event is a first-class event argument | PASS |
| 未发生事件 | a goal objective is discussable, not occurred | PASS |
| 模式 | a question proposition is never a story fact | PASS |
| 字段真源 | a question event reads the occurred event's field | PASS |
| Agent join | an unknown action and its agent join through Agent | PASS |
| 无上溯 | a nested question solves by its own class | PASS |
| 无上溯 | a wrapper rescues nothing by itself | PASS |
| 邻接语义 | same mention, three different meanings | PASS |
| realization | only asserted Agents shape an event's wording | PASS |

## 15 个问题结果

全部 PASS（文本与 r1 相同，此处仅列求解机制的变化）：

- Q1 类（S1Q1/S3Q1）：question `Agent{action: 事件, actor: V}`，锚定具体事件。
- Q2/Q4 类（时序）：question `Before{earlier: 事件, later: V}`。
- Q3 类（因果）：question `Causes{cause: V, effect: 事件}`。
- S1Q5（结果状态）：question `LocatedAt{entity: pebble, place: V}`，held
  语义从被 assert 的 `ResultsIn` 内容中取候选。
- S2Q1（theme 字段直读）：question 是一个未发生的 `Fall{theme: V}` 事件，
  与已发生的 Fall 按"occurred + 字段匹配"求解——无 EventTheme 关系。
- S2Q3：question `Believes{believer: crow, proposition: V}`，答案是被相信
  的 `VoiceSurpasses` 命题对象。
- S2Q4/S3Q5：question `Goal{actor, objective: V}` + to-infinitive realization。
- S2Q5（联合）：question `Causes{cause: E, effect: dropCheese}` +
  `Agent{action: E, actor: V}`，E 与 V 在同一 Query 内 join。
- S3Q3：question `Motivates{driver: V, action: spare}`，答案为 `Tickled` 命题。
- S3Q4：question `Promise{promiser: mouse, deed: V}` + 不定式。

## Cognition classes 变化

### 删除（相对 r1）

- `Role`、`State`、`Claim`、`Initially`、`Becomes`、`Utterance` 六个
  generic/stringly 类型整体删除；
- `Action.kind`、`Role.role`、`State.attribute`、`Claim.attribute`、
  `Utterance.kind` 全部消失；`Action.verb` 从语义核心移入 realization 层。

### 新增

- 世界对象：`Entity`（仅 `name` 表层串）；abstract `Event`；abstract
  `Action`；`Says extends Action`（fields: `content`、`text`）。
- 非 Action Event：`Fall`、`Rise`、`Wake`、`GetTrapped`（theme/destination/
  location 为 intrinsic 字段；无 agent）。
- Action 子类（22 个）：`ComeUpon Put TryToDrink ThinkUp Drop Quench Save`
  / `FlyOff Settle WalkUpTo Sing SnapUp` / `RunUpon Seize Spare Tie
  SearchFor Carry PassBy Gnaw Help Eat`（r1 的 `CastIn` 并入 `Drop`，
  `Lift` 作为无下游作用的色彩动作删除）。
- 关系命题：`Occurs`、`Agent`（reified 施事关系）、`Before`、`Causes`、
  `ResultsIn`、`Failed`、`Goal`、`InOrderTo` + `Motivates`、`Promise`、
  `Believes`、`Veracity`。
- 条件命题：`LocatedAt`、`Thirsty`、`OutOfReach`、`Asleep`、`Free`、
  `Tickled`、`VoiceSurpasses`、`DistrustFlatterers`。
- realization 层：`Realize` / `Lexicon` / `Phrases` / `Wording`（solver
  不读取）。

### 表示法约定

- 施事：**只有** `Agent(action, actor)` 命题，事件类无 agent 字段（无双重
  表示）；
- theme/destination/instrument/location/source/manner：**只有** 具体
  Event/Action 类的字段，不存在等价关系 Node（无双重表示）；
- 条件的"成立"：直接 `Assert(P)`（叙事时点起成立），或被 assert 的
  `ResultsIn(event, P)`（事件结果）；`Says.content` 永不成立。

## Solver 结构

- `QuerySolver.js`：对每个剩余 Variable 取 `Bindings(variable)` 的直接
  mentioner，逐个交给 `QuestionTuples` 解释并 join；无上溯、无 AST 假设。
- `Search.js`：按语义类别分派——question Event → occurred 同类事件
  （字段子集匹配）；question 关系命题 → 被 assert 的同类命题（字段全集
  匹配）；question 条件命题 → held 同类命题（直接 assert 或被 assert 的
  ResultsIn 内容）。`Occurred` 与 `heldOf` 都是有明确语义的领域判定。
- `Match.js`：纯机械助手（fieldsOf、sameValue、BindFields、join）。
