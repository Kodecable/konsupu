// Five questions over the Fox-and-the-Crow cognition. Constraints are held
// by the asked Situation; Q1 asks through a Fall description with an
// unknown theme (the field is the canonical representation, matched via
// Among); Q4 describes a getting with the open Get class; Q5 joins an
// unknown causing event with its unknown agent. Expected answers are
// machine projections of the resolved values; the English `text` is for
// human comparison only and never reaches the resolver.
import {
  About,
  Agent,
  Among,
  Assert,
  AssertOccurs,
  Believes,
  Causes,
  Fall,
  Get,
  Goal,
  Next,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: "What fell to the ground?",
    expected: "Entity(the cheese)",
    // "to the ground" constrains the fall's destination; the theme is the
    // unknown, read through the description's own field.
    build(input, asked, world, answer) {
      const f = new Fall(asked);
      f.destination = world.ground;
      f.theme = answer;
      input.push(f);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = f;
      Assert(input, h);
      AssertOccurs(input, f);
    },
  },
  {
    text: "What happened when the crow began to sing?",
    expected: "Fall(destination=Entity(the ground),theme=Entity(the cheese))",
    // "when" asks what followed the singing at once.
    build(input, asked, world, answer) {
      const when = new Next(asked);
      when.earlier = world.sing;
      when.later = answer;
      Assert(input, when);
    },
  },
  {
    text: "What did the crow believe about her voice?",
    expected: "VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))",
    // "about her voice" is the belief content's topic.
    build(input, asked, world, answer) {
      const belief = new Believes(asked);
      belief.believer = world.crow;
      belief.proposition = answer;
      Assert(input, belief);
      const about = new About(asked);
      about.proposition = answer;
      about.topic = world.voice;
      Assert(input, about);
    },
  },
  {
    text: "What did the fox want to get?",
    expected: "Entity(the cheese)",
    // The asked object of "get" is the getting's theme; the open Get class
    // describes it without deciding how the story words the seizing.
    build(input, asked, world, answer) {
      const g = new Get(asked);
      g.theme = answer;
      input.push(g);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = g;
      Assert(input, h);
      const want = new Goal(asked);
      want.actor = world.fox;
      want.objective = g;
      Assert(input, want);
    },
  },
  {
    text: "Who made the cheese fall?",
    expected: "Entity(the crow)",
    build(input, asked, world, answer) {
      const event = new Variable(asked);
      input.push(event);
      const cause = new Causes(asked);
      cause.cause = event;
      cause.effect = world.dropCheese;
      Assert(input, cause);
      const who = new Agent(asked);
      who.action = event;
      who.actor = answer;
      Assert(input, who);
      return [event];
    },
  },
];
