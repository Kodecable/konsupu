// BuildStory for "The Fox and the Crow". Speaking is an Action (Says) with
// a reified agent; the flattery claim is a real proposition referenced by
// Says.content, Believes, and Veracity — but only the Assertion layer makes
// anything hold. The crow's voice is an individual in its own right, and
// the claim is explicitly about it. The cheese's fall is a non-agentive
// Fall with the cheese as theme; the chain asserts adjacent Next only.
import {
  About,
  Agent,
  Assert,
  AssertOccurs,
  Believes,
  Causes,
  Entity,
  Fall,
  FlyOff,
  Goal,
  InOrderTo,
  LocatedAt,
  Motivates,
  Next,
  ResultsIn,
  Says,
  Settle,
  Sing,
  SnapUp,
  Veracity,
  VoiceSurpasses,
  DistrustFlatterers,
  WalkUpTo,
} from "../../space/Interface/Aesop.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const fox = entity(root, "the fox");
  const crow = entity(root, "the crow");
  const voice = entity(root, "the crow's voice");
  const cheese = entity(root, "the cheese");
  const branch = entity(root, "a branch of the tree");
  const footOfTree = entity(root, "the foot of the tree");
  const ground = entity(root, "the ground");
  const jaws = entity(root, "the fox's jaws");
  const otherBirds = entity(root, "other birds");
  input.push(
    fox, crow, voice, cheese, branch, footOfTree, ground, jaws, otherBirds,
  );

  // Speech content: propositions that exist without being held.
  const claimVoice = new VoiceSurpasses(root);
  claimVoice.subject = crow;
  claimVoice.others = otherBirds;
  const advice = new DistrustFlatterers(root);
  input.push(claimVoice, advice);
  // The claim concerns her voice — its topic.
  const claimTopic = new About(root);
  claimTopic.proposition = claimVoice;
  claimTopic.topic = voice;
  Assert(input, claimTopic);

  const flyOff = new FlyOff(root);
  flyOff.theme = cheese;
  const settle = new Settle(root);
  settle.location = branch;
  const approach = new WalkUpTo(root);
  approach.destination = footOfTree;
  const greet = new Says(root);
  greet.text = "Good-day, Mistress Crow. How well you are looking to-day.";
  const flatter = new Says(root);
  flatter.text =
    "How glossy your feathers; how bright your eye; I feel sure your voice must surpass that of other birds.";
  flatter.content = claimVoice;
  const request = new Says(root);
  request.text =
    "Let me hear but one song from you, that I may greet you as the Queen of Birds.";
  const sing = new Sing(root);
  sing.manner = "her best";
  const dropCheese = new Fall(root);
  dropCheese.theme = cheese;
  dropCheese.destination = ground;
  const snapUp = new SnapUp(root);
  snapUp.theme = cheese;
  const gloat = new Says(root);
  gloat.text =
    "That will do. That was all I wanted. In exchange for your cheese I will give you a piece of advice for the future.";
  const advise = new Says(root);
  advise.text = "Do not trust flatterers.";
  advise.content = advice;
  const chain = [
    flyOff,
    settle,
    approach,
    greet,
    flatter,
    request,
    sing,
    dropCheese,
    snapUp,
    gloat,
    advise,
  ];
  input.push(...chain);
  for (const event of chain) AssertOccurs(input, event);

  agent(root, input, flyOff, crow);
  agent(root, input, settle, crow);
  agent(root, input, approach, fox);
  agent(root, input, greet, fox);
  agent(root, input, flatter, fox);
  agent(root, input, request, fox);
  agent(root, input, sing, crow);
  agent(root, input, snapUp, fox);
  agent(root, input, gloat, fox);
  agent(root, input, advise, fox);

  for (let index = 0; index + 1 < chain.length; index += 1) {
    next(root, input, chain[index], chain[index + 1]);
  }

  const singingCaused = new Causes(root);
  singingCaused.cause = sing;
  singingCaused.effect = dropCheese;
  Assert(input, singingCaused);

  const cheeseOnGround = new LocatedAt(root);
  cheeseOnGround.entity = cheese;
  cheeseOnGround.place = ground;
  input.push(cheeseOnGround);
  const fallResult = new ResultsIn(root);
  fallResult.event = dropCheese;
  fallResult.proposition = cheeseOnGround;
  Assert(input, fallResult);

  const cheeseInJaws = new LocatedAt(root);
  cheeseInJaws.entity = cheese;
  cheeseInJaws.place = jaws;
  input.push(cheeseInJaws);
  const snapResult = new ResultsIn(root);
  snapResult.event = snapUp;
  snapResult.proposition = cheeseInJaws;
  Assert(input, snapResult);

  const goal = new Goal(root);
  goal.actor = fox;
  goal.objective = snapUp;
  Assert(input, goal);
  const flatteryAimed = new InOrderTo(root);
  flatteryAimed.action = flatter;
  flatteryAimed.goal = sing;
  Assert(input, flatteryAimed);

  const believedPraise = new Believes(root);
  believedPraise.believer = crow;
  believedPraise.proposition = claimVoice;
  Assert(input, believedPraise);
  const claimFalse = new Veracity(root);
  claimFalse.proposition = claimVoice;
  claimFalse.truth = false;
  Assert(input, claimFalse);
  const praiseMoved = new Motivates(root);
  praiseMoved.driver = believedPraise;
  praiseMoved.action = sing;
  Assert(input, praiseMoved);

  return {
    root,
    fox,
    crow,
    voice,
    cheese,
    ground,
    sing,
    dropCheese,
    snapUp,
  };
}
