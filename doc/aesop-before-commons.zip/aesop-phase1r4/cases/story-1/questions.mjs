// Five questions over the Crow-and-the-Pitcher cognition. Every question
// is expressed as constraints the asked Situation HOLDS (Assert), never as
// unasserted templates; story individuals are referenced directly only
// where the story has a single instance, and a description plus an Among
// correspondence carries "a/the ... one" where the story has several.
// Expected answers are machine projections of the resolved values; the
// English `text` is for human comparison only and never reaches the
// resolver.
import {
  About,
  Agent,
  Among,
  Assert,
  AssertOccurs,
  Before,
  Causes,
  Drop,
  Enables,
  Fall,
  Get,
  Goal,
  LocatedAt,
  Motivates,
  Next,
  Promise,
  ResultsIn,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: "Who dropped a pebble into the pitcher?",
    expected: "Entity(the crow)",
    // "a pebble ... into the pitcher" describes the doing; the story has
    // three Drops, so the description leaves the theme open and Among carries the
    // correspondence; the actor is unique either way.
    build(input, asked, world, answer) {
      const d = new Drop(asked);
      d.destination = world.pitcher;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = answer;
      Assert(input, who);
    },
  },
  {
    text: "What happened after the crow put its beak into the pitcher?",
    expected: "TryToDrink(theme=Entity(the water))",
    // "after" asks for the narrative sequel: the immediate Next.
    build(input, asked, world, answer) {
      const next = new Next(asked);
      next.earlier = world.putBeak;
      next.later = answer;
      Assert(input, next);
    },
  },
  {
    text: "Why did the water mount up?",
    expected:
      "Series(parts=[Drop(destination=Entity(the pitcher),theme=Entity(a pebble)),Drop(destination=Entity(the pitcher),theme=Entity(the other pebbles))])",
    // The cause is the dropping as a whole; no single Drop is credited.
    build(input, asked, world, answer) {
      const why = new Causes(asked);
      why.cause = answer;
      why.effect = world.waterRise;
      Assert(input, why);
    },
  },
  {
    text: "What was the crow able to do after the water mounted up?",
    expected: "Quench(theme=Entity(its thirst))",
    // "able to" is the enabling; "after" is plain temporal order here: the
    // text puts the casting of more pebbles between the rise and the
    // drinking, so the drinking is not the immediate Next.
    build(input, asked, world, answer) {
      const able = new Enables(asked);
      able.enabler = world.waterRise;
      able.enabled = answer;
      Assert(input, able);
      const after = new Before(asked);
      after.earlier = world.waterRise;
      after.later = answer;
      Assert(input, after);
    },
  },
  {
    text: "Where did the pebble end up after the crow dropped it?",
    expected: "Entity(the pitcher)",
    // The asked holds the result-state itself: dropping the pebble (the one
    // the story drops first — theme pins it) resulted in it being somewhere.
    build(input, asked, world, answer) {
      const d = new Drop(asked);
      d.theme = world.pebble;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const ended = new LocatedAt(asked);
      ended.entity = world.pebble;
      ended.place = answer;
      input.push(ended);
      const result = new ResultsIn(asked);
      result.event = d;
      result.proposition = ended;
      Assert(input, result);
    },
  },
];
