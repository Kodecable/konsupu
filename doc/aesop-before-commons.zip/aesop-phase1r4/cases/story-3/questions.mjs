// Five questions over the Lion-and-the-Mouse cognition. Constraints are
// held by the asked Situation. Expected answers are machine projections of
// the resolved values; the English `text` is for human comparison only and
// never reaches the resolver.
import {
  Agent,
  Assert,
  Goal,
  InOrderTo,
  Motivates,
  Next,
  Promise,
} from "../../space/Interface/Aesop.js";

export const Questions = [
  {
    text: "Who gnawed away the ropes?",
    expected: "Entity(the mouse)",
    build(input, asked, world, answer) {
      const who = new Agent(asked);
      who.action = world.gnaw;
      who.actor = answer;
      Assert(input, who);
    },
  },
  {
    text: "What did the hunters do after the lion got caught in the trap?",
    expected: "Tie(destination=Entity(the tree),theme=Entity(the lion))",
    // "the hunters" constrains the doer; "after" the immediate successor of
    // the trapping.
    build(input, asked, world, answer) {
      const next = new Next(asked);
      next.earlier = world.getTrapped;
      next.later = answer;
      Assert(input, next);
      const who = new Agent(asked);
      who.action = answer;
      who.actor = world.hunters;
      Assert(input, who);
    },
  },
  {
    text: "Why did the lion spare the mouse?",
    expected: "Tickled(at=Entity(the mouse's offer),subject=Entity(the lion))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked);
      why.driver = answer;
      why.action = world.spare;
      Assert(input, why);
    },
  },
  {
    text: "What did the mouse promise to do for the lion?",
    expected: "Help(theme=Entity(the lion))",
    // "for the lion" needs no extra beneficiary cognition: the promised deed
    // is a single instance and helping takes its beneficiary as theme, so
    // the answer itself carries it.
    build(input, asked, world, answer) {
      const promise = new Promise(asked);
      promise.promiser = world.mouse;
      promise.deed = answer;
      Assert(input, promise);
    },
  },
  {
    text: "Why did the hunters tie the lion to the tree?",
    expected: "Carry(destination=Entity(the king),theme=Entity(the lion))",
    // The tie-up itself, not just its actor, anchors the question.
    build(input, asked, world, answer) {
      const why = new InOrderTo(asked);
      why.action = world.tieUp;
      why.goal = answer;
      Assert(input, why);
    },
  },
];
