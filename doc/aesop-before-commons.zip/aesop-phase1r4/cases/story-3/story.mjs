// BuildStory for "The Lion and the Mouse". Wake and GetTrapped are
// non-agentive events happening to the lion; the sayings are Actions. The
// intended and promised doings — eating the mouse, carrying the lion,
// helping — exist without occurring. The chain asserts adjacent Next only.
import {
  Agent,
  Asleep,
  Assert,
  AssertOccurs,
  Carry,
  Causes,
  Eat,
  Entity,
  Free,
  GetTrapped,
  Gnaw,
  Goal,
  Help,
  InOrderTo,
  Motivates,
  Next,
  PassBy,
  Promise,
  ResultsIn,
  RunUpon,
  Says,
  SearchFor,
  Seize,
  Spare,
  Tickled,
  Tie,
  Wake,
} from "../../space/Interface/Aesop.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const lion = entity(root, "the lion");
  const mouse = entity(root, "the mouse");
  const hunters = entity(root, "the hunters");
  const trap = entity(root, "the trap");
  const tree = entity(root, "the tree");
  const rope = entity(root, "the ropes");
  const king = entity(root, "the king");
  const paw = entity(root, "his huge paw");
  const waggon = entity(root, "a waggon");
  const offer = entity(root, "the mouse's offer");
  input.push(lion, mouse, hunters, trap, tree, rope, king, paw, waggon, offer);

  const asleep = new Asleep(root);
  asleep.subject = lion;
  Assert(input, asleep);

  const plead = new Says(root);
  plead.text =
    "Pardon, O King. Forgive me this time, I shall never forget it: who knows but what I may be able to do you a turn some of these days?";
  const taunt = new Says(root);
  taunt.text = "Was I not right?";

  const runOver = new RunUpon(root);
  runOver.theme = lion;
  const wake = new Wake(root);
  wake.theme = lion;
  const seize = new Seize(root);
  seize.theme = mouse;
  seize.instrument = paw;
  const spare = new Spare(root);
  spare.theme = mouse;
  const getTrapped = new GetTrapped(root);
  getTrapped.theme = lion;
  getTrapped.location = trap;
  const tieUp = new Tie(root);
  tieUp.theme = lion;
  tieUp.destination = tree;
  const searchWaggon = new SearchFor(root);
  searchWaggon.theme = waggon;
  const passBy = new PassBy(root);
  const gnaw = new Gnaw(root);
  gnaw.theme = rope;
  const happened = [
    runOver,
    wake,
    seize,
    plead,
    spare,
    getTrapped,
    tieUp,
    searchWaggon,
    passBy,
    gnaw,
    taunt,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  // Intended or promised only; never asserted as occurred.
  const eatMouse = new Eat(root);
  eatMouse.theme = mouse;
  const carryLion = new Carry(root);
  carryLion.theme = lion;
  carryLion.destination = king;
  const helpLion = new Help(root);
  helpLion.theme = lion;
  input.push(eatMouse, carryLion, helpLion);

  agent(root, input, runOver, mouse);
  agent(root, input, seize, lion);
  agent(root, input, spare, lion);
  agent(root, input, tieUp, hunters);
  agent(root, input, searchWaggon, hunters);
  agent(root, input, passBy, mouse);
  agent(root, input, gnaw, mouse);
  agent(root, input, plead, mouse);
  agent(root, input, taunt, mouse);
  agent(root, input, eatMouse, lion);
  agent(root, input, carryLion, hunters);
  agent(root, input, helpLion, mouse);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  const runningWoke = new Causes(root);
  runningWoke.cause = runOver;
  runningWoke.effect = wake;
  Assert(input, runningWoke);

  const tickled = new Tickled(root);
  tickled.subject = lion;
  tickled.at = offer;
  Assert(input, tickled);
  const amusementMoved = new Motivates(root);
  amusementMoved.driver = tickled;
  amusementMoved.action = spare;
  Assert(input, amusementMoved);

  const freed = new Free(root);
  freed.subject = lion;
  input.push(freed);
  const gnawResult = new ResultsIn(root);
  gnawResult.event = gnaw;
  gnawResult.proposition = freed;
  Assert(input, gnawResult);

  const wantedMeal = new Goal(root);
  wantedMeal.actor = lion;
  wantedMeal.objective = eatMouse;
  Assert(input, wantedMeal);
  const wantedDelivery = new Goal(root);
  wantedDelivery.actor = hunters;
  wantedDelivery.objective = carryLion;
  Assert(input, wantedDelivery);
  const tyingAimed = new InOrderTo(root);
  tyingAimed.action = tieUp;
  tyingAimed.goal = carryLion;
  Assert(input, tyingAimed);
  const promisedHelp = new Promise(root);
  promisedHelp.promiser = mouse;
  promisedHelp.deed = helpLion;
  Assert(input, promisedHelp);

  return {
    root,
    lion,
    mouse,
    hunters,
    spare,
    getTrapped,
    tieUp,
    gnaw,
  };
}
