# Konsupu Aesop Phase 1r4 — 结果记录

以 `run/aesop-phase1r3/`（r3）为直接基线、按 Foundation 语义重新表达"提问"
与"求解"的一轮。运行方式：

```sh
node regression.mjs   # 42/42 passed
node run.mjs          # Foundation/domain regression tests: 42/42 passed
                      # Aesop questions: 15/15 passed
```

不经过 Konsupu Runtime / Translation / Learning；Foundation 为冻结 substrate
（`space/Memory/Foundation/`、`space/Test*`、`space/Resolve.js` 与
`src/foundation/` 逐字节一致，且由最后一项回归在运行时持续核对；零修改）。
r1/r2/r3 目录原样保留且各自仍全绿。

## r3 的三个问题在本轮的消除方式

1. **"未断言且含 Variable"当约束（question template）**：已删除。约束现在
   只是 asked Situation **持有**的命题（Assertion），未断言的 Node 无论含
   什么 Variable 都不构成约束（回归 `constraints: an unasserted Node binds
   nothing`；变异验证：约束收集退化为"所有 Node"时 18 项回归失败）。
   r3 的 `requested()` 排除规则与 question-Event 模板规则一并删除——三层
   结构下回复 Says 位于 dialogue，对 asked 求解结构性不可见（回归
   `reply: the dialogue Says is invisible`，含 Perspective 级断言），不再
   需要任何补丁。
2. **提问翻译丢失原文约束**：15 题全部按原文重译（见下表）；认知不足则补
   （voice 个体 + `About`、`Enables`、`Next`、`Get` 开放类、hunters/tie
   约束等）。
3. **相邻 Before 的数据巧合**：故事改断言相邻事件的 `Next`；`Before` 是
   Next 链传递推出的领域推理，不再枚举。"after/when" 类问题按原文语义
   （叙事后继）用 `Next`，答案唯一（回归 `temporal: Next keeps
   after-questions unique; Before is derived` 同时验证 Before 派生的
   多解形态）。

## Situation 结构（每个 case）

```text
[dialogue, story, …故事事实…, asked, …问题约束(被持有)…, Query(asked),
 Asks(dialogue){story, asked}, Query(dialogue,[ref(asked, answer)]),
 Says(dialogue){content=ref(asked, answer)},
 Imperative(dialogue, KonsupuIdentity.Ref(), says)]
```

- dialogue 是 Input 首个 Situation（Analyze 仅豁免第一个的 semantic
  mention），其成员节点因"引用指向更早出现"只能排在 story 树之后——
  交错布局是结构必然，不是风格选择；`Asks` 以普通字段提及 story 与
  asked（Situation 引用不受跨 Situation ref 规则约束，仅需位置更早）。
- story 与 dialogue 无共同祖先：dialogue 不能直接引用故事 Node（回归
  `structure: dialogue cannot reference a story Node directly` 断言 Analyze
  以 "Cross-Situation cognition requires ref" 拒绝），只能经
  `ref(asked, answer)` 取值；asked 的祖先链不含 dialogue。
- dialogue 的 re-export Query 被 PlanQueries 判为 `source.query !== query`
  而 remaining 为空，QueryLoop 不调用 resolver——纯重导出零成本。
- asked 是故事的细化：继承全部故事事实，预设只存在于 asked。

## 15 题逐题翻译与 expected 变化

问题文本不变。expected 有两处变化：S2Q4（指导明文规定）与 S1Q3（第二次
审查后修正 story-1，见文末）；其余 13 题与 r3 逐字符一致。

| 题 | asked 持有的约束 | expected |
|---|---|---|
| S1Q1 | `Drop`描述{destination: pitcher} + `Among` + `Occurs` + `Agent(d, x)`；两次 Drop 都匹配，施事唯一 | 不变 |
| S1Q2 | `Next(putBeak, x)`（putBeak 单例直引） | 不变 |
| S1Q3 | `Causes(x, waterRise)` | **改为 `Series(parts=[Drop(...a pebble), Drop(...the other pebbles)])`**（第二次审查后：水位由逐颗投石整体造成，不归于第一颗） |
| S1Q4 | `Enables(waterRise, x)` + `Before(waterRise, x)`（故事新增 Enables 断言；第二次审查后由 `Next` 改为 `Before`） | 不变 |
| S1Q5 | `Drop`描述{theme: pebble} + `Among` + `Occurs` + `ResultsIn(d, LocatedAt(pebble, x))` | 不变 |
| S2Q1 | `Fall`描述{destination: ground, theme: x} + `Among` + `Occurs` | 不变 |
| S2Q2 | `Next(sing, x)`（"when"＝紧接着发生的事） | 不变 |
| S2Q3 | `Believes(crow, x)` + `About(x, voice)`（故事新增 voice 个体与 About 断言） | 不变 |
| S2Q4 | `Get`描述{theme: x} + `Among` + `Goal(fox, g)`（`Get` 为 concrete 非 final，`SnapUp extends Get`） | **改为 `Entity(the cheese)`**（r3 答的是事件，丢失"get 的宾语"；指导规定） |
| S2Q5 | `Causes(e, dropCheese)` + `Agent(e, x)`，e 为 Query 内未知事件 | 不变 |
| S3Q1 | `Agent(gnaw, x)` | 不变 |
| S3Q2 | `Next(getTrapped, x)` + `Agent(x, hunters)`（r3 丢失 hunters） | 不变 |
| S3Q3 | `Motivates(x, spare)` | 不变 |
| S3Q4 | `Promise(mouse, x)`（"for the lion"判断：单例 Promise + `Help.theme` 即受益者，无需新认知，理由见 FRAMEWORK_NOTES） | 不变 |
| S3Q5 | `InOrderTo(tieUp, x)`（r3 误用 Goal{hunters, x}，丢失 tie） | 不变 |

## 求解语义

- **约束只来自持有**：`ResolveQuery` 以 asked 的 Assertion 为约束集；支持
  池来自祖先链（story）持有的命题（`heldAbove` 遍历 `view.Ancestors()`，
  修正了 r3 `view.Nodes()` 只看当前 Situation 的范围）。
- **由祖先蕴含**：被持有的 `Among` 点名的 asked Node 是描述（按类+已写
  字段匹配子类实例，并绑定对应者）；asked 命题按内容匹配；其余 Node
  （story Node、无 `Among` 的 asked Node）是常量、按 identity；Array 与
  普通 record 字段逐项匹配，其中的 Variable/描述同样绑定；`Among` 是显式对应
  关系；`Occurs(f)` 要求对应事件已发生，`Among` 不蕴含发生；`ResultsIn`
  支持要求事件已发生（r3 修复的语义保留，回归 + 变异验证）；`Before` 由
  Next 链传递推导；Variable 只取祖先已有个体。
- **结构化结果**（审查后修订，见文末）：`Unknown` / `Ambiguous{candidates}` /
  `NotEstablished{constraints, level}`
  为普通冻结值，照常进入 Imperative 阶段、由 Says 说出、Project 投影
  （如 `{candidates=[Entity(the cheese),Entity(the bread)],result=ambiguous}`）；
  硬异常只保留给实现错误。辅助变量可 Ambiguous 而被问变量唯一（回归）。

## Regression（42 项，全 PASS；首版 31 项，历次审查后增至 42 项）

r3 的 27 项中：identity/undefined/layering/project/imperatives/reply 系保留
（fixture 改为三层形态）；question-Template 系（field-canonical、
question-proposition、occurrence-question、agent-join、no-climb×2）按 r4
语义改写为对应/持有形态；`requested()` 专属回归删除（机制本身删除）；
r3 两个 correctness 回归保留并改写为 r4 形态（`resultsin:`、`exact:`）。
新增覆盖指导第六节全部 12 项：未断言不构成约束、回复不可见且无排除规则、
祖先继承、描述+对应（唯一/未写字段不约束/开放类 Get 匹配 SnapUp 不匹配
无关类）、Occurs 与 Among 分离、Occurs 不产生第二事件、蕴含而非相容、
三种结构化结果经 Says 输出、辅助变量 Ambiguous、Next 唯一 + Before 派生、
dialogue 直引被拒、Foundation 逐字节一致（运行时核对）。

变异验证：去掉 ResultsIn 内容的 occurred 过滤 → 恰好 `resultsin` 一项失败
（审查后复测 34/35）；约束收集退化为所有 Node → 审查后复测 13/35。恢复后
35/35。

## 模块变化

- 新增：`Correspondence.js`（`Among`）、`Outcomes.js`（三种结构化结果）、
  `Support.js`（支持池机械层）；Relations 增 `Next`/`Enables`，Attitudes
  增 `About`，Objects 增开放类 `Get` 与 dialogue 的 `Asks`，
  `SnapUp extends Get`；故事断言链 Before→`Next`。
- 重写：`QuerySolver.js`（持有约束 + 祖先支持 + 结构化结果）、
  `Search.js`（按类分派支持，含 Before 派生）、`Match.js` 增
  `matchValue`（描述/常量双角色递归匹配，按字面查字段、顺序无关）。
- 删除：`requested()` 排除、question-Event 模板规则、r3 的
  `Bindings`-mentioner 扫描求解路径。
- 领域 `space/` 文件全部 ≤160 行；故事 fixture 文件为 180–194 行
  （r3 已如此，非框架模块）。

## 完成标准对照（指导 §七）

- Foundation source unchanged ✓（diff + 运行时回归双核对）
- 三层 Situation 结构；story 不含问题认知 ✓（grep 零命中）
- requested() 与 question-Event 模板规则删除 ✓（grep 零命中）
- 约束只来自持有认知，且由祖先蕴含 ✓（回归 + 变异验证）
- solver 读祖先链 ✓（heldAbove / view.Ancestors()）
- 描述 + 对应关系 h（Among）实现，Occurs 与 h 分离 ✓
- 无解/多解/预设不成立为结构化结果，不抛异常 ✓
- 15 题按原文忠实重译；expected 变化逐题说明 ✓（S2Q4 按指导规定；S1Q3
  于第二次审查后随 story-1 修正）
- regression 全通过，新增项覆盖第六节 ✓（42/42）
- FRAMEWORK_NOTES 更新为当前 canonical semantics ✓
- FOUNDATION_NOTES 记录本轮 Foundation 使用观察 ✓

## 审查后修正（2026-10-02）

首版 r4 通过全部 31 项回归与 15 题，但审查发现"描述 + 对应"没有按指导
实现。三个缺陷均先以小反例复现，修正后各有独立回归，并经变异验证：

1. **描述不绑定指称**（正确性）。`matchValue` 对描述只做"类 + 已写字段"
   检查，不记录对应到哪个故事 Node，于是同一描述在 `Occurs(d)`、
   `Agent(d, x)` 中可由不同事件分别支持。反例：乌鸦的 Drop 发生了、狐狸
   的 Drop 只是目标，问"谁（已发生地）投入水罐"得到
   `Ambiguous{crow, fox}`。修正：描述像 Variable 一样在 tuple 中绑定
   `d → 对应者`，所有约束必须对应同一 Node。回归
   `correspondence: one description names one event in every constraint`；
   去掉绑定的变异恰好使该项与 failure-kinds 项失败（33/35），而 15 题
   **仍全过**——寓言数据不触发此缺陷，只有定向回归能抓住。
2. **`Among` 不起作用**。描述角色由隐式规则"asked 坐落的 Node 一律是
   描述"决定，去掉 `Among` 结果不变——对应关系从 Situation 坐落推断，
   违反"指称同一性只由显式认知表达"。修正：只有被持有的 `Among` 点名的
   asked Node 才是描述；asked 命题按内容匹配；其余 Node 是常量。回归
   `correspondence: without Among an asked event is no description`；
   恢复隐式规则的变异恰好使该项（及依赖它的 exact 项）失败。
3. **未写字段读成 `undefined`**。故事 Fall 没写 theme 时，"what fell"
   回答 `undefined`。修正：`fieldValue` 对未写字段返回 `Unknown`；它满足
   Variable（得 Unknown）但不满足任何已写字段。显式写入的 `undefined`
   仍是值。回归在 `outcomes: failure kinds stay distinguishable` 中；
   变异恰好使该项失败。

### 失败结果的重新设计

`PresuppositionFailed` 改为 `NotEstablished{constraint, level}`。故事是
开放世界（未断言 ≠ 假，且领域无否定），预设不可能被"驳倒"，只能未被
确立；原名承诺了实现无法兑现的判断。设计目标是"将来能明确区分，现在
暂不需要"：失败时保留哪条约束未获支持、卡在哪一层，分类留给将来。

| level | 含义 | 例 |
|---|---|---|
| `correspondence` | 描述在指定 Situation 中没有对应者 | 故事里没有落到地上的 Fall |
| `instance` | 没有故事命题支持该约束 | gnaw 发生了，但没有断言 `Agent` |
| `joint` | 各约束单独有支持，但无一组值/对应者同时满足 | 发生的 Drop 无施事、有施事的 Drop 未发生 |

值未写出则为 `Unknown`（如 Fall 没写 theme）。将来引入"Action 蕴含施事"
等领域蕴含后，`instance` 级的 `Agent` 失败可升级为 `Unknown`；记录已保留
所需信息，无需改表示。投影形如
`{constraint=Agent,level=instance,result=not-established}`。

### 其余顺带修正

- 支持池（条件、ResultsIn、通用命题）由 `constructor ===` 改为
  `instanceof`，与描述的子类匹配规则一致；回归
  `support: a general constraint is supported by a subclass instance`。
- 删除 r3 遗留、已无生产调用的 `BindFields`；exact 回归改为验证内容匹配
  与描述匹配的字段顺序无关性。

## 第二次审查后修正（2026-10-02）

### story-1 与原文对齐

原文 "he saw the water mount up near him, and after casting in a few more
pebbles he was able to quench his thirst"。原故事把 "a few more pebbles"
的投石放在水位上升之前，使 `waterRise → drink` 相邻；S1Q4 译
`Enables + Next` 唯一命中，正是指导要消除的相邻关系巧合。原故事还只断言
`Causes(dropFirst, waterRise)`，把水位上升归于第一颗石子，与 "little by
little" 不符。

- 事件链改为 `dropFirst(a pebble) → dropOthers(the other pebbles) →
  waterRise → castMore(a few more pebbles) → drink → saveLife`。原文六句
  "took (another) pebble and dropped it" 压缩为第一枚与其余几枚两次 Drop，
  主题是集合个体；这是叙述压缩，不产生原文没有的事实。
- 新增集合事件 `Series{parts}`（见 FRAMEWORK_NOTES §5a）：
  `Causes(Series[dropFirst, dropOthers], waterRise)`，`InOrderTo` 同步改为
  Series。
- S1Q3 的 expected 改为该 Series 的投影；S1Q4 改译 `Before`，答案仍是
  `Quench`。改回 `Next` 时得到 `NotEstablished`（joint），由回归锁定。

### 求解层修正

1. **条件类不再硬编码**：新增抽象 `Condition`，求解按类识别。回归
   `support: a new Condition subclass is held without registration`。
2. **失败归属与约束顺序无关**：`NotEstablished{constraint}` 改为
   `NotEstablished{constraints, level}`，判定规则见 FRAMEWORK_NOTES §4；
   投影形如 `{constraints=[Agent],level=instance,result=not-established}`。
   回归 `outcomes: failure attribution does not depend on constraint order`。
3. **`Among` 只能指向上层 Situation**：指向 asked 自身时，原先会把裸
   Variable 绑成值并在赋值点抛 `TypeError`；现在得到 correspondence 级
   `NotEstablished`。回归 `correspondence: Among over the asking Situation
   has no correspondent`。
4. **未写出的解不再混入 Ambiguous**：原先会得到
   `Ambiguous{[unknown, cheese]}`；现在得到
   `{candidates=[Entity(the cheese)],result=ambiguous,unstated=true}`。回归
   `outcomes: an unstated solution keeps one stated value from being
   unique`。

变异验证：恢复条件列表、去掉 `Among` 上层检查、取消 unstated 拆分，各自
恰好使对应的新回归失败（39/40），15 题仍全部通过。

### 未写字段各有自己的 `Unknown`

原先 `Unknown` 是单例，两个不同的未写字段在 join 中被视为相等。反例：
故事中 Fall 与 Drop 都没写 theme，问"谁扔下了掉落的那个东西"得到 crow，
但故事并未确立两者是同一个东西。

修正：`fieldValue(node, key)` 对未写字段返回该字段自己的 Unknown
（`UnstatedField`），字段身份以不可枚举的 Symbol 键存放在值上，不做跨调用
缓存。同一字段读两次相等（同一描述经多条约束读同一故事字段时必须能 join），
不同字段永不相等；没有约束提及的变量仍得到无字段的 `Unknown()`。投影
不变，仍是 `{result=unknown}`。回归 `outcomes: two unstated fields are never
the same value` 同时验证反例得到 joint 级 `NotEstablished`、同一字段可与
自己 join。变异验证：令所有 Unknown 相等，恰好该项失败；令任何两次读取
都不相等，该项与另外两项 Unknown 回归失败。回归总数 41/41。

## 第三次审查后修正（2026-10-02）

### 容器字段中的 Variable 不绑定

`matchValue` 对非 Node 的 pattern 直接走 `sameValue`，不进入 Array／普通
record，其中的 Variable 与描述既不绑定也不匹配。第二次审查引入的
`Series{parts}` 正是 Array 字段：问 `Series(parts=[dropFirst, x])` +
`Among` + `Causes(s, waterRise)` 得到 correspondence 级
`NotEstablished`——即"故事里没有这个东西"，是错误结论而非未知。

修正：Array 与普通 record（原型为 `Object.prototype` 或 null）的 pattern
按形状逐项递归匹配，与 Node 字段同样在 trial 上绑定、成功才提交；长度或
键集不同即不匹配。`sameValue` 的结构比较同步收紧为只比较 Array 与普通
record：原先两个没有自有键的不同 Map／Set 会被判为相等，现在按 identity。

回归 `match: a Variable inside an Array field binds like a Node field`：
解出 `x = dropOthers`，部件数不同或常量项不符均为 correspondence 级
`NotEstablished`。变异验证：关闭容器递归恰好使该项失败（41/42），15 题
仍全部通过。回归总数 42/42。

### 文档

- 本文件与 FRAMEWORK_NOTES 中过时的回归计数、"expected 仅 S2Q4"、
  "asked 坐落即描述"、`NotEstablished{constraint, level}` 描述已更新。
- S1Q4 改译 `Before` 的理由改为以问题本身的语义陈述（见 FRAMEWORK_NOTES
  §6），不以故事内容倒推。
- `ResolveQueryDefer.js` 注释更新：求解器总是返回结构化结果，不抛领域
  错误。
