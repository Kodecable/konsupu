// Domain-level regression tests for the r4 world framework: three-layer
// Situation structure (dialogue / story / asked), constraints held by the
// asked Situation and supported along the story chain, descriptions with
// an explicit Among correspondence, and structured Unknown / Ambiguous /
// NotEstablished results. Runnable both ways: `node regression.mjs`
// standalone, or imported by run.mjs.
import { pathToFileURL, fileURLToPath } from "node:url";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import {
  Action,
  Agent,
  Among,
  Asks,
  Assert,
  AssertOccurs,
  Before,
  Believes,
  Causes,
  Condition,
  Drop,
  Enables,
  Eat,
  Entity,
  Event,
  Fall,
  Get,
  Gnaw,
  Goal,
  LocatedAt,
  Next,
  Occurs,
  ResultsIn,
  Says,
  Series,
  Sing,
  SnapUp,
  VoiceSurpasses,
} from "./space/Interface/Aesop.js";
import { BuildStory as BuildCrowStory } from "./cases/story-1/story.mjs";
import {
  Brand,
  Final,
  GlobalNode,
  Imperative,
  KonsupuIdentity,
  Proposition,
  Query,
  ReportDataMembers,
  Situation,
  Variable,
  ref,
} from "./space/Interface/Nodes.js";
import { Assertion } from "./space/Memory/Aesop/Assertion.js";
import { MatchContext, matchValue, sameValue } from "./space/Memory/Aesop/Match.js";
import { SolveQuery } from "./space/Memory/Aesop/QuerySolver.js";
import { Analyze } from "./space/Memory/Foundation/Analyze.js";
import { CreateState } from "./space/Memory/Foundation/ResolveState.js";
import { Perspective } from "./space/Memory/Foundation/Perspective.js";
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";

function assert(condition, message) {
  if (!condition) throw new Error(`assert failed: ${message}`);
}

function assertThrows(thunk, fragment, message) {
  try {
    thunk();
  } catch (caught) {
    assert(
      String(caught.message).includes(fragment),
      `${message}: expected "${fragment}" in "${caught.message}"`,
    );
    return;
  }
  throw new Error(`${message}: expected an error containing "${fragment}"`);
}

// A second global identity, so a fixture can address someone else.
class SomeoneElse extends GlobalNode {
  static BRAND = Brand("aesop-test:SomeoneElse:v1");
  constructor(key, fields = {}) {
    Final(SomeoneElse, new.target);
    super(key, fields);
  }
}

function entity(situation, name) {
  const value = new Entity(situation);
  value.name = name;
  return value;
}

function makeAgent(situation, action, actor) {
  const relation = new Agent(situation);
  relation.action = action;
  relation.actor = actor;
  return relation;
}

// Assemble the three-layer Input exactly the way cases.mjs does: dialogue
// root first (the initial Situation), story facts, asked constraints and
// its Query, then the dialogue members that reference them. Returns the
// pieces so tests can solve, evaluate, or inspect directly.
function assembleCase(buildWorld, buildAsked) {
  const dialogue = new Situation();
  const story = new Situation();
  const input = [dialogue, story];
  const world = buildWorld(input, story);
  const asked = new Situation(story);
  input.push(asked);
  const answer = new Variable(asked);
  input.push(answer);
  const extra = buildAsked(input, asked, world, answer) ?? [];
  const query = new Query(asked, [answer, ...extra]);
  input.push(query);
  const asks = new Asks(dialogue);
  asks.story = story;
  asks.asked = asked;
  input.push(asks);
  input.push(new Query(dialogue, [ref(asked, answer)]));
  const say = new Says(dialogue);
  say.content = ref(asked, answer);
  input.push(say);
  input.push(new Imperative(dialogue, KonsupuIdentity.Ref(), say));
  return { input, story, asked, dialogue, answer, say, world, query };
}

function solveAssembled(assembled) {
  const { input, query } = assembled;
  const state = CreateState(Analyze(input));
  return SolveQuery(input, query, [...query.variables], state);
}

// Whether a solved value is a NotEstablished record at the given level.
function isNotEstablished(value, level) {
  return value?.result === "not-established" && value.level === level;
}

function answerText(assembled) {
  return Texts(Evaluate(assembled.input))[0];
}

// A world with one occurred singing by the crow, for the small fixtures.
function singingWorld(input, story) {
  const crow = entity(story, "the crow");
  const fox = entity(story, "the fox");
  const sing = new Sing(story);
  input.push(crow, fox, sing);
  AssertOccurs(input, sing);
  Assert(input, makeAgent(story, sing, crow));
  return { root: story, crow, fox, sing };
}

// Two Drops into the pitcher: the crow's occurred; the fox's is only the
// fox's goal and never occurred.
function twoDropsWorld(input, story) {
  const crow = entity(story, "the crow");
  const fox = entity(story, "the fox");
  const pitcher = entity(story, "the pitcher");
  const real = new Drop(story);
  real.destination = pitcher;
  const wished = new Drop(story);
  wished.destination = pitcher;
  input.push(crow, fox, pitcher, real, wished);
  AssertOccurs(input, real);
  Assert(input, makeAgent(story, real, crow));
  Assert(input, makeAgent(story, wished, fox));
  const goal = new Goal(story);
  goal.actor = fox;
  goal.objective = wished;
  Assert(input, goal);
  return { root: story, crow, fox, pitcher };
}

// As above, but the occurred Drop has no asserted agent: Occurs(d) and
// Agent(d, x) are each supported, by different Drops.
function splitDropsWorld(input, story) {
  const fox = entity(story, "the fox");
  const pitcher = entity(story, "the pitcher");
  const real = new Drop(story);
  real.destination = pitcher;
  const wished = new Drop(story);
  wished.destination = pitcher;
  input.push(fox, pitcher, real, wished);
  AssertOccurs(input, real);
  Assert(input, makeAgent(story, wished, fox));
  return { root: story, fox, pitcher };
}

// "Who dropped (something) into the pitcher?", with or without the Among
// that makes d a description.
function whoDroppedOccurred(withAmong) {
  return (input, asked, w, answer) => {
    const d = new Drop(asked);
    d.destination = w.pitcher;
    input.push(d);
    if (withAmong) {
      const h = new Among(asked);
      h.situation = w.root;
      h.node = d;
      Assert(input, h);
    }
    AssertOccurs(input, d);
    Assert(input, makeAgent(asked, d, answer));
  };
}

// One occurred Fall whose theme the story never writes; with `elsewhere`
// it lands on the roof instead of the ground.
function groundWorld(elsewhere) {
  return (input, story) => {
    const ground = entity(story, "the ground");
    const roof = entity(story, "the roof");
    const fall = new Fall(story);
    fall.destination = elsewhere ? roof : ground;
    input.push(ground, roof, fall);
    AssertOccurs(input, fall);
    return { root: story, ground };
  };
}

// "What fell to the ground?"
function whatFell(input, asked, w, answer) {
  const f = new Fall(asked);
  f.destination = w.ground;
  f.theme = answer;
  input.push(f);
  const h = new Among(asked);
  h.situation = w.root;
  h.node = f;
  Assert(input, h);
  AssertOccurs(input, f);
}

// An open general proposition and a refinement of it, test-local.
class Holding extends Proposition {
  static BRAND = Brand("aesop-test:Holding:v1");
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
class Gripping extends Holding {
  static BRAND = Brand("aesop-test:Gripping:v1");
  constructor(situated) {
    Final(Gripping, new.target);
    super(situated);
  }
}

// A test-local condition class nothing in the solver lists by name.
class Wet extends Condition {
  static BRAND = Brand("aesop-test:Wet:v1");
  constructor(situated) {
    Final(Wet, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// "Who dropped (something) into the pitcher?" with its held constraints in
// the given order of "among", "occurs", "agent".
function whoDroppedInOrder(order) {
  return (input, asked, w, answer) => {
    const d = new Drop(asked);
    d.destination = w.pitcher;
    input.push(d);
    for (const step of order) {
      if (step === "among") {
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
      } else if (step === "occurs") {
        AssertOccurs(input, d);
      } else {
        Assert(input, makeAgent(asked, d, answer));
      }
    }
  };
}

// The constraint classes a NotEstablished record names, as one string.
function failingClasses(record) {
  return record.constraints.map((item) => item.constructor.name).join(",");
}

// One occurred Fall and one occurred Drop by the crow, neither theme
// written; with `sameDrop` both descriptions are Drops and can only name
// the one Drop.
function unstatedThemes(sameDrop) {
  return {
    world(input, story) {
      const crow = entity(story, "the crow");
      const fall = new Fall(story);
      const drop = new Drop(story);
      input.push(crow, fall, drop);
      AssertOccurs(input, fall);
      AssertOccurs(input, drop);
      Assert(input, makeAgent(story, drop, crow));
      return { root: story, crow };
    },
    asked(input, asked, w, answer) {
      const thing = new Variable(asked);
      input.push(thing);
      const first = sameDrop ? new Drop(asked) : new Fall(asked);
      first.theme = thing;
      const second = new Drop(asked);
      second.theme = thing;
      input.push(first, second);
      for (const node of [first, second]) {
        const h = new Among(asked);
        h.situation = w.root;
        h.node = node;
        Assert(input, h);
      }
      Assert(input, makeAgent(asked, second, answer));
      return [thing];
    },
  };
}

export const Tests = [
  {
    name: "identity: identical declarations are distinct Nodes",
    run() {
      const root = new Situation();
      const a = entity(root, "the crow");
      const b = entity(root, "the crow");
      assert(a !== b, "two constructions are two objects");
      assert(sameValue(a, b) === false, "sameValue must not unify them");
      assert(sameValue(a, a), "a Node equals itself");
    },
  },
  {
    name: "identity: repeated Variable must not unify distinct Nodes",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const a = entity(root, "the crow");
      const b = entity(root, "the crow");
      const x = new Variable(asked);
      const pattern = new LocatedAt(asked);
      pattern.entity = x;
      pattern.place = x;
      const fact = new LocatedAt(root);
      fact.entity = a;
      fact.place = b;
      const bindings = new Map();
      assert(
        !matchValue(pattern, fact, bindings, MatchContext(asked)),
        "(X, X) must not match (a, b) with a !== b",
      );
    },
  },
  {
    name: "undefined: a bound undefined conflicts with later bindings",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const crow = entity(root, "the crow");
      const sing = new Sing(root);
      const x = new Variable(asked);
      const bindings = new Map();
      assert(
        matchValue(
          makeAgent(asked, sing, x),
          makeAgent(root, sing, undefined),
          bindings,
          MatchContext(asked),
        ),
        "X binds undefined",
      );
      assert(
        !matchValue(
          makeAgent(asked, sing, x),
          makeAgent(root, sing, crow),
          bindings,
          MatchContext(asked),
        ),
        "undefined then crow is a conflict, not an overwrite",
      );
    },
  },
  {
    name: "undefined: Map keeps [X, undefined] as a binding",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const sing = new Sing(root);
      const x = new Variable(asked);
      const bindings = new Map();
      matchValue(
        makeAgent(asked, sing, x),
        makeAgent(root, sing, undefined),
        bindings,
        MatchContext(asked),
      );
      assert(bindings.has(x), "undefined binding must stay in the Map");
      assert(bindings.get(x) === undefined, "the bound value is undefined");
    },
  },
  {
    name: "layering: world objects, events, and propositions separate",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      const sing = new Sing(root);
      const says = new Says(root);
      const fall = new Fall(root);
      const occurs = new Occurs(root);
      const before = new Before(root);
      const causes = new Causes(root);
      const assertion = new Assertion(root);
      assert(!(crow instanceof Proposition), "Entity is not a Proposition");
      assert(!(says instanceof Proposition), "Says is not a Proposition");
      assert(says instanceof Action, "Says is an Action");
      assert(
        fall instanceof Event && !(fall instanceof Action),
        "Fall is an Event but not an Action",
      );
      assert(
        occurs instanceof Proposition &&
          before instanceof Proposition &&
          causes instanceof Proposition,
        "Occurs, Before, and Causes are Propositions",
      );
      assert(
        !(assertion instanceof Proposition),
        "Assertion is not a Proposition",
      );
    },
  },
  {
    name: "layering: Event and Action are abstract",
    run() {
      const root = new Situation();
      assertThrows(
        () => new Event(root),
        "abstract",
        "Event cannot be constructed",
      );
      assertThrows(
        () => new Action(root),
        "abstract",
        "Action cannot be constructed",
      );
    },
  },
  {
    name: "layering: Get is open, SnapUp refines it, others do not",
    run() {
      const root = new Situation();
      const get = new Get(root);
      const snap = new SnapUp(root);
      const sing = new Sing(root);
      assert(get instanceof Action, "Get is a constructible Action");
      assert(snap instanceof Get, "SnapUp is a Get");
      assert(!(get instanceof SnapUp), "Get is not a SnapUp");
      assert(!(sing instanceof Get), "an unrelated doing is no Get");
    },
  },
  {
    name: "support: asked inherits story facts along the chain",
    run() {
      const assembled = assembleCase(
        singingWorld,
        (input, asked, world, answer) => {
          Assert(input, makeAgent(asked, world.sing, answer));
        },
      );
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.crow,
        "the story's asserted Agent supports the asked constraint",
      );
    },
  },
  {
    name: "constraints: an unasserted Node binds nothing, whatever it holds",
    run() {
      const loose = assembleCase(singingWorld, (input, asked, world, answer) => {
        const who = makeAgent(asked, world.sing, answer);
        input.push(who); // exists in the asked Situation, never asserted
      });
      const unknown = solveAssembled(loose);
      assert(
        unknown.get(loose.answer).result === "unknown",
        "an unasserted mentioner contributes no constraint",
      );
      const held = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, answer));
      });
      const solved = solveAssembled(held);
      assert(
        solved.get(held.answer) === held.world.crow,
        "the same cognition held as an Assertion does constrain",
      );
    },
  },
  {
    name: "reply: the dialogue Says is invisible to the asked solving",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const world = singingWorld(input, story);
          const taunt = new Says(story);
          taunt.text = "Was I not right?";
          input.push(taunt);
          AssertOccurs(input, taunt);
          Assert(input, makeAgent(story, taunt, world.fox));
          return world;
        },
        (input, asked, world, answer) => {
          Assert(input, makeAgent(asked, world.sing, answer));
        },
      );
      assert(
        answerText(assembled) === "Entity(the crow)",
        "solving needs no exclusion rule for the reply Says",
      );
      const view = new Perspective(
        assembled.query,
        CreateState(Analyze(assembled.input)),
      );
      assert(
        !view.Bindings(assembled.answer).includes(assembled.say),
        "the dialogue's reply Says never enters the asked view",
      );
    },
  },
  {
    name: "correspondence: a description matches class and written fields",
    run() {
      const world = (input, story) => {
        const cheese = entity(story, "the cheese");
        const bread = entity(story, "the bread");
        const ground = entity(story, "the ground");
        const dropCheese = new Fall(story);
        dropCheese.theme = cheese;
        dropCheese.destination = ground;
        const dropBread = new Fall(story);
        dropBread.theme = bread;
        dropBread.destination = ground;
        const snap = new SnapUp(story);
        snap.theme = cheese;
        const sing = new Sing(story);
        input.push(cheese, bread, ground, dropCheese, dropBread, snap, sing);
        AssertOccurs(input, dropCheese);
        AssertOccurs(input, dropBread);
        AssertOccurs(input, snap);
        AssertOccurs(input, sing);
        return { root: story, cheese, bread, ground };
      };
      // Written fields select; unwritten ones never constrain.
      const unique = assembleCase(world, (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = w.cheese;
        f.destination = answer;
        input.push(f);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = f;
        Assert(input, h);
      });
      assert(
        solveAssembled(unique).get(unique.answer) === unique.world.ground,
        "the one matching fall supplies the unwritten field",
      );
      const overConstrained = assembleCase(world, (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = w.cheese;
        f.destination = w.bread; // written wrongly on purpose
        input.push(f);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = f;
        Assert(input, h);
      });
      assert(
        isNotEstablished(solveAssembled(overConstrained).get(overConstrained.answer), "correspondence"),
        "a written-but-wrong field blocks the correspondence",
      );
      // An open-class description matches subclass instances, nothing else.
      const openClass = assembleCase(world, (input, asked, w, answer) => {
        const g = new Get(asked);
        g.theme = answer;
        input.push(g);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = g;
        Assert(input, h);
      });
      assert(
        solveAssembled(openClass).get(openClass.answer) ===
          openClass.world.cheese,
        "Get matches the SnapUp, and only it",
      );
    },
  },
  {
    name: "occurrence: Occurs(f) demands a happened match; Among alone does not",
    run() {
      const world = (input, story) => {
        const lion = entity(story, "the lion");
        const mouse = entity(story, "the mouse");
        const eatMouse = new Eat(story);
        eatMouse.theme = mouse;
        input.push(lion, mouse, eatMouse);
        const goal = new Goal(story);
        goal.actor = lion;
        goal.objective = eatMouse;
        Assert(input, goal);
        return { root: story, lion, mouse, eatMouse };
      };
      const demanded = assembleCase(world, (input, asked, w, answer) => {
        const d = new Eat(asked);
        d.theme = answer;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
      });
      assert(
        isNotEstablished(solveAssembled(demanded).get(demanded.answer), "instance"),
        "an unoccurred objective never satisfies Occurs",
      );
      const tolerated = assembleCase(world, (input, asked, w, answer) => {
        const d = new Eat(asked);
        d.theme = answer;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        const goal = new Goal(asked);
        goal.actor = w.lion;
        goal.objective = d;
        Assert(input, goal);
      });
      assert(
        solveAssembled(tolerated).get(tolerated.answer) ===
          tolerated.world.mouse,
        "without Occurs the description may name an unoccurred objective",
      );
    },
  },
  {
    name: "occurrence: asserting Occurs(f) adds no second event",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const fall = new Fall(story);
          fall.theme = cheese;
          fall.destination = ground;
          input.push(cheese, ground, fall);
          AssertOccurs(input, fall);
          return { root: story, cheese, ground };
        },
        (input, asked, w, answer) => {
          const f = new Fall(asked);
          f.theme = answer;
          input.push(f);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = f;
          Assert(input, h);
          AssertOccurs(input, f);
        },
      );
      const before = assembled.input.length;
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.cheese,
        "the description still names the one real fall",
      );
      assert(
        assembled.input.length === before,
        "nothing entered the Input while solving",
      );
      assert(
        answerText(assembled) === "Entity(the cheese)",
        "the asked Occurs corresponded to the original event, not a new one",
      );
    },
  },
  {
    name: "entailment: a held constraint needs matching story content",
    run() {
      const wrong = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, world.fox));
      });
      assert(
        isNotEstablished(solveAssembled(wrong).get(wrong.answer), "instance"),
        "a merely compatible actor is not support; content must match",
      );
      const right = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, answer));
      });
      assert(
        solveAssembled(right).get(right.answer) === right.world.crow,
        "the matching story Agent entails the held constraint",
      );
    },
  },
  {
    name: "says: a speech event is a first-class chain argument",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const world = singingWorld(input, story);
          const taunt = new Says(story);
          taunt.text = "Was I not right?";
          const other = new Fall(story);
          input.push(taunt, other);
          Assert(input, makeNext(story, taunt, other));
          AssertOccurs(input, taunt);
          AssertOccurs(input, other);
          return { root: story, crow: world.crow, taunt, other };
        },
        (input, asked, world, answer) => {
          const next = new Next(asked);
          next.earlier = world.taunt;
          next.later = answer;
          Assert(input, next);
          const occurs = new Occurs(asked);
          occurs.event = answer;
          Assert(input, occurs);
        },
      );
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.other,
        "a Says serves as a chain argument and can occur",
      );
    },
  },
  {
    name: "adjacency: speech content, assertion, and result content differ",
    run() {
      // The same LocatedAt, once only spoken, once asserted, once the
      // content of an occurred event's ResultsIn — three different
      // consequences for the very same mention shape.
      const base = (input, story) => {
        const cheese = entity(story, "the cheese");
        const ground = entity(story, "the ground");
        const fox = entity(story, "the fox");
        const fall = new Fall(story);
        fall.theme = cheese;
        fall.destination = ground;
        input.push(cheese, ground, fox, fall);
        AssertOccurs(input, fall);
        return { cheese, ground, fox, fall };
      };
      const speechWorld = (input, story) => {
        const w = base(input, story);
        const located = new LocatedAt(story);
        located.entity = w.cheese;
        located.place = w.ground;
        input.push(located);
        const says = new Says(story);
        says.text = "it is on the ground";
        says.content = located;
        input.push(says);
        AssertOccurs(input, says);
        return { root: story, ...w };
      };
      const assertedWorld = (input, story) => {
        const w = base(input, story);
        const located = new LocatedAt(story);
        located.entity = w.cheese;
        located.place = w.ground;
        Assert(input, located); // Assert pushes; never push the same Node twice
        return { root: story, ...w };
      };
      const resultWorld = (input, story) => {
        const w = base(input, story);
        const located = new LocatedAt(story);
        located.entity = w.cheese;
        located.place = w.ground;
        input.push(located);
        const result = new ResultsIn(story);
        result.event = w.fall;
        result.proposition = located;
        Assert(input, result);
        return { root: story, ...w };
      };
      const hold = (world) =>
        assembleCase(world, (input, asked, w, answer) => {
          const held = new LocatedAt(asked);
          held.entity = w.cheese;
          held.place = answer;
          Assert(input, held);
        });
      const speechOnly = hold(speechWorld);
      assert(
        isNotEstablished(solveAssembled(speechOnly).get(speechOnly.answer), "instance"),
        "an occurred Says does not make its content hold",
      );
      const asserted = hold(assertedWorld);
      assert(
        solveAssembled(asserted).get(asserted.answer) ===
          asserted.world.ground,
        "an Assertion holds the proposition",
      );
      const asResult = hold(resultWorld);
      assert(
        solveAssembled(asResult).get(asResult.answer) === asResult.world.ground,
        "an occurred event's asserted ResultsIn holds its result content",
      );
    },
  },
  {
    name: "resultsin: an unoccurred event's result is not held",
    run() {
      const clean = assembleCase(
        (input, story) => {
          const pebble = entity(story, "a pebble");
          const pitcher = entity(story, "the pitcher");
          const drop = new Drop(story);
          input.push(pebble, pitcher, drop);
          const rests = new LocatedAt(story);
          rests.entity = pebble;
          rests.place = pitcher;
          input.push(rests);
          const result = new ResultsIn(story);
          result.event = drop;
          result.proposition = rests;
          Assert(input, result);
          return { root: story, pebble, pitcher, drop };
        },
        (input, asked, w, answer) => {
          const held = new LocatedAt(asked);
          held.entity = w.pebble;
          held.place = answer;
          Assert(input, held);
        },
      );
      assert(
        isNotEstablished(solveAssembled(clean).get(clean.answer), "instance"),
        "an asserted ResultsIn without Occurs must not hold its content",
      );
      AssertOccurs(clean.input, clean.world.drop);
      const state = CreateState(Analyze(clean.input));
      const solved = SolveQuery(
        clean.input,
        clean.query,
        [...clean.query.variables],
        state,
      );
      assert(
        solved.get(clean.answer) === clean.world.pitcher,
        "once the event occurred, its result is held",
      );
    },
  },
  {
    name: "outcomes: Unknown passes through the reply Says",
    run() {
      const assembled = assembleCase(
        singingWorld,
        (input, asked, world, answer) => {
          const occurs = new Occurs(asked);
          occurs.event = world.sing;
          Assert(input, occurs); // supported, but says nothing about X
        },
      );
      assert(
        answerText(assembled) === "{result=unknown}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: Ambiguous passes through the reply Says",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const bread = entity(story, "the bread");
          const ground = entity(story, "the ground");
          const dropCheese = new Fall(story);
          dropCheese.theme = cheese;
          dropCheese.destination = ground;
          const dropBread = new Fall(story);
          dropBread.theme = bread;
          dropBread.destination = ground;
          input.push(cheese, bread, ground, dropCheese, dropBread);
          AssertOccurs(input, dropCheese);
          AssertOccurs(input, dropBread);
          return { root: story };
        },
        (input, asked, world, answer) => {
          const f = new Fall(asked);
          f.theme = answer;
          input.push(f);
          const h = new Among(asked);
          h.situation = world.root;
          h.node = f;
          Assert(input, h);
        },
      );
      assert(
        answerText(assembled) ===
          "{candidates=[Entity(the cheese),Entity(the bread)],result=ambiguous}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: NotEstablished passes through the reply Says",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world) => {
        Assert(input, makeAgent(asked, world.sing, world.fox));
      });
      assert(
        answerText(assembled) ===
          "{constraints=[Agent],level=instance,result=not-established}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "correspondence: one description names one event in every constraint",
    run() {
      const assembled = assembleCase(twoDropsWorld, whoDroppedOccurred(true));
      const value = solveAssembled(assembled).get(assembled.answer);
      assert(
        value === assembled.world.crow,
        "Occurs(d) and Agent(d, x) must speak of the same Drop; " +
          "the fox's unoccurred Drop never lends its agent",
      );
    },
  },
  {
    name: "correspondence: without Among an asked event is no description",
    run() {
      const assembled = assembleCase(twoDropsWorld, whoDroppedOccurred(false));
      assert(
        isNotEstablished(
          solveAssembled(assembled).get(assembled.answer),
          "instance",
        ),
        "an asked Drop no Among names is its own individual and matches " +
          "no story fact",
      );
    },
  },
  {
    name: "outcomes: failure kinds stay distinguishable",
    run() {
      // Value level: the fall is there, its theme is never written.
      const unstated = assembleCase(groundWorld(false), whatFell);
      const value = solveAssembled(unstated).get(unstated.answer);
      assert(value?.result === "unknown", "an unwritten field is Unknown");
      assert(
        answerText(unstated) === "{result=unknown}",
        "Unknown, never the text undefined",
      );
      // Correspondence level: nothing fell to the ground at all.
      const absent = assembleCase(groundWorld(true), whatFell);
      assert(
        isNotEstablished(
          solveAssembled(absent).get(absent.answer),
          "correspondence",
        ),
        "a description without correspondent fails at correspondence",
      );
      // Instance level: the gnawing happened, no Agent is asserted. Action
      // entails some agent, so a future entailment rule may reclassify
      // this as Unknown; the record keeps what that rule needs.
      const agentless = assembleCase(
        (input, story) => {
          const gnaw = new Gnaw(story);
          input.push(gnaw);
          AssertOccurs(input, gnaw);
          return { root: story, gnaw };
        },
        (input, asked, w, answer) => {
          Assert(input, makeAgent(asked, w.gnaw, answer));
        },
      );
      const record = solveAssembled(agentless).get(agentless.answer);
      assert(
        isNotEstablished(record, "instance") &&
          record.constraints.length === 1 &&
          record.constraints[0] instanceof Agent,
        "the record names the unsupported Agent constraint",
      );
      // Joint level: each constraint has support, never the same Drop.
      const split = assembleCase(splitDropsWorld, whoDroppedOccurred(true));
      assert(
        isNotEstablished(solveAssembled(split).get(split.answer), "joint"),
        "separately supported constraints may still fail together",
      );
    },
  },
  {
    name: "support: a general constraint is supported by a subclass instance",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const cheese = entity(story, "the cheese");
          input.push(crow, cheese);
          const grip = new Gripping(story);
          grip.holder = crow;
          grip.thing = cheese;
          Assert(input, grip);
          return { root: story, crow, cheese };
        },
        (input, asked, w, answer) => {
          const holding = new Holding(asked);
          holding.holder = w.crow;
          holding.thing = answer;
          Assert(input, holding);
        },
      );
      assert(
        solveAssembled(assembled).get(assembled.answer) ===
          assembled.world.cheese,
        "a held Gripping supports the asked Holding",
      );
    },
  },
  {
    name: "outcomes: a helper may stay Ambiguous while the answer is unique",
    run() {
      const complete = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const start = new Sing(story);
          const branchA = new Sing(story);
          const branchB = new Sing(story);
          input.push(crow, start, branchA, branchB);
          Assert(input, makeNext(story, start, branchA));
          Assert(input, makeNext(story, start, branchB));
          Assert(input, makeAgent(story, branchA, crow));
          Assert(input, makeAgent(story, branchB, crow));
          return { root: story, crow, start };
        },
        (input, asked, world, answer) => {
          const which = new Variable(asked);
          input.push(which);
          const next = new Next(asked);
          next.earlier = world.start;
          next.later = which;
          Assert(input, next);
          const who = new Agent(asked);
          who.action = which;
          who.actor = answer;
          Assert(input, who);
          return [which];
        },
      );
      const result = solveAssembled(complete);
      assert(
        result.get(complete.answer) === complete.world.crow,
        "the asked-about variable is unique",
      );
      const helper = result.get(
        complete.query.variables.find((v) => v !== complete.answer),
      );
      assert(
        helper.result === "ambiguous" && helper.candidates.length === 2,
        "the helper variable may carry an Ambiguous result",
      );
      assert(
        answerText(complete) === "Entity(the crow)",
        "the reply says the unique answer only",
      );
    },
  },
  {
    name: "temporal: Next keeps after-questions unique; Before is derived",
    run() {
      const world = (input, story) => {
        const a = new Sing(story);
        const b = new Sing(story);
        const c = new Sing(story);
        input.push(a, b, c);
        AssertOccurs(input, a);
        AssertOccurs(input, b);
        AssertOccurs(input, c);
        Assert(input, makeNext(story, a, b));
        Assert(input, makeNext(story, b, c));
        return { root: story, a, b, c };
      };
      const afterNext = assembleCase(world, (input, asked, w, answer) => {
        const next = new Next(asked);
        next.earlier = w.a;
        next.later = answer;
        Assert(input, next);
      });
      assert(
        solveAssembled(afterNext).get(afterNext.answer) === afterNext.world.b,
        "the immediate successor is unique",
      );
      const afterBefore = assembleCase(world, (input, asked, w, answer) => {
        const before = new Before(asked);
        before.earlier = w.a;
        before.later = answer;
        Assert(input, before);
      });
      const derived = solveAssembled(afterBefore).get(afterBefore.answer);
      assert(
        derived.result === "ambiguous" && derived.candidates.length === 2,
        "Before is derived transitively from the Next chain",
      );
      const constants = assembleCase(world, (input, asked, w, answer) => {
        const before = new Before(asked);
        before.earlier = w.a;
        before.later = w.c;
        Assert(input, before);
        const holds = new Occurs(asked);
        holds.event = w.c;
        Assert(input, holds);
      });
      assert(
        solveAssembled(constants).get(constants.answer).result === "unknown",
        "fully constant derived constraints support without binding X",
      );
    },
  },
  {
    name: "exact: field assignment order does not affect matching",
    run() {
      const root = new Situation();
      const cheese = entity(root, "the cheese");
      const ground = entity(root, "the ground");
      const sing = new Sing(root);
      const fall = new Fall(root);
      fall.theme = cheese;
      fall.destination = ground;
      const fact = new Causes(root);
      fact.effect = fall;
      fact.cause = sing;
      const asked = new Situation(root);
      // An asked proposition matches by content, looked up by field name.
      const pattern = new Causes(asked);
      pattern.cause = sing;
      pattern.effect = fall;
      const bindings = new Map();
      assert(
        matchValue(pattern, fact, bindings, MatchContext(asked)),
        "content matching compares fields by name, not insertion order",
      );
      assert(bindings.size === 0, "constant fields bind nothing");
      // A description is order-blind for the same reason.
      const described = new Fall(asked);
      described.destination = ground;
      described.theme = cheese;
      assert(
        matchValue(
          described,
          fall,
          new Map(),
          MatchContext(asked, new Set([described])),
        ),
        "descriptions match regardless of assignment order",
      );
    },
  },
  {
    name: "reply: Says.content reads a resolved Entity",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      assert(answerText(assembled) === "Entity(the crow)");
    },
  },
  {
    name: "reply: Says.content reads a resolved Event",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const fall = new Fall(story);
          fall.theme = cheese;
          fall.destination = ground;
          input.push(cheese, ground, fall);
          AssertOccurs(input, fall);
          return { root: story };
        },
        (input, asked, world, answer) => {
          const occurs = new Occurs(asked);
          occurs.event = answer;
          Assert(input, occurs);
        },
      );
      assert(
        answerText(assembled) ===
          "Fall(destination=Entity(the ground),theme=Entity(the cheese))",
      );
    },
  },
  {
    name: "reply: Says.content reads a resolved Proposition",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const birds = entity(story, "other birds");
          const claim = new VoiceSurpasses(story);
          claim.subject = crow;
          claim.others = birds;
          const belief = new Believes(story);
          belief.believer = crow;
          belief.proposition = claim;
          input.push(crow, birds, claim);
          Assert(input, belief);
          return { root: story, crow };
        },
        (input, asked, world, answer) => {
          const belief = new Believes(asked);
          belief.believer = world.crow;
          belief.proposition = answer;
          Assert(input, belief);
        },
      );
      assert(
        answerText(assembled) ===
          "VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))",
      );
    },
  },
  {
    name: "imperatives: a foreign addressee never reaches this Konsupu",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      const say = assembled.say;
      const foreign = new Imperative(assembled.dialogue, SomeoneElse.Ref(), say);
      assembled.input.push(foreign);
      const outputs = Evaluate(assembled.input);
      assert(
        outputs.length === 1,
        "the Konsupu Imperative already in the Input still resolves",
      );
      const only = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      only.input.pop(); // remove the Konsupu Imperative
      only.input.push(
        new Imperative(only.dialogue, SomeoneElse.Ref(), only.say),
      );
      assert(
        Evaluate(only.input).length === 0,
        "a foreign addressee resolves nothing here",
      );
    },
  },
  {
    name: "imperatives: a requested Says never occurs",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      const before = assembled.input.length;
      const outputs = Evaluate(assembled.input);
      assert(outputs.length === 1, "the request resolves to one output");
      assert(assembled.input.length === before, "resolution adds no cognition");
      const occurred = assembled.input.some((node) => {
        return node instanceof Occurs && node.event === assembled.say;
      });
      assert(
        !occurred,
        "being requested by an Imperative must not assert Occurs(says)",
      );
    },
  },
  {
    name: "project: machine output is structural, not English",
    run() {
      const world = (input, story) => {
        const crow = entity(story, "the crow");
        const fox = entity(story, "the fox");
        const sing = new Sing(story);
        sing.manner = "her best";
        input.push(crow, fox, sing);
        AssertOccurs(input, sing);
        Assert(input, makeAgent(story, sing, crow));
        return { root: story, crow, fox, sing };
      };
      const plain = assembleCase(world, (input, asked, w, answer) => {
        const occurs = new Occurs(asked);
        occurs.event = answer;
        Assert(input, occurs);
        const by = new Agent(asked);
        by.action = answer;
        by.actor = w.crow;
        Assert(input, by);
      });
      assert(
        answerText(plain) === "Sing(manner=her best)",
        `machine text reflects structure only, got "${answerText(plain)}"`,
      );
      const withUnasserted = assembleCase(world, (input, asked, w, answer) => {
        const occurs = new Occurs(asked);
        occurs.event = answer;
        Assert(input, occurs);
        const by = new Agent(asked);
        by.action = answer;
        by.actor = w.crow;
        Assert(input, by);
        input.push(makeAgent(asked, w.sing, w.fox)); // never asserted
      });
      assert(
        answerText(withUnasserted) === "Sing(manner=her best)",
        "projection never consults Agents or any wording lexicon",
      );
    },
  },
  {
    name: "support: a new Condition subclass is held without registration",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const fall = new Fall(story);
          fall.theme = cheese;
          input.push(cheese, fall);
          AssertOccurs(input, fall);
          const wet = new Wet(story);
          wet.subject = cheese;
          input.push(wet);
          const result = new ResultsIn(story);
          result.event = fall;
          result.proposition = wet;
          Assert(input, result);
          return { root: story, cheese };
        },
        (input, asked, w, answer) => {
          const wet = new Wet(asked);
          wet.subject = answer;
          Assert(input, wet);
        },
      );
      assert(
        solveAssembled(assembled).get(assembled.answer) ===
          assembled.world.cheese,
        "a Condition held as the result of an occurred event is supported " +
          "by its class alone, with no list to register in",
      );
    },
  },
  {
    name: "outcomes: failure attribution does not depend on constraint order",
    run() {
      const orders = [
        ["among", "occurs", "agent"],
        ["agent", "occurs", "among"],
      ];
      const joint = orders.map((order) => {
        const assembled = assembleCase(splitDropsWorld, whoDroppedInOrder(order));
        return solveAssembled(assembled).get(assembled.answer);
      });
      for (const record of joint) {
        assert(isNotEstablished(record, "joint"), "joint in every order");
        assert(
          [...failingClasses(record).split(",")].sort().join(",") ===
            "Agent,Among,Occurs",
          `joint names the whole held set, got ${failingClasses(record)}`,
        );
      }
      // An absent correspondent and an unsupported Agent: correspondence
      // wins whichever is held first.
      for (const amongFirst of [true, false]) {
        const assembled = assembleCase(singingWorld, (input, asked, w) => {
          const f = new Fall(asked);
          input.push(f);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = f;
          const who = makeAgent(asked, w.sing, w.fox);
          if (amongFirst) Assert(input, h);
          Assert(input, who);
          if (!amongFirst) Assert(input, h);
        });
        const record = solveAssembled(assembled).get(assembled.answer);
        assert(
          isNotEstablished(record, "correspondence") &&
            failingClasses(record) === "Among",
          `order-independent correspondence, got ${JSON.stringify(record?.level)}`,
        );
      }
    },
  },
  {
    name: "correspondence: Among over the asking Situation has no correspondent",
    run() {
      const assembled = assembleCase(groundWorld(false), (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = answer;
        input.push(f);
        const h = new Among(asked);
        h.situation = asked; // not a Situation above the asking one
        h.node = f;
        Assert(input, h);
      });
      assert(
        answerText(assembled) ===
          "{constraints=[Among],level=correspondence,result=not-established}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: an unstated solution keeps one stated value from being unique",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const stated = new Fall(story);
          stated.theme = cheese;
          stated.destination = ground;
          const unstated = new Fall(story);
          unstated.destination = ground;
          input.push(cheese, ground, stated, unstated);
          AssertOccurs(input, stated);
          AssertOccurs(input, unstated);
          return { root: story, ground };
        },
        whatFell,
      );
      assert(
        answerText(assembled) ===
          "{candidates=[Entity(the cheese)],result=ambiguous,unstated=true}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "story-1: more pebbles come between the rise and the drinking",
    run() {
      const solve = (build) => {
        const assembled = assembleCase(BuildCrowStory, build);
        return [solveAssembled(assembled).get(assembled.answer), assembled];
      };
      const [sequel, first] = solve((input, asked, w, answer) => {
        Assert(input, makeNext(asked, w.waterRise, answer));
      });
      assert(
        sequel === first.world.castMore,
        "right after the rise the crow casts in a few more pebbles",
      );
      const [immediate] = solve((input, asked, w, answer) => {
        const able = new Enables(asked);
        able.enabler = w.waterRise;
        able.enabled = answer;
        Assert(input, able);
        Assert(input, makeNext(asked, w.waterRise, answer));
      });
      assert(
        isNotEstablished(immediate, "joint"),
        "the drinking is enabled by the rise but is not its immediate Next",
      );
      const [cause] = solve((input, asked, w, answer) => {
        const why = new Causes(asked);
        why.cause = answer;
        why.effect = w.waterRise;
        Assert(input, why);
      });
      assert(
        cause instanceof Series && cause.parts.length === 2,
        "the water rises from the dropping as a whole, not from one pebble",
      );
    },
  },
  {
    name: "match: a Variable inside an Array field binds like a Node field",
    run() {
      const solve = (parts) => {
        const assembled = assembleCase(BuildCrowStory, (input, asked, w, x) => {
          const series = new Series(asked);
          series.parts = parts(w, x);
          input.push(series);
          const among = new Among(asked);
          among.situation = w.root;
          among.node = series;
          Assert(input, among);
          const why = new Causes(asked);
          why.cause = series;
          why.effect = w.waterRise;
          Assert(input, why);
        });
        return [solveAssembled(assembled).get(assembled.answer), assembled];
      };
      const [other, first] = solve((w, x) => [w.dropFirst, x]);
      assert(
        other === first.world.dropOthers,
        "the dropping that joins the first pebble's is the other pebbles'",
      );
      const [shorter] = solve((w, x) => [x]);
      assert(
        isNotEstablished(shorter, "correspondence"),
        "a one-part series is not the two-part dropping",
      );
      const [wrong] = solve((w, x) => [w.castMore, x]);
      assert(
        isNotEstablished(wrong, "correspondence"),
        "a constant item still has to match its counterpart",
      );
    },
  },
  {
    name: "outcomes: two unstated fields are never the same value",
    run() {
      // "Who dropped the thing that fell?": the story writes neither theme,
      // so it never says the dropped thing is the fallen one.
      const apart = unstatedThemes(false);
      const split = assembleCase(apart.world, apart.asked);
      assert(
        isNotEstablished(solveAssembled(split).get(split.answer), "joint"),
        "unstated themes of two events do not join",
      );
      // Both descriptions can only name the one Drop: the same unstated
      // field read twice still agrees with itself.
      const together = unstatedThemes(true);
      const same = assembleCase(together.world, together.asked);
      const solved = solveAssembled(same);
      assert(
        solved.get(same.answer) === same.world.crow,
        "one unstated field joins with itself",
      );
      assert(
        answerText(same) === "Entity(the crow)",
        `got "${answerText(same)}"`,
      );
    },
  },
  {
    name: "structure: dialogue cannot reference a story Node directly",
    run() {
      const dialogue = new Situation();
      const story = new Situation();
      const crow = entity(story, "the crow");
      const says = new Says(dialogue);
      says.content = crow; // cross-root cognition without a ref
      const input = [dialogue, story, crow, says];
      assertThrows(
        () => Analyze(input),
        "Cross-Situation cognition requires ref",
        "direct story references from the dialogue must be refused",
      );
    },
  },
  {
    name: "foundation: the copied source is byte-identical to src",
    run() {
      const here = fileURLToPath(new URL(".", import.meta.url));
      const pairs = [
        ["space/Memory/Foundation", "../../src/foundation/Memory/Foundation"],
        ["space/Test", "../../src/foundation/Test"],
        ["space/Test.js", "../../src/foundation/Test.js"],
        ["space/Resolve.js", "../../src/foundation/Resolve.js"],
      ];
      const walk = (path) => {
        if (statSync(path).isFile()) return [path];
        const files = [];
        for (const name of readdirSync(path)) {
          files.push(...walk(join(path, name)));
        }
        return files;
      };
      for (const [copy, origin] of pairs) {
        const from = join(here, copy);
        const to = join(here, origin);
        const left = walk(from).map((p) => p.slice(from.length)).sort();
        const right = walk(to).map((p) => p.slice(to.length)).sort();
        assert(
          JSON.stringify(left) === JSON.stringify(right),
          `${copy} and the original differ in file set`,
        );
        for (const rel of left) {
          assert(
            readFileSync(join(from, rel)).equals(readFileSync(join(to, rel))),
            `${copy}${rel} is not byte-identical to the original`,
          );
        }
      }
    },
  },
];

function makeNext(situation, earlier, later) {
  const relation = new Next(situation);
  relation.earlier = earlier;
  relation.later = later;
  return relation;
}

async function main() {
  let passed = 0;
  for (const test of Tests) {
    try {
      test.run();
      passed += 1;
      console.log(`PASS  ${test.name}`);
    } catch (caught) {
      console.log(`FAIL  ${test.name}`);
      console.log(caught.stack ?? String(caught));
    }
  }
  console.log(`Foundation/domain regression tests: ${passed}/${Tests.length} passed`);
  process.exit(passed === Tests.length ? 0 : 1);
}

const invokedDirectly =
  process.argv[1] !== undefined &&
  import.meta.url === pathToFileURL(process.argv[1]).href;
if (invokedDirectly) await main();
