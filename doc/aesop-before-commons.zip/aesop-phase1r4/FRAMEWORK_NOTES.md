# Konsupu Aesop Phase 1r2 → 1r3 → 1r4 — Framework 观察

按 r2 指导第 20 节逐题回答；文末为额外的 friction 与自然之处记录；其后
为 **Phase1r3 修订**（回答链路、真值语义勘误、机械投影）与 **Phase1r4
修订**（三层 Situation、持有约束、描述与对应、结构化结果）。基线：
`node regression.mjs` → 42/42；`node run.mjs` → 42/42 + 15/15（r3 时为
27/27 + 15/15；r4 起 expected 两处改变：S2Q4 按指导，S1Q3 随 story-1
与原文对齐，见 RESULTS）。

---

## 指导要求的 11 个回答

### 1. Event / Action 最终采用了什么严格语义？

- `Event`（abstract SituatedNode）：可指称、可讨论、具有"发生/未发生"
  区别的世界事件。Event 对象存在 ≠ `Occurs(event)` 成立；发生只由
  `Assertion(Occurs(E))` 表达。Event 不要求施事者。
- `Action extends Event`（abstract）：被建模为由某 Entity 实施的事件。
  唯一附加语义是 agentivity；intention / goal / success / responsibility
  一律不进类型，由 `Goal`、`Failed`、`Motivates` 等独立命题表达。
- 施事关系本身被 reify 为 `Agent(action, actor)` 命题（见第 3、9 条），
  因此 Action 类上没有任何 agent 字段。

### 2. 哪些旧 Action 被重新分类为非 Action Event，为什么？

| r1 事件 | r2 分类 | 理由 |
|---|---|---|
| `waterRise`（水升高） | `Rise`（Event） | 无施事者：水位上升不由任何 Entity 实施 |
| `dropCheese`（奶酪掉落） | `Fall`（Event） | 奶酪是 theme 不是 agent；r1 的 `Role(dropCheese,"actor",cheese)` 是明确错误表示，r2 结构上不可能复现（Fall 无 agent 通道） |
| `wake`（狮被弄醒） | `Wake`（Event） | "被弄醒"发生在睡眠者身上，非狮的施为 |
| `getTrapped`（落入陷阱） | `GetTrapped`（Event） | 被困是遭遇，不是施为 |

判定一律按世界语义，不按英语动词形态（如 `Spare`/`TryToDrink` 仍是
Action）。回归测试锁定 `Fall instanceof Event && !(Fall instanceof Action)`。

### 3. 哪些关系保留为 field，哪些升级成独立 Node，为什么？

- **保留字段**：theme、destination、instrument、location、source、
  manner——它们只作为"事件内在结构"被读取；15 问中没有任何一问需要
  在两个 Variable 之间 join 这些关系（S2Q1 只需要把 theme 当作最终答案
  读出，question-Fall 机制足够，见第 9 条）。
- **升级为 Node**：`Agent(action, actor)`。证据（指导 §14 预告的压力
  测试，见第 9 条）：S2Q5 需要表达"未知事件 E 的施事是 V"——两个
  Variable 之间的可引用、可 join 关系。字段表示在 E 是 Variable 时根本
  无法写出这个连接；这不是实现困难，是表达力缺失。升级后全局删除
  agent 字段（包括指导 §4 草图里的 `says.agent = fox`，Says 的施事同样
  走 `Agent(says, fox)`），保持唯一 canonical representation。
- 其余全部是命题间关系（Before/Causes/ResultsIn/Goal/...），不涉及
  field-vs-Node 抉择。

### 4. 是否存在任何 field + relation Node 双重表示？

**否。**已核查：事件类上无 agent 字段（grep 验证）；不存在
`EventTheme`/`EventAgent` 之类的镜像类；反过来 theme/destination 等没有
对应关系 Node。指导 §4 的 `says.agent` 草图与 §14 的升级要求冲突时，
按 §14 的证据结论执行。

### 5. Role / State / Claim 如何被替代？

- `Role(event, role:string, filler)` → 参与者语义回到具体事件类的
  intrinsic 字段；施事单独 reify 为 `Agent`。generic Role 整体删除。
- `State(holder, attribute:string, value)` → 每个真实状态一个具体条件
  命题：`LocatedAt`、`Thirsty`、`OutOfReach`、`Asleep`、`Free`、
  `Tickled`；r1 的 `State(x,"location",y)` 即 `LocatedAt(x, y)`。
- `Claim(subject, attribute:string, value:string)` → 真命题子类：
  `VoiceSurpasses{subject, others}`（乌鸦嗓音胜过其他鸟）、
  `DistrustFlatterers`（狐狸的忠告内容）。`Says.content` 与
  `Believes.proposition` 直接引用这些对象。

### 6. Initially / Becomes 如何按真实语义拆解？

未机械套换，逐条判断：

- r1 `Initially(State(crow, condition, "half-dead with thirst"))` →
  `Thirsty(crow)` 直接 assert：这是世界状态，不是叙事相对概念。
- r1 `Initially(State(water, amount, "very little"))` → `OutOfReach(water)`
  （叙事中的操作语义："够不着"）；不保留"量很少"的抄写性事实。
- r1 `Initially(State(cheese, location, beak))` → 删除独立状态，改为
  `FlyOff{theme: cheese}` 的 intrinsic 结构（叼着奶酪飞走）。
- r1 `Becomes(dropFirst, State(pebble, location, pitcher))` →
  `ResultsIn(dropFirst, LocatedAt(pebble, pitcher))`：投石的结果。
- r1 `Becomes(dropCheese/gnaw/snapUp, ...)` → 同上 `ResultsIn`。
- r1 `Becomes(waterRise, State(water, level, "near the top"))`、
  `Becomes(drink, State(crow, thirst, "quenched"))` → 删除：水位上升
  与解渴分别是 `Rise`/`Quench` 事件本身的内涵，再挂结果命题是同义反复。
- r1 `Becomes(plead, State(lion, mood, tickled))` → `Tickled(lion, offer)`
  直接 assert（叙事时点起成立）+ `Motivates(tickled, spare)`。

约定（**r3 勘误后的当前语义**）：**plain Assertion = 当前 Situation 无条件
持有该 Proposition**。Input occurrence order 不是 truth interval——"从其
叙事位置起成立直到后续反例"不是本模型的语义；若未来需要"事件前成立、
事件后失效"等时间化真值，应由显式 cognition（时序命题 / Situation /
未来类型）表达，而不是从 Input 顺序推导。`ResultsIn(E, P)` = 该 Situation
持有"P 是 E 的结果"这一命题；r3 起，经 `ResultsIn` 把 P 计入 held 候选
还要求 `Occurs(E)` 已被断言（见 r3 修订）。未引入 HoldsBefore/HoldsAfter
——现有三篇没有需要"在事件 X 之前成立"的真实表达。

### 7. 删除 topLevelPattern 后 resolver 如何寻找证据？

从 `Bindings(variable)` 的**直接 mentioner** 出发，按 mentioner 自身的
语义类解释（`Search.QuestionTuples` 分派）：

- question Event（未发生、字段含 Variable）→ 扫描 occurred 同类事件，
  按"question 声明的字段子集"匹配（未声明字段即通配）；
- question 关系命题 → 扫描被 assert 的同类命题，字段全集匹配；
- question 条件命题 → 扫描 held 同类命题（直接被 assert，或为被 assert
  的 `ResultsIn` 的内容），字段全集匹配。

S1Q5 证明了不需要上溯：问题 `LocatedAt{pebble, place: V}` 的直接
mentioner 就是它自己；"held" 候选集合包含被 assert 的
`ResultsIn(dropFirst, LocatedAt(pebble, pitcher))` 的内容，因此直接命中。
回归 "no-climb" 两例锁定：外层未 assert wrapper 既不参与匹配也救不了
无匹配的问题。§11 指出的"mentioner ≠ 可透明穿透的包装层"在此成为
solver 的结构性质而非纪律约定。

### 8. Bindings() 在新 solver 中具体只承担了什么？

三个纯索引用途，无一携带推理含义：

1. `Bindings(variable)`：找直接提到该 Variable 的 question cognition
   （r3 起排除作为 Imperative content 的 requested Node，见 r3 修订）；
2. `Bindings(event)`（`Occurred` 内）：确认某 `Occurs(e)` 被断言（r2 的
   `agentName` 属英语 realization 层，r3 已随该层删除）；
3. `Bindings(proposition)`（`IsAsserted` 内）：确认某命题被断言。

"X mentions P ⇒ P 如何参与求解"由 mentioner 的语义类决定：回归
"adjacency: same mention, three different meanings" 用同一个
`LocatedAt` 被三种节点提及展示差异——`Says.content`（说了 ≠ 成立）、
`Assertion`（成立）、`ResultsIn` 的内容（作为结果成立）。

### 9. Story 2 Q5 如何联合求解；对 field-vs-Node 边界提供了什么证据？

求解：同一 Query 含 `E`、`V` 两变量；question `Causes{cause: E,
effect: dropCheese}` 给出 E 的候选 {sing}，question
`Agent{action: E, actor: V}` 给出全部 (action, actor) 对；join 后唯一
幸存 {E: sing, V: crow}。

**结论（按指导要求明确记录，不模糊处理）**：

> field-only 的施事关系无法表达"未知事件的施事"——当 E 还是 Variable
> 时，不存在任何 cognition 能写出 agent(E)=V 这个连接。这构成施事关系
> 必须作为变量之间可引用、可 join 的独立语义对象的真实证据；因此
> `Agent` 升级为 Node，且全局删除 agent 字段，无双真源。

反向证据同样成立：theme 从未出现在变量间 join 中（S2Q1 的 theme 只是
最终答案槽），question-Fall + occurred 匹配机制足以及时求解，因此 theme
留在字段。**边界判据 = 该关系是否需要以变量对变量的身份参与推理**，
而不是"是否被查询"。

### 10. 哪些仍是 framework friction，哪些只是 vocabulary 未成熟？

- **Framework friction**：① 声明字段只能整体出现在 Object.entries 可见
  的位置——situation-only 构造 + 赋值风格可行，但字段成为普通可写属性，
  "Resolve 期间不改 Declaration" 从 Foundation 的 writable:false 约定退化
  为纯纪律（Foundation 原文即说这本来就只是约定）；② `Bindings` 的
  "直接 mention" 语义让嵌套问题（r1 的 S1Q5 形态）必须由**内层** cognition
  自带完整求解语义，外层锚定信息（"after the drop"）只能作为冗余语境
  存在或干脆不写——信息没有被利用，问题答案恰好无歧义所以成立；若
  出现多个 ResultsIn 时代的 LocatedAt，需要更强的时序条件，届时应引入
  真正的时序条件命题而不是恢复上溯。
- **Vocabulary 未成熟**：`Veracity{proposition, truth:boolean}` 仍是
  布尔开关（指导允许保留的观察点）；`Tickled{subject, at}` 的 `at` 指向
  一个名义化实体 "the mouse's offer"——叙事把承诺说成物，模型跟随叙事，
  但 offer 的本体（事件？命题？）未定；`Sing.manner` 是表层串挂在事件上。

### 11. Foundation 是否保持零修改？

**是。**`diff -r src/foundation/Memory/Foundation run/.../space/Memory/Foundation`
及 Test/Test.js/Resolve.js 逐字节一致；`src/`、`doc/` git 干净；space 副本
自检通过。领域层只使用了 Perspective / Bindings / Value / Evaluate 这些
公开面。

---

## 额外记录

### 自然之处

1. **situation-only 构造 + 字段赋值显著改善了 story source 可读性**：
   `const fall = new Fall(root); fall.theme = cheese;` 比 r1 的
   fields-object 一步到位更接近叙事书写顺序，新增字段不破坏任何调用点。
2. **语义子类消解了 stringly 判断**：solver 不再解析 "actor"/"location"
   字符串；每个类的含义在 Search/Realize 的 instanceof 分派里一眼可读。
3. **Fall/Rise/Wake/GetTrapped 非 Action 化后，"谁做了什么"与"什么发生
   了"自然分家**：r2 的 realization 对无 agent 事件自动以 theme 作表层
   主语，cheese-fall 的错误表示（cheese 当 actor）在类型层面不可复现
   （r3 起英语 realization 层删除，分家本身仍成立——施事只在
   `Agent` 命题里，事件类上无通道）。
4. **question-Event 机制**（未发生、含 Variable 字段的同类事件）让
   "What fell?" 这类存在性问题无需任何关系 Node 即可求解，直接验证了
   §14 前半命题。

### Friction

1. **注册副作用的隐式性**（r2 记录；r3 已随英语 realization 层整体删除
   而消解）：lexicon 拆两个文件后，action 词条模块必须被副作用导入
   （`import "./Lexicon.js"`）才生效——漏导入在运行期才以
   "No realization" 暴露。机器投影没有注册表，无此问题。
2. **字段可选性 vs 全集匹配**：关系命题的字段全集匹配依赖"该类字段
   必填"的约定（Says 的 content/text 可选，故 Says 不做 question 类）。
   该约定目前只存在于类注释，Analyze 不检查。
3. **行数预算迫使词表按故事拆文件**（Actions.js / Deeds.js、Lexicon.js /
   Phrases.js），拆分纯为 160 行门禁，无语义含义——词汇量继续增长时
   需要更好的组织维度。
4. **本轮真值语义仍未开始**：Veracity 布尔、offer 名义化、belief 未
   Situation 化——均为指导 §11 明确留到下一轮的问题。

### 实现过程中修正的两个自身 bug（均有回归锁定）

- `sameValue` 重写时丢失 `instanceof Node` 排除，两个同形 Entity 一度
  被判等（identity 回归抓住；agent-join 回归连带验证了它对 join 的污染：
  两个无字段 Fall 被结构误判相等导致 Causes 多匹配）；
- story 迁移中对同一命题先手工 push 又 `Assert`（Assert 自身会 push），
  被 Analyze 的 Duplicate Node occurrence 当场拦截。

---

## Phase1r3 修订（当前 canonical semantics）

### 1. Assertion 的真值语义（勘误）

普通 `Assertion(P)` 的语义是：**当前 Situation 无条件持有 P**。不存在
"从 Input / 叙事位置开始成立、直到后续反例"的自动时间区间语义；Input
occurrence order 不是 truth interval。时间化真值条件属于未来的显式
cognition（时序命题 / Situation 等），不属于本模型的基础断言。

### 2. `ResultsIn` 的 held 传递需要事件已发生

`Assertion(ResultsIn(E, P))` 只表示"该 Situation 持有：P 是 E 的结果"。
领域 resolver 若因此把 P 当作当前 held 候选，必须先确认
`Assertion(Occurs(E))` 在可见 cognition 中成立。E 存在、甚至
`ResultsIn(E, P)` 被断言，都不足以让 P 当前成立。回归
`resultsin: an unoccurred event's result is not held` 锁定（含正向对照）。

### 3. 回答链路：Query 解析 → 请求 Konsupu 执行 Says

每个 case 的询问结构（同一 root Situation、同一 ordered Input）：

```text
question cognition（未断言、含 Variable；与 r2 完全相同）
Query([answer, ...extra])
Says(content = answer)                        // 回复形式，非世界断言
Imperative(KonsupuIdentity.Ref(), says)       // 请求当前 Konsupu 执行
```

三条边界继续保持：

- **Says 存在 ≠ 被请求 ≠ 已发生**：不添加 `Assertion(Occurs(answerSay))`
  （回归 `imperatives: a requested Says never occurs` 同时断言 resolution
  不向 Input 添加任何 Node）；
- **ResolveImperatives 不做 Query reasoning**：经 Imperative Perspective
  `RequireValue(says.content, reason)` 读取已完成 resolution 的值；读取
  失败按 InputStructureError 处理（Input 顺序破坏了依赖），绝不悄悄重解；
- **applicability 只判断领域可执行性**：addressee 的 KonsupuIdentity 筛选
  由 Foundation 的 ImperativeLoop 承担，领域只检查 `content instanceof
  Says`，不重复实现身份筛选（回归 `imperatives: a foreign addressee ...`
  用第二个 GlobalNode 身份验证外来祈使不进入本 Konsupu 的 resolution）。

### 4. requested content 不是 question cognition（本轮新领域规则）

`Says(content = answerVariable)` 使回复 Says 成为 answer Variable 的
Event mentioner；`Bindings` 如实报告这一邻接。但邻接不定义含义：
Imperative 的 content 是**被请求执行的 doing（回复形式）**，不是对世界的
询问。`QuerySolver` 据此把"作为某 Imperative content 的 mentioner"排除出
question 解释（`requested(view, node)`）。禁用该排除的变异测试：7 项回归
失败、问题 1/15——该排除保护的是整个回复链路。这不是上溯（topLevelPattern
仍不存在）：不是沿 mention 链向上爬，而是按 Imperative 类自身的语义
（"请求执行其 content"）判定该 mention 不参与提问。

### 5. 输出：集中机械投影，删除英语 realization

`Project.js` 是唯一的 value→文本规则：`Entity` → `Entity(<name>)`（name
是既有表层串）；其他 Node → `Class(field=..., ...)`，**字段名排序**（属性
插入顺序是构造细节，非声明语义——与 exact 匹配的顺序无关化同一条原则）；
数组/纯数据各有确定形态。投影只读 value 自身结构，不读其他 cognition
（对 asserted/unasserted `Agent` 完全不敏感，回归锁定），不做事实推理。
15 个 expected answer 相应改为 machine text；`form`（past/to-infinitive）
概念删除。英语时态/词形/phrase 生成（Realize/Lexicon/Phrases/Wording）
整体删除，未以任何形式保留。

### 6. 字段匹配的顺序无关性

`BindFields(..., exact)` 的 exact 判定改为"字段名集合相同 + 逐字段值
匹配"。逐位置比较 `Object.entries()` 顺序会把 construction detail 当成
declaration semantics（situation-only 构造 + 逐字段赋值风格下，赋值顺序
任意），回归 `exact: field assignment order does not affect matching`
锁定。`sameValue` 的 plain-object 分支本就排序，与此一致。

---

## Phase1r4 修订（当前 canonical semantics）

### 1. 三层 Situation 与交错布局（结构事实，非风格选择）

每个 case 是 `dialogue`（初始 root）/ `story`（另一 root，只含寓言事实）/
`asked`（story 的子 Situation，每问一个）三层。两个由 Foundation 结构
决定的布局事实：

- **dialogue 必须是 Input 的第一个 Situation**：Analyze 对除第一个外的
  全部 Situation 强制 semantic mention，而 dialogue 没有提及者；
- **dialogue 的成员节点必须排在 story 树之后**：引用必须指向更早的
  Input 出现（Asks 提及 story/asked、Query/Says 经 ref(asked, answer)
  取值都要求 story/asked 在前）。

二者合成交错布局 `[dialogue, story…, asked…, Asks, Query(dlg), Says,
Imperative]`。`Asks` 以普通字段提及两个 Situation——Situation 引用不受
"Cross-Situation cognition requires ref" 约束（CheckReference 对
Situation 提前返回），这是 mention 机制的合法通道。dialogue 的
re-export Query 被 PlanQueries 以 `source.query !== query` 判空，
QueryLoop 从不调用 resolver：纯重导出零成本，也无需任何领域处理。

### 2. 问就是 Query；约束就是持有

r2/r3 的"未断言且含 Variable 的认知＝问题模板"在本轮从语义上删除。
当前语义：**Query 只声明未知量；约束是 asked 持有的命题（Assertion），
支持池是祖先链持有的命题**。未断言的 Node 无论含什么 Variable 都不构
成约束（回归 + 变异验证）。r3 的 `requested()` 排除随之删除：回复 Says
在 dialogue，不在 asked 的祖先链上，对求解**结构性**不可见——r3 记录的
那条例外规则（friction 清单第 5 条）被结构本身取代，这是本轮最直接的
friction 消解。

### 3. 描述与对应：Node 身份 ≠ 指称身份

asked 中的描述是普通 Node；它与故事中哪个 Node 对应由显式命题
`Among{situation, node}` 表达，由求解时确定（存在性匹配：类含子类、
只约束已写字段）。`matchValue` 中 Node 的角色（审查后修订）：

- **描述**＝被持有的 `Among` 点名的 asked Node。每个解中它对应恰好一个
  故事 Node，因此像 Variable 一样在 tuple 中绑定对应者；同一描述在所有
  约束里必须对应同一 Node。
- **asked 命题**按内容匹配（类含子类 + 字段），因为命题的身份就是它的
  内容（如 S1Q5 的 `ResultsIn(d, LocatedAt(pebble, x))` 内层）。
- **其余**（故事 Node、没有 `Among` 的 asked 个体）是常量，只匹配自己。
  坐落在 asked 本身**不**使 Node 成为描述——首版用的正是这条隐式规则，
  导致 `Among` 形同虚设、描述指称不统一（见 RESULTS 审查后修正）。

字段值是 Array 或普通 record 时按形状逐项递归匹配（长度、键集须相同），
其中的 Variable 与描述照常绑定，例如 `Series(parts=[dropFirst, x])`。
Map、Set 等其他对象按 identity 比较。

开放类 `Get`（concrete 非 final，`SnapUp extends Get`）让
翻译不必知道故事用词的最具体类——Foundation 只规定 concrete 类"默认"
final，领域选择开放是合法的。`Among` 不蕴含发生；`Occurs(f)` 单独持有
且要求对应事件已发生。

### 4. 变量只取祖先个体；resolved ≠ known

Variable 的值域是祖先（story）中已有的个体，不引入新个体；故事未写的
字段读作 `Unknown`，不是 `undefined`。每个未写字段有自己的 Unknown：同一
字段的两次读取相等，不同字段的 Unknown 永不相等（故事没说它们是同一个值）。无解是正常结果：`Unknown`（值未
确定）、`Ambiguous{candidates, unstated?}`（多值同时满足；有解未写出该值
时 candidates 只列已写出的值并标 `unstated`，此时单个 candidate 也不算唯一）、
`NotEstablished{constraints, level}`（持有约束未被故事确立，level 为
correspondence / instance / joint）。失败归属与约束在 Input 中的顺序无关：
有无对应者的 `Among` 时为 correspondence 并列出这些 `Among`；否则有无支持
的约束时为 instance 并列出它们；否则为 joint 并列出全部持有约束（没有
单一约束可以归责）。`Among.situation` 必须是 asked 之上的 Situation，指向
asked 自身或链外 Situation 时没有对应者（correspondence），不抛异常。开放世界中预设无法被驳倒，只能未被
确立，故不设 PresuppositionFailed；失败记录保留约束与层级，将来按领域
蕴含（如 Action 蕴含施事）细分时无需改表示。这些都是普通冻结值，
经 Says 说出、Project 机械投影；只有被 Says 说出的变量的 Ambiguous 才是
最终回答，辅助变量（含描述的隐式对应与显式 helper Variable）允许
Ambiguous。硬异常保留给实现错误。

### 5. 时间关系：Next 断言，Before 推导

故事只断言相邻事件的 `Next`；`Before` 是 Next 链的传递闭包（领域推理，
`beforePairs`），不要求也不允许故事枚举两两 Before。"after/when" 的翻译
按原文语义选择：叙事后继读法用 `Next`（唯一），字面"之前/之后"用派生
`Before`（如实多解为 Ambiguous）。未定义任何英语词的直译概念。

条件命题以抽象类 `Condition` 标识（`LocatedAt` 等均继承它）；求解按类
识别，新增条件类无需登记即获得"经已发生的 ResultsIn 持有"的支持。

### 5a. 集合事件 Series

`Series{parts}` 是若干事件依次发生、作为整体的一个事件（`Event`，非
`Action`）。它让故事表达"这些部分合起来造成了什么"而不把结果归于任何
单个部分；各部分保留自己的发生与 Next 次序，Series 本身不进入 Next 链。
story-1 用它表达 "little by little"：`Causes(Series[dropFirst,
dropOthers], waterRise)`、`InOrderTo(Series, waterRise)`。

### 6. 本轮翻译判断记录（指导授权范围内的选择）

- **S2Q3**（用户确认）：故事新增 voice 个体 + `About(claimVoice, voice)`
  断言；asked 持有 `Believes(crow, x)` + `About(x, voice)`——问题级约束
  显式，expected 不变。About（话题性）与 VoiceSurpasses.subject（论元）
  是不同语义关系，不构成双重表示。
- **after/when**（用户确认）：按指导第三节第 4 条，不定义英语词的直译
  概念，由翻译按各问题原文选择语义明确的关系，同一个 "after" 在不同问题
  中可译成不同关系。S1Q2、S3Q2 的 "What happened / did ... do after X" 问
  的是叙事上紧接着的下一件事，S2Q2 的 "when" 同理，译 `Next`。S1Q4 的
  "What was the crow able to do after the water mounted up" 问的是水位上升
  之后能做到的事，不含"紧接着"，于第二次审查后译 `Enables` + `Before`。
  同一次审查另行修正了 story-1（补上原文水位上升后的再投石），两者独立：
  翻译依据问题原文，不以故事内容倒推。
- **S3Q4**："for the lion" 判断为**不需要**新受益者认知：故事只有一件
  Promise（单例直引即可），且 `Help.theme` 即受益者——答案
  `Help(theme=Entity(the lion))` 自身承载该信息，额外关系只会是无判别力
  的机器。
- **S1Q1**："a pebble" 不加约束（故事有三次投石：第一枚、其余几枚、
  水位上升后再投的几枚；主题开放时三次 Drop 都匹配而施事唯一）；若加 theme=pebble 约束则唯一匹配首次
  投石——两种译法答案相同，取信息量更少的一种，由 `Among` 的字段子集
  语义自然承载。

### 7. Foundation 零修改（延续）

三层结构、ref 跨 root 取值、Asks 显式提及、re-export Query、
CheckVariableValue 对结构化结果的放行，全部是既有语义的正用；diff 逐
字节一致并由最后一项回归在每次运行时核对。本轮无 Foundation change
candidate（体验观察见 FOUNDATION_NOTES.md）。
