# Konsupu Aesop Phase 1r4 — Foundation 使用体验观察

本轮第一次使用多 root Input（dialogue / story）、子 Situation 细化
（asked）、跨 root 的 `ref` 取值、Situation 的显式提及（Asks）、以及
结构化结果值（Unknown / Ambiguous / NotEstablished；审查后由
PresuppositionFailed 改名重设计，见 RESULTS）。按 r3 的
分类记录：**A** 领域设计问题、**B** API ergonomics、**C** 语义缺陷。
结论先行：**未发现 C 类问题，无 Foundation change candidate**。

## 1. 三层 Situation 与 ref 跨 root 取值

- 结构表达自然。`Situation(parent)` 一参数即可建立细化关系；story 与
  dialogue 无共同祖先即两个 root，`CanImport` 的"无关树可导入"规则让
  `ref(asked, answer)` 从 dialogue 取值完全合法，无需任何特殊通道。
- **交错布局是结构推出的，不是文档明说的**（A/B 之间，偏 B 的可发现性
  问题）：Analyze 只豁免 Input 第一个 Situation 的 semantic mention，
  而引用又必须指向更早出现——两者合谋要求"dialogue Situation 最前、
  dialogue 成员最后"。这个不变量在 InputContract 的条目里分开可推
  （"situations"/"mention"/"order"三条），但没有一处直接陈述多 root
  时的合成结果。本轮靠读源码（Analyze.slice(1) + CheckReference）确证；
  一个把"多 root 布局"写进 contract 文本的补充能让领域作者少走一步。
  这是文档/契约可发现性问题，不是语义缺陷。
- `ref(asked, answer)` 作为 Says.content 与 Query 项都工作良好；对话层
  的 re-export Query 被 PlanQueries 自动判空、QueryLoop 跳过——"列 ref
  即重导出"的既有设计在本轮被第一次真实使用，零成本、零意外。
- Situation 的显式提及（Asks 的普通字段指向 story/asked）是合法通道：
  CheckReference 对 Situation 引用豁免跨 Situation 规则，IndexMentions
  把 ReportReferences 报告的 Situation 记为 mentioned。机制干净；唯一
  注意点是提及必须由类型**显式报告**（ReportDataMembers 恰好做到），
  纯结构引用（不写 ReportReferences）不计——这与文档一致。

## 2. Nodes() 与 Bindings() 的范围不一致（指导 §八点名观察）

- 事实：`Perspective.Nodes()` 默认只返回当前 Situation 的成员；
  `Bindings()` 与 `Ancestors()` 看整条祖先链。r3 的 solver 因此在 asked
  下看不到故事事实——本轮 `heldAbove` 显式遍历 `view.Ancestors()` 并对
  每个 Situation 调 `Nodes(situation)`。
- 判断（B，轻微且可辩护）：两者范围不同是**有语义理由的**——Nodes 是
  "这个 Situation 自己声明了什么"（约束、成员），Bindings 是"谁提到了这
  个引用"（索引按可见性过滤）。求解器恰好需要这两个不同的问题。但
  "给我整条链上持有的命题"这类最常见询问没有便捷形态，领域要自己写
  三行遍历。可考虑的 ergonomics（不需要现在做）：一个
  `HeldAbove()`/`ChainNodes()` 便捷方法。本轮选择在 Support.js 固化为
  领域机械层，不构成 Foundation 缺陷。

## 3. "Query 列出的每个变量都必须求解" × 辅助变量 Ambiguous

- QueryLoop 的进度语义（每轮必须完成非空子集、直到 remaining 清空）
  与"辅助变量允许 Ambiguous"配合良好：Ambiguous 是一个普通值，赋给
  helper Variable 即算"已求解"。S2Q5 的未知事件、S1Q1 的描述对应都是
  helper，被问变量唯一即可回答。
- 唯一要注意的（B，已由结构化结果自然消解）：变量"完全无约束"时不能
  留空，必须显式赋 `Unknown`——这正是"resolved ≠ known"的体现，语义
  上正确，写法上要求 resolver 覆盖 remaining 的全部变量（本 solver 天然
  如此）。
- `CheckVariableValue` 对冻结 plain object 值直接放行（只禁裸 Variable
  与坏 ref），结构化结果作为值无需任何包装类型——这是本轮最顺手的
  Foundation 行为之一。

## 4. 描述 Node 与对应关系 vs 身份语义边界

- 描述 + `Among` 完全落在既有身份语义之内：两个 Node 永不合并（描述
  与故事事件是不同对象），指称同一性由显式认知（Among）表达且只在求解
  时确定。`matchValue` 的角色分派（`Among` 点名者＝描述并绑定对应者、
  asked 命题＝内容匹配、其余＝常量）是纯领域规则，Foundation 无需知情。
  首版以"asked 坐落即描述"分派，属 A 类领域缺陷，已修正（见 RESULTS
  审查后修正）。
- 未出现需要"描述 Node 指称等价"进入 Input 结构（如把描述当 ref 目标）
  的场景；`Among` 作为普通 Proposition 参与持有/支持语义已经足够。
  若未来需要给"同一指称"建模多个方向的等价（description ↔ description），
  那将是新的领域命题类，不是 Foundation 改动。

## 5. 其余观察

- `InputStructureError`（"Cross-Situation cognition requires ref"、
  "Duplicate Node occurrence"、"Situation lacks semantic mention"）在
  本轮 fixture 构造错误时全部给出可定位信息——结构边界回归把第一个
  错误文案直接用作结构边界断言。
- 运行时以 fs 逐字节比对 Foundation 副本与 `src/foundation`（最后一项
  回归）比外部 diff 更早报警，建议后续轮次保留。
- 本轮再次零修改 Foundation；上述可发现性/便捷性建议均属 B 类记录，
  不构成 change candidate。
