export function ResolveQueryDefer(input, query, remaining, state) {
  // The story-world solver assigns every remaining variable in one pass,
  // as a value or a structured Unknown / Ambiguous / NotEstablished result.
  // Nothing is left for a deferred pass, so this entry stays a legal no-op.
  return new Map();
}
