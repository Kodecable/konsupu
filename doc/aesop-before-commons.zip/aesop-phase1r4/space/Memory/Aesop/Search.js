// Domain-semantic support. The asking Situation (asked) holds propositions
// as constraints; every one of them must be supported by what the Situation
// chain above holds — the story. The structure only supplies adjacency and
// fields; the meaning of each class is decided here.
//
// - Among{situation, node}: the described node is one of that Situation's
//   nodes. It is the only thing that makes an asked Node a description:
//   Node identity never places one, and being among them never means the
//   event happened. Only a Situation above the asking one can support it;
//   naming the asking Situation itself, or one outside its chain, has no
//   correspondent.
// - Conditions (every Condition subclass): supported by propositions of
//   the class the story asserts directly, or carries as the content of an
//   asserted ResultsIn whose event occurred.
// - Before: never enumerated by the story; it is what the story's asserted
//   Next chain entails (transitive domain reasoning).
// - ResultsIn: supported only when the supporting event occurred.
// - Every other proposition: supported by a proposition of its class (or a
//   subclass) the story asserts, matched field by field.
import { Among } from "./Correspondence.js";
import { Condition } from "./Conditions.js";
import { matchValue } from "./Match.js";
import { Before, ResultsIn } from "./Relations.js";
import {
  heldAbove,
  tuplesFrom,
  classPool,
  occurredSet,
  conditionPool,
  beforePairs,
  amongTuples,
} from "./Support.js";

// The level a constraint fails at when it has no support at all.
export function SupportLevel(constraint) {
  return constraint instanceof Among ? "correspondence" : "instance";
}

export function Support(view, constraint, context) {
  const asked = context.asked;
  if (constraint instanceof Among) {
    const above = view.Ancestors().filter((situation) => situation !== asked);
    if (!above.includes(constraint.situation)) return [];
    const pool = view.Nodes(constraint.situation);
    return amongTuples(constraint, pool, context);
  }
  const held = heldAbove(view, asked);
  if (constraint instanceof Before) {
    const tuples = [];
    for (const [earlier, laterList] of beforePairs(held)) {
      for (const later of laterList) {
        const bindings = new Map();
        if (
          matchValue(constraint.earlier, earlier, bindings, context) &&
          matchValue(constraint.later, later, bindings, context)
        ) {
          tuples.push(bindings);
        }
      }
    }
    return tuples;
  }
  if (constraint instanceof Condition) {
    return tuplesFrom(constraint, conditionPool(constraint, held), context);
  }
  if (constraint instanceof ResultsIn) {
    const occurred = occurredSet(held);
    const pool = classPool(constraint, held).filter((proposition) => {
      return occurred.has(proposition.event);
    });
    return tuplesFrom(constraint, pool, context);
  }
  return tuplesFrom(constraint, classPool(constraint, held), context);
}
