// Structured Resolve results. "Unresolved" is a normal, structured answer,
// not an exception: a Query variable may come back as one of these plain
// frozen values, which the reply Says then utters and the machine projector
// renders like any other value. Hard errors stay reserved for genuine
// domain implementation faults.
//
// The story is open-world: unasserted is not false, and the domain has no
// negation, so the story can never refute what a question presupposes. It
// can only fail to establish it. Failure is therefore recorded, not judged:
// NotEstablished keeps which held constraints lacked support and at which
// level, so a finer classification (presupposition failure, unstated
// value, refutation once negation exists) can be added later as a pure
// function of this record, without changing the representation.

// The value is not determined: the story leaves a field unstated, or no
// supported constraint mentions the variable at all. Every Unknown reads
// { result: "unknown" }; which field it stands for is kept under a
// non-enumerable key, so projection never shows story structure. Two reads
// of the same field agree in bindings and joins; two different unstated
// fields never do, because the story does not say they hold one value.
// The slot lives on the value itself, so nothing is cached between calls.
const SLOT = Symbol("aesop:unknown-slot");

function makeUnknown(node, key) {
  const value = { result: "unknown" };
  Object.defineProperty(value, SLOT, { value: { node, key } });
  return Object.freeze(value);
}

const unconstrained = makeUnknown(null, null);

// The Unknown of a variable no supported constraint determines.
export function Unknown() {
  return unconstrained;
}

// The Unknown of one unstated field of a story Node. Without a Node there
// is no field to share, so such a read equals only itself.
export function UnstatedField(node, key) {
  const owner = node !== null && typeof node === "object" ? node : null;
  return makeUnknown(owner, owner === null ? null : key);
}

export function isUnknown(value) {
  return (
    value !== null && typeof value === "object" && Object.hasOwn(value, SLOT)
  );
}

// Whether two Unknowns stand for the same unstated field.
export function sameUnknown(left, right) {
  if (left === right) return true;
  if (!isUnknown(left) || !isUnknown(right)) return false;
  const a = left[SLOT];
  const b = right[SLOT];
  return a.node !== null && a.node === b.node && a.key === b.key;
}

// Several values satisfy every constraint at once. `unstated` marks that
// some solutions also leave the value unstated: the candidates are then
// what the story states, not an exhaustive list, and one candidate alone
// is still no unique answer.
export function Ambiguous(candidates, unstated = false) {
  const value = { result: "ambiguous", candidates: [...candidates] };
  if (unstated) value.unstated = true;
  return Object.freeze(value);
}

// Levels at which a held constraint can lack support:
// - "correspondence": an Among description has no correspondent in the
//   named Situation; the thing the question talks about is not there;
// - "instance": no proposition of the story supports the constraint;
// - "joint": each constraint is supported alone, but no single choice of
//   values and correspondents supports them together.
// `constraints` names the failing ones independently of their order: the
// unsupported constraints at the first two levels, the whole held set at
// "joint".
export const Levels = Object.freeze(["correspondence", "instance", "joint"]);

export function NotEstablished(constraints, level) {
  if (!Levels.includes(level)) {
    throw new TypeError(`Unknown support level ${level}`);
  }
  if (!Array.isArray(constraints) || constraints.length === 0) {
    throw new TypeError("NotEstablished needs the failing constraints");
  }
  return Object.freeze({
    result: "not-established",
    level,
    constraints: Object.freeze([...constraints]),
  });
}

export function isOutcome(value) {
  return (
    isUnknown(value) ||
    (value !== null &&
      typeof value === "object" &&
      (value.result === "ambiguous" || value.result === "not-established"))
  );
}
