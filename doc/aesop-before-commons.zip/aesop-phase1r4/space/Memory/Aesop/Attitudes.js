// Attitude propositions: motives, commitments, beliefs, and truth
// verdicts. Existing as objects asserts nothing.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// What moved an actor to act: fields driver, action.
export class Motivates extends Proposition {
  static BRAND = Brand("aesop:Motivates:v1");
  constructor(situated) {
    Final(Motivates, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A commitment to a future deed: fields promiser, deed.
export class Promise extends Proposition {
  static BRAND = Brand("aesop:Promise:v1");
  constructor(situated) {
    Final(Promise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Holding a proposition true: fields believer, proposition.
export class Believes extends Proposition {
  static BRAND = Brand("aesop:Believes:v1");
  constructor(situated) {
    Final(Believes, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// What a proposition is about — its topic: fields proposition, topic.
// Distinct from any participant field of the proposition itself; it says
// the content concerns that individual.
export class About extends Proposition {
  static BRAND = Brand("aesop:About:v1");
  constructor(situated) {
    Final(About, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Whether a proposition holds in the story world: fields proposition,
// truth. Kept as a boolean-carrying relation; see FRAMEWORK_NOTES.
export class Veracity extends Proposition {
  static BRAND = Brand("aesop:Veracity:v1");
  constructor(situated) {
    Final(Veracity, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
