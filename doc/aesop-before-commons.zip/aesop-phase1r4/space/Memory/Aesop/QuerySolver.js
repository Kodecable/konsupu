// Generic entry, domain semantics inside. A Query in the asked Situation
// names its unknowns; the constraints are exactly the propositions the
// asked Situation holds, and every one of them must be supported by the
// Situation chain above — the story. Unasserted cognition never
// contributes constraints, whatever Variables it mentions. Nothing climbs
// mentioners, and no node is excluded for being requested: the reply Says
// lives in the dialogue Situation and is structurally invisible here.
//
// Descriptions are exactly the asked Nodes a held Among names. Each binds
// to one correspondent per solution, so all constraints on a description
// speak of the same story Node. Variables only take values found in the
// ancestors; an unstated field yields Unknown. Constraints without support
// yield NotEstablished, which keeps those constraints and their level for
// later classification. This entry holds no state between calls.
import { Perspective } from "../Foundation/Perspective.js";
import { Assertion } from "./Assertion.js";
import { Among } from "./Correspondence.js";
import { Support, SupportLevel } from "./Search.js";
import { MatchContext, join, sameValue } from "./Match.js";
import { Unknown, Ambiguous, NotEstablished, isUnknown } from "./Outcomes.js";

function heldConstraints(view) {
  const constraints = [];
  for (const node of view.Nodes()) {
    if (node instanceof Assertion) constraints.push(node.proposition);
  }
  return constraints;
}

function descriptions(constraints, asked) {
  const described = new Set();
  for (const constraint of constraints) {
    if (constraint instanceof Among && constraint.node?.situated === asked) {
      described.add(constraint.node);
    }
  }
  return described;
}

// Solve the held constraints together. Returns the surviving tuples, or a
// failure { constraints, level } that does not depend on the order the
// constraints occur in: the Among constraints without a correspondent if
// there are any, else every constraint without support, else (joint) the
// whole held set, since no single member is to blame.
function solveConstraints(view, constraints, context) {
  const supports = constraints.map((constraint) => {
    return Support(view, constraint, context);
  });
  const unsupported = constraints.filter((_, index) => {
    return supports[index].length === 0;
  });
  const absent = unsupported.filter((constraint) => {
    return SupportLevel(constraint) === "correspondence";
  });
  if (absent.length > 0) {
    return { failure: { constraints: absent, level: "correspondence" } };
  }
  if (unsupported.length > 0) {
    return { failure: { constraints: unsupported, level: "instance" } };
  }
  let tuples = null;
  for (const found of supports) {
    tuples = tuples === null ? found : join(tuples, found);
    if (tuples.length === 0) {
      return { failure: { constraints, level: "joint" } };
    }
  }
  return { tuples: tuples ?? [] };
}

// The variable's value across the surviving tuples. Solutions that leave it
// unstated never count as a separate candidate: with no stated value it is
// Unknown; otherwise the stated values are candidates, and the result is
// unique only when there is one of them and no solution leaves it unstated.
function valueOf(variable, tuples) {
  const stated = [];
  let unstated = false;
  for (const tuple of tuples) {
    if (!tuple.has(variable)) continue;
    const value = tuple.get(variable);
    if (isUnknown(value)) unstated = true;
    else if (!stated.some((item) => sameValue(item, value))) stated.push(value);
  }
  if (stated.length === 0) return Unknown();
  if (stated.length === 1 && !unstated) return stated[0];
  return Ambiguous(stated, unstated);
}

export function SolveQuery(input, query, remaining, state) {
  const view = new Perspective(query, state);
  const asked = view.situated;
  const constraints = heldConstraints(view);
  const context = MatchContext(asked, descriptions(constraints, asked));
  const { tuples, failure } = solveConstraints(view, constraints, context);
  const result = new Map();
  for (const variable of remaining) {
    result.set(
      variable,
      failure
        ? NotEstablished(failure.constraints, failure.level)
        : valueOf(variable, tuples),
    );
  }
  return result;
}
