// The explicit correspondence between a question's description and the
// story world. A description is an ordinary Node in the asked Situation;
// which story Node it refers to is not implied by Node identity (two Nodes
// never merge, and one Node never becomes another) but expressed by this
// proposition: the described node is one of the named Situation's nodes.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

// "node is among the cognition of situation": fields situation, node.
// Holding this does not mean the described event happened; occurrence is
// the separate Occurs constraint.
export class Among extends Proposition {
  static BRAND = Brand("aesop:Among:v1");
  constructor(situated) {
    Final(Among, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
