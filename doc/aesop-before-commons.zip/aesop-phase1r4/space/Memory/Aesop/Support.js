// Mechanical support pools for the solver: what the story chain holds,
// which events occurred, where conditions come from, and what the Next
// chain entails. Nothing here decides what any semantic class means; the
// dispatch in Search.js does. Pools select by instanceof, so a constraint
// of a general class is supported by instances of its subclasses — the
// same rule descriptions follow.
import { Assertion } from "./Assertion.js";
import { fieldValue, fieldsOf, matchValue } from "./Match.js";
import { Occurs, Next, ResultsIn } from "./Relations.js";

// All propositions asserted by the Situations above the asking one.
export function heldAbove(view, asked) {
  const held = [];
  for (const situation of view.Ancestors()) {
    if (situation === asked) continue;
    for (const node of view.Nodes(situation)) {
      if (node instanceof Assertion) held.push(node.proposition);
    }
  }
  return held;
}

// Match a constraint's written fields against each candidate; a fresh Map
// per candidate keeps bindings independent.
export function tuplesFrom(constraint, pool, context) {
  const tuples = [];
  for (const candidate of pool) {
    const bindings = new Map();
    let ok = true;
    for (const [key, pattern] of fieldsOf(constraint)) {
      const value = fieldValue(candidate, key);
      if (!matchValue(pattern, value, bindings, context)) {
        ok = false;
        break;
      }
    }
    if (ok) tuples.push(bindings);
  }
  return tuples;
}

// Held propositions of the constraint's class, subclasses included.
export function classPool(constraint, held) {
  return held.filter((proposition) => {
    return proposition instanceof constraint.constructor;
  });
}

// What the story asserts as occurred, as a set of event nodes.
export function occurredSet(held) {
  const occurred = new Set();
  for (const proposition of held) {
    if (proposition instanceof Occurs) occurred.add(proposition.event);
  }
  return occurred;
}

// Conditions hold when asserted directly, or as the result content of an
// asserted ResultsIn whose event actually occurred.
export function conditionPool(constraint, held) {
  const occurred = occurredSet(held);
  const pool = classPool(constraint, held);
  for (const proposition of held) {
    if (
      proposition instanceof ResultsIn &&
      occurred.has(proposition.event) &&
      proposition.proposition instanceof constraint.constructor
    ) {
      pool.push(proposition.proposition);
    }
  }
  return pool;
}

// All ordered pairs the story's Next chain makes true, deduplicated.
export function beforePairs(held) {
  const successors = new Map();
  for (const proposition of held) {
    if (!(proposition instanceof Next)) continue;
    if (!successors.has(proposition.earlier)) {
      successors.set(proposition.earlier, []);
    }
    successors.get(proposition.earlier).push(proposition.later);
  }
  const pairs = new Map();
  for (const earlier of successors.keys()) {
    const seen = new Set();
    const agenda = [...successors.get(earlier)];
    while (agenda.length) {
      const later = agenda.pop();
      if (seen.has(later)) continue;
      seen.add(later);
      pairs.set(earlier, [...(pairs.get(earlier) ?? []), later]);
      agenda.push(...(successors.get(later) ?? []));
    }
  }
  return pairs;
}

// Among matches its description against every node of the named
// Situation; the match binds the description to its correspondent, so
// every other constraint on the same description must agree with it.
export function amongTuples(constraint, pool, context) {
  const tuples = [];
  for (const node of pool) {
    const bindings = new Map();
    if (matchValue(constraint.node, node, bindings, context)) {
      tuples.push(bindings);
    }
  }
  return tuples;
}
