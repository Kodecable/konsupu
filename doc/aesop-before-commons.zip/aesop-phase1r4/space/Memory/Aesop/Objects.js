// World objects. An Entity or Event occurrence says "this object is part of
// the cognition", never "something is true" and never "it happened".
// Occurrence is the asserted Occurs proposition. Events without an agent
// are plain Events; agentive doings extend Action; Says is an Action
// because speaking is something the speaker does. Get is a concrete but
// open general doing: descriptions may instantiate it without knowing the
// story's most specific class.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

// A discourse individual, identified by object identity; `name` is surface
// text for realization only.
export class Entity extends SituatedNode {
  static BRAND = Brand("aesop:Entity:v1");
  constructor(situated) {
    Final(Entity, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// A referable happening with an occurred / not-occurred distinction. No
// agent is implied. Fields are declared per concrete class as intrinsic
// structure (theme, destination, ...) via explicit assignment.
export class Event extends SituatedNode {
  static BRAND = Brand("aesop:Event:v1");
  constructor(situated) {
    if (new.target === Event) throw new TypeError("Event is abstract");
    super(situated);
  }
}

// An Event modeled as carried out by some Entity. The only added meaning
// is agentivity; intention, success, or responsibility are separate
// cognitions. The agent itself is the reified Agent proposition (see
// Relations.js), never a field here.
export class Action extends Event {
  static BRAND = Brand("aesop:Action:v1");
  constructor(situated) {
    if (new.target === Action) throw new TypeError("Action is abstract");
    super(situated);
  }
}

// Speaking: fields `content` (the semantic content being said) and `text`
// (surface string). Story speech says Propositions; the reply Says that an
// Imperative requests says the resolved answer value — an Entity, an
// Event, or any other semantic content. Says.content is speech content:
// the Situation does not hold it true just because it was said.
export class Says extends Action {
  static BRAND = Brand("aesop:Says:v1");
  constructor(situated) {
    Final(Says, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled downward motion: fields theme, destination.
export class Fall extends Event {
  static BRAND = Brand("aesop:Fall:v1");
  constructor(situated) {
    Final(Fall, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled upward motion: field theme.
export class Rise extends Event {
  static BRAND = Brand("aesop:Rise:v1");
  constructor(situated) {
    Final(Rise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Coming out of sleep, happening to the sleeper: field theme.
export class Wake extends Event {
  static BRAND = Brand("aesop:Wake:v1");
  constructor(situated) {
    Final(Wake, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Being caught in a trap, happening to the trapped: fields theme, location.
export class GetTrapped extends Event {
  static BRAND = Brand("aesop:GetTrapped:v1");
  constructor(situated) {
    Final(GetTrapped, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Coming to hold something. Concrete but deliberately not final: a question
// may describe a getting without knowing how the story words it, so more
// specific doings (SnapUp, ...) refine this class. Field theme.
export class Get extends Action {
  static BRAND = Brand("aesop:Get:v1");
  constructor(situated) {
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// One happening made of several events done one after another, taken as a
// whole: field parts (the events, in narration order). It lets the story
// say what the parts did together ("little by little") without crediting
// any single part. Its parts keep their own occurrence and order.
export class Series extends Event {
  static BRAND = Brand("aesop:Series:v1");
  constructor(situated) {
    Final(Series, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Dialogue cognition: the asking situation of a dialogue names the story
// world it is about and the asked Situation that refines it. Fields story,
// asked. This is what gives both Situations their semantic mention.
export class Asks extends SituatedNode {
  static BRAND = Brand("aesop:Asks:v1");
  constructor(situated) {
    Final(Asks, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
