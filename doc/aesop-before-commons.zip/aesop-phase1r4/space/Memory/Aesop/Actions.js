// Concrete agentive doings used by the pitcher and crow stories. The split
// between this file and Deeds.js is only the line budget; both hold the
// same kind of vocabulary. Fields are intrinsic structure assigned after
// construction; the agent is the reified Agent proposition.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action, Get } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Finding something: field theme.
export class ComeUpon extends Action {
  static BRAND = Brand("aesop:ComeUpon:v1");
  constructor(situated) {
    Final(ComeUpon, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Placing something somewhere: fields theme, destination.
export class Put extends Action {
  static BRAND = Brand("aesop:Put:v1");
  constructor(situated) {
    Final(Put, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Attempting to drink: field theme.
export class TryToDrink extends Action {
  static BRAND = Brand("aesop:TryToDrink:v1");
  constructor(situated) {
    Final(TryToDrink, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Having an idea.
export class ThinkUp extends Action {
  static BRAND = Brand("aesop:ThinkUp:v1");
  constructor(situated) {
    Final(ThinkUp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Letting go of something into a container: fields theme, destination.
export class Drop extends Action {
  static BRAND = Brand("aesop:Drop:v1");
  constructor(situated) {
    Final(Drop, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Satisfying thirst: field theme.
export class Quench extends Action {
  static BRAND = Brand("aesop:Quench:v1");
  constructor(situated) {
    Final(Quench, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Preserving one's life: field theme.
export class Save extends Action {
  static BRAND = Brand("aesop:Save:v1");
  constructor(situated) {
    Final(Save, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Leaving while carrying: field theme.
export class FlyOff extends Action {
  static BRAND = Brand("aesop:FlyOff:v1");
  constructor(situated) {
    Final(FlyOff, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Taking a perch: field location.
export class Settle extends Action {
  static BRAND = Brand("aesop:Settle:v1");
  constructor(situated) {
    Final(Settle, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Approaching on foot: field destination.
export class WalkUpTo extends Action {
  static BRAND = Brand("aesop:WalkUpTo:v1");
  constructor(situated) {
    Final(WalkUpTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Making one's calling sound: field manner (surface).
export class Sing extends Action {
  static BRAND = Brand("aesop:Sing:v1");
  constructor(situated) {
    Final(Sing, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Seizing food abruptly — a specific way of getting: field theme. Extends
// the open Get class so a description of "getting" can match it.
export class SnapUp extends Get {
  static BRAND = Brand("aesop:SnapUp:v1");
  constructor(situated) {
    Final(SnapUp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
