// Condition propositions: states and claim contents that can hold in the
// world. They participate in Queries through "held" semantics: directly
// asserted, or carried as the result content of an asserted ResultsIn.
// Every condition class extends the abstract Condition, so the solver
// recognizes a new one by its class, not by a list.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// A state that can hold; abstract.
export class Condition extends Proposition {
  static BRAND = Brand("aesop:Condition:v1");
  constructor(situated) {
    if (new.target === Condition) throw new TypeError("Condition is abstract");
    super(situated);
  }
}

// Where something is: fields entity, place.
export class LocatedAt extends Condition {
  static BRAND = Brand("aesop:LocatedAt:v1");
  constructor(situated) {
    Final(LocatedAt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Suffering thirst: field subject.
export class Thirsty extends Condition {
  static BRAND = Brand("aesop:Thirsty:v1");
  constructor(situated) {
    Final(Thirsty, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Not reachable by the story's actor: field subject.
export class OutOfReach extends Condition {
  static BRAND = Brand("aesop:OutOfReach:v1");
  constructor(situated) {
    Final(OutOfReach, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Sleeping: field subject.
export class Asleep extends Condition {
  static BRAND = Brand("aesop:Asleep:v1");
  constructor(situated) {
    Final(Asleep, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// No longer bound: field subject.
export class Free extends Condition {
  static BRAND = Brand("aesop:Free:v1");
  constructor(situated) {
    Final(Free, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Amused by something: fields subject, at.
export class Tickled extends Condition {
  static BRAND = Brand("aesop:Tickled:v1");
  constructor(situated) {
    Final(Tickled, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The flattery claim — voice outshining others: fields subject, others.
export class VoiceSurpasses extends Condition {
  static BRAND = Brand("aesop:VoiceSurpasses:v1");
  constructor(situated) {
    Final(VoiceSurpasses, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The advice content — flatterers must not be trusted.
export class DistrustFlatterers extends Condition {
  static BRAND = Brand("aesop:DistrustFlatterers:v1");
  constructor(situated) {
    Final(DistrustFlatterers, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
