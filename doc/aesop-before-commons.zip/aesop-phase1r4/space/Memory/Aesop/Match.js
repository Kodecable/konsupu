// Low-level mechanical helpers only. Nothing here decides what any
// semantic class means; Search.js owns the per-class interpretations.
// Node identity rule: a Node's semantic identity is object identity, so
// plain-data comparison never equates two distinct Nodes. "Bound to
// undefined" is a binding (Map.has), never a free slot; a field the story
// never wrote is a different thing — it reads as Unknown, not undefined.
//
// A Node inside a constraint pattern plays one of three roles:
// - a description: an asked Node named by a held Among. It corresponds to
//   exactly one story Node per solution, so it binds like a Variable (after
//   a class + written-field check) and every later use must name the same
//   correspondent;
// - an asked proposition: matched by content (class + fields), because a
//   proposition's identity is what it says;
// - anything else (story Nodes, asked individuals no Among describes): a
//   constant, matching only itself. Being situated in asked never makes a
//   Node a description by itself.
import { Node, Proposition, Variable } from "../../Interface/Nodes.js";
import { UnstatedField, isUnknown, sameUnknown } from "./Outcomes.js";

export function fieldsOf(node) {
  return Object.entries(node).filter(([key]) => key !== "situated");
}

// The story's value for a field, or that field's own Unknown when it was
// never written. An explicitly written undefined stays undefined.
export function fieldValue(node, key) {
  if (node === null || typeof node !== "object") {
    return UnstatedField(node, key);
  }
  if (!Object.hasOwn(node, key)) return UnstatedField(node, key);
  return Object.getOwnPropertyDescriptor(node, key).value;
}

// The matching context of one solving call: the asking Situation and the
// set of asked Nodes that held Among constraints describe.
export function MatchContext(asked, described = new Set()) {
  return { asked, described };
}

function matchFields(pattern, value, bindings, context) {
  for (const [key, item] of fieldsOf(pattern)) {
    const field = fieldValue(value, key);
    if (!matchValue(item, field, bindings, context)) return false;
  }
  return true;
}

// Match the items of an Array or plain-record pattern pairwise, so the
// Variables and descriptions inside a container field bind like those in
// a Node field. Both sides must have the same shape.
function matchContainer(pattern, value, bindings, context) {
  const pairs = [];
  if (Array.isArray(pattern)) {
    if (!Array.isArray(value) || value.length !== pattern.length) return false;
    pattern.forEach((item, index) => pairs.push([item, value[index]]));
  } else {
    if (!isRecord(value)) return false;
    const keys = Object.keys(pattern).sort();
    const valueKeys = Object.keys(value).sort();
    if (!sameValue(keys, valueKeys)) return false;
    for (const key of keys) pairs.push([pattern[key], value[key]]);
  }
  const trial = new Map(bindings);
  for (const [item, field] of pairs) {
    if (!matchValue(item, field, trial, context)) return false;
  }
  for (const [key, item] of trial) bindings.set(key, item);
  return true;
}

// Match one pattern value against one story value, extending `bindings`
// only on success. An unstated story value satisfies a Variable (binding
// it to Unknown) but never a written field.
export function matchValue(pattern, value, bindings, context) {
  if (pattern instanceof Variable) {
    if (bindings.has(pattern)) return sameValue(bindings.get(pattern), value);
    bindings.set(pattern, value);
    return true;
  }
  if (isUnknown(value)) return false;
  if (Array.isArray(pattern) || isRecord(pattern)) {
    return matchContainer(pattern, value, bindings, context);
  }
  if (!(pattern instanceof Node)) return sameValue(pattern, value);
  if (context.described.has(pattern)) {
    if (bindings.has(pattern)) return bindings.get(pattern) === value;
    if (!(value instanceof pattern.constructor)) return false;
    const trial = new Map(bindings);
    if (!matchFields(pattern, value, trial, context)) return false;
    for (const [key, item] of trial) bindings.set(key, item);
    bindings.set(pattern, value);
    return true;
  }
  if (pattern.situated === context.asked && pattern instanceof Proposition) {
    if (!(value instanceof pattern.constructor)) return false;
    const trial = new Map(bindings);
    if (!matchFields(pattern, value, trial, context)) return false;
    for (const [key, item] of trial) bindings.set(key, item);
    return true;
  }
  return pattern === value;
}

// Equality for non-Variable values: identity first, then Arrays and plain
// records by content. An Unknown equals only an Unknown of the same
// unstated field; Maps, Sets, and Nodes compare by identity.
export function sameValue(left, right) {
  if (left === right) return true;
  if (isUnknown(left) || isUnknown(right)) return sameUnknown(left, right);
  if (Array.isArray(left) && Array.isArray(right)) {
    return (
      left.length === right.length &&
      left.every((item, index) => sameValue(item, right[index]))
    );
  }
  if (isRecord(left) && isRecord(right)) {
    const leftKeys = Object.keys(left).sort();
    const rightKeys = Object.keys(right).sort();
    return (
      leftKeys.length === rightKeys.length &&
      leftKeys.every(
        (key, index) =>
          key === rightKeys[index] && sameValue(left[key], right[key]),
      )
    );
  }
  return false;
}

// An ordinary object literal: Maps, Sets, Nodes, and other class instances
// are not records and keep identity comparison in patterns.
function isRecord(value) {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

// Join binding tuples on shared keys (Variables and descriptions);
// contradictory values or correspondents drop out.
export function join(leftTuples, rightTuples) {
  const merged = [];
  for (const left of leftTuples) {
    for (const right of rightTuples) {
      const tuple = new Map(left);
      let consistent = true;
      for (const [key, value] of right) {
        if (tuple.has(key) && !sameValue(tuple.get(key), value)) {
          consistent = false;
          break;
        }
        tuple.set(key, value);
      }
      if (consistent) merged.push(tuple);
    }
  }
  return merged;
}
