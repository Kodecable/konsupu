// Domain-level regression tests for the Phase 2 world framework:
// dialogue / world / asked structure with independent context roots,
// constraints held by the asked Situation and supported along the world
// chain, descriptions with an explicit Among correspondence, structured
// Unknown / Ambiguous / NotEstablished results, and the Reply answer
// path. Runnable both ways: `node regression.mjs` standalone, or imported
// by run.mjs.
import { pathToFileURL, fileURLToPath } from "node:url";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import {
  Action,
  About,
  Agent,
  Among,
  Asks,
  Assert,
  Hold,
  AssertOccurs,
  AskWhether,
  After,
  Before,
  Believes,
  Causes,
  Means,
  Carrying,
  Condition,
  CryOut,
  ComeToHelp,
  Deceives,
  DigUp,
  Drought,
  Drop,
  Enables,
  Forbids,
  GetAt,
  GetOut,
  Hurt,
  Eat,
  Entity,
  Event,
  Fall,
  Get,
  Gnaw,
  Goal,
  Hide,
  Habitual,
  HoldsIn,
  HoldsWhen,
  Has,
  Initially,
  Instance,
  InOrderTo,
  LocatedAt,
  Motivates,
  Next,
  Not,
  NoEvent,
  Nth,
  OnlyDid,
  Occurs,
  Overlaps,
  PriorTo,
  ResultsIn,
  Reply,
  SameReferent,
  See,
  Says,
  Sell,
  Shut,
  Buy,
  ByChance,
  Promise,
  JumpDown,
  Kind,
  CallForHelp,
  GoAway,
  ComeTo,
  Plans,
  Pounce,
  While,
  BelongsTo,
  Help,
  context,
  Series,
  Sing,
  Present,
  SnapUp,
  Take,
  TheEnd,
  Throw,
  Toss,
  Unable,
  VoiceSurpasses,
} from "./space/Interface/Aesop.js";
import { BuildStory as BuildCrowStory } from "./cases/story-1/story.mjs";
import { BuildStory as BuildLionStory } from "./cases/story-3/story.mjs";
import { BuildStory as BuildCrowFoxStory } from "./cases/story-2/story.mjs";
import { BuildStory as BuildDogStory } from "./cases/story-4/story.mjs";
import { BuildStory as BuildMaskStory } from "./cases/story-5/story.mjs";
import { BuildStory as BuildMiserStory } from "./cases/story-6/story.mjs";
import { BuildStory as BuildMilkmaidStory } from "./cases/story-7/story.mjs";
import { BuildStory as BuildNurseStory } from "./cases/story-8/story.mjs";
import { BuildStory as BuildClothingStory } from "./cases/story-9/story.mjs";
import { BuildStory as BuildShepherdStory } from "./cases/story-10/story.mjs";
import { BuildStory as BuildGoatStory } from "./cases/story-11/story.mjs";
import { BuildStory as BuildAssStory } from "./cases/story-12/story.mjs";
import { BuildStory as BuildCockStory } from "./cases/story-13/story.mjs";
import * as Twin4 from "./cases/story-4/cases.mjs";
import * as Twin5 from "./cases/story-5/cases.mjs";
import * as Twin6 from "./cases/story-6/cases.mjs";
import * as Twin7 from "./cases/story-7/cases.mjs";
import * as Twin8 from "./cases/story-8/cases.mjs";
import * as Twin9 from "./cases/story-9/cases.mjs";
import * as Twin10 from "./cases/story-10/cases.mjs";
import * as Twin11 from "./cases/story-11/cases.mjs";
import * as Twin12 from "./cases/story-12/cases.mjs";
import * as Twin13 from "./cases/story-13/cases.mjs";
const twinCases = [
  Twin4, Twin5, Twin6, Twin7, Twin8, Twin9, Twin10, Twin11, Twin12, Twin13,
];
import {
  Brand,
  Final,
  GlobalNode,
  Imperative,
  KonsupuIdentity,
  Proposition,
  Query,
  ReportDataMembers,
  Situation,
  Variable,
  ref,
} from "./space/Interface/Nodes.js";
import { Assertion } from "./space/Memory/Aesop/Assertion.js";
import { MatchContext, matchValue, sameValue } from "./space/Memory/Aesop/Match.js";
import { SolveQuery } from "./space/Memory/Aesop/QuerySolver.js";
import { Analyze } from "./space/Memory/Foundation/Analyze.js";
import { CreateState } from "./space/Memory/Foundation/ResolveState.js";
import { Perspective } from "./space/Memory/Foundation/Perspective.js";
import { Evaluate } from "./space/Memory/Foundation/Evaluate.js";
import { Texts } from "./space/Interface/Outputs.js";

function assert(condition, message) {
  if (!condition) throw new Error(`assert failed: ${message}`);
}

function assertThrows(thunk, fragment, message) {
  try {
    thunk();
  } catch (caught) {
    assert(
      String(caught.message).includes(fragment),
      `${message}: expected "${fragment}" in "${caught.message}"`,
    );
    return;
  }
  throw new Error(`${message}: expected an error containing "${fragment}"`);
}

function walk(path) {
  if (statSync(path).isFile()) return [path];
  const files = [];
  for (const name of readdirSync(path)) {
    files.push(...walk(join(path, name)));
  }
  return files;
}

function normalizeText(text) {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// A "Wolf, Wolf" cry shape in the asked Situation.
function cryShape(input, asked) {
  const d = new CryOut(asked);
  d.call = "Wolf, Wolf";
  input.push(d);
  return d;
}

// A second global identity, so a fixture can address someone else.
class SomeoneElse extends GlobalNode {
  static BRAND = Brand("aesop-test:SomeoneElse:v1");
  constructor(key, fields = {}) {
    Final(SomeoneElse, new.target);
    super(key, fields);
  }
}

function entity(situation, name) {
  const value = new Entity(situation);
  value.name = name;
  return value;
}

function makeAgent(situation, action, actor) {
  const relation = new Agent(situation);
  relation.action = action;
  relation.actor = actor;
  return relation;
}

// Assemble the three-layer Input exactly the way cases.mjs does: dialogue
// root first (the initial Situation), story facts, asked constraints and
// its Query, then the dialogue members that reference them. Returns the
// pieces so tests can solve, evaluate, or inspect directly.
function assembleCase(buildWorld, buildAsked) {
  const dialogue = new Situation();
  const story = new Situation();
  const input = [dialogue, story];
  const world = buildWorld(input, story);
  const asked = new Situation(story);
  input.push(asked);
  const answer = new Variable(asked);
  input.push(answer);
  const extra = buildAsked(input, asked, world, answer) ?? [];
  const query = new Query(asked, [answer, ...extra]);
  input.push(query);
  const asks = new Asks(dialogue);
  asks.story = story;
  asks.asked = asked;
  input.push(asks);
  input.push(new Query(dialogue, [ref(asked, answer)]));
  const reply = new Reply(dialogue);
  reply.content = ref(asked, answer);
  input.push(reply);
  input.push(new Imperative(dialogue, KonsupuIdentity.Ref(), reply));
  return { input, story, asked, dialogue, answer, reply, world, query };
}

function solveAssembled(assembled) {
  const { input, query } = assembled;
  const state = CreateState(Analyze(input));
  return SolveQuery(input, query, [...query.variables], state);
}

// Whether a solved value is a NotEstablished record at the given level.
function isNotEstablished(value, level) {
  return value?.result === "not-established" && value.level === level;
}

function answerText(assembled) {
  return Texts(Evaluate(assembled.input))[0];
}

// A world with one occurred singing by the crow, for the small fixtures.
function singingWorld(input, story) {
  const crow = entity(story, "the crow");
  const fox = entity(story, "the fox");
  const sing = new Sing(story);
  input.push(crow, fox, sing);
  AssertOccurs(input, sing);
  Assert(input, makeAgent(story, sing, crow));
  return { root: story, crow, fox, sing };
}

// Two Drops into the pitcher: the crow's occurred; the fox's is only the
// fox's goal and never occurred.
function twoDropsWorld(input, story) {
  const crow = entity(story, "the crow");
  const fox = entity(story, "the fox");
  const pitcher = entity(story, "the pitcher");
  const real = new Drop(story);
  real.destination = pitcher;
  const wished = new Drop(story);
  wished.destination = pitcher;
  input.push(crow, fox, pitcher, real, wished);
  AssertOccurs(input, real);
  Assert(input, makeAgent(story, real, crow));
  Assert(input, makeAgent(story, wished, fox));
  const goal = new Goal(story);
  goal.actor = fox;
  goal.objective = wished;
  Assert(input, goal);
  return { root: story, crow, fox, pitcher };
}

// As above, but the occurred Drop has no asserted agent: Occurs(d) and
// Agent(d, x) are each supported, by different Drops.
function splitDropsWorld(input, story) {
  const fox = entity(story, "the fox");
  const pitcher = entity(story, "the pitcher");
  const real = new Drop(story);
  real.destination = pitcher;
  const wished = new Drop(story);
  wished.destination = pitcher;
  input.push(fox, pitcher, real, wished);
  AssertOccurs(input, real);
  Assert(input, makeAgent(story, wished, fox));
  return { root: story, fox, pitcher };
}

// "Who dropped (something) into the pitcher?", with or without the Among
// that makes d a description.
function whoDroppedOccurred(withAmong) {
  return (input, asked, w, answer) => {
    const d = new Drop(asked);
    d.destination = w.pitcher;
    input.push(d);
    if (withAmong) {
      const h = new Among(asked);
      h.situation = w.root;
      h.node = d;
      Assert(input, h);
    }
    AssertOccurs(input, d);
    Assert(input, makeAgent(asked, d, answer));
  };
}

// One occurred Fall whose theme the story never writes; with `elsewhere`
// it lands on the roof instead of the ground.
function groundWorld(elsewhere) {
  return (input, story) => {
    const ground = entity(story, "the ground");
    const roof = entity(story, "the roof");
    const fall = new Fall(story);
    fall.destination = elsewhere ? roof : ground;
    input.push(ground, roof, fall);
    AssertOccurs(input, fall);
    return { root: story, ground };
  };
}

// "What fell to the ground?"
function whatFell(input, asked, w, answer) {
  const f = new Fall(asked);
  f.destination = w.ground;
  f.theme = answer;
  input.push(f);
  const h = new Among(asked);
  h.situation = w.root;
  h.node = f;
  Assert(input, h);
  AssertOccurs(input, f);
}

// An open general proposition and a refinement of it, test-local.
class Holding extends Proposition {
  static BRAND = Brand("aesop-test:Holding:v1");
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
class Gripping extends Holding {
  static BRAND = Brand("aesop-test:Gripping:v1");
  constructor(situated) {
    Final(Gripping, new.target);
    super(situated);
  }
}

// A test-local condition class nothing in the solver lists by name.
class Wet extends Condition {
  static BRAND = Brand("aesop-test:Wet:v1");
  constructor(situated) {
    Final(Wet, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// "Who dropped (something) into the pitcher?" with its held constraints in
// the given order of "among", "occurs", "agent".
function whoDroppedInOrder(order) {
  return (input, asked, w, answer) => {
    const d = new Drop(asked);
    d.destination = w.pitcher;
    input.push(d);
    for (const step of order) {
      if (step === "among") {
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
      } else if (step === "occurs") {
        AssertOccurs(input, d);
      } else {
        Assert(input, makeAgent(asked, d, answer));
      }
    }
  };
}

// The constraint classes a NotEstablished record names, as one string.
function failingClasses(record) {
  return record.constraints.map((item) => item.constructor.name).join(",");
}

// One occurred Fall and one occurred Drop by the crow, neither theme
// written; with `sameDrop` both descriptions are Drops and can only name
// the one Drop.
function unstatedThemes(sameDrop) {
  return {
    world(input, story) {
      const crow = entity(story, "the crow");
      const fall = new Fall(story);
      const drop = new Drop(story);
      input.push(crow, fall, drop);
      AssertOccurs(input, fall);
      AssertOccurs(input, drop);
      Assert(input, makeAgent(story, drop, crow));
      return { root: story, crow };
    },
    asked(input, asked, w, answer) {
      const thing = new Variable(asked);
      input.push(thing);
      const first = sameDrop ? new Drop(asked) : new Fall(asked);
      first.theme = thing;
      const second = new Drop(asked);
      second.theme = thing;
      input.push(first, second);
      for (const node of [first, second]) {
        const h = new Among(asked);
        h.situation = w.root;
        h.node = node;
        Assert(input, h);
      }
      Assert(input, makeAgent(asked, second, answer));
      return [thing];
    },
  };
}

export const Tests = [
  {
    name: "identity: identical declarations are distinct Nodes",
    run() {
      const root = new Situation();
      const a = entity(root, "the crow");
      const b = entity(root, "the crow");
      assert(a !== b, "two constructions are two objects");
      assert(sameValue(a, b) === false, "sameValue must not unify them");
      assert(sameValue(a, a), "a Node equals itself");
    },
  },
  {
    name: "identity: repeated Variable must not unify distinct Nodes",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const a = entity(root, "the crow");
      const b = entity(root, "the crow");
      const x = new Variable(asked);
      const pattern = new LocatedAt(asked);
      pattern.entity = x;
      pattern.place = x;
      const fact = new LocatedAt(root);
      fact.entity = a;
      fact.place = b;
      const bindings = new Map();
      assert(
        !matchValue(pattern, fact, bindings, MatchContext(asked)),
        "(X, X) must not match (a, b) with a !== b",
      );
    },
  },
  {
    name: "undefined: a bound undefined conflicts with later bindings",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const crow = entity(root, "the crow");
      const sing = new Sing(root);
      const x = new Variable(asked);
      const bindings = new Map();
      assert(
        matchValue(
          makeAgent(asked, sing, x),
          makeAgent(root, sing, undefined),
          bindings,
          MatchContext(asked),
        ),
        "X binds undefined",
      );
      assert(
        !matchValue(
          makeAgent(asked, sing, x),
          makeAgent(root, sing, crow),
          bindings,
          MatchContext(asked),
        ),
        "undefined then crow is a conflict, not an overwrite",
      );
    },
  },
  {
    name: "undefined: Map keeps [X, undefined] as a binding",
    run() {
      const root = new Situation();
      const asked = new Situation(root);
      const sing = new Sing(root);
      const x = new Variable(asked);
      const bindings = new Map();
      matchValue(
        makeAgent(asked, sing, x),
        makeAgent(root, sing, undefined),
        bindings,
        MatchContext(asked),
      );
      assert(bindings.has(x), "undefined binding must stay in the Map");
      assert(bindings.get(x) === undefined, "the bound value is undefined");
    },
  },
  {
    name: "layering: world objects, events, and propositions separate",
    run() {
      const root = new Situation();
      const crow = new Entity(root);
      const sing = new Sing(root);
      const says = new Says(root);
      const fall = new Fall(root);
      const occurs = new Occurs(root);
      const before = new Before(root);
      const causes = new Causes(root);
      const assertion = new Assertion(root);
      assert(!(crow instanceof Proposition), "Entity is not a Proposition");
      assert(!(says instanceof Proposition), "Says is not a Proposition");
      assert(says instanceof Action, "Says is an Action");
      assert(
        fall instanceof Event && !(fall instanceof Action),
        "Fall is an Event but not an Action",
      );
      assert(
        occurs instanceof Proposition &&
          before instanceof Proposition &&
          causes instanceof Proposition,
        "Occurs, Before, and Causes are Propositions",
      );
      assert(
        !(assertion instanceof Proposition),
        "Assertion is not a Proposition",
      );
    },
  },
  {
    name: "layering: Event and Action are abstract",
    run() {
      const root = new Situation();
      assertThrows(
        () => new Event(root),
        "abstract",
        "Event cannot be constructed",
      );
      assertThrows(
        () => new Action(root),
        "abstract",
        "Action cannot be constructed",
      );
    },
  },
  {
    name: "layering: Get is open, SnapUp refines it, others do not",
    run() {
      const root = new Situation();
      const get = new Get(root);
      const snap = new SnapUp(root);
      const sing = new Sing(root);
      assert(get instanceof Action, "Get is a constructible Action");
      assert(snap instanceof Get, "SnapUp is a Get");
      assert(!(get instanceof SnapUp), "Get is not a SnapUp");
      assert(!(sing instanceof Get), "an unrelated doing is no Get");
    },
  },
  {
    name: "support: asked inherits story facts along the chain",
    run() {
      const assembled = assembleCase(
        singingWorld,
        (input, asked, world, answer) => {
          Assert(input, makeAgent(asked, world.sing, answer));
        },
      );
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.crow,
        "the story's asserted Agent supports the asked constraint",
      );
    },
  },
  {
    name: "constraints: an unasserted Node binds nothing, whatever it holds",
    run() {
      const loose = assembleCase(singingWorld, (input, asked, world, answer) => {
        const who = makeAgent(asked, world.sing, answer);
        input.push(who); // exists in the asked Situation, never asserted
      });
      const unknown = solveAssembled(loose);
      assert(
        unknown.get(loose.answer).result === "unknown",
        "an unasserted mentioner contributes no constraint",
      );
      const held = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, answer));
      });
      const solved = solveAssembled(held);
      assert(
        solved.get(held.answer) === held.world.crow,
        "the same cognition held as an Assertion does constrain",
      );
    },
  },
  {
    name: "reply: the dialogue Says is invisible to the asked solving",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const world = singingWorld(input, story);
          const taunt = new Says(story);
          taunt.text = "Was I not right?";
          input.push(taunt);
          AssertOccurs(input, taunt);
          Assert(input, makeAgent(story, taunt, world.fox));
          return world;
        },
        (input, asked, world, answer) => {
          Assert(input, makeAgent(asked, world.sing, answer));
        },
      );
      assert(
        answerText(assembled) === "Entity(the crow)",
        "solving needs no exclusion rule for the reply Says",
      );
      const view = new Perspective(
        assembled.query,
        CreateState(Analyze(assembled.input)),
      );
      assert(
        !view.Bindings(assembled.answer).includes(assembled.reply),
        "the dialogue's reply Reply never enters the asked view",
      );
    },
  },
  {
    name: "correspondence: a description matches class and written fields",
    run() {
      const world = (input, story) => {
        const cheese = entity(story, "the cheese");
        const bread = entity(story, "the bread");
        const ground = entity(story, "the ground");
        const dropCheese = new Fall(story);
        dropCheese.theme = cheese;
        dropCheese.destination = ground;
        const dropBread = new Fall(story);
        dropBread.theme = bread;
        dropBread.destination = ground;
        const snap = new SnapUp(story);
        snap.theme = cheese;
        const sing = new Sing(story);
        input.push(cheese, bread, ground, dropCheese, dropBread, snap, sing);
        AssertOccurs(input, dropCheese);
        AssertOccurs(input, dropBread);
        AssertOccurs(input, snap);
        AssertOccurs(input, sing);
        return { root: story, cheese, bread, ground };
      };
      // Written fields select; unwritten ones never constrain.
      const unique = assembleCase(world, (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = w.cheese;
        f.destination = answer;
        input.push(f);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = f;
        Assert(input, h);
      });
      assert(
        solveAssembled(unique).get(unique.answer) === unique.world.ground,
        "the one matching fall supplies the unwritten field",
      );
      const overConstrained = assembleCase(world, (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = w.cheese;
        f.destination = w.bread; // written wrongly on purpose
        input.push(f);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = f;
        Assert(input, h);
      });
      assert(
        isNotEstablished(solveAssembled(overConstrained).get(overConstrained.answer), "correspondence"),
        "a written-but-wrong field blocks the correspondence",
      );
      // An open-class description matches subclass instances, nothing else.
      const openClass = assembleCase(world, (input, asked, w, answer) => {
        const g = new Get(asked);
        g.theme = answer;
        input.push(g);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = g;
        Assert(input, h);
      });
      assert(
        solveAssembled(openClass).get(openClass.answer) ===
          openClass.world.cheese,
        "Get matches the SnapUp, and only it",
      );
    },
  },
  {
    name: "occurrence: Occurs(f) demands a happened match; Among alone does not",
    run() {
      const world = (input, story) => {
        const lion = entity(story, "the lion");
        const mouse = entity(story, "the mouse");
        const eatMouse = new Eat(story);
        eatMouse.theme = mouse;
        input.push(lion, mouse, eatMouse);
        const goal = new Goal(story);
        goal.actor = lion;
        goal.objective = eatMouse;
        Assert(input, goal);
        return { root: story, lion, mouse, eatMouse };
      };
      const demanded = assembleCase(world, (input, asked, w, answer) => {
        const d = new Eat(asked);
        d.theme = answer;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
      });
      assert(
        isNotEstablished(solveAssembled(demanded).get(demanded.answer), "instance"),
        "an unoccurred objective never satisfies Occurs",
      );
      const tolerated = assembleCase(world, (input, asked, w, answer) => {
        const d = new Eat(asked);
        d.theme = answer;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        const goal = new Goal(asked);
        goal.actor = w.lion;
        goal.objective = d;
        Assert(input, goal);
      });
      assert(
        solveAssembled(tolerated).get(tolerated.answer) ===
          tolerated.world.mouse,
        "without Occurs the description may name an unoccurred objective",
      );
    },
  },
  {
    name: "occurrence: asserting Occurs(f) adds no second event",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const fall = new Fall(story);
          fall.theme = cheese;
          fall.destination = ground;
          input.push(cheese, ground, fall);
          AssertOccurs(input, fall);
          return { root: story, cheese, ground };
        },
        (input, asked, w, answer) => {
          const f = new Fall(asked);
          f.theme = answer;
          input.push(f);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = f;
          Assert(input, h);
          AssertOccurs(input, f);
        },
      );
      const before = assembled.input.length;
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.cheese,
        "the description still names the one real fall",
      );
      assert(
        assembled.input.length === before,
        "nothing entered the Input while solving",
      );
      assert(
        answerText(assembled) === "Entity(the cheese)",
        "the asked Occurs corresponded to the original event, not a new one",
      );
    },
  },
  {
    name: "entailment: a held constraint needs matching story content",
    run() {
      const wrong = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, world.fox));
      });
      assert(
        isNotEstablished(solveAssembled(wrong).get(wrong.answer), "instance"),
        "a merely compatible actor is not support; content must match",
      );
      const right = assembleCase(singingWorld, (input, asked, world, answer) => {
        Assert(input, makeAgent(asked, world.sing, answer));
      });
      assert(
        solveAssembled(right).get(right.answer) === right.world.crow,
        "the matching story Agent entails the held constraint",
      );
    },
  },
  {
    name: "says: a speech event is a first-class chain argument",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const world = singingWorld(input, story);
          const taunt = new Says(story);
          taunt.text = "Was I not right?";
          const other = new Fall(story);
          input.push(taunt, other);
          Assert(input, makeNext(story, taunt, other));
          AssertOccurs(input, taunt);
          AssertOccurs(input, other);
          return { root: story, crow: world.crow, taunt, other };
        },
        (input, asked, world, answer) => {
          const next = new Next(asked);
          next.earlier = world.taunt;
          next.later = answer;
          Assert(input, next);
          const occurs = new Occurs(asked);
          occurs.event = answer;
          Assert(input, occurs);
        },
      );
      const result = solveAssembled(assembled);
      assert(
        result.get(assembled.answer) === assembled.world.other,
        "a Says serves as a chain argument and can occur",
      );
    },
  },
  {
    name: "adjacency: speech content, assertion, and result content differ",
    run() {
      // The same LocatedAt, once only spoken, once asserted, once the
      // content of an occurred event's ResultsIn — three different
      // consequences for the very same mention shape.
      const base = (input, story) => {
        const cheese = entity(story, "the cheese");
        const ground = entity(story, "the ground");
        const fox = entity(story, "the fox");
        const fall = new Fall(story);
        fall.theme = cheese;
        fall.destination = ground;
        input.push(cheese, ground, fox, fall);
        AssertOccurs(input, fall);
        return { cheese, ground, fox, fall };
      };
      const speechWorld = (input, story) => {
        const w = base(input, story);
        const speech = new Situation();
        input.push(speech);
        const located = new LocatedAt(speech);
        located.entity = w.cheese;
        located.place = w.ground;
        Assert(input, located, speech);
        const says = new Says(story);
        says.text = "it is on the ground";
        says.content = speech;
        input.push(says);
        AssertOccurs(input, says);
        return { root: story, ...w };
      };
      const assertedWorld = (input, story) => {
        const w = base(input, story);
        const located = new LocatedAt(story);
        located.entity = w.cheese;
        located.place = w.ground;
        Assert(input, located); // Assert pushes; never push the same Node twice
        return { root: story, ...w };
      };
      const resultWorld = (input, story) => {
        const w = base(input, story);
        const located = new LocatedAt(story);
        located.entity = w.cheese;
        located.place = w.ground;
        input.push(located);
        const result = new ResultsIn(story);
        result.event = w.fall;
        result.proposition = located;
        Assert(input, result);
        return { root: story, ...w };
      };
      const hold = (world) =>
        assembleCase(world, (input, asked, w, answer) => {
          const held = new LocatedAt(asked);
          held.entity = w.cheese;
          held.place = answer;
          Assert(input, held);
        });
      const speechOnly = hold(speechWorld);
      assert(
        isNotEstablished(solveAssembled(speechOnly).get(speechOnly.answer), "instance"),
        "an occurred Says does not make its speech context's content hold in the world",
      );
      const asserted = hold(assertedWorld);
      assert(
        solveAssembled(asserted).get(asserted.answer) ===
          asserted.world.ground,
        "an Assertion holds the proposition",
      );
      const asResult = hold(resultWorld);
      assert(
        solveAssembled(asResult).get(asResult.answer) === asResult.world.ground,
        "an occurred event's asserted ResultsIn holds its result content",
      );
    },
  },
  {
    name: "resultsin: an unoccurred event's result is not held",
    run() {
      const clean = assembleCase(
        (input, story) => {
          const pebble = entity(story, "a pebble");
          const pitcher = entity(story, "the pitcher");
          const drop = new Drop(story);
          input.push(pebble, pitcher, drop);
          const rests = new LocatedAt(story);
          rests.entity = pebble;
          rests.place = pitcher;
          input.push(rests);
          const result = new ResultsIn(story);
          result.event = drop;
          result.proposition = rests;
          Assert(input, result);
          return { root: story, pebble, pitcher, drop };
        },
        (input, asked, w, answer) => {
          const held = new LocatedAt(asked);
          held.entity = w.pebble;
          held.place = answer;
          Assert(input, held);
        },
      );
      assert(
        isNotEstablished(solveAssembled(clean).get(clean.answer), "instance"),
        "an asserted ResultsIn without Occurs must not hold its content",
      );
      AssertOccurs(clean.input, clean.world.drop);
      const state = CreateState(Analyze(clean.input));
      const solved = SolveQuery(
        clean.input,
        clean.query,
        [...clean.query.variables],
        state,
      );
      assert(
        solved.get(clean.answer) === clean.world.pitcher,
        "once the event occurred, its result is held",
      );
    },
  },
  {
    name: "outcomes: Unknown passes through the reply Says",
    run() {
      const assembled = assembleCase(
        singingWorld,
        (input, asked, world, answer) => {
          const occurs = new Occurs(asked);
          occurs.event = world.sing;
          Assert(input, occurs); // supported, but says nothing about X
        },
      );
      assert(
        answerText(assembled) === "{result=unknown}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: Ambiguous passes through the reply Says",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const bread = entity(story, "the bread");
          const ground = entity(story, "the ground");
          const dropCheese = new Fall(story);
          dropCheese.theme = cheese;
          dropCheese.destination = ground;
          const dropBread = new Fall(story);
          dropBread.theme = bread;
          dropBread.destination = ground;
          input.push(cheese, bread, ground, dropCheese, dropBread);
          AssertOccurs(input, dropCheese);
          AssertOccurs(input, dropBread);
          return { root: story };
        },
        (input, asked, world, answer) => {
          const f = new Fall(asked);
          f.theme = answer;
          input.push(f);
          const h = new Among(asked);
          h.situation = world.root;
          h.node = f;
          Assert(input, h);
        },
      );
      assert(
        answerText(assembled) ===
          "{candidates=[Entity(the cheese),Entity(the bread)],result=ambiguous}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: NotEstablished passes through the reply Says",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world) => {
        Assert(input, makeAgent(asked, world.sing, world.fox));
      });
      assert(
        answerText(assembled) ===
          "{constraints=[Agent],level=instance,result=not-established}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "correspondence: one description names one event in every constraint",
    run() {
      const assembled = assembleCase(twoDropsWorld, whoDroppedOccurred(true));
      const value = solveAssembled(assembled).get(assembled.answer);
      assert(
        value === assembled.world.crow,
        "Occurs(d) and Agent(d, x) must speak of the same Drop; " +
          "the fox's unoccurred Drop never lends its agent",
      );
    },
  },
  {
    name: "correspondence: without Among an asked event is no description",
    run() {
      const assembled = assembleCase(twoDropsWorld, whoDroppedOccurred(false));
      assert(
        isNotEstablished(
          solveAssembled(assembled).get(assembled.answer),
          "instance",
        ),
        "an asked Drop no Among names is its own individual and matches " +
          "no story fact",
      );
    },
  },
  {
    name: "outcomes: failure kinds stay distinguishable",
    run() {
      // Value level: the fall is there, its theme is never written.
      const unstated = assembleCase(groundWorld(false), whatFell);
      const value = solveAssembled(unstated).get(unstated.answer);
      assert(value?.result === "unknown", "an unwritten field is Unknown");
      assert(
        answerText(unstated) === "{result=unknown}",
        "Unknown, never the text undefined",
      );
      // Correspondence level: nothing fell to the ground at all.
      const absent = assembleCase(groundWorld(true), whatFell);
      assert(
        isNotEstablished(
          solveAssembled(absent).get(absent.answer),
          "correspondence",
        ),
        "a description without correspondent fails at correspondence",
      );
      // Instance level: the gnawing happened, no Agent is asserted. Action
      // entails some agent, so a future entailment rule may reclassify
      // this as Unknown; the record keeps what that rule needs.
      const agentless = assembleCase(
        (input, story) => {
          const gnaw = new Gnaw(story);
          input.push(gnaw);
          AssertOccurs(input, gnaw);
          return { root: story, gnaw };
        },
        (input, asked, w, answer) => {
          Assert(input, makeAgent(asked, w.gnaw, answer));
        },
      );
      const record = solveAssembled(agentless).get(agentless.answer);
      assert(
        isNotEstablished(record, "instance") &&
          record.constraints.length === 1 &&
          record.constraints[0] instanceof Agent,
        "the record names the unsupported Agent constraint",
      );
      // Joint level: each constraint has support, never the same Drop.
      const split = assembleCase(splitDropsWorld, whoDroppedOccurred(true));
      assert(
        isNotEstablished(solveAssembled(split).get(split.answer), "joint"),
        "separately supported constraints may still fail together",
      );
    },
  },
  {
    name: "support: a general constraint is supported by a subclass instance",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const cheese = entity(story, "the cheese");
          input.push(crow, cheese);
          const grip = new Gripping(story);
          grip.holder = crow;
          grip.thing = cheese;
          Assert(input, grip);
          return { root: story, crow, cheese };
        },
        (input, asked, w, answer) => {
          const holding = new Holding(asked);
          holding.holder = w.crow;
          holding.thing = answer;
          Assert(input, holding);
        },
      );
      assert(
        solveAssembled(assembled).get(assembled.answer) ===
          assembled.world.cheese,
        "a held Gripping supports the asked Holding",
      );
    },
  },
  {
    name: "outcomes: a helper may stay Ambiguous while the answer is unique",
    run() {
      const complete = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const start = new Sing(story);
          const branchA = new Sing(story);
          const branchB = new Sing(story);
          input.push(crow, start, branchA, branchB);
          Assert(input, makeNext(story, start, branchA));
          Assert(input, makeNext(story, start, branchB));
          Assert(input, makeAgent(story, branchA, crow));
          Assert(input, makeAgent(story, branchB, crow));
          return { root: story, crow, start };
        },
        (input, asked, world, answer) => {
          const which = new Variable(asked);
          input.push(which);
          const next = new Next(asked);
          next.earlier = world.start;
          next.later = which;
          Assert(input, next);
          const who = new Agent(asked);
          who.action = which;
          who.actor = answer;
          Assert(input, who);
          return [which];
        },
      );
      const result = solveAssembled(complete);
      assert(
        result.get(complete.answer) === complete.world.crow,
        "the asked-about variable is unique",
      );
      const helper = result.get(
        complete.query.variables.find((v) => v !== complete.answer),
      );
      assert(
        helper.result === "ambiguous" && helper.candidates.length === 2,
        "the helper variable may carry an Ambiguous result",
      );
      assert(
        answerText(complete) === "Entity(the crow)",
        "the reply says the unique answer only",
      );
    },
  },
  {
    name: "temporal: Next keeps after-questions unique; Before is derived",
    run() {
      const world = (input, story) => {
        const a = new Sing(story);
        const b = new Sing(story);
        const c = new Sing(story);
        input.push(a, b, c);
        AssertOccurs(input, a);
        AssertOccurs(input, b);
        AssertOccurs(input, c);
        Assert(input, makeNext(story, a, b));
        Assert(input, makeNext(story, b, c));
        return { root: story, a, b, c };
      };
      const afterNext = assembleCase(world, (input, asked, w, answer) => {
        const next = new Next(asked);
        next.earlier = w.a;
        next.later = answer;
        Assert(input, next);
      });
      assert(
        solveAssembled(afterNext).get(afterNext.answer) === afterNext.world.b,
        "the immediate successor is unique",
      );
      const afterBefore = assembleCase(world, (input, asked, w, answer) => {
        const before = new Before(asked);
        before.earlier = w.a;
        before.later = answer;
        Assert(input, before);
      });
      const derived = solveAssembled(afterBefore).get(afterBefore.answer);
      assert(
        derived.result === "ambiguous" && derived.candidates.length === 2,
        "Before is derived transitively from the Next chain",
      );
      const constants = assembleCase(world, (input, asked, w, answer) => {
        const before = new Before(asked);
        before.earlier = w.a;
        before.later = w.c;
        Assert(input, before);
        const holds = new Occurs(asked);
        holds.event = w.c;
        Assert(input, holds);
      });
      assert(
        solveAssembled(constants).get(constants.answer).result === "unknown",
        "fully constant derived constraints support without binding X",
      );
    },
  },
  {
    name: "exact: field assignment order does not affect matching",
    run() {
      const root = new Situation();
      const cheese = entity(root, "the cheese");
      const ground = entity(root, "the ground");
      const sing = new Sing(root);
      const fall = new Fall(root);
      fall.theme = cheese;
      fall.destination = ground;
      const fact = new Causes(root);
      fact.effect = fall;
      fact.cause = sing;
      const asked = new Situation(root);
      // An asked proposition matches by content, looked up by field name.
      const pattern = new Causes(asked);
      pattern.cause = sing;
      pattern.effect = fall;
      const bindings = new Map();
      assert(
        matchValue(pattern, fact, bindings, MatchContext(asked)),
        "content matching compares fields by name, not insertion order",
      );
      assert(bindings.size === 0, "constant fields bind nothing");
      // A description is order-blind for the same reason.
      const described = new Fall(asked);
      described.destination = ground;
      described.theme = cheese;
      assert(
        matchValue(
          described,
          fall,
          new Map(),
          MatchContext(asked, new Set([described])),
        ),
        "descriptions match regardless of assignment order",
      );
    },
  },
  {
    name: "reply: Reply.content reads a resolved Entity",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      assert(answerText(assembled) === "Entity(the crow)");
    },
  },
  {
    name: "reply: Reply.content reads a resolved Event",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const fall = new Fall(story);
          fall.theme = cheese;
          fall.destination = ground;
          input.push(cheese, ground, fall);
          AssertOccurs(input, fall);
          return { root: story };
        },
        (input, asked, world, answer) => {
          const occurs = new Occurs(asked);
          occurs.event = answer;
          Assert(input, occurs);
        },
      );
      assert(
        answerText(assembled) ===
          "Fall(destination=Entity(the ground),theme=Entity(the cheese))",
      );
    },
  },
  {
    name: "reply: Reply.content reads a resolved Proposition",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const crow = entity(story, "the crow");
          const birds = entity(story, "other birds");
          input.push(crow, birds);
          const beliefCtx = new Situation();
          input.push(beliefCtx);
          const claim = new VoiceSurpasses(beliefCtx);
          claim.subject = crow;
          claim.others = birds;
          Assert(input, claim, beliefCtx);
          const belief = new Believes(story);
          belief.believer = crow;
          belief.content = beliefCtx;
          Assert(input, belief);
          return { root: story, crow };
        },
        (input, asked, world, answer) => {
          const b = new Variable(asked);
          input.push(b);
          const belief = new Believes(asked);
          belief.believer = world.crow;
          belief.content = b;
          Assert(input, belief);
          const held = new HoldsIn(asked);
          held.context = b;
          held.proposition = answer;
          Assert(input, held);
          return [b];
        },
      );
      assert(
        answerText(assembled) ===
          "VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))",
      );
    },
  },
  {
    name: "imperatives: a foreign addressee never reaches this Konsupu",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      const reply = assembled.reply;
      const foreign = new Imperative(assembled.dialogue, SomeoneElse.Ref(), reply);
      assembled.input.push(foreign);
      const outputs = Evaluate(assembled.input);
      assert(
        outputs.length === 1,
        "the Konsupu Imperative already in the Input still resolves",
      );
      const only = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      only.input.pop(); // remove the Konsupu Imperative
      only.input.push(
        new Imperative(only.dialogue, SomeoneElse.Ref(), only.reply),
      );
      assert(
        Evaluate(only.input).length === 0,
        "a foreign addressee resolves nothing here",
      );
    },
  },
  {
    name: "imperatives: a requested Reply never occurs",
    run() {
      const assembled = assembleCase(singingWorld, (input, asked, world, answ) => {
        Assert(input, makeAgent(asked, world.sing, answ));
      });
      const before = assembled.input.length;
      const outputs = Evaluate(assembled.input);
      assert(outputs.length === 1, "the request resolves to one output");
      assert(assembled.input.length === before, "resolution adds no cognition");
      const occurred = assembled.input.some((node) => {
        return node instanceof Occurs && node.event === assembled.reply;
      });
      assert(
        !occurred,
        "being requested by an Imperative must not assert Occurs(reply)",
      );
    },
  },
  {
    name: "project: machine output is structural, not English",
    run() {
      const world = (input, story) => {
        const crow = entity(story, "the crow");
        const fox = entity(story, "the fox");
        const sing = new Sing(story);
        sing.manner = "her best";
        input.push(crow, fox, sing);
        AssertOccurs(input, sing);
        Assert(input, makeAgent(story, sing, crow));
        return { root: story, crow, fox, sing };
      };
      const plain = assembleCase(world, (input, asked, w, answer) => {
        const occurs = new Occurs(asked);
        occurs.event = answer;
        Assert(input, occurs);
        const by = new Agent(asked);
        by.action = answer;
        by.actor = w.crow;
        Assert(input, by);
      });
      assert(
        answerText(plain) === "Sing(manner=her best)",
        `machine text reflects structure only, got "${answerText(plain)}"`,
      );
      const withUnasserted = assembleCase(world, (input, asked, w, answer) => {
        const occurs = new Occurs(asked);
        occurs.event = answer;
        Assert(input, occurs);
        const by = new Agent(asked);
        by.action = answer;
        by.actor = w.crow;
        Assert(input, by);
        input.push(makeAgent(asked, w.sing, w.fox)); // never asserted
      });
      assert(
        answerText(withUnasserted) === "Sing(manner=her best)",
        "projection never consults Agents or any wording lexicon",
      );
    },
  },
  {
    name: "support: a new Condition subclass is held without registration",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const fall = new Fall(story);
          fall.theme = cheese;
          input.push(cheese, fall);
          AssertOccurs(input, fall);
          const wet = new Wet(story);
          wet.subject = cheese;
          input.push(wet);
          const result = new ResultsIn(story);
          result.event = fall;
          result.proposition = wet;
          Assert(input, result);
          return { root: story, cheese };
        },
        (input, asked, w, answer) => {
          const wet = new Wet(asked);
          wet.subject = answer;
          Assert(input, wet);
        },
      );
      assert(
        solveAssembled(assembled).get(assembled.answer) ===
          assembled.world.cheese,
        "a Condition held as the result of an occurred event is supported " +
          "by its class alone, with no list to register in",
      );
    },
  },
  {
    name: "outcomes: failure attribution does not depend on constraint order",
    run() {
      const orders = [
        ["among", "occurs", "agent"],
        ["agent", "occurs", "among"],
      ];
      const joint = orders.map((order) => {
        const assembled = assembleCase(splitDropsWorld, whoDroppedInOrder(order));
        return solveAssembled(assembled).get(assembled.answer);
      });
      for (const record of joint) {
        assert(isNotEstablished(record, "joint"), "joint in every order");
        assert(
          [...failingClasses(record).split(",")].sort().join(",") ===
            "Agent,Among,Occurs",
          `joint names the whole held set, got ${failingClasses(record)}`,
        );
      }
      // An absent correspondent and an unsupported Agent: correspondence
      // wins whichever is held first.
      for (const amongFirst of [true, false]) {
        const assembled = assembleCase(singingWorld, (input, asked, w) => {
          const f = new Fall(asked);
          input.push(f);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = f;
          const who = makeAgent(asked, w.sing, w.fox);
          if (amongFirst) Assert(input, h);
          Assert(input, who);
          if (!amongFirst) Assert(input, h);
        });
        const record = solveAssembled(assembled).get(assembled.answer);
        assert(
          isNotEstablished(record, "correspondence") &&
            failingClasses(record) === "Among",
          `order-independent correspondence, got ${JSON.stringify(record?.level)}`,
        );
      }
    },
  },
  {
    name: "correspondence: Among over the asking Situation has no correspondent",
    run() {
      const assembled = assembleCase(groundWorld(false), (input, asked, w, answer) => {
        const f = new Fall(asked);
        f.theme = answer;
        input.push(f);
        const h = new Among(asked);
        h.situation = asked; // not a Situation above the asking one
        h.node = f;
        Assert(input, h);
      });
      assert(
        answerText(assembled) ===
          "{constraints=[Among],level=correspondence,result=not-established}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "outcomes: an unstated solution keeps one stated value from being unique",
    run() {
      const assembled = assembleCase(
        (input, story) => {
          const cheese = entity(story, "the cheese");
          const ground = entity(story, "the ground");
          const stated = new Fall(story);
          stated.theme = cheese;
          stated.destination = ground;
          const unstated = new Fall(story);
          unstated.destination = ground;
          input.push(cheese, ground, stated, unstated);
          AssertOccurs(input, stated);
          AssertOccurs(input, unstated);
          return { root: story, ground };
        },
        whatFell,
      );
      assert(
        answerText(assembled) ===
          "{candidates=[Entity(the cheese)],result=ambiguous,unstated=true}",
        `got "${answerText(assembled)}"`,
      );
    },
  },
  {
    name: "story-1: more pebbles come between the rise and the drinking",
    run() {
      const solve = (build) => {
        const assembled = assembleCase(BuildCrowStory, build);
        return [solveAssembled(assembled).get(assembled.answer), assembled];
      };
      const [sequel, first] = solve((input, asked, w, answer) => {
        Assert(input, makeNext(asked, w.waterRise, answer));
      });
      assert(
        sequel === first.world.castMore,
        "right after the rise the crow casts in a few more pebbles",
      );
      const [immediate] = solve((input, asked, w, answer) => {
        const able = new Enables(asked);
        able.enabler = w.waterRise;
        able.enabled = answer;
        Assert(input, able);
        Assert(input, makeNext(asked, w.waterRise, answer));
      });
      assert(
        isNotEstablished(immediate, "joint"),
        "the drinking is enabled by the rise but is not its immediate Next",
      );
      const [cause] = solve((input, asked, w, answer) => {
        const why = new Causes(asked);
        why.cause = answer;
        why.effect = w.waterRise;
        Assert(input, why);
      });
      assert(
        cause instanceof Series && cause.parts.length === 2,
        "the water rises from the dropping as a whole, not from one pebble",
      );
    },
  },
  {
    name: "match: a Variable inside an Array field binds like a Node field",
    run() {
      const solve = (parts) => {
        const assembled = assembleCase(BuildCrowStory, (input, asked, w, x) => {
          const series = new Series(asked);
          series.parts = parts(w, x);
          input.push(series);
          const among = new Among(asked);
          among.situation = w.root;
          among.node = series;
          Assert(input, among);
          const why = new Causes(asked);
          why.cause = series;
          why.effect = w.waterRise;
          Assert(input, why);
        });
        return [solveAssembled(assembled).get(assembled.answer), assembled];
      };
      const [other, first] = solve((w, x) => [w.dropFirst, x]);
      assert(
        other === first.world.dropOthers,
        "the dropping that joins the first pebble's is the other pebbles'",
      );
      const [shorter] = solve((w, x) => [x]);
      assert(
        isNotEstablished(shorter, "correspondence"),
        "a one-part series is not the two-part dropping",
      );
      const [wrong] = solve((w, x) => [w.castMore, x]);
      assert(
        isNotEstablished(wrong, "correspondence"),
        "a constant item still has to match its counterpart",
      );
    },
  },
  {
    name: "outcomes: two unstated fields are never the same value",
    run() {
      // "Who dropped the thing that fell?": the story writes neither theme,
      // so it never says the dropped thing is the fallen one.
      const apart = unstatedThemes(false);
      const split = assembleCase(apart.world, apart.asked);
      assert(
        isNotEstablished(solveAssembled(split).get(split.answer), "joint"),
        "unstated themes of two events do not join",
      );
      // Both descriptions can only name the one Drop: the same unstated
      // field read twice still agrees with itself.
      const together = unstatedThemes(true);
      const same = assembleCase(together.world, together.asked);
      const solved = solveAssembled(same);
      assert(
        solved.get(same.answer) === same.world.crow,
        "one unstated field joins with itself",
      );
      assert(
        answerText(same) === "Entity(the crow)",
        `got "${answerText(same)}"`,
      );
    },
  },
  {
    name: "structure: the dialogue reply boundary after the ref revision",
    run() {
      // A constant story Node may be mentioned directly from the dialogue
      // root: only Situation-relative state needs a ref.
      const dialogue = new Situation();
      const story = new Situation();
      const crow = entity(story, "the crow");
      const mentions = new Says(dialogue);
      mentions.text = "about the crow";
      mentions.content = null;
      mentions.note = crow;
      mentions.about = story;
      const input = [dialogue, story, crow, mentions];
      Analyze(input);
      // The asked answer is Situation-relative: no direct reference from
      // the dialogue, only ref(asked, answer).
      const asked = new Situation(story);
      const answer = new Variable(asked);
      const query = new Query(asked, [answer]);
      const asks = new Asks(dialogue);
      asks.story = story;
      asks.asked = asked;
      const reply = new Reply(dialogue);
      reply.content = ref(asked, answer);
      const imperative = new Imperative(dialogue, KonsupuIdentity.Ref(), reply);
      const full = [dialogue, story, crow, asked, answer, query, asks,
        new Query(dialogue, [ref(asked, answer)]), reply, imperative];
      Analyze(full);
      const direct = new Reply(dialogue);
      direct.content = answer;
      assertThrows(
        () => Analyze([...full, direct]),
        "Cross-Situation Variable requires ref",
        "a direct asked Variable reference from the dialogue must be refused",
      );
    },
  },
  {
    name: "foundation: the copied source is byte-identical to src",
    run() {
      const here = fileURLToPath(new URL(".", import.meta.url));
      const pairs = [
        ["space/Memory/Foundation", "../../src/foundation/Memory/Foundation"],
        ["space/Test", "../../src/foundation/Test"],
        ["space/Test.js", "../../src/foundation/Test.js"],
        ["space/Resolve.js", "../../src/foundation/Resolve.js"],
        ["space/Interface/Nodes.js", "../../src/foundation/Interface/Nodes.js"],
        ["space/Interface/Outputs.js", "../../src/foundation/Interface/Outputs.js"],
      ];
      const walk = (path) => {
        if (statSync(path).isFile()) return [path];
        const files = [];
        for (const name of readdirSync(path)) {
          files.push(...walk(join(path, name)));
        }
        return files;
      };
      for (const [copy, origin] of pairs) {
        const from = join(here, copy);
        const to = join(here, origin);
        const left = walk(from).map((p) => p.slice(from.length)).sort();
        const right = walk(to).map((p) => p.slice(to.length)).sort();
        assert(
          JSON.stringify(left) === JSON.stringify(right),
          `${copy} and the original differ in file set`,
        );
        for (const rel of left) {
          assert(
            readFileSync(join(from, rel)).equals(readFileSync(join(to, rel))),
            `${copy}${rel} is not byte-identical to the original`,
          );
        }
      }
    },
  },
  // ----- Phase 2: contexts -----
  {
    name: "context: world constraints are not supported by belief content",
    run() {
      // Positive: what the dog really saw is a world fact.
      const saw = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const d = new See(asked);
        d.theme = answer;
        d.place = w.water;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        const who = new Agent(asked);
        who.action = d;
        who.actor = w.dog;
        Assert(input, who);
      });
      assert(
        answerText(saw) === "Entity(his own shadow reflected in the water)",
        "the world answers what the dog really saw",
      );
      // Negative: the belief's characterization never supports a world
      // question, whatever it holds.
      const dreamed = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const carried = new Carrying(asked);
        carried.carrier = answer;
        carried.theme = w.otherMeat;
        Assert(input, carried);
      });
      assert(
        isNotEstablished(
          solveAssembled(dreamed).get(dreamed.answer),
          "instance",
        ),
        "the dog's belief does not hold in the world",
      );
    },
  },
  {
    name: "context: a belief's evaluation sees only its own held cognition",
    run() {
      const inside = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.dog;
        belief.content = b;
        Assert(input, belief);
        const identification = new SameReferent(asked);
        identification.left = w.shadow;
        identification.right = answer;
        input.push(identification);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = identification;
        Assert(input, held);
        return [b];
      });
      assert(
        answerText(inside) === "Entity(another dog)",
        "the belief's own content answers inside it",
      );
      // The belief mentions the world's shadow; that mention does not
      // let it see what the world holds (the meat's location).
      const blinded = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.dog;
        belief.content = b;
        Assert(input, belief);
        const where = new LocatedAt(asked);
        where.entity = w.meat;
        where.place = answer;
        input.push(where);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = where;
        Assert(input, held);
        return [b];
      });
      assert(
        isNotEstablished(
          solveAssembled(blinded).get(blinded.answer),
          "instance",
        ),
        "mentioning world individuals does not import world cognition",
      );
    },
  },
  {
    name: "context: one referent, two characterizations, explicit correspondence",
    run() {
      const build = (withIdentity) => (input, story) => {
        const dog = entity(story, "the dog");
        const water = entity(story, "the water");
        const shadow = entity(story, "his own shadow");
        input.push(dog, water, shadow);
        const belief = new Situation();
        input.push(belief);
        const otherDog = new Entity(belief);
        otherDog.name = "another dog";
        input.push(otherDog);
        if (withIdentity) {
          const mistaken = new SameReferent(belief);
          mistaken.left = shadow;
          mistaken.right = otherDog;
          Assert(input, mistaken, belief);
        }
        const believed = new Believes(story);
        believed.believer = dog;
        believed.content = belief;
        Assert(input, believed);
        return { root: story, dog, shadow, belief };
      };
      const ask = (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.dog;
        belief.content = b;
        Assert(input, belief);
        const identification = new SameReferent(asked);
        identification.left = w.shadow;
        identification.right = answer;
        input.push(identification);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = identification;
        Assert(input, held);
        return [b];
      };
      const identified = assembleCase(build(true), ask);
      assert(
        answerText(identified) === "Entity(another dog)",
        "the belief's identification answers",
      );
      const unlinked = assembleCase(build(false), ask);
      assert(
        isNotEstablished(
          solveAssembled(unlinked).get(unlinked.answer),
          "instance",
        ),
        "without the explicit correspondence the match fails",
      );
    },
  },
  {
    name: "context: belief-specific objects are mentionable but never real",
    run() {
      // Positive: the world goal mentions the belief's meat.
      const mentioned = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const why = new InOrderTo(asked);
        why.action = w.snapAt;
        why.goal = answer;
        Assert(input, why);
      });
      assert(
        answerText(mentioned) === "Get(theme=Entity(another piece of meat))",
        "the world's goal names the belief-specific object",
      );
      // Negative: mentioned is not existed-as — Occurs finds nothing.
      const d = () => (input, asked, w, answer) => {
        const g = new Get(asked);
        g.theme = w.otherMeat;
        input.push(g);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = g;
        Assert(input, h);
        AssertOccurs(input, g);
      };
      const never = assembleCase(BuildDogStory, d());
      assert(
        isNotEstablished(solveAssembled(never).get(never.answer), "instance"),
        "the belief's meat never occurred in the world",
      );
    },
  },
  {
    name: "context: imagined events stay imagined",
    run() {
      // The imagined toss is a member of the plan context; reading its
      // occurrence there succeeds, but Occurs is a world constraint.
      const inPlan = assembleCase(BuildMilkmaidStory, (input, asked, w, answer) => {
        const d = new Toss(asked);
        d.theme = w.head;
        d.manner = "like this";
        input.push(d);
        const h = new Among(asked);
        h.situation = w.plan;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
      });
      assert(
        isNotEstablished(solveAssembled(inPlan).get(inPlan.answer), "instance"),
        "an event occurring in the plan never occurs in the world",
      );
      // The real toss of the same shape occurs and answers yes.
      const real = assembleCase(BuildMilkmaidStory, (input, asked, w, answer) => {
        const d = new Toss(asked);
        d.theme = w.head;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        const who = new Agent(asked);
        who.action = d;
        who.actor = w.patty;
        Assert(input, who);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const asked1 = new AskWhether(asked);
        asked1.content = happened;
        asked1.verdict = answer;
        Assert(input, asked1);
      });
      assert(
        answerText(real) === "{result=yes}",
        "the real toss happened",
      );
    },
  },
  // ----- Phase 2: time -----
  {
    name: "time: one entity, one place per time; 'at the end' is unique",
    run() {
      const end = assembleCase(BuildCrowFoxStory, (input, asked, w, answer) => {
        const where = new LocatedAt(asked);
        where.entity = w.cheese;
        where.place = answer;
        Assert(input, where);
        const when = new HoldsWhen(asked);
        when.state = where;
        when.when = TheEnd;
        Assert(input, when);
      });
      assert(
        answerText(end) === "Entity(the fox's jaws)",
        `where the cheese ended up, got "${answerText(end)}"`,
      );
      const both = assembleCase(BuildCrowFoxStory, (input, asked, w, answer) => {
        const where = new LocatedAt(asked);
        where.entity = w.cheese;
        where.place = answer;
        Assert(input, where);
        const afterDrop = new After(asked);
        afterDrop.event = w.dropCheese;
        input.push(afterDrop);
        const beforeSnap = new PriorTo(asked);
        beforeSnap.event = w.snapUp;
        input.push(beforeSnap);
        const h1 = new HoldsWhen(asked);
        h1.state = where;
        h1.when = afterDrop;
        Assert(input, h1);
        const h2 = new HoldsWhen(asked);
        h2.state = where;
        h2.when = beforeSnap;
        Assert(input, h2);
      });
      assert(
        answerText(both) === "Entity(the ground)",
        `between the fall and the seize, got "${answerText(both)}"`,
      );
      const loose = assembleCase(BuildCrowFoxStory, (input, asked, w, answer) => {
        const where = new LocatedAt(asked);
        where.entity = w.cheese;
        where.place = answer;
        Assert(input, where);
      });
      const value = solveAssembled(loose).get(loose.answer);
      assert(
        value.result === "ambiguous" && value.candidates.length === 2,
        "without an anchor both places satisfy",
      );
    },
  },
  {
    name: "time: inertia is explicit and needs a start",
    run() {
      const make = (withEnd, withStart) => (input, story) => {
        const cheese = entity(story, "the cheese");
        const ground = entity(story, "the ground");
        const roof = entity(story, "the roof");
        const drop = new Fall(story);
        drop.theme = cheese;
        drop.destination = ground;
        const lift = new SnapUp(story);
        lift.theme = cheese;
        input.push(cheese, ground, roof, drop, lift);
        AssertOccurs(input, drop);
        AssertOccurs(input, lift);
        const onGround = new LocatedAt(story);
        onGround.entity = cheese;
        onGround.place = ground;
        input.push(onGround);
        if (withStart) {
          const result = new ResultsIn(story);
          result.event = drop;
          result.proposition = onGround;
          Assert(input, result);
        }
        if (withEnd) {
          const onRoof = new LocatedAt(story);
          onRoof.entity = cheese;
          onRoof.place = roof;
          input.push(onRoof);
          const moved = new ResultsIn(story);
          moved.event = lift;
          moved.proposition = onRoof;
          Assert(input, moved);
          const order = new Next(story);
          order.earlier = drop;
          order.later = lift;
          Assert(input, order);
        }
        return { root: story, cheese, ground, roof };
      };
      const askFinal = (input, asked, w, answer) => {
        const where = new LocatedAt(asked);
        where.entity = w.cheese;
        where.place = answer;
        Assert(input, where);
        const when = new HoldsWhen(asked);
        when.state = where;
        when.when = TheEnd;
        Assert(input, when);
      };
      const neverStarted = assembleCase(make(false, false), askFinal);
      assert(
        isNotEstablished(
          solveAssembled(neverStarted).get(neverStarted.answer),
          "instance",
        ),
        "a state with no start never holds",
      );
      const holding = assembleCase(make(false, true), askFinal);
      assert(
        answerText(holding) === "Entity(the ground)",
        "no ending event: the started state persists to the end",
      );
      const ended = assembleCase(make(true, true), askFinal);
      assert(
        answerText(ended) === "Entity(the roof)",
        "the later-anchored location ends the earlier one",
      );
    },
  },
  {
    name: "time: belief revision keeps both intervals",
    run() {
      const earlier = assembleCase(BuildMaskStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.fox;
        belief.content = b;
        Assert(input, belief);
        const before = new PriorTo(asked);
        before.event = w.lookClose;
        input.push(before);
        const when = new HoldsWhen(asked);
        when.state = belief;
        when.when = before;
        Assert(input, when);
        const identification = new SameReferent(asked);
        identification.left = w.mask;
        identification.right = answer;
        input.push(identification);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = identification;
        Assert(input, held);
        return [b];
      });
      assert(
        answerText(earlier) === "Entity(a face glaring down on him)",
        "the earlier belief holds before the closer look",
      );
      const later = assembleCase(BuildMaskStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.fox;
        belief.content = b;
        Assert(input, belief);
        const after = new After(asked);
        after.event = w.lookClose;
        input.push(after);
        const when = new HoldsWhen(asked);
        when.state = belief;
        when.when = after;
        Assert(input, when);
        const stillFace = new SameReferent(asked);
        stillFace.left = w.mask;
        stillFace.right = w.face;
        input.push(stillFace);
        const asked1 = new AskWhether(asked);
        asked1.content = stillFace;
        asked1.context = b;
        asked1.verdict = answer;
        Assert(input, asked1);
        return [b];
      });
      assert(
        answerText(later) === "{result=no}",
        "at the closer look the negated identification wins",
      );
    },
  },
  {
    name: "time: a habit is not one happening; its instance is queryable",
    run() {
      const habit = assembleCase(BuildMiserStory, (input, asked, w, answer) => {
        const deed = new Hide(asked);
        deed.theme = w.gold;
        deed.place = answer;
        input.push(deed);
        const h = new Habitual(asked);
        h.doer = w.miser;
        h.deed = deed;
        Assert(input, h);
      });
      assert(
        answerText(habit) === "Entity(the foot of a tree in his garden)",
        "the habit's place answers",
      );
      const happened = assembleCase(BuildMiserStory, (input, asked, w, answer) => {
        const deed = new Hide(asked);
        deed.theme = w.gold;
        input.push(deed);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = deed;
        Assert(input, h);
        AssertOccurs(input, deed);
      });
      assert(
        isNotEstablished(
          solveAssembled(happened).get(happened.answer),
          "instance",
        ),
        "no single hiding ever occurred",
      );
      const instance = assembleCase(BuildMiserStory, (input, asked, w, answer) => {
        const deed = new DigUp(asked);
        deed.theme = w.gold;
        input.push(deed);
        const h = new Habitual(asked);
        h.doer = w.miser;
        h.deed = deed;
        input.push(h);
        const one = new Instance(asked);
        one.habit = h;
        one.event = answer;
        Assert(input, one);
      });
      assert(
        answerText(instance) ===
          "ComeTo(destination=Entity(the foot of a tree in his garden))",
        "the next visit is one event of the habit (the coming; the gloating is its goal, never a happening)",
      );
    },
  },
  {
    name: "time: an earlier match moves the ordinal",
    run() {
      const make = (withEarlier) => (input, story) => {
        const boy = entity(story, "the boy");
        const wolf = entity(story, "the wolf");
        input.push(boy, wolf);
        const cries = [];
        if (withEarlier) {
          const zero = new CryOut(story);
          zero.call = "Wolf";
          input.push(zero);
          AssertOccurs(input, zero);
          cries.push(zero);
        }
        const first = new CryOut(story);
        first.call = "Wolf";
        const second = new CryOut(story);
        second.call = "Wolf";
        input.push(first, second);
        AssertOccurs(input, first);
        AssertOccurs(input, second);
        cries.push(first, second);
        for (let i = 0; i + 1 < cries.length; i += 1) {
          const n = new Next(story);
          n.earlier = cries[i];
          n.later = cries[i + 1];
          Assert(input, n);
        }
        return { root: story, wolf, first, second };
      };
      const ask = (input, asked, w, answer) => {
        const d = new CryOut(asked);
        d.call = "Wolf";
        input.push(d);
        const nth = new Nth(asked);
        nth.pattern = d;
        nth.index = 1;
        input.push(nth);
        const when = new Next(asked);
        when.earlier = nth;
        when.later = answer;
        Assert(input, when);
      };
      const two = assembleCase(make(false), ask);
      const afterFirstOfTwo = solveAssembled(two).get(two.answer);
      assert(
        afterFirstOfTwo === two.world.second,
        "with two cries, after the first is the second",
      );
      const three = assembleCase(make(true), ask);
      const afterFirstOfThree = solveAssembled(three).get(three.answer);
      assert(
        afterFirstOfThree === three.world.first,
        "an earlier matching cry moves 'the first time' onto the inserted cry",
      );
    },
  },
  {
    name: "time: Input order is not time",
    run() {
      // Two equivalent fixtures: the same chain, only independent
      // assertions (the Agent and the Occurs pair) pushed in opposite
      // orders. The answer must not notice.
      const make = (flip) => (input, story) => {
        const crow = entity(story, "the crow");
        const sing = new Sing(story);
        const fall = new Fall(story);
        input.push(crow);
        if (flip) {
          input.push(fall, sing);
        } else {
          input.push(sing, fall);
        }
        if (flip) {
          AssertOccurs(input, fall);
          AssertOccurs(input, sing);
        } else {
          AssertOccurs(input, sing);
          AssertOccurs(input, fall);
        }
        const n = new Next(story);
        n.earlier = sing;
        n.later = fall;
        Assert(input, n);
        const who = new Agent(story);
        who.action = sing;
        who.actor = crow;
        Assert(input, who);
        return { root: story, crow, fall };
      };
      const ask = (input, asked, w, answer) => {
        const before = new Next(asked);
        before.earlier = answer;
        before.later = w.fall;
        Assert(input, before);
        const who = new Agent(asked);
        who.action = answer;
        who.actor = w.crow;
        Assert(input, who);
      };
      const a = assembleCase(make(false), ask);
      const b = assembleCase(make(true), ask);
      assert(
        answerText(a) === "Sing()" && answerText(b) === "Sing()",
        `both orders agree, got "${answerText(a)}" / "${answerText(b)}"`,
      );
    },
  },
  // ----- Phase 2: negation and yes-no -----
  {
    name: "negation: removing the held negation turns 'no' into 'not established'",
    run() {
      const make = (withNegation) => (input, story) => {
        const wolf = entity(story, "the wolf");
        const boy = entity(story, "the boy");
        input.push(wolf, boy);
        const cry = new CryOut(story);
        cry.call = "Wolf";
        input.push(cry);
        AssertOccurs(input, cry);
        if (withNegation) {
          const absent = new Present(story);
          absent.subject = wolf;
          input.push(absent);
          const notPresent = new Not(story);
          notPresent.proposition = absent;
          input.push(notPresent);
          const atFirst = new Initially(story);
          atFirst.state = notPresent;
          Assert(input, atFirst);
        }
        return { root: story, wolf, cry };
      };
      const ask = (input, asked, w, answer) => {
        const there = new Present(asked);
        there.subject = w.wolf;
        input.push(there);
        const asked1 = new AskWhether(asked);
        asked1.content = there;
        asked1.when = w.cry;
        asked1.verdict = answer;
        Assert(input, asked1);
      };
      const denied = assembleCase(make(true), ask);
      assert(answerText(denied) === "{result=no}", "the held negation answers no");
      const open = assembleCase(make(false), ask);
      assert(
        answerText(open).includes("not-established"),
        "without the negation nothing is established",
      );
    },
  },
  {
    name: "negation: a NoEvent refutes only inside its window",
    run() {
      const asked1 = assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const d = new ComeToHelp(asked);
        d.theme = w.boy;
        input.push(d);
        const nth = new Nth(asked);
        nth.pattern = cryShape(input, asked);
        nth.index = 3;
        input.push(nth);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.when = nth;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(asked1) === "{result=no}",
        "the third window refutes the third asking",
      );
      const second = assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const d = new ComeToHelp(asked);
        d.theme = w.boy;
        input.push(d);
        const nth = new Nth(asked);
        nth.pattern = cryShape(input, asked);
        nth.index = 2;
        input.push(nth);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.when = nth;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(second) === "{result=yes}",
        "the same negation never touches the second asking",
      );
    },
  },
  {
    name: "negation: inability is not non-occurrence; ability changes over time",
    run() {
      const before = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const trapped = new Unable(asked);
        trapped.actor = w.fox;
        trapped.deed = deed;
        input.push(trapped);
        const could = new Not(asked);
        could.proposition = trapped;
        input.push(could);
        const before2 = new PriorTo(asked);
        before2.event = w.goatJump;
        input.push(before2);
        const ask = new AskWhether(asked);
        ask.content = could;
        ask.when = before2;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(before) === "{result=no}",
        "he could not get out before the goat came down",
      );
      // The deed itself happened: inability never negates occurrence.
      const escaped = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const happened = new Occurs(asked);
        happened.event = deed;
        input.push(happened);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(escaped) === "{result=yes}",
        "unable before, out anyway after",
      );
      // And after the escape the inability is gone.
      const after = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const trapped = new Unable(asked);
        trapped.actor = w.fox;
        trapped.deed = deed;
        input.push(trapped);
        const could = new Not(asked);
        could.proposition = trapped;
        input.push(could);
        const after2 = new After(asked);
        after2.event = w.escape;
        input.push(after2);
        const ask = new AskWhether(asked);
        ask.content = could;
        ask.when = after2;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(after) === "{result=yes}",
        "the escape ended the inability",
      );
    },
  },
  {
    name: "negation: an in-context negation never answers a world question",
    run() {
      const inNews = assembleCase(BuildCockStory, (input, asked, w, answer) => {
        const deed = new Hurt(asked);
        input.push(deed);
        const forbidden = new Forbids(asked);
        forbidden.deed = deed;
        input.push(forbidden);
        const mayNot = new Not(asked);
        mayNot.proposition = forbidden;
        input.push(mayNot);
        const s = new Variable(asked);
        input.push(s);
        const ask = new AskWhether(asked);
        ask.content = mayNot;
        ask.context = s;
        ask.verdict = answer;
        Assert(input, ask);
        // Bind s by the news speech so the evaluation context is the news.
        const d = new Says(asked);
        d.content = s;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        const who = new Agent(asked);
        who.action = d;
        who.actor = w.fox;
        Assert(input, who);
        return [s];
      });
      assert(
        answerText(inNews) === "{result=no}",
        "inside the news the norm negates",
      );
      const inWorld = assembleCase(BuildCockStory, (input, asked, w, answer) => {
        const deed = new Hurt(asked);
        input.push(deed);
        const forbidden = new Forbids(asked);
        forbidden.deed = deed;
        input.push(forbidden);
        const mayNot = new Not(asked);
        mayNot.proposition = forbidden;
        input.push(mayNot);
        const ask = new AskWhether(asked);
        ask.content = mayNot;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(inWorld).includes("not-established"),
        "the world holds no such negation",
      );
    },
  },
  {
    name: "negation: an exhaustive listing negates only inside its scope",
    run() {
      // Inside the window (from the crying on) the unlisted throwing is
      // negated; before the window, her speaking is untouched.
      const thrown = assembleCase(BuildNurseStory, (input, asked, w, answer) => {
        const d = new Throw(asked);
        d.theme = w.child;
        d.to = w.wolf;
        input.push(d);
        const did = new Agent(asked);
        did.action = d;
        did.actor = w.nurse;
        input.push(did);
        const ask = new AskWhether(asked);
        ask.content = did;
        ask.when = w.childCried;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(thrown) === "{result=no}",
        "the exhaustive listing negates the unlisted throwing",
      );
      // A scoped listing of the nurse's own: everything before its
      // window is untouched — the world's whole-line listing in the
      // fixture is the sentence's own scope, not this rule.
      const scopedWorld = (input, story) => {
        const nurse = entity(story, "the nurse");
        const child = entity(story, "the child");
        const window = new CryOut(story);
        window.call = "cry";
        const spoke = new Says(story);
        spoke.text = "be quiet";
        const shut = new Shut(story);
        shut.theme = window;
        input.push(nurse, child, window, spoke, shut);
        AssertOccurs(input, window);
        AssertOccurs(input, spoke);
        AssertOccurs(input, shut);
        Assert(input, makeAgent(story, spoke, nurse));
        Assert(input, makeAgent(story, shut, nurse));
        const order = new Next(story);
        order.earlier = window;
        order.later = shut;
        Assert(input, order);
        const listed = new OnlyDid(story);
        listed.actor = nurse;
        listed.deeds = [shut];
        listed.from = window;
        listed.until = TheEnd;
        Assert(input, listed);
        return { root: story, nurse, child, window, spoke, shut };
      };
      const spoke = assembleCase(scopedWorld, (input, asked, w, answer) => {
        const d = new Says(asked);
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        const who = new Agent(asked);
        who.action = d;
        who.actor = w.nurse;
        input.push(who);
        const ask = new AskWhether(asked);
        ask.content = who;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(spoke) === "{result=yes}",
        "before the window the listing negates nothing",
      );
    },
  },
  {
    name: "outcomes: yes, no, not established, and conflict are all reachable",
    run() {
      const yes = assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const there = new Present(asked);
        there.subject = w.wolf;
        input.push(there);
        const nth = new Nth(asked);
        nth.pattern = cryShape(input, asked);
        nth.index = 3;
        input.push(nth);
        const ask = new AskWhether(asked);
        ask.content = there;
        ask.when = nth;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(answerText(yes) === "{result=yes}", "the third cry was true");
      // A deliberately inconsistent context: both the presence and its
      // negation hold with no end in sight.
      const conflict = assembleCase(
        (input, story) => {
          const wolf = entity(story, "the wolf");
          input.push(wolf);
          const present = new Present(story);
          present.subject = wolf;
          input.push(present);
          const absent = new Present(story);
          absent.subject = wolf;
          input.push(absent);
          const notPresent = new Not(story);
          notPresent.proposition = absent;
          input.push(notPresent);
          const atFirst = new Initially(story);
          atFirst.state = notPresent;
          Assert(input, atFirst);
          const there = new Present(story);
          there.subject = wolf;
          Assert(input, there);
          return { root: story, wolf };
        },
        (input, asked, w, answer) => {
          const there = new Present(asked);
          there.subject = w.wolf;
          input.push(there);
          const ask = new AskWhether(asked);
          ask.content = there;
          ask.verdict = answer;
          Assert(input, ask);
        },
      );
      assert(
        answerText(conflict) === "{result=conflict}",
        "both sides held: the conflict passes through the Reply",
      );
      const unknown = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const coming = new Drought(asked);
        input.push(coming);
        const ask = new AskWhether(asked);
        ask.content = coming;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(unknown).includes("not-established"),
        "neither side held: not established",
      );
    },
  },
  {
    name: "presupposition: a failed description is not a refuted content",
    run() {
      // The definite description "the dragon" has no correspondent: the
      // question never gets to a verdict.
      const missing = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const dragon = new Entity(asked);
        dragon.name = "the dragon";
        input.push(dragon);
        const d = new Get(asked);
        d.theme = dragon;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
      });
      assert(
        isNotEstablished(
          solveAssembled(missing).get(missing.answer),
          "correspondence",
        ),
        "a failed presupposition is not-established",
      );
      // A refuted content answers no.
      const refuted = assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const d = new ComeToHelp(asked);
        d.theme = w.boy;
        input.push(d);
        const nth = new Nth(asked);
        nth.pattern = cryShape(input, asked);
        nth.index = 3;
        input.push(nth);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.when = nth;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(answerText(refuted) === "{result=no}", "a refuted content is no");
    },
  },
  // ----- Phase 2: speech, belief, deception -----
  {
    name: "deception: a mistaken belief never implies a deceiver",
    run() {
      const nobody = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const deceived = new Deceives(asked);
        deceived.victim = w.dog;
        input.push(deceived);
        const ask = new AskWhether(asked);
        ask.content = deceived;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(nobody).includes("not-established"),
        "the dog was wrong, and no one deceived him",
      );
      const someone = assembleCase(BuildClothingStory, (input, asked, w, answer) => {
        const deceived = new Deceives(asked);
        deceived.deceiver = w.wolf;
        deceived.victim = answer;
        Assert(input, deceived);
      });
      assert(
        answerText(someone) === "Entity(the sheep)",
        "where the text says 'deceiving', the deceiver is answerable",
      );
    },
  },
  {
    name: "deception: a false saying is not yet a lie without the speaker's belief",
    run() {
      // The fox's told reason is false in the world (story-11 Q5), yet no
      // cognition says what HE believed about it.
      const notALie = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.fox;
        belief.content = b;
        Assert(input, belief);
        const said = new Not(asked);
        said.proposition = w.saidWhy;
        input.push(said);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = said;
        Assert(input, held);
        return [b];
      });
      assert(
        isNotEstablished(
          solveAssembled(notALie).get(notALie.answer),
          "instance",
        ),
        "nothing says the fox believed his reason false",
      );
      // The boy, by contrast, is textually a deceiver twice over.
      const aTrick = assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const deceived = new Deceives(asked);
        deceived.deceiver = w.boy;
        deceived.victim = w.villagers;
        Assert(input, deceived);
        const ask = new AskWhether(asked);
        ask.content = deceived;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(aTrick) === "{result=yes}",
        "'the same trick' and 'fooled twice' make the deceiving world-held",
      );
    },
  },
  {
    name: "deception: non-verbal deceiving, without any Says",
    run() {
      const means = assembleCase(BuildClothingStory, (input, asked, w, answer) => {
        const deceiving = new Deceives(asked);
        deceiving.deceiver = w.wolf;
        deceiving.victim = w.sheep;
        input.push(deceiving);
        const how = new ResultsIn(asked);
        how.event = answer;
        how.proposition = deceiving;
        Assert(input, how);
      });
      assert(
        answerText(means).startsWith("PutOn("),
        "the disguise itself is the means",
      );
      const neverSpoke = assembleCase(BuildClothingStory, (input, asked, w, answer) => {
        const d = new Says(asked);
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        const who = new Agent(asked);
        who.action = d;
        who.actor = w.wolf;
        Assert(input, who);
      });
      assert(
        isNotEstablished(
          solveAssembled(neverSpoke).get(neverSpoke.answer),
          "correspondence",
        ),
        "the wolf never said a word",
      );
    },
  },
  {
    name: "speech: the same content is true at one time and false at another",
    run() {
      // The claim the cry itself carries, read out of its context and
      // judged against the world at that cry — the same claim, two
      // verdicts.
      const askTruth = (index) =>
        assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
          const c = new Variable(asked);
          input.push(c);
          const d = new CryOut(asked);
          d.call = "Wolf, Wolf";
          d.content = c;
          input.push(d);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = d;
          Assert(input, h);
          const nth = new Nth(asked);
          nth.pattern = d;
          nth.index = index;
          input.push(nth);
          const claimed = new Entity(asked);
          input.push(claimed);
          const claim = new Present(asked);
          claim.subject = claimed;
          input.push(claim);
          const held = new HoldsIn(asked);
          held.context = c;
          held.proposition = claim;
          Assert(input, held);
          const ask = new AskWhether(asked);
          ask.content = claim;
          ask.when = nth;
          ask.verdict = answer;
          Assert(input, ask);
        });
      assert(
        answerText(askTruth(2)) === "{result=no}",
        "the claim is false at the second cry",
      );
      // The claim's "a wolf" is a wolf: a sheep present all along does
      // not make the second cry true.
      const withSheep = (input, story) => {
        const w = BuildShepherdStory(input, story);
        const sheepKind = new Kind(story);
        input.push(sheepKind);
        const sheep = entity(story, "a sheep");
        sheep.kind = sheepKind;
        input.push(sheep);
        const there = new Present(story);
        there.subject = sheep;
        input.push(there);
        const atFirst = new Initially(story);
        atFirst.state = there;
        Assert(input, atFirst);
        return w;
      };
      const firstTime = assembleCase(withSheep, Twin10.TwinQuestions[1].build);
      assert(
        answerText(firstTime) === "{result=no}",
        "another sort's presence never answers the claim",
      );
      assert(
        answerText(askTruth(3)) === "{result=yes}",
        "the same claim is true at the third",
      );
    },
  },
  {
    name: "speech: what was said is not held by the world",
    run() {
      // The miser's own "Nay" lives in his speech context only.
      const onlyHim = assembleCase(BuildMiserStory, (input, asked, w, answer) => {
        const taking = new Take(asked);
        taking.theme = w.gold;
        taking.source = w.hole;
        input.push(taking);
        const happened = new Occurs(asked);
        happened.event = taking;
        input.push(happened);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(onlyHim).includes("not-established"),
        "the world neither asserts nor denies his taking",
      );
      // The fox's drought lives in his news only.
      const onlyNews = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const coming = new Drought(asked);
        input.push(coming);
        const ask = new AskWhether(asked);
        ask.content = coming;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(onlyNews).includes("not-established"),
        "the claimed drought is not a world fact",
      );
    },
  },
  {
    name: "canon: Veracity and OutOfReach have no second channel",
    run() {
      const here = fileURLToPath(new URL(".", import.meta.url));
      const files = walk(join(here, "space"));
      for (const file of files) {
        const content = readFileSync(file, "utf8");
        assert(
          !content.includes("Veracity") && !content.includes("OutOfReach"),
          `${file} still mentions a removed truth/negation channel`,
        );
      }
      // The story fixtures too.
      for (const file of walk(join(here, "cases"))) {
        const content = readFileSync(file, "utf8");
        assert(
          !content.includes("Veracity") && !content.includes("OutOfReach"),
          `${file} still mentions a removed truth/negation channel`,
        );
      }
    },
  },
  // ----- Phase 2: twins, holding, and Foundation -----
  {
    name: "twins: every guide twin answers through the same machinery",
    run() {
      for (let id = 4; id <= 13; id += 1) {
        const cases = twinCases[id - 4];
        for (const [index, question] of cases.TwinQuestions.entries()) {
          const input = cases.BuildCase(question);
          const actual = Texts(Evaluate(input)).join(" | ");
          assert(
            normalizeText(actual) === normalizeText(question.expected),
            `story-${id} twin ${index + 1} (${question.text}): ` +
              `expected "${question.expected}", got "${actual}"`,
          );
        }
      }
    },
  },
  {
    name: "holding: one proposition introduced in one context, held in another",
    run() {
      // story-2's flattery claim: introduced by the fox's speech context,
      // held by the crow's belief. Only the holder supports the question.
      const fromBelief = assembleCase(BuildCrowFoxStory, (input, asked, w, answer) => {
        const b = new Variable(asked);
        input.push(b);
        const belief = new Believes(asked);
        belief.believer = w.crow;
        belief.content = b;
        Assert(input, belief);
        const held = new HoldsIn(asked);
        held.context = b;
        held.proposition = answer;
        Assert(input, held);
        return [b];
      });
      assert(
        answerText(fromBelief).startsWith("VoiceSurpasses("),
        "the belief's own Assertion supports the question",
      );
      // A context that merely introduces the claim without holding it
      // (the fox's speech holds it as said, so build a fresh third
      // context that only mentions it).
      const fromMention = assembleCase(
        (input, story) => {
          const w = BuildCrowFoxStory(input, story);
          const third = new Situation();
          input.push(third);
          const topic = new About(third);
          topic.proposition = w.claimVoice;
          topic.topic = w.voice;
          input.push(topic);
          return { ...w, third };
        },
        (input, asked, w, answer) => {
          const held = new HoldsIn(asked);
          held.context = w.third;
          held.proposition = answer;
          Assert(input, held);
        },
      );
      assert(
        isNotEstablished(
          solveAssembled(fromMention).get(fromMention.answer),
          "instance",
        ),
        "a context that never asserted the claim holds nothing of it",
      );
    },
  },
  {
    name: "verdicts: the negative side respects the joined bindings",
    run() {
      // "Could the goat get out?" — with the actor bound to the goat
      // through her own jump, and with the constant goat: the fox's
      // inability ending must never answer for the goat.
      const bound = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const a = new Variable(asked);
        input.push(a);
        const jump = new JumpDown(asked);
        jump.theme = a;
        jump.destination = w.well;
        input.push(jump);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = jump;
        Assert(input, h);
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const unable = new Unable(asked);
        unable.actor = a;
        unable.deed = deed;
        input.push(unable);
        const ask = new AskWhether(asked);
        ask.content = unable;
        ask.when = TheEnd;
        ask.verdict = answer;
        Assert(input, ask);
        return [a];
      });
      assert(
        answerText(bound) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "a bound actor is not re-bound onto the fox",
      );
      const constant = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const unable = new Unable(asked);
        unable.actor = w.goat;
        unable.deed = deed;
        input.push(unable);
        const ask = new AskWhether(asked);
        ask.content = unable;
        ask.when = TheEnd;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(constant) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "constant and bound askings agree",
      );
    },
  },
  {
    name: "verdicts: a said content still matches the world by content",
    run() {
      // He said he saw the cheese, and he did see it: reading the said
      // seeing through its context and judging it in the world answers
      // yes — node identity across contexts never blocks it.
      const saidWorld = (input, story) => {
        const fox = entity(story, "the fox");
        const cheese = entity(story, "the cheese");
        input.push(fox, cheese);
        const speech = context(new Situation(), "the fox's claim");
        input.push(speech);
        const saidSee = new See(speech);
        saidSee.theme = cheese;
        input.push(saidSee);
        AssertOccurs(input, saidSee, speech);
        const claim = new Says(story);
        claim.text = "I saw the cheese!";
        claim.content = speech;
        input.push(claim);
        AssertOccurs(input, claim);
        Assert(input, makeAgent(story, claim, fox));
        const worldSee = new See(story);
        worldSee.theme = cheese;
        input.push(worldSee);
        AssertOccurs(input, worldSee);
        Assert(input, makeAgent(story, worldSee, fox));
        return { root: story, fox, cheese, speech, claim };
      };
      const truth = assembleCase(saidWorld, (input, asked, w, answer) => {
        const c = new Variable(asked);
        input.push(c);
        const d = new Says(asked);
        d.content = c;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        Assert(input, makeAgent(asked, d, w.fox));
        const saw = new See(asked);
        saw.theme = w.cheese;
        input.push(saw);
        const said = new Occurs(asked);
        said.event = saw;
        input.push(said);
        const held = new HoldsIn(asked);
        held.context = c;
        held.proposition = said;
        Assert(input, held);
        const ask = new AskWhether(asked);
        ask.content = said;
        ask.verdict = answer;
        Assert(input, ask);
        return [c];
      });
      assert(
        answerText(truth) === "{result=yes}",
        "what was said and happened answers yes",
      );
    },
  },
  {
    name: "verdicts: an agent question is an occurrence question in time",
    run() {
      // The call for help happened after the crying; asked before the
      // crying it is not established, asked from the crying on it is.
      const ask = (whenBuilder) =>
        assembleCase(BuildNurseStory, (input, asked, w, answer) => {
          const d = new CallForHelp(asked);
          input.push(d);
          const h = new Among(asked);
          h.situation = w.root;
          h.node = d;
          Assert(input, h);
          const did = new Agent(asked);
          did.action = d;
          did.actor = w.nurse;
          input.push(did);
          const when = whenBuilder(input, asked, w);
          const ask1 = new AskWhether(asked);
          ask1.content = did;
          if (when) ask1.when = when;
          ask1.verdict = answer;
          Assert(input, ask1);
        });
      const beforeCry = ask((input, asked, w) => {
        const before = new PriorTo(asked);
        before.event = w.childCried;
        input.push(before);
        return before;
      });
      assert(
        answerText(beforeCry) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "the agent relation alone never claims the doing happened",
      );
      const fromCry = ask(() => null);
      assert(answerText(fromCry) === "{result=yes}", "it did happen");
    },
  },
  {
    name: "windows: 'while' scopes an occurrence question",
    run() {
      // The pounce is strictly before the leaving: asking whether it
      // happened while away must not find it.
      const awayWorld = (input, story) => {
        const lion = entity(story, "the lion");
        const deer = entity(story, "the deer");
        const den = entity(story, "the den");
        input.push(lion, deer, den);
        const pounce = new Pounce(story);
        pounce.theme = deer;
        const leave = new GoAway(story);
        leave.theme = lion;
        input.push(pounce, leave);
        AssertOccurs(input, pounce);
        AssertOccurs(input, leave);
        Assert(input, makeNext(story, pounce, leave));
        const away = new LocatedAt(story);
        away.entity = lion;
        away.place = den;
        input.push(away);
        const awayAt = new ResultsIn(story);
        awayAt.event = leave;
        awayAt.proposition = away;
        Assert(input, awayAt);
        return { root: story, lion, deer, den, pounce };
      };
      const whileAway = assembleCase(awayWorld, (input, asked, w, answer) => {
        const d = new Pounce(asked);
        d.theme = w.deer;
        input.push(d);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const where = new LocatedAt(asked);
        where.entity = w.lion;
        where.place = w.den;
        input.push(where);
        const during = new While(asked);
        during.state = where;
        input.push(during);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.when = during;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(whileAway) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "an earlier happening is outside the while-window",
      );
    },
  },
  {
    name: "windows: the n-th episode is closed by the (n+1)-th",
    run() {
      // Three visits, then the deed: asked "the second time" it is
      // outside the window; asked "the third time" it is inside.
      const visitsWorld = (input, story) => {
        const house = entity(story, "the house");
        input.push(house);
        const visits = [1, 2, 3].map(() => {
          const v = new ComeTo(story);
          v.destination = house;
          input.push(v);
          return v;
        });
        const act = new CryOut(story);
        act.call = "Hi";
        input.push(act);
        const events = [...visits, act];
        for (const e of events) AssertOccurs(input, e);
        for (let i = 0; i + 1 < events.length; i += 1) {
          Assert(input, makeNext(story, events[i], events[i + 1]));
        }
        return { root: story, house, visits, act };
      };
      const ask = (index, world) =>
        assembleCase(world ?? visitsWorld, (input, asked, w, answer) => {
          const d = new CryOut(asked);
          d.call = "Hi";
          input.push(d);
          const visit = new ComeTo(asked);
          visit.destination = w.house;
          input.push(visit);
          const nth = new Nth(asked);
          nth.pattern = visit;
          nth.index = index;
          input.push(nth);
          const happened = new Occurs(asked);
          happened.event = d;
          input.push(happened);
          const ask1 = new AskWhether(asked);
          ask1.content = happened;
          ask1.when = nth;
          ask1.verdict = answer;
          Assert(input, ask1);
        });
      assert(
        answerText(ask(2)) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "the second time ends where the third begins",
      );
      assert(answerText(ask(3)) === "{result=yes}", "the third runs to the end");
    },
  },
  {
    name: "windows: a negation starting at E does not cover 'before E'",
    run() {
      const seen = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const d = new See(asked);
        d.theme = w.meat;
        input.push(d);
        const happened = new Occurs(asked);
        happened.event = d;
        input.push(happened);
        const before = new PriorTo(asked);
        before.event = w.dropMeat;
        input.push(before);
        const ask = new AskWhether(asked);
        ask.content = happened;
        ask.when = before;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(seen) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "'never seen more' starts at the drop, not before it",
      );
    },
  },
  {
    name: "verdicts: a state changing after the anchor stays one-sided",
    run() {
      // Just after the pounce the ass still had its brains; they were
      // taken later. Both sides read the same moment, without conflict.
      const ask = (negated) => assembleCase(BuildAssStory, (input, asked, w, answer) => {
        const having = new Has(asked);
        having.owner = w.ass;
        having.possession = w.brains;
        input.push(having);
        let content = having;
        if (negated) {
          content = new Not(asked);
          content.proposition = having;
          input.push(content);
        }
        const after = new After(asked);
        after.event = w.lionPounce;
        input.push(after);
        const q = new AskWhether(asked);
        q.content = content;
        q.when = after;
        q.verdict = answer;
        Assert(input, q);
      });
      assert(answerText(ask(false)) === "{result=yes}", "just after the pounce it had brains");
      assert(answerText(ask(true)) === "{result=no}", "the same moment from the other side");
    },
  },
  {
    name: "negation: a class-derived ending refutes like a stated one",
    run() {
      const inMouth = assembleCase(BuildDogStory, (input, asked, w, answer) => {
        const where = new LocatedAt(asked);
        where.entity = w.meat;
        where.place = w.mouth;
        input.push(where);
        const ask = new AskWhether(asked);
        ask.content = where;
        ask.when = TheEnd;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(inMouth) === "{result=no}",
        "the water location ends the mouth location, and answers for it",
      );
    },
  },
  {
    name: "negation: an exhaustive listing with a theme and a pinned actor",
    run() {
      // "Nay, I only came to look at it" asked with the actor pinned:
      // no crash, and the answer is no inside his saying.
      const asked = assembleCase(BuildMiserStory, (input, asked, w, answer) => {
        const m = new Variable(asked);
        input.push(m);
        const d = new Says(asked);
        d.content = m;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        Assert(input, makeAgent(asked, d, w.miser));
        const taking = new Take(asked);
        taking.theme = w.gold;
        taking.source = w.hole;
        input.push(taking);
        const did = new Agent(asked);
        did.action = taking;
        did.actor = w.miser;
        input.push(did);
        const ask = new AskWhether(asked);
        ask.content = did;
        ask.context = m;
        ask.verdict = answer;
        Assert(input, ask);
        return [m];
      });
      assert(
        answerText(asked) === "{result=no}",
        "the OnlyDid with a theme answers through the pinned actor",
      );
    },
  },
  {
    name: "context: reading a context includes its imagined happenings",
    run() {
      const planned = assembleCase(BuildMilkmaidStory, (input, asked, w, answer) => {
        const p = new Variable(asked);
        input.push(p);
        const plan = new Plans(asked);
        plan.planner = w.patty;
        plan.content = p;
        Assert(input, plan);
        const buying = new Buy(asked);
        buying.buyer = w.patty;
        buying.what = answer;
        input.push(buying);
        const held = new HoldsIn(asked);
        held.context = p;
        held.proposition = buying;
        Assert(input, held);
        return [p];
      });
      const value = solveAssembled(planned).get(planned.answer);
      assert(
        value.result === "ambiguous" && value.candidates.length === 2,
        "the plan's own buyings, both of them, are what it holds",
      );
    },
  },
  {
    name: "chance: a purpose is refuted through the correspondence only",
    run() {
      const chanceWorld = (input, story) => {
        const fox = entity(story, "the fox");
        const goat = entity(story, "the goat");
        const well = entity(story, "the well");
        input.push(fox, goat, well);
        const fall = new Fall(story);
        fall.theme = fox;
        fall.destination = well;
        const jump = new JumpDown(story);
        jump.theme = goat;
        jump.destination = well;
        // Structurally compatible with the goat's jump, yet a different
        // happening: only the question's own correspondence may bind them.
        const foxJump = new JumpDown(story);
        foxJump.theme = fox;
        foxJump.destination = well;
        input.push(fall, jump, foxJump);
        AssertOccurs(input, fall);
        AssertOccurs(input, jump);
        Assert(input, makeAgent(story, jump, goat));
        const chance = new ByChance(story);
        chance.event = fall;
        Assert(input, chance);
        const same = new SameReferent(story);
        same.left = foxJump;
        same.right = fall;
        Assert(input, same);
        return { root: story, fox, goat, well, fall, foxJump, jump };
      };
      const jumpAsked = assembleCase(chanceWorld, (input, asked, w, answer) => {
        // The action is join-bound to the goat's jump through a
        // description, so a rule that rebinds it onto the bark changes
        // the verdict.
        // The field pattern alone matches both jumps; the goat's agency
        // pins the description, so only a rule that rebinds a bound
        // action can reach the other one.
        const jump = new JumpDown(asked);
        jump.destination = w.well;
        input.push(jump);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = jump;
        Assert(input, h);
        Assert(input, makeAgent(asked, jump, w.goat));
        const goal = new Variable(asked);
        input.push(goal);
        const io = new InOrderTo(asked);
        io.action = jump;
        io.goal = goal;
        input.push(io);
        const ask = new AskWhether(asked);
        ask.content = io;
        ask.verdict = answer;
        Assert(input, ask);
        return [goal];
      });
      assert(
        answerText(jumpAsked) ===
          "{constraints=[AskWhether],level=instance,result=not-established}",
        "a correspondence the question never names refutes nothing",
      );
      const throughSaying = assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const s = new Variable(asked);
        input.push(s);
        const d = new Says(asked);
        d.content = s;
        input.push(d);
        const h = new Among(asked);
        h.situation = w.root;
        h.node = d;
        Assert(input, h);
        AssertOccurs(input, d);
        Assert(input, makeAgent(asked, d, w.fox));
        const j = new Variable(asked);
        input.push(j);
        const said = new InOrderTo(asked);
        said.action = j;
        input.push(said);
        const held = new HoldsIn(asked);
        held.context = s;
        held.proposition = said;
        Assert(input, held);
        const ask = new AskWhether(asked);
        ask.content = said;
        ask.verdict = answer;
        Assert(input, ask);
        return [s, j];
      });
      assert(
        answerText(throughSaying) === "{result=no}",
        "the chance rule fires through the bound said action",
      );
    },
  },
  {
    name: "promises: a stated promise is found",
    run() {
      const promised = assembleCase(BuildLionStory, (input, asked, w, answer) => {
        const deed = new Help(asked);
        deed.theme = w.lion;
        input.push(deed);
        const promise = new Promise(asked);
        promise.promiser = w.mouse;
        promise.deed = deed;
        input.push(promise);
        const ask = new AskWhether(asked);
        ask.content = promise;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(
        answerText(promised) === "{result=yes}",
        "the mouse's promise is a promise the world holds",
      );
    },
  },
  {
    name: "presupposition: an unrelated belief does not make a content question yes",
    run() {
      // Story-9 Q4 exactly as translated, over the real fixture with one
      // added belief of the lamb's: the answer must follow the belief's
      // content, never its mere existence.
      const withBelief = (title, holds) => (input, story) => {
        const w = BuildClothingStory(input, story);
        const held = context(new Situation(), title);
        input.push(held);
        holds(input, held, w);
        const belief = new Believes(story);
        belief.believer = w.lamb;
        belief.content = held;
        Assert(input, belief);
        return w;
      };
      const question = Twin9.Questions[3];
      const unrelated = assembleCase(
        withBelief("the grass is green", (input, held) => {
          Assert(input, new Drought(held), held);
        }),
        question.build,
      );
      assert(
        answerText(unrelated).includes("constraints=[AskWhether]") &&
          answerText(unrelated).includes("not-established"),
        "an unrelated belief never carries the asked content",
      );
      const otherOne = assembleCase(
        withBelief("the shepherd is my mother", (input, held, w) => {
          const shepherd = entity(held, "the shepherd");
          input.push(shepherd);
          const same = new SameReferent(held);
          same.left = shepherd;
          same.right = w.flayedSheep;
          Assert(input, same, held);
        }),
        question.build,
      );
      assert(
        answerText(otherOne).includes("not-established"),
        "taking someone else for the mother is not taking the wolf for her",
      );
      const mistaken = assembleCase(
        withBelief("the wolf is my mother", (input, held, w) => {
          const same = new SameReferent(held);
          same.left = w.wolf;
          same.right = w.flayedSheep;
          Assert(input, same, held);
        }),
        question.build,
      );
      assert(
        answerText(mistaken) === "{result=yes}",
        "the stated belief answers yes through the same translation",
      );
    },
  },
  {
    name: "negation: the nurse's listing answers its own moment, not her speech",
    run() {
      // The real fixture: "all the Nurse did" is scoped from the crying
      // on, so her earlier "Be quiet" is untouched while the threatened
      // throwing is still refuted.
      const spoke = assembleCase(BuildNurseStory, (input, asked, w, answer) => {
        const d = new Says(asked);
        input.push(d);
        const did = new Agent(asked);
        did.action = d;
        did.actor = w.nurse;
        input.push(did);
        const ask = new AskWhether(asked);
        ask.content = did;
        ask.verdict = answer;
        Assert(input, ask);
      });
      assert(answerText(spoke) === "{result=yes}", "her warning was spoken");
      const thrown = assembleCase(BuildNurseStory, Twin8.Questions[3].build);
      assert(answerText(thrown) === "{result=no}", "the threat was not carried out");
    },
  },
  {
    name: "time: an unanchored state question reads 'at some time' on both sides",
    run() {
      const ask = (negated, when) => assembleCase(BuildAssStory, (input, asked, w, answer) => {
        const having = new Has(asked);
        having.owner = w.ass;
        having.possession = w.brains;
        input.push(having);
        let content = having;
        if (negated) {
          content = new Not(asked);
          content.proposition = having;
          input.push(content);
        }
        const q = new AskWhether(asked);
        q.content = content;
        if (when) q.when = when(w);
        q.verdict = answer;
        Assert(input, q);
      });
      assert(answerText(ask(false)) === "{result=yes}", "it had brains at first");
      assert(answerText(ask(true)) === "{result=yes}", "and none once taken: no bias");
      assert(answerText(ask(true, () => TheEnd)) === "{result=yes}", "none at the end");
      assert(answerText(ask(true, (w) => w.lionPounce)) === "{result=no}", "brains at the pounce");
    },
  },
  {
    name: "time: PriorTo reads the moment just before the anchor",
    run() {
      const ask = (event) => assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
        const there = new Present(asked);
        there.subject = w.wolf;
        input.push(there);
        const before = new PriorTo(asked);
        before.event = w[event];
        input.push(before);
        const q = new AskWhether(asked);
        q.content = there;
        q.when = before;
        q.verdict = answer;
        Assert(input, q);
      });
      assert(answerText(ask("cry3")) === "{result=yes}", "the wolf had come before the third cry");
      assert(answerText(ask("cry2")) === "{result=no}", "no wolf just before the second");
      // A state that ended before the anchor: gone just before it.
      const brains = assembleCase(BuildAssStory, (input, asked, w, answer) => {
        const having = new Has(asked);
        having.owner = w.ass;
        having.possession = w.brains;
        input.push(having);
        const before = new PriorTo(asked);
        before.event = w.lionBack;
        input.push(before);
        const q = new AskWhether(asked);
        q.content = having;
        q.when = before;
        q.verdict = answer;
        Assert(input, q);
      });
      assert(answerText(brains) === "{result=no}", "taken before the lion came back");
    },
  },
  {
    name: "speech: a saying is judged at the time it is about",
    run() {
      const question = Twin12.Questions[4].build;
      const trapTime = assembleCase(BuildAssStory, question);
      assert(answerText(trapTime) === "{result=no}", "at the trap-time it had brains");
      // The same reply, were it about the moment of speaking: true then.
      const aboutNow = assembleCase((input, story) => {
        const w = BuildAssStory(input, story);
        const anchored = input.find((node) => {
          return node instanceof HoldsWhen && node.situated === w.replyCtx;
        });
        anchored.when = w.foxReply;
        return w;
      }, question);
      assert(answerText(aboutNow) === "{result=yes}", "the time the saying is about decides");
    },
  },
  {
    name: "order: overlapping events share one moment of the line",
    run() {
      // "As this was said" a wolf was passing: the warning is still
      // before everything the passing is before.
      const later = assembleCase(BuildNurseStory, (input, asked, w, answer) => {
        const order = new Before(asked);
        order.earlier = w.beQuiet;
        order.later = answer;
        Assert(input, order);
        const who = new Agent(asked);
        who.action = answer;
        who.actor = w.child;
        Assert(input, who);
      });
      assert(answerText(later).startsWith("Cry("), "the child's crying follows the warning");
    },
  },
  {
    name: "speech: a reason given is not a motive the world holds",
    run() {
      const worldMotive = assembleCase(BuildCockStory, (input, asked, w, answer) => {
        const why = new Motivates(asked);
        why.driver = answer;
        why.action = w.foxExcuse;
        Assert(input, why);
      });
      assert(
        answerText(worldMotive).includes("not-established"),
        "the narrator never confirms the fox's fear",
      );
      const given = assembleCase(BuildCockStory, Twin13.Questions[4].build);
      assert(answerText(given).startsWith("Fears("), "the reason he gave is read from his saying");
    },
  },
  {
    name: "plans: the funding sale tells the purchases apart",
    run() {
      const question = Twin7.Questions[0].build;
      const fowls = assembleCase(BuildMilkmaidStory, question);
      assert(answerText(fowls) === "Entity(some fowls)", "the milk's sale buys the fowls");
      const unfunded = assembleCase(BuildMilkmaidStory, (input, asked, w, answer) => {
        const extra = question(input, asked, w, answer);
        const sale = input.find((node) => node instanceof Sell && node.situated === asked);
        sale.what = w.pail;
        return extra;
      });
      assert(answerText(unfunded).includes("not-established"), "no sale of the pail funds anything");
    },
  },
  {
    name: "ability: an inability of the easy way is not an inability at all",
    run() {
      const ask = (manner) => assembleCase(BuildClothingStory, (input, asked, w, answer) => {
        const deed = new GetAt(asked);
        deed.theme = w.sheep;
        if (manner) deed.manner = manner;
        input.push(deed);
        const unable = new Unable(asked);
        unable.actor = w.wolf;
        unable.deed = deed;
        input.push(unable);
        const could = new Not(asked);
        could.proposition = unable;
        input.push(could);
        const before = new PriorTo(asked);
        before.event = w.foundSkin;
        input.push(before);
        const q = new AskWhether(asked);
        q.content = could;
        q.when = before;
        q.verdict = answer;
        Assert(input, q);
      });
      assert(answerText(ask("easily")) === "{result=no}", "great difficulty: not easily");
      assert(
        answerText(ask(null)).includes("not-established"),
        "nothing says he could not get at them at all",
      );
    },
  },
  {
    name: "means: 'by some means' answers how, never why",
    run() {
      const how = assembleCase(BuildMaskStory, Twin5.Questions[3].build);
      assert(answerText(how) === "{result=unknown}", "an unstated means is Unknown");
      const why = assembleCase(BuildMaskStory, (input, asked, w, answer) => {
        const cause = new Causes(asked);
        cause.cause = answer;
        cause.effect = w.enterStore;
        Assert(input, cause);
      });
      assert(answerText(why).includes("not-established"), "no cause is held for the entering");
    },
  },
  {
    name: "habits: the next visit is found through its instance of the practice",
    run() {
      const question = Twin6.Questions[3].build;
      const found = assembleCase(BuildMiserStory, question);
      assert(answerText(found) === "Entity(the empty hole)", "the visit is the practice's instance");
      const detached = assembleCase((input, story) => {
        const w = BuildMiserStory(input, story);
        const index = input.findIndex((node) => {
          return node instanceof Assertion && node.proposition instanceof Instance;
        });
        input.splice(index, 1);
        return w;
      }, question);
      assert(
        answerText(detached).includes("not-established"),
        "without the instance no coming is the habit's next one",
      );
    },
  },
  {
    name: "ability: being able starts with its means, not with its exercise",
    run() {
      const could = (anchor) => assembleCase(BuildGoatStory, (input, asked, w, answer) => {
        const deed = new GetOut(asked);
        deed.from = w.well;
        input.push(deed);
        const unable = new Unable(asked);
        unable.actor = w.fox;
        unable.deed = deed;
        input.push(unable);
        const can = new Not(asked);
        can.proposition = unable;
        input.push(can);
        const when = anchor(asked, w);
        input.push(when);
        const q = new AskWhether(asked);
        q.content = can;
        q.when = when;
        q.verdict = answer;
        Assert(input, q);
      });
      const before = (asked, w) => Object.assign(new PriorTo(asked), { event: w.goatJump });
      const after = (asked, w) => Object.assign(new After(asked), { event: w.goatJump });
      assert(answerText(could(before)) === "{result=no}", "not before the goat came down");
      assert(answerText(could(after)) === "{result=yes}", "able once she was down, before the escape");
    },
  },
  {
    name: "ordinals: an ordinal nested in a content-matched effect binds",
    run() {
      // "Why did nobody come to help the boy the n-th time?": the window
      // of the asked nobody-coming is part of the Causes' effect. Only
      // the third cry opens the world's nobody-coming; at the first and
      // second the villagers came, and there is no fourth.
      const why = (index) =>
        assembleCase(BuildShepherdStory, (input, asked, w, answer) => {
          const d = new ComeToHelp(asked);
          d.theme = w.boy;
          input.push(d);
          const nth = new Nth(asked);
          nth.pattern = cryShape(input, asked);
          nth.index = index;
          input.push(nth);
          const none = new NoEvent(asked);
          none.pattern = d;
          none.from = nth;
          none.until = TheEnd;
          input.push(none);
          const cause = new Causes(asked);
          cause.cause = answer;
          cause.effect = none;
          Assert(input, cause);
        });
      assert(
        answerText(why(3)).startsWith("Believes(believer=Entity(the villagers)"),
        "the third time is the villagers' believing",
      );
      for (const index of [1, 2, 4]) {
        assert(
          answerText(why(index)) ===
            "{constraints=[Causes],level=instance,result=not-established}",
          `cry ${index} opens no nobody-coming`,
        );
      }
    },
  },
  {
    name: "ordinals: the n-th is defined only on a total order",
    run() {
      // One cry only: "the first" is that cry — never "the one before the
      // second", which does not exist.
      const cries = (count, overlap) => (input, story) => {
        const boy = entity(story, "the boy");
        input.push(boy);
        const made = [];
        for (let index = 0; index < count; index += 1) {
          const cry = new CryOut(story);
          cry.call = "Wolf";
          input.push(cry);
          AssertOccurs(input, cry);
          Assert(input, makeAgent(story, cry, boy));
          made.push(cry);
        }
        if (overlap) {
          const both = new Overlaps(story);
          both.first = made[0];
          both.second = made[1];
          Assert(input, both);
        }
        return { root: story, boy, cries: made };
      };
      const firstCry = (input, asked, w, answer) => {
        const shape = new CryOut(asked);
        shape.call = "Wolf";
        input.push(shape);
        const first = new Nth(asked);
        first.pattern = shape;
        first.index = 1;
        input.push(first);
        const who = new Agent(asked);
        who.action = first;
        who.actor = answer;
        Assert(input, who);
      };
      assert(
        answerText(assembleCase(cries(1, false), firstCry)) === "Entity(the boy)",
        "a single cry is the first",
      );
      assert(
        answerText(assembleCase(cries(2, true), firstCry)).includes("not-established"),
        "two simultaneous cries have no first",
      );
    },
  },
  {
    name: "existence: 'was there a wolf' quantifies over wolves, not one wolf",
    run() {
      const cryAt = (input, asked, index) => {
        const cry = new CryOut(asked);
        cry.call = "Wolf, Wolf";
        input.push(cry);
        const nth = new Nth(asked);
        nth.pattern = cry;
        nth.index = index;
        input.push(nth);
        return nth;
      };
      const ask = (world, subject, negated = false) =>
        assembleCase(world, (input, asked, w, answer) => {
          const there = new Present(asked);
          there.subject = subject(input, asked, w);
          input.push(there);
          let content = there;
          if (negated) {
            content = new Not(asked);
            content.proposition = there;
            input.push(content);
          }
          const q = new AskWhether(asked);
          q.content = content;
          q.when = cryAt(input, asked, 2);
          q.verdict = answer;
          Assert(input, q);
        });
      const ofKind = (kind) => (input, asked, w) => {
        const x = new Entity(asked);
        x.kind = kind(asked, input, w);
        input.push(x);
        return x;
      };
      const wolves = ofKind((asked, input, w) => w.wolfKind);
      assert(answerText(ask(BuildShepherdStory, wolves)) === "{result=no}", "no wolf at the second cry");
      assert(answerText(ask(BuildShepherdStory, wolves, true)) === "{result=yes}", "there was no wolf");
      assert(
        answerText(ask(BuildShepherdStory, (input, asked, w) => w.wolf)) === "{result=no}",
        "so not the wolf either",
      );
      const sheep = ofKind((asked, input) => {
        const kind = new Kind(asked);
        input.push(kind);
        return kind;
      });
      assert(
        answerText(ask(BuildShepherdStory, sheep)).includes("not-established"),
        "no wolf says nothing of other sorts",
      );
      const anotherWolf = (input, story) => {
        const w = BuildShepherdStory(input, story);
        const other = entity(story, "another wolf");
        other.kind = w.wolfKind;
        input.push(other);
        const there = new Present(story);
        there.subject = other;
        input.push(there);
        const atFirst = new Initially(story);
        atFirst.state = there;
        Assert(input, atFirst);
        return w;
      };
      assert(
        answerText(ask(anotherWolf, wolves)) === "{result=conflict}",
        "a wolf present all along contradicts the denial",
      );
    },
  },
  {
    name: "surface: a name never decides a match",
    run() {
      const twoDogs = (input, story) => {
        const dog = entity(story, "the dog");
        const other = entity(story, "another dog");
        input.push(dog, other);
        for (const who of [dog, other]) {
          const seeing = new See(story);
          input.push(seeing);
          AssertOccurs(input, seeing);
          Assert(input, makeAgent(story, seeing, who));
        }
        return { root: story, dog, other };
      };
      const named = assembleCase(twoDogs, (input, asked, w, answer) => {
        const seer = new Entity(asked);
        seer.name = "the dog";
        input.push(seer);
        const known = new Among(asked);
        known.situation = w.root;
        known.node = seer;
        Assert(input, known);
        const seeing = new See(asked);
        input.push(seeing);
        const k = new Among(asked);
        k.situation = w.root;
        k.node = seeing;
        Assert(input, k);
        Assert(input, makeAgent(asked, seeing, seer));
        const who = new Agent(asked);
        who.action = seeing;
        who.actor = answer;
        Assert(input, who);
      });
      assert(
        answerText(named).includes("ambiguous"),
        "the description's name does not pick one dog out",
      );
    },
  },
];

function makeNext(situation, earlier, later) {
  const relation = new Next(situation);
  relation.earlier = earlier;
  relation.later = later;
  return relation;
}

async function main() {
  let passed = 0;
  for (const test of Tests) {
    try {
      test.run();
      passed += 1;
      console.log(`PASS  ${test.name}`);
    } catch (caught) {
      console.log(`FAIL  ${test.name}`);
      console.log(caught.stack ?? String(caught));
    }
  }
  console.log(`Foundation/domain regression tests: ${passed}/${Tests.length} passed`);
  process.exit(passed === Tests.length ? 0 : 1);
}

const invokedDirectly =
  process.argv[1] !== undefined &&
  import.meta.url === pathToFileURL(process.argv[1]).href;
if (invokedDirectly) await main();
