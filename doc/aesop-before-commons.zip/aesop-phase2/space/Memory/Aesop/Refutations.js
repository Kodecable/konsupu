// Refutation machinery for yes-no evaluation: how a held negation
// covers a question — explicit Not-matching, endings, negated existence
// and its window, exhaustive listings and their scope, and the
// class-level incompatibilities (an empty container holds nothing
// inside it; a chance happening is done for no purpose, under any name
// the world knows it by). Nothing here decides the verdict; Verdicts.js
// does. An ended state is negated from its ending on, and the ending
// counts whether the story stated it or class knowledge derived it (a
// new LocatedAt for the same entity). Every match starts from the
// scope-filtered join bindings, so a bound Variable or description can
// never be re-bound onto another context's individual.
import { Not, NoEvent, NoneSuch, OnlyDid } from "./Negation.js";
import { Empty } from "./Possession.js";
import { TheEnd } from "./Time.js";
import { ByChance } from "./Chance.js";
import { SameReferent } from "./Correspondence.js";
import { Agent, InOrderTo, Occurs } from "./Relations.js";
import { LocatedAt } from "./Conditions.js";
import { matchValue, fieldValue } from "./Match.js";
import { anchorWindow, holdsAt } from "./Anchors.js";
import {
  endNegatesAt,
  windowCovers,
  covers,
  pointCovered,
  coversState,
} from "./Covering.js";

function occurrenceNegated(timeline, content, when, context, pins, base) {
  const tuples = [];
  const window = anchorWindow(timeline, when, context);
  if (window?.kind === "none") return tuples;
  const description = content.event;
  const actors = pins.get(description) ?? [];
  for (const proposition of timeline.carriedNodes()) {
    if (proposition instanceof NoEvent) {
      if (!covers(proposition.pattern, description, context)) continue;
      if (proposition.actor != null && !actors.includes(proposition.actor)) {
        continue;
      }
      const from = proposition.from ?? null;
      const until = proposition.until ?? TheEnd;
      if (windowCovers(timeline, from, until, window)) {
        tuples.push(new Map(base));
      }
    } else if (proposition instanceof OnlyDid) {
      if (!actors.includes(proposition.actor)) continue;
      if (proposition.theme != null) {
        const theme = fieldValue(description, "theme");
        if (
          theme === undefined ||
          !matchValue(proposition.theme, theme, new Map(base), context)
        ) {
          continue;
        }
      }
      const listed = proposition.deeds.some((deed) => {
        return matchValue(description, deed, new Map(base), context);
      });
      if (listed) continue;
      const from = proposition.from ?? null;
      const until = proposition.until ?? TheEnd;
      if (windowCovers(timeline, from, until, window)) {
        tuples.push(new Map(base));
      }
    }
  }
  return tuples;
}

// Held propositions that directly negate the content: an explicit Not,
// a negated existence whose window holds the moment, an empty container
// for a location inside it, and — explicit or
// class-derived — the ending of a matching state.
function refutingProps(timeline, content, when, context, base) {
  const tuples = [];
  for (const proposition of timeline.carriedNodes()) {
    if (proposition instanceof Not) {
      const trial = new Map(base);
      if (
        matchValue(content, proposition.proposition, trial, context) &&
        holdsAt(timeline, proposition, when, context)
      ) {
        tuples.push(trial);
      }
    } else if (
      proposition instanceof NoneSuch &&
      coversState(proposition, content, context) &&
      pointCovered(timeline, proposition.from, proposition.until ?? TheEnd, when, context)
    ) {
      tuples.push(new Map(base));
    } else if (
      proposition instanceof Empty &&
      content instanceof LocatedAt &&
      matchValue(content.place, proposition.container, new Map(base), context) &&
      holdsAt(timeline, proposition, when, context)
    ) {
      tuples.push(new Map(base));
    }
  }
  for (const candidate of timeline.stateCandidates(content, context)) {
    const trial = new Map(base);
    if (!matchValue(content, candidate, trial, context)) continue;
    const end = timeline.endOf(candidate);
    if (end !== null && endNegatesAt(timeline, end, when)) tuples.push(trial);
  }
  return tuples;
}

export function negativeOf(timeline, content, when, context, pins, base) {
  if (content instanceof Occurs) {
    return occurrenceNegated(timeline, content, when, context, pins, base);
  }
  // "Did the actor do it": an Agent content is an occurrence question
  // whose actor is named inside it.
  if (content instanceof Agent) {
    const wrapped = new Occurs(content.situated);
    wrapped.event = content.action;
    const local = new Map(pins);
    if (!local.has(content.action)) local.set(content.action, []);
    local.get(content.action).push(content.actor);
    return occurrenceNegated(timeline, wrapped, when, context, local, base);
  }
  const tuples = refutingProps(timeline, content, when, context, base);
  // A chance happening is not done for a purpose, under any name the
  // world knows it by — through an explicit correspondence only.
  if (content instanceof InOrderTo) {
    const everything = timeline.carriedNodes();
    for (const chance of everything) {
      if (!(chance instanceof ByChance)) continue;
      for (const pair of everything) {
        if (!(pair instanceof SameReferent)) continue;
        const action = content.action;
        const named = (left, right) => {
          const trial = new Map(base);
          return matchValue(action, left, trial, context) && chance.event === right;
        };
        if (named(pair.left, pair.right) || named(pair.right, pair.left)) {
          tuples.push(new Map(base));
        }
      }
    }
  }
  return tuples;
}
