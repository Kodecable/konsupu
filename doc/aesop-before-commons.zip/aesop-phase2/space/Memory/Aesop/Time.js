// Time vocabulary. Changeable states hold on intervals bounded by events:
// Initially marks a state holding from the story's beginning, ResultsIn
// (in Relations.js) starts a state at an event, Ends stops it there; the
// explicit inertia rule (the only default reasoning this domain allows)
// keeps a started state holding until something ends it. Questions anchor
// evaluation with HoldsWhen; PriorTo / After / While / TheEnd / Nth name
// the anchor. Input order is never time; order comes only from the Next
// chain of the context being read.
import {
  Brand,
  Final,
  Proposition,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// A state that holds from the story's beginning: field state.
export class Initially extends Proposition {
  static BRAND = Brand("aesop:Initially:v1");
  constructor(situated) {
    Final(Initially, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// An event whose happening ends a state: fields event, state. After the
// event the state is negated, not merely unstated.
export class Ends extends Proposition {
  static BRAND = Brand("aesop:Ends:v1");
  constructor(situated) {
    Final(Ends, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A question's time anchor: `state` holds `when`. The state is an asked
// pattern matched by content; `when` is an event, a marker below, or TheEnd.
export class HoldsWhen extends Proposition {
  static BRAND = Brand("aesop:HoldsWhen:v1");
  constructor(situated) {
    Final(HoldsWhen, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The anchor "before event": field event.
export class PriorTo extends SituatedNode {
  static BRAND = Brand("aesop:PriorTo:v1");
  constructor(situated) {
    Final(PriorTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The anchor "after event": field event.
export class After extends SituatedNode {
  static BRAND = Brand("aesop:After:v1");
  constructor(situated) {
    Final(After, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The anchor "during a state": field state (an asked pattern).
export class While extends SituatedNode {
  static BRAND = Brand("aesop:While:v1");
  constructor(situated) {
    Final(While, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The n-th occurred event matching a description, counted along the
// context's own timeline: fields pattern (an event shape, never a
// referent), index.
export class Nth extends SituatedNode {
  static BRAND = Brand("aesop:Nth:v1");
  constructor(situated) {
    Final(Nth, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// How long a state held: fields state, duration. A vague textual duration
// ("for some time") is a stated value here, not an Unknown.
export class Lasted extends Proposition {
  static BRAND = Brand("aesop:Lasted:v1");
  constructor(situated) {
    Final(Lasted, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The anchor "at the end of the story": after every event. A plain frozen
// record compared by content, so it needs no identity or Situation.
export const TheEnd = Object.freeze({ time: "the-end" });

// The moment "at the beginning of the story": before every event. Only
// the solver uses it, to read an unanchored state question moment by
// moment; questions never name it.
export const TheBeginning = Object.freeze({ time: "the-beginning" });
