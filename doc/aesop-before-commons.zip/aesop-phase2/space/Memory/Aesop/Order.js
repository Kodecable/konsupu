// The event order of one context: the strict order its Next chain
// entails, transitively. Overlapping events ("as he crossed, he saw")
// share one moment of the line, so whatever is ordered against one of
// them is ordered against the other, and neither is before the other.
// Input order is never consulted.
import { Next, Overlaps } from "./Relations.js";

export class EventOrder {
  constructor(held) {
    const parent = new Map();
    this.moment = (event) => {
      while (parent.has(event) && parent.get(event) !== event) {
        event = parent.get(event);
      }
      return event;
    };
    const pairs = [];
    this.events = new Set();
    for (const proposition of held) {
      if (proposition instanceof Next) {
        pairs.push([proposition.earlier, proposition.later]);
        this.events.add(proposition.earlier).add(proposition.later);
      } else if (proposition instanceof Overlaps) {
        const left = this.moment(proposition.first);
        const right = this.moment(proposition.second);
        if (left !== right) parent.set(right, left);
        this.events.add(proposition.first).add(proposition.second);
      }
    }
    const direct = new Map();
    for (const [earlier, later] of pairs) {
      const from = this.moment(earlier);
      if (!direct.has(from)) direct.set(from, []);
      direct.get(from).push(this.moment(later));
    }
    this.reach = new Map();
    for (const start of direct.keys()) {
      const seen = new Set();
      const agenda = [...direct.get(start)];
      while (agenda.length) {
        const item = agenda.pop();
        if (seen.has(item)) continue;
        seen.add(item);
        agenda.push(...(direct.get(item) ?? []));
      }
      this.reach.set(start, seen);
    }
  }

  before(earlier, later) {
    const from = this.moment(earlier);
    const to = this.moment(later);
    return from !== to && Boolean(this.reach.get(from)?.has(to));
  }

  atOrBefore(earlier, later) {
    return (
      this.moment(earlier) === this.moment(later) ||
      this.before(earlier, later)
    );
  }
}
