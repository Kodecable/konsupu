// Manner-of-happening facts about single events. Kept apart from
// motivation vocabulary: ByChance says how an event came about, and the
// class-level incompatibility rule (an unplanned happening is not done
// for a purpose) reads it, so a story never needs a per-story rule.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

// The event happened by chance, not by design: field event.
export class ByChance extends Proposition {
  static BRAND = Brand("aesop:ByChance:v1");
  constructor(situated) {
    Final(ByChance, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// The way an event was brought about — what "how did …" asks: fields
// event, means. "By some means" holds it with the means unwritten, an
// Unknown way; it is never a cause, which "why" asks for.
export class Means extends Proposition {
  static BRAND = Brand("aesop:Means:v1");
  constructor(situated) {
    Final(Means, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
