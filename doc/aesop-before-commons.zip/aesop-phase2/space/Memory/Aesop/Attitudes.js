// Attitude propositions. Every attitude that takes propositional content
// takes it as a context Situation — one canonical form per attitude, so a
// belief is never sometimes a proposition and sometimes a context; the
// content's internal structure lives in that context, which mentions
// world individuals directly and may hold objects of its own. Goal and
// Promise are not attitudes of this kind: they relate an actor to one
// single un-happened deed, and no story needs deed-directed wanting with
// internal propositional structure — where a plan has content, the plan
// is a Plans context and the deed it wants is one node inside it.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// What moved an actor to act: fields driver, action. The driver may be a
// state, an attitude proposition, or any cognition the holder names.
export class Motivates extends Proposition {
  static BRAND = Brand("aesop:Motivates:v1");
  constructor(situated) {
    Final(Motivates, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A commitment to a future deed: fields promiser, deed.
export class Promise extends Proposition {
  static BRAND = Brand("aesop:Promise:v1");
  constructor(situated) {
    Final(Promise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Holding a body of cognition true: fields believer, content (Situation).
// The believing itself is a changeable state: it starts and ends on
// events like any other, so a corrected belief is two beliefs with
// different intervals.
export class Believes extends Proposition {
  static BRAND = Brand("aesop:Believes:v1");
  constructor(situated) {
    Final(Believes, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// What a proposition is about — its topic: fields proposition, topic.
export class About extends Proposition {
  static BRAND = Brand("aesop:About:v1");
  constructor(situated) {
    Final(About, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Dreading that a content holds: fields fearer, content (Situation).
export class Fears extends Proposition {
  static BRAND = Brand("aesop:Fears:v1");
  constructor(situated) {
    Final(Fears, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Intentions worked out in thought: fields planner, content (Situation).
// The content's events exist only there; none of them occurs.
export class Plans extends Proposition {
  static BRAND = Brand("aesop:Plans:v1");
  constructor(situated) {
    Final(Plans, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A favorable judgment of something: fields approver, of.
export class Approves extends Proposition {
  static BRAND = Brand("aesop:Approves:v1");
  constructor(situated) {
    Final(Approves, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Succeeding in making someone believe what the world does not hold, by
// any means — words or disguise; there need be no Says: fields deceiver,
// victim. A changeable state: it starts at the deceiving means and lasts
// as long as it succeeds. Held only where the text states or lexically
// implies it (deceive, trick, fool); a false belief alone never implies
// it.
export class Deceives extends Proposition {
  static BRAND = Brand("aesop:Deceives:v1");
  constructor(situated) {
    Final(Deceives, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
