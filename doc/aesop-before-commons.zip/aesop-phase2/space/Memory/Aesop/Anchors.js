// Anchor evaluation: the time a question asks about — an event, TheEnd,
// a PriorTo / After / While / Nth marker — read over one context's
// timeline. PriorTo reads the moment just before the anchor and After
// the moment just after it, so a state that changes inside the window
// is never supported on both sides at once. Occurrence windows come
// from the same markers: an event opens "from" it, PriorTo scopes
// "before", the n-th opens the episode the (n+)-th closes, and While
// restricts to the while-state's intervals.
import { Nth, PriorTo, After, While, TheEnd, TheBeginning } from "./Time.js";
import { matchValue } from "./Match.js";

// Whether the state holds at `when`: an event, TheEnd, a marker, an Nth,
// or null (held at some time — true for every started state).
export function holdsAt(timeline, node, when, context) {
  if (when === null || when === undefined) return true;
  if (when === TheEnd) return timeline.endOf(node) === null;
  if (when === TheBeginning) return timeline.startOf(node) === null;
  if (when instanceof Nth) {
    const event = resolveNth(timeline, when, context);
    return event !== null && timeline.holdsPoint(node, event);
  }
  const start = timeline.startOf(node);
  if (start === undefined) return false;
  if (when instanceof PriorTo) {
    // Just before the anchor: started before it, not ended before it.
    const end = timeline.endOf(node);
    return (
      (start === null || timeline.before(start, when.event)) &&
      (end === null || timeline.atOrBefore(when.event, end))
    );
  }
  if (when instanceof After) {
    // Just after the anchor: the anchor lies inside the state's
    // interval. A state that changes later never supports both sides
    // of one question at once, and After(E) with PriorTo(F) names the
    // stretch between E and F.
    const end = timeline.endOf(node);
    return (
      (start === null || timeline.atOrBefore(start, when.event)) &&
      (end === null || timeline.before(when.event, end))
    );
  }
  if (when instanceof While) {
    return intervalOverlaps(timeline, node, when.state, context);
  }
  return timeline.holdsPoint(node, when);
}

// Whether this state's interval overlaps any candidate matching the
// While pattern's interval.
export function intervalOverlaps(timeline, node, pattern, context) {
  for (const other of timeline.stateCandidates(pattern, context)) {
    const left = timeline.startOf(node);
    const right = timeline.endOf(node);
    const otherLeft = timeline.startOf(other);
    const otherRight = timeline.endOf(other);
    const beforeStart =
      left === null ||
      otherRight === null ||
      timeline.before(left, otherRight);
    const afterStart =
      otherLeft === null || right === null || timeline.before(otherLeft, right);
    if (beforeStart && afterStart) return true;
  }
  return false;
}

// The window a question's occurrence-content asks about, derived from its
// anchor: an event anchor scopes "from" that event (the incident it names
// opens the window), PriorTo scopes "before", the n-th opens the episode
// the (n+1)-th matching event closes, While scopes to the state's
// intervals, and TheEnd or no anchor asks about the whole timeline.
export function anchorWindow(timeline, when, context) {
  if (when === null || when === undefined) return null;
  if (when === TheEnd) return null;
  if (when === TheBeginning) return { kind: "none" };
  if (when instanceof Nth) {
    const events = nthEvents(timeline, when, context) ?? [];
    const event = events[when.index - 1] ?? null;
    if (event === null) return { kind: "none" };
    return { kind: "until", event, until: events[when.index] ?? null };
  }
  if (when instanceof PriorTo) return { kind: "before", event: when.event };
  if (when instanceof After) return { kind: "from", event: when.event };
  if (when instanceof While) {
    const intervals = [];
    for (const candidate of timeline.stateCandidates(when.state, context)) {
      intervals.push({
        start: timeline.startOf(candidate),
        end: timeline.endOf(candidate),
      });
    }
    return { kind: "during", intervals };
  }
  return { kind: "from", event: when };
}

// The occurred events matching an ordinal's pattern, in chain order — or
// null when they are not totally ordered (two of them overlap or the
// chain leaves them unordered): "the n-th" is then undefined, never an
// arbitrary pick that would make Input order count as time.
function nthEvents(timeline, nth, context) {
  const matches = [];
  for (const event of timeline.occurred) {
    if (matchValue(nth.pattern, event, new Map(), context)) matches.push(event);
  }
  for (let i = 0; i < matches.length; i += 1) {
    for (let j = i + 1; j < matches.length; j += 1) {
      const [left, right] = [matches[i], matches[j]];
      if (!timeline.before(left, right) && !timeline.before(right, left)) {
        return null;
      }
    }
  }
  return matches.sort((left, right) => (timeline.before(left, right) ? -1 : 1));
}

// The n-th occurred event matching the pattern along this timeline ("the
// first" is the 1st: no matching event before it), or null when there
// are too few matches or they are not totally ordered.
export function resolveNth(timeline, nth, context) {
  return nthEvents(timeline, nth, context)?.[nth.index - 1] ?? null;
}

// Whether one occurred event lies inside a window of any kind.
export function inWindow(timeline, event, window) {
  if (window === null || window === undefined) return true;
  if (window.kind === "none") return false;
  if (window.kind === "from") return timeline.atOrBefore(window.event, event);
  if (window.kind === "before") return timeline.before(event, window.event);
  if (window.kind === "until") {
    if (!timeline.atOrBefore(window.event, event)) return false;
    return window.until === null || timeline.before(event, window.until);
  }
  return window.intervals.some((interval) => {
    const fromOk =
      interval.start === null || timeline.atOrBefore(interval.start, event);
    const toOk =
      interval.end === null || timeline.before(event, interval.end);
    return fromOk && toOk;
  });
}

// The occurred events matching a description, restricted to a window:
// null window = all, "from" = at-or-after an event, "before" = strictly
// before an event, "until" = the n-th's episode, "during" = inside the
// while-state's intervals.
export function eventsMatching(timeline, pattern, context, window) {
  const found = [];
  for (const event of timeline.occurred) {
    if (!matchValue(pattern, event, new Map(), context)) continue;
    if (!inWindow(timeline, event, window)) continue;
    found.push(event);
  }
  return found;
}
