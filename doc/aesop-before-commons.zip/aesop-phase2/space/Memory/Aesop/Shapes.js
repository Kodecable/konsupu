// Shape machinery: which asked Nodes act as patterns rather than
// referents. WithShapes marks the pattern fields of pattern-bearing
// constraints (ability's deed, habit's deed, negated existence's
// pattern, ordinals' pattern), walking the whole constraint because the
// pattern-bearing node may be nested anywhere inside it. QuestionShapes
// marks every asked Node inside a content question (HoldsIn, AskWhether,
// HoldsWhen): reading another context matches by shape, never by
// identity with a Node of this question's own making, while an unmarked
// asked Node in a world-facing constraint stays a constant (the r4
// rule). Variables keep binding as Variables.
import { Node, Variable } from "../../Interface/Nodes.js";
import { Unable } from "./Conditions.js";
import { Habitual } from "./Habits.js";
import { NoEvent } from "./Negation.js";
import { Nth } from "./Time.js";

const PATTERN_FIELDS = new Map([
  [Unable, ["deed"]],
  [Habitual, ["deed"]],
  [NoEvent, ["pattern"]],
  [Nth, ["pattern"]],
]);

function collectNodes(value, seen, visit) {
  if (value === null || typeof value !== "object" || seen.has(value)) return;
  seen.add(value);
  if (value instanceof Node) {
    visit(value);
    for (const [key, item] of Object.entries(value)) {
      if (key !== "situated") collectNodes(item, seen, visit);
    }
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectNodes(item, seen, visit);
    return;
  }
  for (const item of Object.values(value)) collectNodes(item, seen, visit);
}

// An inability's deed is an exact shape: being unable to do a narrowly
// described deed ("easily") never answers being unable to do it at all.
function markExact(context, node, exact) {
  if (node instanceof Unable && node.situated === context.asked && node.deed) {
    exact.add(node.deed);
  }
}

function extended(context, shapes, exact, changed) {
  if (!changed && exact.size === (context.exact?.size ?? 0)) return context;
  return { ...context, shapes, exact };
}

export function withShapes(context, constraint) {
  const shapes = new Set(context.shapes);
  const exact = new Set(context.exact ?? []);
  let changed = false;
  const seen = new Set();
  collectNodes(constraint, seen, (node) => {
    markExact(context, node, exact);
    const fields = PATTERN_FIELDS.get(node.constructor);
    if (!fields || node.situated !== context.asked) return;
    for (const field of fields) {
      const mark = (value) => {
        if (Array.isArray(value)) {
          for (const item of value) mark(item);
        } else if (value && !shapes.has(value)) {
          shapes.add(value);
          changed = true;
        }
      };
      mark(node[field]);
    }
  });
  return extended(context, shapes, exact, changed);
}

export function withQuestionShapes(context, ...patterns) {
  const shapes = new Set(context.shapes);
  const exact = new Set(context.exact ?? []);
  let changed = false;
  const seen = new Set();
  for (const pattern of patterns) {
    collectNodes(pattern, seen, (node) => {
      if (node instanceof Variable) return;
      markExact(context, node, exact);
      if (node.situated === context.asked && !shapes.has(node)) {
        shapes.add(node);
        changed = true;
      }
    });
  }
  return extended(context, shapes, exact, changed);
}
