// Domain-semantic support. The asking Situation (asked) holds propositions
// as constraints; every one of them must be supported by what the Situation
// chain above holds — the story. The structure only supplies adjacency and
// fields; the meaning of each class is decided here.
//
// - Among{situation, node}: the described node corresponds to one of that
//   Situation's talked-about objects (its members plus what its held
//   cognition mentions). It is the only thing that makes an asked Node a
//   description; Node identity never places one, and being among them
//   never means the event happened. The named Situation may be an
//   ancestor of the asking one or any other context, never the asking
//   one itself or a descendant of it.
// - HoldsIn{context, proposition}: the asked pattern matches by content
//   against what that context itself holds — never what the world holds.
// - HoldsWhen{state, when}: a held state matching the pattern at the
//   anchor, over the story chain's timeline.
// - Conditions (every Condition subclass): supported by propositions of
//   the class the story asserts directly or anchors (Initially, an
//   occurred event's ResultsIn), matched with interval knowledge at
//   disposal in the timeline files.
// - Before: never enumerated by the story; it is what the story's asserted
//   Next chain entails, overlapping events sharing a moment (Order.js).
// - ResultsIn: supported only when the supporting event occurred.
// - Every other proposition: supported by a proposition of its class (or a
//   subclass) the story asserts, matched field by field.
// - AskWhether is not supported here at all: the QuerySolver judges it
//   after joining the other constraints, so its context and content
//   Variables are already bound.
import { Among } from "./Correspondence.js";
import { Condition, Unable } from "./Conditions.js";
import { Habitual } from "./Habits.js";
import { NoEvent } from "./Negation.js";
import { HoldsIn, AskWhether } from "./Asking.js";
import { HoldsWhen } from "./Time.js";
import { matchValue } from "./Match.js";
import { Node } from "../../Interface/Nodes.js";
import { Before, ResultsIn } from "./Relations.js";
import { Timeline } from "./Temporal.js";
import { holdsAt } from "./Anchors.js";
import { resolveNthAnchors } from "./Ordinals.js";
import { withShapes, withQuestionShapes } from "./Shapes.js";
import { amongSupport, holdsInSupport } from "./Reading.js";
import {
  heldAbove,
  tuplesFrom,
  classPool,
  occurredSet,
  conditionPool,
} from "./Support.js";

// The level a constraint fails at when it has no support at all.
export function SupportLevel(constraint) {
  return constraint instanceof Among ? "correspondence" : "instance";
}

// The Situations an Among may never point at: the asking one and its
// descendants. Ancestors and other contexts are all legal targets.
function forbiddenTargets(view) {
  const asked = view.situated;
  const forbidden = new Set([asked]);
  const walk = (situation) => {
    for (const child of view.Children(situation)) {
      forbidden.add(child);
      walk(child);
    }
  };
  walk(asked);
  return forbidden;
}

export function Support(view, constraint, context) {
  const asked = context.asked;
  if (constraint instanceof Among) {
    return amongSupport(view, constraint, context, forbiddenTargets(view));
  }
  if (constraint instanceof HoldsIn) {
    return holdsInSupport(view, constraint, context);
  }
  if (constraint instanceof AskWhether) {
    // Judged after the join in the QuerySolver; never unsupported here.
    return [new Map()];
  }
  if (constraint instanceof HoldsWhen) {
    const held = heldAbove(view, asked);
    const timeline = new Timeline(held);
    const shaped = withQuestionShapes(context, constraint.state);
    const tuples = [];
    for (const candidate of timeline.stateCandidates(constraint.state, shaped)) {
      const bindings = new Map();
      if (
        matchValue(constraint.state, candidate, bindings, shaped) &&
        holdsAt(timeline, candidate, constraint.when, shaped)
      ) {
        tuples.push(bindings);
      }
    }
    return tuples;
  }
  const shapeContext = withShapes(context, constraint);
  const held = heldAbove(view, asked);
  const resolved = resolveNthAnchors(constraint, held, shapeContext);
  if (resolved === null) return [];
  if (resolved !== constraint) {
    return Support(view, resolved, context);
  }
  if (constraint instanceof Before) {
    const order = new Timeline(held).order;
    const tuples = [];
    for (const earlier of order.events) {
      for (const later of order.events) {
        if (!order.before(earlier, later)) continue;
        const bindings = new Map();
        if (
          matchValue(constraint.earlier, earlier, bindings, shapeContext) &&
          matchValue(constraint.later, later, bindings, shapeContext)
        ) {
          tuples.push(bindings);
        }
      }
    }
    return tuples;
  }
  if (constraint instanceof Condition) {
    return tuplesFrom(constraint, conditionPool(constraint, held), shapeContext);
  }
  if (constraint instanceof ResultsIn) {
    const occurred = occurredSet(held);
    const pool = classPool(constraint, held).filter((proposition) => {
      return occurred.has(proposition.event);
    });
    return tuplesFrom(constraint, pool, shapeContext);
  }
  // Every other held proposition class is supported by direct assertions
  // and by contents an occurred event's ResultsIn carries.
  return tuplesFrom(constraint, conditionPool(constraint, held), shapeContext);
}
