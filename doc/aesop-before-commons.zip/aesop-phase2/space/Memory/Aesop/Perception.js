// Perception vocabulary. Perceiving is an action of the perceiver; what
// is perceived is a theme, and a perceived content (an absence, a
// non-return) is a proposition as theme. Perceiving something does not
// make it so, and a speech content describing a perception is held only
// in that speech context.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";
import { Condition } from "./Conditions.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Seeing something, somewhere: fields theme, place.
export class See extends Action {
  static BRAND = Brand("aesop:See:v1");
  constructor(situated) {
    Final(See, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Becoming aware of something, including an absence or a negated
// happening: field theme.
export class Notice extends Action {
  static BRAND = Brand("aesop:Notice:v1");
  constructor(situated) {
    Final(Notice, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Taking in an utterance or a piece of news: field theme.
export class Hear extends Action {
  static BRAND = Brand("aesop:Hear:v1");
  constructor(situated) {
    Final(Hear, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Having taken in some news: fields hearer, news. A state, so its Not is
// the worry the fox voiced about the dog.
export class HeardOf extends Condition {
  static BRAND = Brand("aesop:HeardOf:v1");
  constructor(situated) {
    Final(HeardOf, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Examining again more closely: field theme.
export class LookClosely extends Action {
  static BRAND = Brand("aesop:LookClosely:v1");
  constructor(situated) {
    Final(LookClosely, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
