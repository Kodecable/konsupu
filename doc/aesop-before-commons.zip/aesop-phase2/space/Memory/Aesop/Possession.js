// Possession, absence, and adornment — states of having, belonging,
// missing, emptiness, and wearing, plus the doings that move possession.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action, Get } from "./Objects.js";
import { Condition } from "./Conditions.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Holding something as a part or possession: fields owner, possession.
// Its Not, in a speech context, is the fox's "you have not got any
// brains".
export class Has extends Condition {
  static BRAND = Brand("aesop:Has:v1");
  constructor(situated) {
    Final(Has, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Something belongs to someone: fields possession, owner.
export class BelongsTo extends Condition {
  static BRAND = Brand("aesop:BelongsTo:v1");
  constructor(situated) {
    Final(BelongsTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Something that was there is gone: field thing. Absence is itself a
// perceptible state (N6), starting at whatever took the thing away.
export class Missing extends Condition {
  static BRAND = Brand("aesop:Missing:v1");
  constructor(situated) {
    Final(Missing, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A container with nothing in it: field container. Class knowledge makes
// this negate anything LocatedAt inside it.
export class Empty extends Condition {
  static BRAND = Brand("aesop:Empty:v1");
  constructor(situated) {
    Final(Empty, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Wearing something over one's body: fields wearer, clothing.
export class Wears extends Condition {
  static BRAND = Brand("aesop:Wears:v1");
  constructor(situated) {
    Final(Wears, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Conveying something in the mouth: fields carrier, theme. The state that
// goes with mouth-carrying doings; a belief may hold it of an object that
// exists nowhere else.
export class Carrying extends Condition {
  static BRAND = Brand("aesop:Carrying:v1");
  constructor(situated) {
    Final(Carrying, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Taking something, from somewhere: fields theme, source.
export class Take extends Action {
  static BRAND = Brand("aesop:Take:v1");
  constructor(situated) {
    Final(Take, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Putting something out of sight somewhere: fields theme, place.
export class Hide extends Action {
  static BRAND = Brand("aesop:Hide:v1");
  constructor(situated) {
    Final(Hide, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Taking what is another's: field theme. Extends the open Get class so a
// description of "getting" matches it.
export class Steal extends Get {
  static BRAND = Brand("aesop:Steal:v1");
  constructor(situated) {
    Final(Steal, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
