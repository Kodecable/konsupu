// Explicit correspondence. Node identity never decides reference: two
// Nodes never merge and one never becomes another. Among says a described
// Node corresponds to one of the objects a named Situation talks about —
// its own members plus the Nodes its held cognition mentions; the
// described Node may sit in the asking Situation (a question description,
// the r4 form) or in any context that itself makes a correspondence, and
// the named Situation may be an ancestor of the asking one or any other
// context, never the asking one itself or its descendants. SameReferent
// is the identity of two known objects across contexts, held by whichever
// context makes the identification.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// "node is among the cognition situation talks about": fields situation,
// node. Holding this does not mean the described event happened, nor that
// the correspondent exists in the world; occurrence and existence are
// separate constraints.
export class Among extends Proposition {
  static BRAND = Brand("aesop:Among:v1");
  constructor(situated) {
    Final(Among, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Two Nodes name one referent under the holder's view: fields left,
// right. The dog's belief held the shadow and "another dog" to be one
// thing; the world held the fox's "I jumped down" to be the very fall it
// watched. Never inferred from types or similarity.
export class SameReferent extends Proposition {
  static BRAND = Brand("aesop:SameReferent:v1");
  constructor(situated) {
    Final(SameReferent, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
