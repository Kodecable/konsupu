// Mechanical support pools for the solver: what the story chain holds,
// which events occurred, and where conditions come from. Nothing here decides what any semantic class means; the
// dispatch in Search.js does. Pools select by instanceof, so a constraint
// of a general class is supported by instances of its subclasses — the
// same rule descriptions follow.
import { Assertion } from "./Assertion.js";
import { fieldValue, fieldsOf, matchValue } from "./Match.js";
import { Initially } from "./Time.js";
import { Occurs, ResultsIn } from "./Relations.js";

// All propositions asserted by the Situations above the asking one.
export function heldAbove(view, asked) {
  const held = [];
  for (const situation of view.Ancestors()) {
    if (situation === asked) continue;
    for (const node of view.Nodes(situation)) {
      if (node instanceof Assertion) held.push(node.proposition);
    }
  }
  return held;
}

// Match a constraint's written fields against each candidate; a fresh Map
// per candidate keeps bindings independent.
export function tuplesFrom(constraint, pool, context) {
  const tuples = [];
  for (const candidate of pool) {
    const bindings = new Map();
    let ok = true;
    for (const [key, pattern] of fieldsOf(constraint)) {
      const value = fieldValue(candidate, key);
      if (!matchValue(pattern, value, bindings, context)) {
        ok = false;
        break;
      }
    }
    if (ok) tuples.push(bindings);
  }
  return tuples;
}

// Held propositions of the constraint's class, subclasses included.
export function classPool(constraint, held) {
  return held.filter((proposition) => {
    return proposition instanceof constraint.constructor;
  });
}

// What the story asserts as occurred, as a set of event nodes.
export function occurredSet(held) {
  const occurred = new Set();
  for (const proposition of held) {
    if (proposition instanceof Occurs) occurred.add(proposition.event);
  }
  return occurred;
}

// A proposition holds when asserted directly, as the result content of an
// asserted ResultsIn whose event actually occurred, or as the content of
// an asserted Initially — for conditions and for every other class alike
// (a belief carried as an event's result is a held belief, with its start
// anchored).
export function conditionPool(constraint, held) {
  const occurred = occurredSet(held);
  const pool = classPool(constraint, held);
  for (const proposition of held) {
    if (proposition instanceof ResultsIn) {
      if (
        occurred.has(proposition.event) &&
        proposition.proposition instanceof constraint.constructor
      ) {
        pool.push(proposition.proposition);
      }
    } else if (proposition instanceof Initially) {
      if (proposition.state instanceof constraint.constructor) {
        pool.push(proposition.state);
      }
    }
  }
  return pool;
}

// Every proposition some occurred event's asserted ResultsIn carries.
export function carriedContents(held) {
  const occurred = occurredSet(held);
  const carried = [];
  for (const proposition of held) {
    if (
      proposition instanceof ResultsIn &&
      occurred.has(proposition.event) &&
      proposition.proposition
    ) {
      carried.push(proposition.proposition);
    }
  }
  return carried;
}

// Among matches its description against every node of the named
// Situation; the match binds the description to its correspondent, so
// every other constraint on the same description must agree with it.
export function amongTuples(constraint, pool, context) {
  const tuples = [];
  for (const node of pool) {
    const bindings = new Map();
    if (matchValue(constraint.node, node, bindings, context)) {
      tuples.push(bindings);
    }
  }
  return tuples;
}
