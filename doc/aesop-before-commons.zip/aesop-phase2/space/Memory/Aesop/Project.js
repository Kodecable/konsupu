// Mechanical projection of a resolved value into deterministic machine
// text: enough to identify exactly what the Query resolved, nothing more.
// No English realization, no tense, no wording choices, and no reading of
// other cognition — only the value's own structure. Field names sort
// alphabetically because property insertion order is a construction
// detail, not declaration semantics.
import { Entity } from "./Objects.js";
import { Node, Situation, Variable } from "../../Interface/Nodes.js";

function dataFields(node) {
  return Object.entries(node)
    .filter(([key]) => key !== "situated")
    .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0));
}

export function Project(value) {
  // A failure record names the failing constraints by class only: they are
  // question cognition whose Variables never resolve.
  if (value?.result === "not-established") {
    const names = value.constraints.map((item) => item.constructor.name);
    const listed = `[${names.join(",")}]`;
    return `{constraints=${listed},level=${value.level},result=not-established}`;
  }
  if (value instanceof Entity) return `Entity(${value.name})`;
  if (value instanceof Variable) {
    throw new TypeError("Machine projection of an unresolved Variable");
  }
  // A context Situation projects by its title — surface text it was given
  // at construction, the same status Entity.name has. An untitled context
  // still projects, structurally.
  if (value instanceof Situation) {
    return `Context(${value.title ?? ""})`;
  }
  if (value instanceof Node) {
    const fields = dataFields(value).map(
      ([key, item]) => `${key}=${Project(item)}`,
    );
    return `${value.constructor.name}(${fields.join(",")})`;
  }
  if (Array.isArray(value)) {
    return `[${value.map(Project).join(",")}]`;
  }
  if (value !== null && typeof value === "object") {
    const fields = Object.entries(value)
      .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
      .map(([key, item]) => `${key}=${Project(item)}`);
    return `{${fields.join(",")}}`;
  }
  return String(value);
}
