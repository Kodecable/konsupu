// Sorts of individuals. An Entity's optional `kind` field names the sort
// it rigidly belongs to ("a wolf" is any Entity of the wolf Kind), which
// is what an indefinite or a negated existence quantifies over. A Kind is
// identified by object identity; its `name` is surface text only, like
// an Entity's. Sorts never come from names, and a context's belief that
// something is of another sort is a SameReferent in that context, never a
// changed kind.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

export class Kind extends SituatedNode {
  static BRAND = Brand("aesop:Kind:v1");
  constructor(situated) {
    Final(Kind, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
