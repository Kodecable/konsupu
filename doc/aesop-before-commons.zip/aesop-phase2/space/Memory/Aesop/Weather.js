// Weather conditions.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Condition } from "./Conditions.js";

// A long dry spell: field subject (the land).
export class Drought extends Condition {
  static BRAND = Brand("aesop:Drought:v1");
  constructor(situated) {
    Final(Drought, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
