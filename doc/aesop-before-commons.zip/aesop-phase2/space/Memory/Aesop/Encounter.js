// Contact and conflict vocabulary: touchings, attacks, threats, and
// cryings.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Touching something: field theme. The deed a prohibition forbids.
export class Touch extends Action {
  static BRAND = Brand("aesop:Touch:v1");
  constructor(situated) {
    Final(Touch, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Springing suddenly on something: field theme.
export class Pounce extends Action {
  static BRAND = Brand("aesop:Pounce:v1");
  constructor(situated) {
    Final(Pounce, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Attacking and troubling something: field theme.
export class Worry extends Action {
  static BRAND = Brand("aesop:Worry:v1");
  constructor(situated) {
    Final(Worry, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Causing harm or pain: fields doer (who would do it — a kind, in a
// general rule such as the truce), theme.
export class Hurt extends Action {
  static BRAND = Brand("aesop:Hurt:v1");
  constructor(situated) {
    Final(Hurt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Casting something to somewhere or someone: fields theme, to.
export class Throw extends Action {
  static BRAND = Brand("aesop:Throw:v1");
  constructor(situated) {
    Final(Throw, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Making the crying sound of a child: field theme.
export class Cry extends Action {
  static BRAND = Brand("aesop:Cry:v1");
  constructor(situated) {
    Final(Cry, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Calling out something: field call (surface).
export class CryOut extends Action {
  static BRAND = Brand("aesop:CryOut:v1");
  constructor(situated) {
    Final(CryOut, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Calling others to come to aid: field theme.
export class CallForHelp extends Action {
  static BRAND = Brand("aesop:CallForHelp:v1");
  constructor(situated) {
    Final(CallForHelp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
