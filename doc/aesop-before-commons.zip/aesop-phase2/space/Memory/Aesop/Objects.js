// World objects. An Entity or Event occurrence says "this object is part of
// the cognition", never "something is true" and never "it happened".
// Occurrence is the asserted Occurs proposition. Events without an agent
// are plain Events; agentive doings extend Action; Says is an Action
// because speaking is something the speaker does. Get is a concrete but
// open general doing: descriptions may instantiate it without knowing the
// story's most specific class.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

// Titles for context Situations: surface text for machine projection only,
// the same status Entity.name has. A context's semantic mention comes from
// the attitude or speech proposition that introduces it, never from its
// title.
export function context(situation, title) {
  situation.title = title;
  return situation;
}

// A discourse individual, identified by object identity; `name` is surface
// text for realization only; optional `kind` is its sort (Kinds.js).
export class Entity extends SituatedNode {
  static BRAND = Brand("aesop:Entity:v1");
  constructor(situated) {
    Final(Entity, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// A referable happening with an occurred / not-occurred distinction. No
// agent is implied. Fields are declared per concrete class as intrinsic
// structure (theme, destination, ...) via explicit assignment.
export class Event extends SituatedNode {
  static BRAND = Brand("aesop:Event:v1");
  constructor(situated) {
    if (new.target === Event) throw new TypeError("Event is abstract");
    super(situated);
  }
}

// An Event modeled as carried out by some Entity. The only added meaning
// is agentivity; intention, success, or responsibility are separate
// cognitions. The agent itself is the reified Agent proposition (see
// Relations.js), never a field here.
export class Action extends Event {
  static BRAND = Brand("aesop:Action:v1");
  constructor(situated) {
    if (new.target === Action) throw new TypeError("Action is abstract");
    super(situated);
  }
}

// Speaking: fields `content` (the Situation whose cognition is what is
// said — one canonical form for story speech) and `text` (surface string).
// Field `to` names the addressee when the story gives one. The Situation
// saying the content does not hold it true just because it was said; the
// speech context holds whatever its own Assertions hold. The dialogue
// reply is a distinct class (Reply), so Says.content never carries a
// second, value-shaped meaning.
export class Says extends Action {
  static BRAND = Brand("aesop:Says:v1");
  constructor(situated) {
    Final(Says, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled downward motion: fields theme, destination.
export class Fall extends Event {
  static BRAND = Brand("aesop:Fall:v1");
  constructor(situated) {
    Final(Fall, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// An uncontrolled upward motion: field theme.
export class Rise extends Event {
  static BRAND = Brand("aesop:Rise:v1");
  constructor(situated) {
    Final(Rise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Coming out of sleep, happening to the sleeper: field theme.
export class Wake extends Event {
  static BRAND = Brand("aesop:Wake:v1");
  constructor(situated) {
    Final(Wake, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Being caught in a trap, happening to the trapped: fields theme, location.
export class GetTrapped extends Event {
  static BRAND = Brand("aesop:GetTrapped:v1");
  constructor(situated) {
    Final(GetTrapped, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Coming to hold something. Concrete but deliberately not final: a question
// may describe a getting without knowing how the story words it, so more
// specific doings (SnapUp, ...) refine this class. Field theme.
export class Get extends Action {
  static BRAND = Brand("aesop:Get:v1");
  constructor(situated) {
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// One happening made of several events done one after another, taken as a
// whole: field parts (the events, in narration order). It lets the story
// say what the parts did together ("little by little") without crediting
// any single part. Its parts keep their own occurrence and order.
export class Series extends Event {
  static BRAND = Brand("aesop:Series:v1");
  constructor(situated) {
    Final(Series, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
