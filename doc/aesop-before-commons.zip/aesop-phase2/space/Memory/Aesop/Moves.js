// More doing vocabulary: jumps, exitings, lurking, and bodily doings.
// Same kind of vocabulary as Motion.js; separate file only for the line
// budget.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Jumping downward into somewhere: fields theme, destination.
export class JumpDown extends Action {
  static BRAND = Brand("aesop:JumpDown:v1");
  constructor(situated) {
    Final(JumpDown, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Jumping onto something: field target.
export class JumpOn extends Action {
  static BRAND = Brand("aesop:JumpOn:v1");
  constructor(situated) {
    Final(JumpOn, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Getting out of somewhere: field from. Concrete but deliberately open,
// like Get: a question may describe an escape without knowing how the
// story words it.
export class GetOut extends Action {
  static BRAND = Brand("aesop:GetOut:v1");
  constructor(situated) {
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Jumping up as high as somewhere: field to. Extends the open GetOut
// class so an escape described as "getting out" matches it.
export class JumpUp extends GetOut {
  static BRAND = Brand("aesop:JumpUp:v1");
  constructor(situated) {
    Final(JumpUp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Moving about quietly and warily: field theme.
export class Prowl extends Action {
  static BRAND = Brand("aesop:Prowl:v1");
  constructor(situated) {
    Final(Prowl, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Pressing low to the ground: field place.
export class Crouch extends Action {
  static BRAND = Brand("aesop:Crouch:v1");
  constructor(situated) {
    Final(Crouch, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Staying in expectation: field theme.
export class Wait extends Action {
  static BRAND = Brand("aesop:Wait:v1");
  constructor(situated) {
    Final(Wait, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Hunting: field theme.
export class Hunt extends Action {
  static BRAND = Brand("aesop:Hunt:v1");
  constructor(situated) {
    Final(Hunt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Getting at something — reaching to within one's grasp: fields theme,
// manner.
export class GetAt extends Action {
  static BRAND = Brand("aesop:GetAt:v1");
  constructor(situated) {
    Final(GetAt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Throwing part of oneself upward or back: fields theme, manner.
export class Toss extends Action {
  static BRAND = Brand("aesop:Toss:v1");
  constructor(situated) {
    Final(Toss, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Atelic traveling toward a place — on the way, arrival not implied:
// field destination. "Was going to market" is a HeadTo, not a ComeTo.
export class HeadTo extends Action {
  static BRAND = Brand("aesop:HeadTo:v1");
  constructor(situated) {
    Final(HeadTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
