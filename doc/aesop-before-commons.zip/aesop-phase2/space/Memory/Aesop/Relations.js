// Relational propositions about events, agents, and outcomes: discussible
// claims. Existing as an object asserts nothing; an Assertion does.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// "This event took place": field event.
export class Occurs extends Proposition {
  static BRAND = Brand("aesop:Occurs:v1");
  constructor(situated) {
    Final(Occurs, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The reified agent relation: fields action, actor. Agent lives as a
// proposition because questions must join an unknown action to its unknown
// actor (see FRAMEWORK_NOTES); no Action carries an agent field.
export class Agent extends Proposition {
  static BRAND = Brand("aesop:Agent:v1");
  constructor(situated) {
    Final(Agent, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Temporal order (transitive): fields earlier, later. Stories assert only
// the adjacent Next of their event chains; Before is what those chains
// entail, and a question holds it when the original text says "before".
export class Before extends Proposition {
  static BRAND = Brand("aesop:Before:v1");
  constructor(situated) {
    Final(Before, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Immediate succession — the next thing that happened: fields earlier,
// later. Stories assert this for adjacent events; the transitive Before
// follows from it by domain reasoning, not by enumeration.
export class Next extends Proposition {
  static BRAND = Brand("aesop:Next:v1");
  constructor(situated) {
    Final(Next, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// One event making another possible without causing it ("was then able
// to"): fields enabler, enabled.
export class Enables extends Proposition {
  static BRAND = Brand("aesop:Enables:v1");
  constructor(situated) {
    Final(Enables, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Causal dependence: fields cause, effect.
export class Causes extends Proposition {
  static BRAND = Brand("aesop:Causes:v1");
  constructor(situated) {
    Final(Causes, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// An event whose outcome is that a proposition holds: fields event,
// proposition. Asserting ResultsIn means the Situation holds that
// proposition as the event's result — unlike Says.content, which holds
// nothing.
export class ResultsIn extends Proposition {
  static BRAND = Brand("aesop:ResultsIn:v1");
  constructor(situated) {
    Final(ResultsIn, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// An attempt that did not achieve its end: field action.
export class Failed extends Proposition {
  static BRAND = Brand("aesop:Failed:v1");
  constructor(situated) {
    Final(Failed, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// What an actor wants: fields actor, objective.
export class Goal extends Proposition {
  static BRAND = Brand("aesop:Goal:v1");
  constructor(situated) {
    Final(Goal, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// An action done to reach a goal: fields action, goal.
export class InOrderTo extends Proposition {
  static BRAND = Brand("aesop:InOrderTo:v1");
  constructor(situated) {
    Final(InOrderTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Overlapping frames — "as he crossed, he saw it": fields first,
// second. Neither event is before the other; the narration may still
// order each of them against the rest of the chain.
export class Overlaps extends Proposition {
  static BRAND = Brand("aesop:Overlaps:v1");
  constructor(situated) {
    Final(Overlaps, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
