// Negation vocabulary. The domain stays open-world: unasserted is neither
// true nor false, and no negation-as-failure exists anywhere. "No" answers
// come only from held negation cognition — an explicit Not, a NoEvent or
// NoneSuch (negated existence of events or of individuals in a state,
// within a time window), or an OnlyDid exhaustive
// listing from which the solver derives what did not happen. The six
// negation kinds (unhappened event, negated existence, inability,
// in-context negation, exhaustion, absence) are distinguishable through
// these classes plus Unable and Missing in Conditions.js.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// The holder holds the negation of `proposition`'s content: field
// proposition. In a belief or speech context it is negation only there
// (N4); held by the world it negates a world question directly. Its
// complement is the inner proposition itself.
export class Not extends Proposition {
  static BRAND = Brand("aesop:Not:v1");
  constructor(situated) {
    Final(Not, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Negated existence: no event matching `pattern` (an event shape, never a
// referent) occurs within the window. Optional `actor` restricts the
// agent of the covered events. A question is refuted only when its
// description is covered by the pattern and its time falls inside the
// window — the third nobody-coming never refutes the second
// somebody-coming.
export class NoEvent extends Proposition {
  static BRAND = Brand("aesop:NoEvent:v1");
  constructor(situated) {
    Final(NoEvent, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Exhaustive listing (N5): within the window, all the actor did —
// optionally all the actor did concerning `theme` — was `deeds`; anything
// else that scope covers did not happen. The solver derives the negative
// consequences; fixtures state the exhaustion itself, not its derived
// negatives.
export class OnlyDid extends Proposition {
  static BRAND = Brand("aesop:OnlyDid:v1");
  constructor(situated) {
    Final(OnlyDid, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Negated existence of individuals: within the window [from, until),
// there are no `some` (the quantified individuals, listed explicitly)
// for which the state `pattern` holds — "no wolf was present" is
// some: [x], pattern: Present{subject: x}, x an Entity of the wolf Kind.
// Only the listed individuals are open; every other node in the pattern
// (a Kind, a story individual) is itself. It refutes a state question the
// pattern covers, at a time inside the window, and nothing at other times.
export class NoneSuch extends Proposition {
  static BRAND = Brand("aesop:NoneSuch:v1");
  constructor(situated) {
    Final(NoneSuch, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

