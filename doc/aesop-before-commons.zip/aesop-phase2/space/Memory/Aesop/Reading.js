// Reading other contexts. A question never climbs into a context
// structurally: Among names the Situation it corresponds into, HoldsIn
// names the context whose held cognition it matches against, and both
// find a Variable-bound context among the Situations that visible
// attitude and speech cognition introduce — never by scanning the Input.
// A context's own held cognition is all a question sees of it: mentioning
// world individuals does not let a context see what the world holds.
import { Situation, WalkReferences } from "../../Interface/Nodes.js";
import { Assertion } from "./Assertion.js";
import { Believes, Fears, Plans } from "./Attitudes.js";
import { Says } from "./Objects.js";
import { Initially } from "./Time.js";
import { matchValue } from "./Match.js";
import { withQuestionShapes } from "./Shapes.js";
import { carriedContents, heldAbove, occurredSet } from "./Support.js";
import { Occurs } from "./Relations.js";

// The propositions one Situation holds: exactly its own Assertions.
export function heldInContext(view, situation) {
  const held = [];
  for (const node of view.Nodes(situation)) {
    if (node instanceof Assertion) held.push(node.proposition);
  }
  return held;
}

// The Situations that visible cognition introduces as attitude or speech
// content — the only candidates a Variable-bound context may resolve to.
// An attitude carried as an event's result (a belief that started when
// something was seen) introduces its content just the same, and so does
// any occurred event that carries a content Situation — a Says, and a
// speech-action like a cry whose claim rides on it.
export function introducedContexts(view, asked) {
  const contexts = new Set();
  const consider = (proposition) => {
    if (
      proposition instanceof Believes ||
      proposition instanceof Fears ||
      proposition instanceof Plans
    ) {
      contexts.add(proposition.content);
    } else if (proposition instanceof Says && proposition.content) {
      contexts.add(proposition.content);
    }
  };
  const held = heldAbove(view, asked);
  for (const proposition of held) consider(proposition);
  for (const proposition of carriedContents(held)) consider(proposition);
  for (const event of occurredSet(held)) {
    if (event.content) contexts.add(event.content);
  }
  return [...contexts];
}

// The objects a Situation talks about: its own members plus the Nodes its
// held cognition mentions (a belief may mention the world's shadow).
export function talkedAbout(view, situation) {
  const nodes = new Set(view.Nodes(situation));
  for (const proposition of heldInContext(view, situation)) {
    WalkReferences(proposition, (reference) => nodes.add(reference));
  }
  return [...nodes];
}

// Support for Among{situation, node}: the description binds to one of the
// named Situation's talked-about objects. The named Situation may be an
// ancestor of the asking one or any other context, never the asking one
// itself or one of its descendants.
export function amongSupport(view, constraint, context, forbidden) {
  const targets = constraint.situation instanceof Situation
    ? [constraint.situation]
    : introducedContexts(view, context.asked);
  const tuples = [];
  for (const target of targets) {
    if (forbidden.has(target)) continue;
    const bindings = new Map();
    if (constraint.situation !== target) {
      if (!matchValue(constraint.situation, target, bindings, context)) continue;
    }
    for (const node of talkedAbout(view, target)) {
      const trial = new Map(bindings);
      if (matchValue(constraint.node, node, trial, context)) tuples.push(trial);
    }
  }
  return tuples;
}

// Everything a context holds for reading: its own Assertions, contents
// its occurred events' ResultsIn carry, its Initially states, and the
// events it asserts as happened (an imagination's happenings are part
// of what it holds). This is the same pool a verdict Timeline builds
// over the context, so both reading paths agree.
export function contextHolds(view, situation) {
  const held = heldInContext(view, situation);
  const pool = [...held, ...carriedContents(held)];
  for (const proposition of held) {
    if (proposition instanceof Initially) pool.push(proposition.state);
  }
  for (const event of occurredSet(held)) pool.push(event);
  return [...new Set(pool)];
}

// Support for HoldsIn{context, proposition}: the asked pattern matches by
// content against what the context itself holds. Holding at some time in
// the context is enough here; time-anchored reading goes through
// AskWhether with a context.
export function holdsInSupport(view, constraint, context) {
  const targets = constraint.context instanceof Situation
    ? [constraint.context]
    : introducedContexts(view, context.asked);
  const shaped = withQuestionShapes(context, constraint.proposition);
  const tuples = [];
  for (const target of targets) {
    const base = new Map();
    if (constraint.context !== target) {
      if (!matchValue(constraint.context, target, base, shaped)) continue;
    }
    for (const proposition of contextHolds(view, target)) {
      const trial = new Map(base);
      if (matchValue(constraint.proposition, proposition, trial, shaped)) {
        tuples.push(trial);
      }
    }
  }
  return tuples;
}
