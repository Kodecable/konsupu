// Habitual practice and its instances. A habit is a generalization with a
// frequency, not an enumeration of happenings and never one happening; a
// concrete "next time" is a separate event linked to the habit explicitly.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// The actor habitually does `deed` (an event shape), optionally with a
// `frequency` value: fields doer, deed, frequency.
export class Habitual extends Proposition {
  static BRAND = Brand("aesop:Habitual:v1");
  constructor(situated) {
    Final(Habitual, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// This event is one instance of that habitual practice: fields habit,
// event. The instance occurs on its own; the habit never did.
export class Instance extends Proposition {
  static BRAND = Brand("aesop:Instance:v1");
  constructor(situated) {
    Final(Instance, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
