// Low-level mechanical helpers only; Search.js owns the per-class
// interpretations. A Node's semantic identity is object identity. "Bound
// to undefined" is a binding (Map.has), never a free slot; a field the
// story never wrote reads as Unknown. A Node in a pattern plays one of
// three roles:
// - a description: an asked Node named by a held Among. It binds to one
//   story Node per solution (after a class + written-field check), and
//   every later use must name the same correspondent;
// - an asked proposition: matched by content (class + fields);
// - anything else (story Nodes, asked individuals no Among describes): a
//   constant, matching only itself.
import { Node, Proposition, Variable } from "../../Interface/Nodes.js";
import { UnstatedField, isUnknown } from "./Outcomes.js";
import { isRecord, sameValue } from "./Values.js";

export { join, sameValue } from "./Values.js";

export function fieldsOf(node) {
  return Object.entries(node).filter(([key]) => key !== "situated");
}

// The story's value for a field, or that field's own Unknown when it was
// never written. An explicitly written undefined stays undefined.
export function fieldValue(node, key) {
  if (node === null || typeof node !== "object") {
    return UnstatedField(node, key);
  }
  if (!Object.hasOwn(node, key)) return UnstatedField(node, key);
  return Object.getOwnPropertyDescriptor(node, key).value;
}

// The matching context of one solving call: the asking Situation, the
// set of asked Nodes that held Among constraints describe, and the set of
// asked Nodes used as shapes — patterns inside negation, ability, habit,
// and ordinal cognition. A shape is never a referent: it corresponds to
// nothing and never occurs, but like a description it binds once and
// must agree with itself across constraints. An exact shape (an
// inability's deed) also never matches a story node narrower than it.
export function MatchContext(asked, described = new Set(), shapes = new Set()) {
  return { asked, described, shapes, exact: new Set() };
}

// Surface text (an Entity's name) is for projection only: it never
// takes part in matching, on either side.
export const SURFACE = new Set(["name"]);

function matchFields(pattern, value, bindings, context) {
  if (context.exact?.has(pattern)) {
    const extra = fieldsOf(value).some(([key]) => {
      return !SURFACE.has(key) && !Object.hasOwn(pattern, key);
    });
    if (extra) return false;
  }
  for (const [key, item] of fieldsOf(pattern)) {
    if (SURFACE.has(key)) continue;
    const field = fieldValue(value, key);
    if (!matchValue(item, field, bindings, context)) return false;
  }
  return true;
}

// Match the items of an Array or plain-record pattern pairwise, so the
// Variables and descriptions inside a container field bind like those in
// a Node field. Both sides must have the same shape.
function matchContainer(pattern, value, bindings, context) {
  const pairs = [];
  if (Array.isArray(pattern)) {
    if (!Array.isArray(value) || value.length !== pattern.length) return false;
    pattern.forEach((item, index) => pairs.push([item, value[index]]));
  } else {
    if (!isRecord(value)) return false;
    const keys = Object.keys(pattern).sort();
    const valueKeys = Object.keys(value).sort();
    if (!sameValue(keys, valueKeys)) return false;
    for (const key of keys) pairs.push([pattern[key], value[key]]);
  }
  const trial = new Map(bindings);
  for (const [item, field] of pairs) {
    if (!matchValue(item, field, trial, context)) return false;
  }
  for (const [key, item] of trial) bindings.set(key, item);
  return true;
}

// Match one pattern value against one story value, extending `bindings`
// only on success. An unstated story value satisfies a Variable (binding
// it to Unknown) but never a written field.
export function matchValue(pattern, value, bindings, context) {
  // A node the join bound in another context stands in for its pattern:
  // here it matches by its own content, its context's nodes as shapes.
  if (context.standIn?.has(pattern)) pattern = context.standIn.get(pattern);
  if (pattern instanceof Variable) {
    if (bindings.has(pattern)) return sameValue(bindings.get(pattern), value);
    bindings.set(pattern, value);
    return true;
  }
  if (isUnknown(value)) return false;
  if (Array.isArray(pattern) || isRecord(pattern)) {
    return matchContainer(pattern, value, bindings, context);
  }
  if (!(pattern instanceof Node)) return sameValue(pattern, value);
  if (
    context.described.has(pattern) ||
    context.shapes.has(pattern) ||
    context.foreign?.has(pattern.situated)
  ) {
    if (bindings.has(pattern)) return bindings.get(pattern) === value;
    if (!(value instanceof pattern.constructor)) return false;
    const trial = new Map(bindings);
    if (!matchFields(pattern, value, trial, context)) return false;
    for (const [key, item] of trial) bindings.set(key, item);
    bindings.set(pattern, value);
    return true;
  }
  if (pattern.situated === context.asked && pattern instanceof Proposition) {
    if (!(value instanceof pattern.constructor)) return false;
    const trial = new Map(bindings);
    if (!matchFields(pattern, value, trial, context)) return false;
    for (const [key, item] of trial) bindings.set(key, item);
    return true;
  }
  return pattern === value;
}
