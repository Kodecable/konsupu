// Ordinal anchors inside a constraint: "the first cry", "the third
// time" name events by their position along the story chain, resolved
// before the constraint is matched.
import { Proposition } from "../../Interface/Nodes.js";
import { Nth } from "./Time.js";
import { Timeline } from "./Temporal.js";
import { resolveNth } from "./Anchors.js";

// An asked proposition nested in a constraint matches by content, so an
// Nth inside it ("the third time" of a negated existence a Causes names)
// is part of the constraint and resolves with it. Descriptions and
// shapes bind by identity and are never rebuilt.
function contentNested(value, context) {
  return (
    value instanceof Proposition &&
    value.situated === context.asked &&
    !context.described.has(value) &&
    !context.shapes.has(value)
  );
}

// An Nth in any event position of a constraint names an event by its
// position ("the first cry"): resolve it along the story chain before
// matching, also inside content-matched asked propositions. Each node on
// the path is copied so the original constraint stays intact; null when
// some ordinal names no event.
export function resolveNthAnchors(constraint, held, context) {
  const timeline = new Timeline(held);
  const resolve = (node) => {
    let copy = null;
    for (const [field, value] of Object.entries(node)) {
      if (field === "situated") continue;
      let next = value;
      if (value instanceof Nth) {
        next = resolveNth(timeline, value, context);
      } else if (contentNested(value, context)) {
        next = resolve(value);
      }
      if (next === null) return null;
      if (next === value) continue;
      if (copy === null) {
        // A real instance of the same class, not an Object.create proxy:
        // the re-dispatch below checks instanceof.
        copy = new node.constructor(node.situated);
        for (const [key, item] of Object.entries(node)) {
          if (key !== "situated") copy[key] = item;
        }
      }
      copy[field] = next;
    }
    return copy ?? node;
  };
  return resolve(constraint);
}
