// Imperative handling for the reply path. A Konsupu-directed Imperative
// requests one Reply action; its content is the already-resolved answer
// value (story speech Says a Situation; the reply utters a value — one
// canonical form each). Resolution only reads that value through the
// Imperative's Perspective and projects it mechanically — no Query
// reasoning happens here, and a value that should have resolved but did
// not is an Input structure error, not something to re-solve quietly.
import { Perspective } from "../Foundation/Perspective.js";
import { Reply } from "./Dialogue.js";
import { Project } from "./Project.js";
import { TextOutput } from "../../Interface/Outputs.js";

export function SayApplicable(input, imperative) {
  return imperative.content instanceof Reply;
}

export function SayImperatives(input, imperatives, remaining, state) {
  const resolved = new Set();
  const outputs = [];
  for (const imperative of remaining) {
    const view = new Perspective(imperative, state);
    const reply = imperative.content;
    const value = view.RequireValue(
      reply.content,
      "the requested Reply read content whose Query had not resolved",
    );
    outputs.push(new TextOutput(Project(value)));
    resolved.add(imperative);
  }
  return { resolved, outputs };
}
