// Exchange vocabulary: buyings and sellings, in the world or in a plan.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Acquiring something by payment: fields buyer, what, from (the seller).
export class Buy extends Action {
  static BRAND = Brand("aesop:Buy:v1");
  constructor(situated) {
    Final(Buy, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Giving something up for payment: fields seller, what, to (the buyer).
export class Sell extends Action {
  static BRAND = Brand("aesop:Sell:v1");
  constructor(situated) {
    Final(Sell, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
