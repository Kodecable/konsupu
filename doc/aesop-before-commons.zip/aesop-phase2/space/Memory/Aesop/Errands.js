// Undertakings and pronouncements: declaring, advising, summoning,
// dwelling, and seeking out.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Making an official pronouncement: field declaration.
export class Declare extends Action {
  static BRAND = Brand("aesop:Declare:v1");
  constructor(situated) {
    Final(Declare, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Recommending a course to someone: fields to (the advised one), advised
// (the deed).
export class Advise extends Action {
  static BRAND = Brand("aesop:Advise:v1");
  constructor(situated) {
    Final(Advise, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Living somewhere together: field manner.
export class Dwell extends Action {
  static BRAND = Brand("aesop:Dwell:v1");
  constructor(situated) {
    Final(Dwell, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Coming upon something after seeking: field theme.
export class Find extends Action {
  static BRAND = Brand("aesop:Find:v1");
  constructor(situated) {
    Final(Find, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Unearthing something hidden: field theme.
export class DigUp extends Action {
  static BRAND = Brand("aesop:DigUp:v1");
  constructor(situated) {
    Final(DigUp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Feeding on one's own satisfaction over something: field theme.
export class Gloat extends Action {
  static BRAND = Brand("aesop:Gloat:v1");
  constructor(situated) {
    Final(Gloat, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Entering somewhere: field place.
export class Enter extends Action {
  static BRAND = Brand("aesop:Enter:v1");
  constructor(situated) {
    Final(Enter, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Producing eggs: field theme.
export class Lay extends Action {
  static BRAND = Brand("aesop:Lay:v1");
  constructor(situated) {
    Final(Lay, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Offering someone good wishes on an occasion: fields theme (who is
// congratulated), occasion.
export class Congratulate extends Action {
  static BRAND = Brand("aesop:Congratulate:v1");
  constructor(situated) {
    Final(Congratulate, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
