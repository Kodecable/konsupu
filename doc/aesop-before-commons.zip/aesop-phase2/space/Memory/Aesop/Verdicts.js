// Yes-no evaluation inside one context (the world chain by default): the
// content is supported, its held negation is, both (conflict), or
// neither (not established; absence is never negation). Both sides start
// from the join: Variables, nodes in scope, and the world's individuals
// stay bound; a node local to another context (a claim's "a wolf", a
// reply's proposition) stands in for its pattern and matches here by its
// own content, its context's nodes acting as shapes. Positives.js and
// Refutations.js hold the two sides.
import { withQuestionShapes } from "./Shapes.js";
import { Timeline } from "./Temporal.js";
import { Not } from "./Negation.js";
import { Agent, Occurs } from "./Relations.js";
import { TheBeginning, TheEnd } from "./Time.js";
import { negativeOf as refute } from "./Refutations.js";
import { positiveOf } from "./Positives.js";
import { Conflict, No, Yes } from "./Outcomes.js";
import { heldInContext } from "./Reading.js";
import { heldAbove } from "./Support.js";
import { Node, Situation, Variable } from "../../Interface/Nodes.js";

// The actor pins of a description: constants the asked's Agent
// constraints attach to it, so an OnlyDid can match its actor.
export function actorPins(constraints) {
  const pins = new Map();
  for (const constraint of constraints) {
    if (constraint instanceof Agent && constraint.action) {
      if (!pins.has(constraint.action)) pins.set(constraint.action, []);
      pins.get(constraint.action).push(constraint.actor);
    }
  }
  return pins;
}

// The negation of a Not-content is the inner proposition's own positive
// support; every other content delegates to the refutation machinery.
function negativeOf(timeline, content, when, context, pins, base) {
  if (content instanceof Not) {
    return positiveOf(timeline, content.proposition, when, context, base);
  }
  return refute(timeline, content, when, context, pins, base);
}

// The moments an unanchored state question is read at: the beginning,
// every event the context knows, and the end. Unanchored means "at some
// time", on both sides alike: supported at some moment is yes; supported
// at none but negated at some is no; a conflict needs both sides at one
// and the same moment. An ending thus counts as much as a start.
function moments(timeline) {
  return [TheBeginning, ...timeline.occurred, TheEnd];
}

// Judge one AskWhether inside one evaluation context. `accumulated`
// carries the join so far; `scope` is the set of Situations whose nodes
// keep their bindings here. A `when` that is a Variable or a
// description reads the event the join bound it to (the time a saying
// is about; the crying a threat was conditioned on). Returns verdict
// tuples: maps over the content's bindings plus the verdict value; an
// empty list means not established.
export function VerdictTuples(held, constraint, context, accumulated, pins, scope, real) {
  const timeline = new Timeline(held);
  const content = constraint.content;
  let when = constraint.when ?? null;
  if (when !== null && accumulated.has(when)) {
    when = accumulated.get(when);
  } else if (when instanceof Variable) {
    return [];
  }
  const base = new Map();
  const standIn = new Map();
  const foreign = new Set();
  for (const [pattern, value] of accumulated) {
    if (
      pattern instanceof Variable ||
      !(value instanceof Node) ||
      scope.has(value.situated) ||
      real.has(value.situated)
    ) {
      base.set(pattern, value);
    } else {
      standIn.set(pattern, value);
      foreign.add(value.situated);
    }
  }
  const shaped = {
    ...withQuestionShapes(context, content, when?.pattern),
    standIn,
    foreign,
  };
  const occurrence = content instanceof Occurs || content instanceof Agent;
  const anchors = when === null && !occurrence ? moments(timeline) : [when];
  const conflict = [];
  const yes = [];
  let no = false;
  for (const at of anchors) {
    const positive = positiveOf(timeline, content, at, shaped, base);
    const negative = negativeOf(timeline, content, at, shaped, pins, base);
    if (positive.length > 0 && negative.length > 0) conflict.push(...positive);
    else if (positive.length > 0) yes.push(...positive);
    else if (negative.length > 0) no = true;
  }
  const tag = (tuples, verdict) => {
    return tuples.map((tuple) => new Map([...tuple, [constraint.verdict, verdict]]));
  };
  if (conflict.length > 0) return tag(conflict, Conflict());
  if (yes.length > 0) return tag(yes, Yes());
  if (no) return [new Map([...base, [constraint.verdict, No()]])];
  return [];
}

// The held-cognition lists one AskWhether evaluates under, for one
// accumulated tuple, with the scope of Situations whose nodes count as
// this evaluation's own: the named Situation, the bound context
// Variable's Situation, or — with no context named — the whole
// Situation chain above the asking one (the world).
function evaluationHeld(view, constraint, accumulated) {
  const named = constraint.context;
  if (named instanceof Situation) {
    return [{ held: heldInContext(view, named), scope: new Set([named]) }];
  }
  if (named !== null && named !== undefined && accumulated.has(named)) {
    const value = accumulated.get(named);
    if (value instanceof Situation) {
      return [{ held: heldInContext(view, value), scope: new Set([value]) }];
    }
    return [];
  }
  return [{ held: heldAbove(view, view.situated), scope: new Set(view.Ancestors()) }];
}

// Judge the yes-no constraints against the joined tuples of the others.
// Each accumulated tuple is extended by its verdict bindings; a question
// nothing supports yields no verdict tuples at all.
export function judgeAsks(view, asks, tuples, context, constraints) {
  if (asks.length === 0) return tuples;
  const pins = actorPins(constraints);
  const real = new Set(view.Ancestors());
  let judged = tuples;
  for (const ask of asks) {
    const extended = [];
    for (const accumulated of judged) {
      for (const target of evaluationHeld(view, ask, accumulated)) {
        for (const tuple of VerdictTuples(
          target.held,
          ask,
          context,
          accumulated,
          pins,
          target.scope,
          real,
        )) {
          extended.push(tuple);
        }
      }
    }
    judged = extended;
  }
  return judged;
}
