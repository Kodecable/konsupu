// Per-context timeline model. One Timeline is built from the propositions
// a single context holds; it knows which events occurred, their order
// (Order.js), and where each anchored state starts and stops. Interval and anchor questions resolve against it
// (Anchors.js). Inertia is explicit class-level knowledge: a state
// started by Initially or an occurred event's ResultsIn holds until
// something ends it — an explicit Ends, or the class rule that a later
// LocatedAt for the same entity ends an earlier one. A state with no
// start anchor holds on the whole timeline; if such a state conflicts
// with an anchored one, that is a fixture fault the solver does not
// reconcile. Input order is never consulted.
import { LocatedAt } from "./Conditions.js";
import { Ends, Initially } from "./Time.js";
import { Occurs, ResultsIn } from "./Relations.js";
import { EventOrder } from "./Order.js";
import { matchValue } from "./Match.js";

export class Timeline {
  constructor(held) {
    this.held = held;
    this.occurred = new Set();
    const results = [];
    const endings = [];
    this.initial = new Set();
    for (const proposition of held) {
      if (proposition instanceof Occurs) this.occurred.add(proposition.event);
      else if (proposition instanceof ResultsIn) {
        results.push(proposition);
      } else if (proposition instanceof Initially) {
        this.initial.add(proposition.state);
      } else if (proposition instanceof Ends) {
        endings.push(proposition);
      }
    }
    // Held-list order is not semantics: anchors register only once every
    // occurrence is known.
    this.starts = new Map();
    for (const proposition of results) {
      if (this.occurred.has(proposition.event)) {
        this.starts.set(proposition.proposition, proposition.event);
      }
    }
    this.ends = new Map();
    for (const proposition of endings) {
      if (this.occurred.has(proposition.event)) {
        if (!this.ends.has(proposition.state)) {
          this.ends.set(proposition.state, []);
        }
        this.ends.get(proposition.state).push(proposition.event);
      }
    }
    this.order = new EventOrder(held);
  }

  before(earlier, later) {
    return this.order.before(earlier, later);
  }

  atOrBefore(earlier, later) {
    return this.order.atOrBefore(earlier, later);
  }

  // The start event of a held state node: null for whole-timeline and
  // initially-holding states, undefined when the node is not held at all.
  startOf(node) {
    if (this.starts.has(node)) return this.starts.get(node);
    if (this.initial.has(node)) return null;
    if (this.held.includes(node)) return null;
    return undefined;
  }

  // The earliest event ending the state, explicit or class-derived. The
  // class rule: a thing is in one place at a time, so a later-anchored
  // LocatedAt for the same entity ends an earlier one — including one
  // that held from the story's start.
  endOf(node) {
    let end = null;
    for (const event of this.ends.get(node) ?? []) {
      if (!this.occurred.has(event)) continue;
      if (end === null || this.before(event, end)) end = event;
    }
    const start = this.startOf(node);
    if (start !== undefined && node instanceof LocatedAt) {
      for (const other of this.carriedNodes()) {
        if (!(other instanceof LocatedAt) || other === node) continue;
        if (other.entity !== node.entity) continue;
        const otherStart = this.startOf(other);
        if (otherStart === null || otherStart === undefined) continue;
        if (start === null || this.before(start, otherStart)) {
          if (end === null || this.before(otherStart, end)) end = otherStart;
        }
      }
    }
    return end;
  }

  holdsPoint(node, event) {
    const start = this.startOf(node);
    if (start !== undefined && start !== null && !this.atOrBefore(start, event)) {
      return false;
    }
    const end = this.endOf(node);
    return end === null || this.before(event, end);
  }

  // Every node the context holds: direct assertions, contents an
  // occurred event's ResultsIn carries, and Initially contents.
  carriedNodes() {
    return [...new Set([...this.held, ...this.starts.keys(), ...this.initial])];
  }

  // Held state nodes matching the pattern, direct, started, or initial.
  stateCandidates(pattern, context) {
    const found = [];
    for (const node of this.carriedNodes()) {
      if (found.includes(node)) continue;
      if (matchValue(pattern, node, new Map(), context)) found.push(node);
    }
    return found;
  }

}
