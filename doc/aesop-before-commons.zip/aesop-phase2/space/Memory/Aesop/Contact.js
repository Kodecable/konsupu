// Bodily contact and dress: bitings at, openings, shuttings, touchings,
// and wearings.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Biting at something in the air or water: field theme. An attempt, not a
// seizing; whether it got anything is separate.
export class SnapAt extends Action {
  static BRAND = Brand("aesop:SnapAt:v1");
  constructor(situated) {
    Final(SnapAt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Making something open: field theme.
export class Open extends Action {
  static BRAND = Brand("aesop:Open:v1");
  constructor(situated) {
    Final(Open, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Making something shut: field theme.
export class Shut extends Action {
  static BRAND = Brand("aesop:Shut:v1");
  constructor(situated) {
    Final(Shut, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Dressing oneself in something, possibly over something else: fields
// theme, over.
export class PutOn extends Action {
  static BRAND = Brand("aesop:PutOn:v1");
  constructor(situated) {
    Final(PutOn, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
