// The Assertion layer: separates a Proposition object from a Situation
// treating it as holding. An Assertion is itself not a Proposition, so
// there is no regress; it is world content, like an Entity or an Event.
// Holding and introducing are separate: the Situation the Assertion sits
// in decides which context holds the proposition, not the Situation the
// proposition object itself sits in (one context may introduce a
// proposition object and another context's Assertion hold it).
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Occurs } from "./Relations.js";

// One occurrence means: the owning Situation holds `proposition` true.
export class Assertion extends SituatedNode {
  static BRAND = Brand("aesop:Assertion:v1");
  constructor(situated) {
    Final(Assertion, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// Explicit fixture helper: push the proposition and an Assertion in the
// holding Situation. The holder defaults to the proposition's own
// Situation; call sites that hold a proposition in another context name
// that context explicitly, so nothing asserts quietly or in the wrong
// place.
export function Assert(input, proposition, holder = proposition.situated) {
  input.push(proposition);
  const assertion = new Assertion(holder);
  assertion.proposition = proposition;
  input.push(assertion);
  return proposition;
}

// Assert that an event actually happened, in the holding Situation.
// Events referenced only by goals, promises, or hypotheses never pass
// through here.
export function AssertOccurs(input, event, holder = event.situated) {
  const occurs = new Occurs(event.situated);
  occurs.event = event;
  return Assert(input, occurs, holder);
}

// Hold in `holder` a proposition already occurring in the Input: pushes
// only the Assertion, never the proposition a second time. This is the
// holding-and-introducing split made explicit at a call site.
export function Hold(input, proposition, holder) {
  const assertion = new Assertion(holder);
  assertion.proposition = proposition;
  input.push(assertion);
  return proposition;
}

// Whether `proposition` is held true in the perspective's visible
// cognition. Semantically: some visible Assertion names exactly this
// proposition object.
export function IsAsserted(view, proposition) {
  return view.Bindings(proposition).some((node) => {
    return node instanceof Assertion && node.proposition === proposition;
  });
}
