// Emotion states. An emotion is a state of the one feeling it; its cause
// is a separate cognition and is whatever the story says moved it —
// typically a belief or a perception, not the world fact itself.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Condition } from "./Conditions.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Suffering fear: field subject.
export class Frightened extends Condition {
  static BRAND = Brand("aesop:Frightened:v1");
  constructor(situated) {
    Final(Frightened, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Envying what another has: field subject.
export class Jealous extends Condition {
  static BRAND = Brand("aesop:Jealous:v1");
  constructor(situated) {
    Final(Jealous, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Being without company: field subject.
export class Lonely extends Condition {
  static BRAND = Brand("aesop:Lonely:v1");
  constructor(situated) {
    Final(Lonely, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Great gladness: field subject.
export class Overjoyed extends Condition {
  static BRAND = Brand("aesop:Overjoyed:v1");
  constructor(situated) {
    Final(Overjoyed, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
