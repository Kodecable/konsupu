// Reading other contexts and asking yes-no questions. A question never
// climbs into a context structurally: it names the context (directly when
// the story has exactly one, or through a bound Variable an attitude
// constraint resolved) and then matches content against what that context
// holds. Yes-no questions attach the truth of one proposition to a
// Variable (draft §2.6) and read the structured verdict — yes / no /
// not-established / conflict — as an ordinary value through the Reply.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// `proposition` holds in `context`: fields context, proposition. The
// proposition is an asked pattern (or the answer Variable itself, to
// retrieve a whole held node) matched by content against only the
// Assertions the context itself holds; mentioning world individuals does
// not let a context see what the world holds.
export class HoldsIn extends Proposition {
  static BRAND = Brand("aesop:HoldsIn:v1");
  constructor(situated) {
    Final(HoldsIn, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A yes-no question: fields content, verdict, and optional when (an
// anchor, Time.js) and context (a Situation or a bound Variable). The
// verdict is the answer Variable; its resolved value is Yes() when the
// content is supported in the evaluation context at the anchor, No()
// when a held negation of any form supports its complement, both
// (Conflict()), or neither (NotEstablished). A presupposition inside the
// content that fails leaves the question NotEstablished, not No.
export class AskWhether extends Proposition {
  static BRAND = Brand("aesop:AskWhether:v1");
  constructor(situated) {
    Final(AskWhether, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
