// How a negation's scope covers a question: window containment over
// the dense line the chain orders, pattern coverage of a description,
// and when an ended state is negated from its ending on. A window is
// one of: null (the whole line), "from" [event, end), "before"
// [begin, event), "until" [event, next) — the n-th's episode, closed by
// the (n+1)-th — or "during" a while-state's intervals. A negation
// window [from, until] covers a question window only when it contains
// every moment of it: "before E" demands the negation reach back to
// the beginning; an episode window demands it reach past the closer.
import { TheEnd, TheBeginning, PriorTo, After, Nth, While } from "./Time.js";
import { matchValue, fieldValue, fieldsOf, SURFACE } from "./Match.js";
import { sameValue } from "./Values.js";
import { resolveNth } from "./Anchors.js";
import { Node, Proposition } from "../../Interface/Nodes.js";

// An ended state is negated from its ending on. PriorTo / After read
// the dense line the chain orders, not only the events themselves.
function endNegatesAt(timeline, endEvent, when) {
  if (when === null || when === undefined) return false;
  if (when === TheEnd) return true;
  if (when === TheBeginning) return false;
  if (when instanceof PriorTo) {
    return timeline.before(endEvent, when.event);
  }
  if (when instanceof After) {
    return timeline.atOrBefore(endEvent, when.event);
  }
  return timeline.atOrBefore(endEvent, when);
}

// Whether a negating window [from, until] covers the question's window.
function windowCovers(timeline, from, until, window) {
  if (window === null) {
    return from == null && until === TheEnd;
  }
  if (window.kind === "none") return false;
  if (window.kind === "before") {
    // The whole span strictly before the bound: only a negation that
    // holds from the beginning and past the bound covers it.
    if (from != null) return false;
    if (until === TheEnd) return true;
    return timeline.atOrBefore(window.event, until);
  }
  if (window.kind === "from") {
    if (from != null && !timeline.atOrBefore(from, window.event)) return false;
    return until === TheEnd;
  }
  if (window.kind === "until") {
    if (from != null && !timeline.atOrBefore(from, window.event)) return false;
    if (until === TheEnd) return true;
    if (window.until === null) return false;
    return !timeline.before(until, window.until);
  }
  // "during": every interval of the while-state must be covered, each
  // read as the window it is.
  let any = false;
  for (const interval of window.intervals) {
    any = true;
    let sub;
    if (interval.start === null && interval.end === null) sub = null;
    else if (interval.start === null) sub = { kind: "before", event: interval.end };
    else if (interval.end === null) sub = { kind: "from", event: interval.start };
    else sub = { kind: "until", event: interval.start, until: interval.end };
    if (!windowCovers(timeline, from, until, sub)) return false;
  }
  return any;
}

// Whether a story pattern covers a question description: every event the
// question could name also matches the pattern.
function covers(pattern, description, context) {
  if (!(description instanceof pattern.constructor)) return false;
  const bindings = new Map();
  for (const [key, value] of fieldsOf(pattern)) {
    if (!matchValue(value, fieldValue(description, key), bindings, context)) {
      return false;
    }
  }
  return true;
}

// Whether the moment `when` lies inside a negation's window [from,
// until): an event, just before / just after one, an ordinal's event,
// the beginning, or the end. A While stretch is never claimed covered.
function pointCovered(timeline, from, until, when, context) {
  if (when === null || when === undefined) {
    return from == null && until === TheEnd;
  }
  if (when === TheBeginning) return from == null;
  if (when === TheEnd) return until === TheEnd;
  if (when instanceof While) return false;
  if (when instanceof PriorTo) {
    return (
      (from == null || timeline.before(from, when.event)) &&
      (until === TheEnd || timeline.atOrBefore(when.event, until))
    );
  }
  const event =
    when instanceof Nth ? resolveNth(timeline, when, context)
    : when instanceof After ? when.event
    : when;
  if (event === null) return false;
  return (
    (from == null || timeline.atOrBefore(from, event)) &&
    (until === TheEnd || timeline.before(event, until))
  );
}

// Whether a negated existence covers a question's state content: its
// quantified individuals are shapes (class + written fields, never a
// surface name), every other node is itself — "no wolf present" covers
// "a wolf present" and "the wolf present", never "a sheep present". A
// stand-in from another context is read as itself.
function coversState(negation, value, context) {
  return coversNode(negation.pattern, value, context, new Set(negation.some ?? []));
}

function coversNode(pattern, value, context, open) {
  value = context.standIn?.get(value) ?? value;
  if (!(pattern instanceof Node)) return sameValue(pattern, value);
  if (pattern === value) return true;
  if (!open.has(pattern) && !(pattern instanceof Proposition)) return false;
  if (!(value instanceof pattern.constructor)) return false;
  return fieldsOf(pattern).every(([key, item]) => {
    if (SURFACE.has(key)) return true;
    return coversNode(item, fieldValue(value, key), context, open);
  });
}

export { endNegatesAt, windowCovers, covers, pointCovered, coversState };
