// Dialogue cognition. The asking situation of a dialogue names the story
// world it is about and the asked Situation that refines it; the reply is
// the requested doing whose content is the already-resolved answer value.
// Reply is deliberately not Says: story speech says a Situation, the reply
// utters a value, and one relation keeps one canonical form.
import {
  Brand,
  Final,
  SituatedNode,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

// Fields story, asked. This is what gives both Situations their semantic
// mention.
export class Asks extends SituatedNode {
  static BRAND = Brand("aesop:Asks:v1");
  constructor(situated) {
    Final(Asks, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}

// The requested reply of a dialogue: field content (the resolved answer
// value, read through a ref). Being requested does not make it occur, and
// its content is a value, never a held proposition.
export class Reply extends Action {
  static BRAND = Brand("aesop:Reply:v1");
  constructor(situated) {
    Final(Reply, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    ReportDataMembers(this, visit);
  }
}
