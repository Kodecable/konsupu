// Condition propositions: states and claim contents that can hold in a
// context. They participate in Queries through "held" semantics: directly
// asserted, or carried as the result content of an asserted ResultsIn.
// Every condition class extends the abstract Condition, so the solver
// recognizes a new one by its class, not by a list. Changeable states are
// time-anchored (see Time.js); a directly asserted condition with no
// anchor holds on the context's whole timeline.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// A state that can hold; abstract.
export class Condition extends Proposition {
  static BRAND = Brand("aesop:Condition:v1");
  constructor(situated) {
    if (new.target === Condition) throw new TypeError("Condition is abstract");
    super(situated);
  }
}

// Where something is: fields entity, place.
export class LocatedAt extends Condition {
  static BRAND = Brand("aesop:LocatedAt:v1");
  constructor(situated) {
    Final(LocatedAt, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Suffering thirst: field subject.
export class Thirsty extends Condition {
  static BRAND = Brand("aesop:Thirsty:v1");
  constructor(situated) {
    Final(Thirsty, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Sleeping: field subject.
export class Asleep extends Condition {
  static BRAND = Brand("aesop:Asleep:v1");
  constructor(situated) {
    Final(Asleep, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// No longer bound: field subject.
export class Free extends Condition {
  static BRAND = Brand("aesop:Free:v1");
  constructor(situated) {
    Final(Free, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Amused by something: fields subject, at.
export class Tickled extends Condition {
  static BRAND = Brand("aesop:Tickled:v1");
  constructor(situated) {
    Final(Tickled, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The flattery claim — voice outshining others: fields subject, others.
export class VoiceSurpasses extends Condition {
  static BRAND = Brand("aesop:VoiceSurpasses:v1");
  constructor(situated) {
    Final(VoiceSurpasses, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// The advice content — flatterers must not be trusted.
export class DistrustFlatterers extends Condition {
  static BRAND = Brand("aesop:DistrustFlatterers:v1");
  constructor(situated) {
    Final(DistrustFlatterers, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Cannot do the deed: fields actor, deed (an event shape, never a
// referent). Distinct from the deed not happening, and from its
// complement Not{Unable{...}} = "can"; it is a changeable state, so it
// starts and ends on events like any other condition.
export class Unable extends Condition {
  static BRAND = Brand("aesop:Unable:v1");
  constructor(situated) {
    Final(Unable, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Being there on the scene: field subject. The wolf was there when it had
// come out; its Not{Present} is what made the first two cries false.
export class Present extends Condition {
  static BRAND = Brand("aesop:Present:v1");
  constructor(situated) {
    Final(Present, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Being gone from the scene: field subject. "While the lion was away" is
// this state's interval.
export class Away extends Condition {
  static BRAND = Brand("aesop:Away:v1");
  constructor(situated) {
    Final(Away, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
