// Normative and propositional content vocabulary, held by whoever says or
// decrees it — usually a speech context. These are contents, not world
// facts: a prohibition in a speech context never negates a world question
// by itself.
import {
  Brand,
  Final,
  Proposition,
  ReportDataMembers,
} from "../../Interface/Nodes.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// A deed is forbidden: field deed (an event shape). "No beast may hurt a
// bird", "Woe betide you if you touch my prey".
export class Forbids extends Proposition {
  static BRAND = Brand("aesop:Forbids:v1");
  constructor(situated) {
    Final(Forbids, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Content is enjoined: field content ("all shall dwell together in
// brotherly friendship"). The positive counterpart of Forbids.
export class Mandates extends Proposition {
  static BRAND = Brand("aesop:Mandates:v1");
  constructor(situated) {
    Final(Mandates, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// A conditional: `antecedent` (an event shape) brings `consequence`: the
// nurse's threat. The consequence is content, not a promise; nothing in
// the world says the antecedent triggers it.
export class Conditional extends Proposition {
  static BRAND = Brand("aesop:Conditional:v1");
  constructor(situated) {
    Final(Conditional, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Putting a proposal to someone: fields proposer, to, proposal. An
// alliance offered, advice given, a suggestion made — content whose being
// made is not its being accepted.
export class Proposes extends Proposition {
  static BRAND = Brand("aesop:Proposes:v1");
  constructor(situated) {
    Final(Proposes, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
