// The positive side of yes-no evaluation: how the evaluation context
// supports the content — a state candidate holding at the anchor, an
// occurred event inside the window, an agent relation whose action
// actually happened in time, and the positive reading of a Not content
// (a matching state's ending negates it from there on, explicit or
// class-derived). Bindings arrive already scope-filtered by Verdicts.js,
// so a pattern the join bound to another context's node still matches
// this evaluation context's own nodes by content.
import { matchValue } from "./Match.js";
import { Not, NoneSuch } from "./Negation.js";
import { TheEnd } from "./Time.js";
import { Agent, Occurs } from "./Relations.js";
import { anchorWindow, eventsMatching, holdsAt, inWindow } from "./Anchors.js";
import { endNegatesAt, pointCovered, coversState } from "./Covering.js";

export function stateTuples(timeline, content, when, context, bindings) {
  const tuples = [];
  for (const candidate of timeline.stateCandidates(content, context)) {
    const trial = new Map(bindings);
    if (!matchValue(content, candidate, trial, context)) continue;
    if (holdsAt(timeline, candidate, when, context)) tuples.push(trial);
  }
  return tuples;
}

export function positiveOf(timeline, content, when, context, bindings) {
  const tuples = [];
  if (content instanceof Not) {
    // A state ended by an event is positively negated from there on:
    // asking "not S" after the end is answered yes.
    for (const candidate of timeline.stateCandidates(content.proposition, context)) {
      const trial = new Map(bindings);
      if (!matchValue(content.proposition, candidate, trial, context)) continue;
      const end = timeline.endOf(candidate);
      if (end !== null && endNegatesAt(timeline, end, when)) tuples.push(trial);
    }
    // "Was there no wolf?": a held negated existence covering the inner
    // content at that moment supports the negative content itself.
    for (const proposition of timeline.carriedNodes()) {
      if (!(proposition instanceof NoneSuch)) continue;
      const { from, until } = proposition;
      if (
        coversState(proposition, content.proposition, context) &&
        pointCovered(timeline, from, until ?? TheEnd, when, context)
      ) {
        tuples.push(new Map(bindings));
      }
    }
    return tuples.concat(stateTuples(timeline, content, when, context, bindings));
  }
  if (content instanceof Agent) {
    // "Did the actor do it" is an occurrence question: the world must
    // hold the agent relation, the action must have happened, and it
    // must lie inside the anchor's window.
    const window = anchorWindow(timeline, when, context);
    if (window?.kind === "none") return tuples;
    for (const proposition of timeline.carriedNodes()) {
      if (!(proposition instanceof Agent)) continue;
      const trial = new Map(bindings);
      if (!matchValue(content, proposition, trial, context)) continue;
      if (!timeline.occurred.has(proposition.action)) continue;
      if (!inWindow(timeline, proposition.action, window)) continue;
      tuples.push(trial);
    }
    return tuples;
  }
  if (content instanceof Occurs) {
    const window = anchorWindow(timeline, when, context);
    if (window?.kind === "none") return tuples;
    for (const event of eventsMatching(timeline, content.event, context, window)) {
      const trial = new Map(bindings);
      if (matchValue(content.event, event, trial, context)) tuples.push(trial);
    }
    return tuples;
  }
  return stateTuples(timeline, content, when, context, bindings);
}
