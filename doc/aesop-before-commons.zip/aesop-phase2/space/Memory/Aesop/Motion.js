// Locomotion vocabulary: comings, goings, and ways of moving. The split
// between Motion.js and Moves.js is only the line budget; both hold the
// same kind of vocabulary.
import {
  Brand,
  Final,
  ReportDataMembers,
} from "../../Interface/Nodes.js";
import { Action } from "./Objects.js";

function report(visit) {
  ReportDataMembers(this, visit);
}

// Getting across something: field what.
export class Cross extends Action {
  static BRAND = Brand("aesop:Cross:v1");
  constructor(situated) {
    Final(Cross, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Coming out, from somewhere: field source.
export class ComeOut extends Action {
  static BRAND = Brand("aesop:ComeOut:v1");
  constructor(situated) {
    Final(ComeOut, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Coming up to somewhere: field destination.
export class ComeTo extends Action {
  static BRAND = Brand("aesop:ComeTo:v1");
  constructor(situated) {
    Final(ComeTo, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Coming back: field theme.
export class ComeBack extends Action {
  static BRAND = Brand("aesop:ComeBack:v1");
  constructor(situated) {
    Final(ComeBack, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Coming to someone's aid: field theme (the one helped).
export class ComeToHelp extends Action {
  static BRAND = Brand("aesop:ComeToHelp:v1");
  constructor(situated) {
    Final(ComeToHelp, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Leaving the scene: field theme.
export class GoAway extends Action {
  static BRAND = Brand("aesop:GoAway:v1");
  constructor(situated) {
    Final(GoAway, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Turning to leave: field manner.
export class TurnAway extends Action {
  static BRAND = Brand("aesop:TurnAway:v1");
  constructor(situated) {
    Final(TurnAway, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Rushing away at speed: field theme.
export class GallopAway extends Action {
  static BRAND = Brand("aesop:GallopAway:v1");
  constructor(situated) {
    Final(GallopAway, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Rushing out of a place: field theme.
export class RushOut extends Action {
  static BRAND = Brand("aesop:RushOut:v1");
  constructor(situated) {
    Final(RushOut, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Walking in an unhurried way: field theme.
export class Stroll extends Action {
  static BRAND = Brand("aesop:Stroll:v1");
  constructor(situated) {
    Final(Stroll, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Going along behind someone: field theme.
export class Follow extends Action {
  static BRAND = Brand("aesop:Follow:v1");
  constructor(situated) {
    Final(Follow, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}

// Guiding someone along: field theme.
export class Lead extends Action {
  static BRAND = Brand("aesop:Lead:v1");
  constructor(situated) {
    Final(Lead, new.target);
    super(situated);
  }
  ReportReferences(visit) {
    report.call(this, visit);
  }
}
