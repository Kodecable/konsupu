// Plain-value helpers: equality for non-Variable values and the join of
// binding tuples. Nodes always compare by identity here.
import { isUnknown, sameUnknown } from "./Outcomes.js";

// Equality for non-Variable values: identity first, then Arrays and plain
// records by content. An Unknown equals only an Unknown of the same
// unstated field; Maps, Sets, and Nodes compare by identity.
export function sameValue(left, right) {
  if (left === right) return true;
  if (isUnknown(left) || isUnknown(right)) return sameUnknown(left, right);
  if (Array.isArray(left) && Array.isArray(right)) {
    return (
      left.length === right.length &&
      left.every((item, index) => sameValue(item, right[index]))
    );
  }
  if (isRecord(left) && isRecord(right)) {
    const leftKeys = Object.keys(left).sort();
    const rightKeys = Object.keys(right).sort();
    return (
      leftKeys.length === rightKeys.length &&
      leftKeys.every(
        (key, index) =>
          key === rightKeys[index] && sameValue(left[key], right[key]),
      )
    );
  }
  return false;
}

// An ordinary object literal: Maps, Sets, Nodes, and other class instances
// are not records and keep identity comparison in patterns.
export function isRecord(value) {
  if (value === null || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

// Join binding tuples on shared keys (Variables and descriptions);
// contradictory values or correspondents drop out.
export function join(leftTuples, rightTuples) {
  const merged = [];
  for (const left of leftTuples) {
    for (const right of rightTuples) {
      const tuple = new Map(left);
      let consistent = true;
      for (const [key, value] of right) {
        if (tuple.has(key) && !sameValue(tuple.get(key), value)) {
          consistent = false;
          break;
        }
        tuple.set(key, value);
      }
      if (consistent) merged.push(tuple);
    }
  }
  return merged;
}
