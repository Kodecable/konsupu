// Public surface of the Aesop story-world cognition for case fixtures,
// grouped by semantic domain. Concrete classes plus the explicit Assert
// helpers; the abstract bases are exported for testing. Solver internals
// (Search, Match, Project) are not exposed here.
export { Entity, Event, Action, Says, Fall, Rise, Wake, GetTrapped, Get, Series, context } from "../Memory/Aesop/Objects.js";
export { Asks, Reply } from "../Memory/Aesop/Dialogue.js";
export { ComeUpon, Put, TryToDrink, ThinkUp, Drop, Quench, Save, FlyOff, Settle, WalkUpTo, Sing, SnapUp } from "../Memory/Aesop/Actions.js";
export { RunUpon, Seize, Spare, Tie, SearchFor, Carry, PassBy, Gnaw, Help, Eat } from "../Memory/Aesop/Deeds.js";
export { Cross, ComeOut, ComeTo, ComeBack, ComeToHelp, GoAway, TurnAway, GallopAway, RushOut, Stroll, Follow, Lead } from "../Memory/Aesop/Motion.js";
export {
  JumpDown,
  JumpOn,
  JumpUp,
  GetOut,
  Prowl,
  Crouch,
  Wait,
  Hunt,
  GetAt,
  Toss,
  HeadTo,
} from "../Memory/Aesop/Moves.js";
export { SnapAt, Open, Shut, PutOn } from "../Memory/Aesop/Contact.js";
export { Touch, Pounce, Worry, Hurt, Throw, Cry, CryOut, CallForHelp } from "../Memory/Aesop/Encounter.js";
export { Declare, Advise, Dwell, Find, DigUp, Gloat, Enter, Lay, Congratulate } from "../Memory/Aesop/Errands.js";
export { See, Notice, Hear, HeardOf, LookClosely } from "../Memory/Aesop/Perception.js";
export { Has, BelongsTo, Missing, Empty, Wears, Carrying, Take, Hide, Steal } from "../Memory/Aesop/Possession.js";
export {
  Occurs,
  Agent,
  Before,
  Next,
  Overlaps,
  Enables,
  Causes,
  ResultsIn,
  Failed,
  Goal,
  InOrderTo,
} from "../Memory/Aesop/Relations.js";
export { Motivates, Promise, Believes, About, Fears, Plans, Approves, Deceives } from "../Memory/Aesop/Attitudes.js";
export { ByChance, Means } from "../Memory/Aesop/Chance.js";
export { Among, SameReferent } from "../Memory/Aesop/Correspondence.js";
export { Condition, LocatedAt, Thirsty, Asleep, Free, Tickled, VoiceSurpasses, DistrustFlatterers, Unable, Present, Away } from "../Memory/Aesop/Conditions.js";
export { Frightened, Jealous, Lonely, Overjoyed } from "../Memory/Aesop/Emotions.js";
export { Initially, Ends, HoldsWhen, PriorTo, After, While, Nth, Lasted, TheEnd } from "../Memory/Aesop/Time.js";
export { Not, NoEvent, NoneSuch, OnlyDid } from "../Memory/Aesop/Negation.js";
export { Kind } from "../Memory/Aesop/Kinds.js";
export { Forbids, Mandates, Conditional, Proposes } from "../Memory/Aesop/Norms.js";
export { Habitual, Instance } from "../Memory/Aesop/Habits.js";
export { Buy, Sell } from "../Memory/Aesop/Trade.js";
export { Drought } from "../Memory/Aesop/Weather.js";
export { HoldsIn, AskWhether } from "../Memory/Aesop/Asking.js";
export { Assert, AssertOccurs, Hold } from "../Memory/Aesop/Assertion.js";
