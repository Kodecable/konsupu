# Konsupu Aesop Phase 2 — 结果记录

以 `run/aesop-phase1r4/`（r4）为直接基线、Foundation 更新为 2026-10-02 修订版
（跨 Situation 引用规则）的一轮：时间、否定、欺骗、认知偏离。运行方式：

```sh
node regression.mjs   # Foundation/domain regression tests: 96/96 passed
node run.mjs          # Foundation/domain regression tests: 96/96 passed
                      # Aesop questions: 65/65 passed
node mutation.mjs     # 23 条定向变异，各自至少击穿一项非字节一致性回归
```

以上为当前（Phase 2r6）数字。本文按修订轮次叠加记录：前半的逐题表与
各篇说明写于首轮，r2–r6 各节的修订优先于前文；逐题表中已被后续修订
改写的少数条目已就地标注。

不经过 Konsupu Runtime / Translation / Learning；Foundation 为冻结 substrate
（`space/Memory/Foundation/`、`space/Test*`、`space/Test.js`、`space/Resolve.js`、
`space/Interface/Nodes.js`、`space/Interface/Outputs.js` 与 `src/foundation/`
逐字节一致，且由回归 `foundation: the copied source is byte-identical to src`
在运行时持续核对；零修改）。r1–r4 目录原样保留；r4 的字节一致性回归自
2026-10-02 起按设计失败（41/42），其余 41 项与 15 题在 r4 目录内仍然通过。

## 基线与结构

- 复制 r4 为 `run/aesop-phase2/`；Foundation 六处用当前 `src/foundation/`
  覆盖（见上）；领域文件（`Memory/Aesop/`、`Interface/Aesop.js`、`Memory/`
  四个入口）从 r4 演化。
- 每个 case 的结构：`dialogue`（root，Input 第一个）→ `world`（root，
  叙述者陈述为实际的认知）→ 语境 root（B/S/P/F/…，各自持有自己的内容，
  直接提及 world 个体，也可引入只属于自己的对象）→ `asked`（world 的子，
  每题一个）。语境之间没有细化关系；语境的意义由 world 中引入它的态度/
  言语命题表达（`Believes`/`Fears`/`Plans`/`Says.content`），该命题同时给
  它语义提及。持有与引入分开：`Assert(input, p, holder)` 的 holder 参数与
  `Hold` 辅助显式指定持有语境（回归 28）。
- 回复链路 `Imperative(KonsupuIdentity.Ref(), Reply)`；故事言语 `Says`
  的 content 统一为 Situation（语境），回复用独立的 `Reply` 类——
  `Says.content` 不再有第二种表示（完成标准之一）。

## 故事选择（10 篇新故事，第六节覆盖矩阵照录）

| # | 故事 | 源文件 |
|---|---|---|
| 4 | The Dog and the Shadow | `run/simple-aesop-dataset/03-the-dog-and-the-shadow.txt` |
| 5 | The Fox and the Mask | `20-the-fox-and-the-mask.txt` |
| 6 | The Miser and His Gold | `62-the-miser-and-his-gold.txt` |
| 7 | The Milkmaid and Her Pail | `77-the-milkmaid-and-her-pail.txt` |
| 8 | The Nurse and the Wolf | `46-the-nurse-and-the-wolf.txt` |
| 9 | The Wolf in Sheep's Clothing | `39-the-wolf-in-sheep-s-clothing.txt` |
| 10 | The Shepherd's Boy | `43-the-shepherd-s-boy.txt` |
| 11 | The Fox and the Goat | `82-the-fox-and-the-goat.txt` |
| 12 | The Ass's Brains | `74-the-ass-s-brains.txt` |
| 13 | The Fox, the Cock, and the Dog | `59-the-fox-the-cock-and-the-dog.txt` |

无候补替换；10 篇全部按计划实现。

## 65 题逐题结果

问题文本冻结自指导第六节。表中"语义 expected"为指导给出的语义；
"机器 expected"为实现时确定、与语义一致的投影；全部实际输出与机器
expected 逐字符相等（normalize 后比较，run.mjs 判定）。主要认知关系列
出该题求解走到的关键类。

### Story 1 — The Crow and the Pitcher（迁移，expected 不变）

| 题 | 机器 expected | 主要关系 |
|---|---|---|
| Who dropped a pebble into the pitcher? | `Entity(the crow)` | Drop 描述 + Among + Occurs + Agent |
| What happened after the crow put its beak into the pitcher? | `TryToDrink(theme=Entity(the water))` | Next |
| Why did the water mount up? | `Series(parts=[Drop(...),Drop(...)])` | Causes |
| What was the crow able to do after the water mounted up? | `Quench(theme=Entity(its thirst))` | Enables + Before |
| Where did the pebble end up after the crow dropped it? | `Entity(the pitcher)` | ResultsIn(LocatedAt) |

迁移：`OutOfReach(water)` → `Unable{crow, deed: GetAt{water}}`，
`ResultsIn{putBeak, unable}` 起、`Ends{castMore, unable}` 止（"he could
not reach far enough down to get at it"/"after casting in a few more
pebbles he was able to"；终点见 r2 第 3 节，deed 见 r5 第 3 节）；`Thirsty` → `Initially` 起、
`Ends{drink, thirsty}` 止。"had once been full of water" 是故事开始前的
状态，不表示（指导第七节）。

### Story 2 — The Fox and the Crow（迁移，S2Q3 expected 不变）

| 题 | 机器 expected | 主要关系 |
|---|---|---|
| What fell to the ground? | `Entity(the cheese)` | Fall 描述 + Among + Occurs |
| What happened when the crow began to sing? | `Fall(destination=Entity(the ground),theme=Entity(the cheese))` | Next |
| What did the crow believe about her voice? | `VoiceSurpasses(others=Entity(other birds),subject=Entity(the crow))` | Believes(语境) + HoldsIn + About |
| What did the fox want to get? | `Entity(the cheese)` | Get 开放类 + Among + Goal |
| Who made the cheese fall? | `Entity(the crow)` | Causes + Agent 联合 |

迁移：奉承内容 `VoiceSurpasses` 由狐狸言语语境 S 引入并持有（说了≠world
成立）；乌鸦信念语境 B 用自己的 `Assertion` 持有同一命题对象（持有与引入
分开的示范，回归 28）。`Veracity(claimVoice, false)` 删除——**P6 审查**：
原文只有奉承，没有任何"乌鸦嗓音不好"的陈述，无依据即删。奶酪两处
LocatedAt 维持 ResultsIn 锚定（时间回归 6 用它们）。

### Story 3 — The Lion and the Mouse（迁移，S3Q3 expected 改变）

| 题 | 机器 expected | 主要关系 |
|---|---|---|
| Who gnawed away the ropes? | `Entity(the mouse)` | Agent |
| What did the hunters do after the lion got caught in the trap? | `Tie(destination=Entity(the tree),theme=Entity(the lion))` | Next + Agent |
| Why did the lion spare the mouse? | `Tickled(at=Believes(believer=Entity(the lion),content=Context(the Mouse being able to help him)),subject=Entity(the lion))` | Motivates |
| What did the mouse promise to do for the lion? | `Help(theme=Entity(the lion))` | Promise |
| Why did the hunters tie the lion to the tree? | `Carry(destination=Entity(the king),theme=Entity(the lion))` | InOrderTo |

**S3Q3 expected 变更理由**：r2 记录的 offer 名义化问题（"the mouse's
offer" 实体）按指导第七节改为 idea 语境——狮子相信的语境 L（标题
"the Mouse being able to help him"），内容为能力肯定
`Not{Unable{mouse, Help{lion}}}`；Tickled.at 指向该 Believes 命题。语义
不变（为"这个念头"所动），投影从名义化实体变为态度命题。

### Story 4 — The Dog and the Shadow

| 题 | 语义 expected | 机器 expected | 主要关系 |
|---|---|---|---|
| What did the dog think his shadow was? | 另一只狗（指导原文多出"叼着另一块肉"，已确认为指导错误） | `Entity(another dog)` | Believes + HoldsIn(SameReferent) |
| What did the dog really see in the water? | 他自己的影子 | `Entity(his own shadow reflected in the water)` | See 描述 + Among + Occurs + Agent |
| Where was the piece of meat before the dog snapped at the shadow? | 狗的嘴里 | `Entity(the dog's mouth)` | HoldsWhen(LocatedAt, PriorTo) |
| Where did the piece of meat end up? | 水里 | `Entity(the water beneath)` | HoldsWhen(LocatedAt, TheEnd) |
| Why did the dog snap at the shadow? | 想把另一块肉也弄到手 | `Get(theme=Entity(another piece of meat))` | InOrderTo |

对照题（regression）：`Did the dog get the other piece of meat?` →
未确立；`Did anyone deceive the dog?` → 未确立（误信不蕴含欺骗，回归 19）。

**Q1 投影判断**：语义 expected 的值是"另一只狗,叼着另一块肉"。机器值为
信念语境中影子的对应者 `Entity(another dog)`，即被指称的对象；"叼着另一块
肉"是该对象在信念 B 中的刻画（B 持有 `Carrying{carrier: otherDog, theme:
otherMeat}`），机器投影**不包含**这一半。r3 之前 asked 额外持有一条
Carrying 约束，它不起区分作用、题面也没有，已删去（Phase 2r4）。
**已确认（r6）**：接受现状。指导的语义 expected 有误：题目问的是狗把影子
当成了什么，没有问那只狗在做什么。语义 expected 改为"另一只狗"；
"叼着另一块肉"是该对象在信念 B 中的刻画，仍由 B 持有，可经 Interface
读出，但不属于本题答案。

### Story 5 — The Fox and the Mask

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| What did the fox at first take the mask to be? | 一张正俯视着瞪着他的脸 | `Entity(a face glaring down on him)` | Believes + HoldsWhen(PriorTo) + HoldsIn(SameReferent) |
| Why was the fox frightened? | 他以为有一张脸在瞪着他 | `Believes(believer=Entity(the fox),content=Context(a face was glaring down on him))` | Causes |
| After looking more closely, did the fox still think a face was glaring down on him? | 否 | `{result=no}` | AskWhether(context: 信念, SameReferent) |
| How did the fox get into the store-room? | 未知("by some means") | `{result=unknown}` | Means(未写方式) |
| What did the fox say the mask did not have? | brains | `Entity(brains)` | Says + HoldsIn(Not(Has)) |

对照：`When the fox first observed it, did he think a face was glaring down on
him?` → 是。信念修正 = 两个 Believes 各自区间（B1[observe..lookClose)、
B2[lookClose..∞)，B2 持有 Not{SameReferent}（"only a Mask" 词汇蕴含）。
Q4：world 持有 `Causes{effect: enterStore}` 而不写 cause——"by some means"
说明有方式但未言明，读 UnstatedField → Unknown（区别于无支持）。

### Story 6 — The Miser and His Gold

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| Where did the miser use to hide his gold? | 花园里一棵树的树脚下 | `Entity(the foot of a tree in his garden)` | Habitual(Hide 描述形状) |
| How often did the miser dig up his gold? | 每周 | `Entity(every week)` | Habitual.frequency |
| Who took the gold? | the robber | `Entity(a robber)` | Get 开放类 + Among + Occurs + Agent（Steal extends Get） |
| What did the miser find when he next came to gloat over his treasures? | 那个空洞 | `Entity(the empty hole)` | Find + Agent + Next(到来〔描述：Instance 实例 + InOrderTo(Gloat)〕) |
| According to the miser, did he ever take any of the gold out? | 否（其言语语境中） | `{result=no}` | Says + AskWhether(context: M, Occurs(Take)) |

对照：`Did the miser ever take any of the gold out?`（world）→ 未确立；
`Was the gold in the hole when the miser next came?` → 否（`Empty{hole}`
自 robSteal 起 + 类级规则"空容器内无物"）。M（吝啬鬼的回答）持有
`NoEvent{pattern: Take{gold, hole}}`（"Nay" 展开为对邻居问句命题的否定，
"ever" 范围=全时间线）与 `OnlyDid{actor: miser, theme: gold, deeds:
[See(gold)]}`（"I only came to look at it"）——N5 按穷尽本身表示，否定由
求解器推出；问句命题 pattern 由邻居问句语境 N 引入，M 直接引用该对象。
Q4 的"next"：`Instance{digHabit, miserVisit}` 显式连接习惯与单次事件
（回归 9）。

### Story 7 — The Milkmaid and Her Pail

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| What did Patty plan to buy with the money from the milk? | 一些家禽(from Farmer Brown) | `Entity(some fowls)` | Plans + HoldsIn(Enables{Sell(milk) → Buy}) |
| Who did Patty imagine would be jealous of her? | Polly Shaw | `Entity(Polly Shaw)` | Plans + HoldsIn(Jealous) |
| Did Patty buy any fowls? | 未确立 | `{constraints=[AskWhether],level=instance,result=not-established}` | AskWhether(Occurs(Buy)) |
| What did Patty do just before the pail fell off her head? | 向后甩头(实际那一次) | `Toss(manner=back,theme=Entity(her head))` | Next |
| Where was the pail before Patty tossed her head back? | 她头上 | `Entity(her head)` | HoldsWhen(LocatedAt, PriorTo) |

对照：`Did Patty toss her head?` → 是（world 中的甩头）；`In Patty's plan,
what would the fowls do each morning?` → `Lay(theme=Entity(eggs))`
（HoldsIn(Habitual.deed=answer)）。计划语境 P 同时由 Plans 态度与说出该盘
算的 Says 引入；P 内部持有 Occurs（想象中的发生）与 Habitual，均不进入
world 的 Next 链（回归 5：P 中的 Toss 在 world 问 Occurs → 未确立）。

### Story 8 — The Nurse and the Wolf

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| Who was the nurse speaking to when she mentioned the wolf? | the child | `Entity(the child)` | Says.to + HoldsIn(Conditional 后件 Throw.to=wolf) |
| What did the wolf hope to eat? | the child | `Entity(the child)` | Believes + HoldsIn(Goal(Eat)) |
| Did the child make the noise again? | 是 | `{result=yes}` | AskWhether(Agent(Cry 形状, child), After(警告)) |
| When the child began to cry, did the nurse throw it to the wolf?（r4 改题） | 否 | `{result=no}` | AskWhether(Agent, when=孩子的哭〔描述〕) + OnlyDid[哭起] |
| Why did the wolf crouch down by the house and wait? | 他预期孩子很快会哭、会被扔给他 | `Believes(believer=Entity(the Wolf),content=Context(the child would soon cry and be thrown to him))` | Motivates |

对照：`Did anyone promise the wolf the child?` → 未确立（wolf 结尾自呼
promise 不构成承诺认知）；`Did the nurse call for help?` → 是（OnlyDid
列表内发生）。护士威胁 = 言语语境 N 持有 `Conditional{antecedent:
Cry(描述), consequent: Throw{child, to: wolf}}`；狼的预期语境 W 持有
`Occurs{crySoon}`、`Occurs{throwChild}`（直接引用 N 的 throwChild——跨
语境常量引用）与 `Goal{wolf, Eat{child}}`；crouch/wait 由 `Motivates{
driver: Believes, action}` 驱动。"that noise"=哭的读法依据狼自己的
"It is sure to cry soon"（词汇层面，已按指导记录）。OnlyDid 窗口
[childCried..TheEnd]：窗口外护士的 Be-quiet 言语不被否定（回归 16）。

### Story 9 — The Wolf in Sheep's Clothing

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| Whose skin was the wolf wearing? | 那只被剥了皮的羊(小羊的母亲) | `Entity(the sheep that had been flayed)` | Wears + BelongsTo |
| How did the wolf deceive the sheep? | 把羊皮披在自己的皮毛外面 | `PutOn(over=Entity(its own pelt),theme=Entity(the skin of a sheep))` | ResultsIn(Deceives) |
| For how long did the wolf succeed in deceiving the sheep? | for some time(模糊时长) | `Entity(some time)` | Lasted.duration |
| Did the lamb think the wolf was its mother? | 未确立 | `{constraints=[Believes],level=instance,result=not-established}` | Believes(无信念可寻) + AskWhether |
| Before he found the sheep's skin, could the wolf get at the sheep easily? | 否 | `{result=no}` | AskWhether(Not(Unable(GetAt easily)), PriorTo) |

对照：`Did the lamb follow the wolf?` → 是；`Whom did the wolf deceive?` →
`Entity(the sheep)`。Deceives 为状态（非言语欺骗无 Says，回归 21 的反例：
狼的 Says 描述在 world 无对应者）；起始 = ResultsIn{putOn}，时长 =
`Lasted{deceives, Entity("some time")}`——模糊时长是值，不是 Unknown
（投影可区分）。Q5："found great difficulty" 词汇蕴含"不能轻易够到"
（P6 依据），Unable[Initially..foundSkin]。"小羊的母亲"以
`BelongsTo{lamb, flayedSheep}` 表达。

### Story 10 — The Shepherd's Boy

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| Why did the boy first cry "Wolf"? | 为了得到一点陪伴和一些刺激 | `Get(theme=[Entity(a little company),Entity(some excitement)])` | InOrderTo(action=Nth{cry,1}；目标对象在计划语境中) |
| Was there a wolf when the boy cried "Wolf" the second time? | 否 | `{result=no}` | AskWhether(Present{一只狼〔kind〕}, when=Nth{cry,2}) + NoneSuch{some:[x 狼], Present(x), until: wolfCome} |
| Why did nobody come to help the boy the third time? | 村民以为他又在骗他们 | `Believes(believer=Entity(the villagers),content=Context(the boy was again deceiving them))` | Causes(Believes → NoEvent〔窗口 from=Nth{cry,3}〕)（r6） |
| Was the boy telling the truth when he cried "Wolf" the third time? | 是 | `{result=yes}` | HoldsIn(claim, Present{x}) + AskWhether(Present{x}〔claim 的不定狼作替身〕, when=Nth{cry,3}) |
| Did any villager come to help the boy the third time? | 否 | `{result=no}` | AskWhether(Occurs, when=Nth{cry,3}) + NoEvent |

对照：`Did the villagers come to help the boy the second time?` → 是；
`Was the boy telling the truth the first time?` → 否。狼在场 = 锚定状态
`Present{wolf}`[wolfCome..∞) 与 `Initially{Not{Present{wolf}}}`+
`Ends{wolfCome, notPresent}`——同一问题在第二次/第三次答案相反（回归
22）。`NoEvent{pattern: ComeToHelp{boy}, from: cry3, until: TheEnd}` 窗口
内否定存在（回归 13：不驳倒第二次）。Q3：无帮时间为被引发的否定，其因
果链指向村民的错误信念。world 另持有 `Deceives{boy, villagers}`
[cry1..cry3)——依据 "tried the same trick"/"fooled twice before"（词汇
蕴含，P6）；wise man 的结语是言语事件但不建模内容（generalization 不处
理）。"truth-telling" 的译文判断：喊"Wolf"的被问命题 = 该时刻狼在场
（回归 25 内以对照题锁定真假随时间翻转）。

### Story 11 — The Fox and the Goat

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| How did the fox really get into the well? | 他(出于不幸的偶然)掉了进去 | `Fall(destination=Entity(a deep well),theme=Entity(the Fox))` | Says→S + HoldsIn(InOrderTo) + SameReferent(world) |
| How did the fox say he got into the well? | 他自己跳了下来(为了确保身边有水) | `JumpDown(destination=Entity(a deep well),theme=Entity(the Fox))` | HoldsIn(Occurs(answer)) + HoldsIn(Agent(answer, fox)) |
| Why did the goat jump into the well? | 她认为狐狸的建议很好 | `Believes(believer=Entity(the Goat),content=Context(the fox's advice was good))` | Motivates(Believes) |
| Could the fox get out of the well before the goat came down? | 否 | `{result=no}` | AskWhether(Not(Unable), PriorTo(goatJump)) |
| Was what the fox told the goat about why he was in the well true? | 否 | `{result=no}` | AskWhether(InOrderTo) + ByChance×SameReferent 类级规则 |

对照：`Did the fox get out of the well?` → 是（GetOut 开放类匹配
JumpUp extends GetOut）；`Was there going to be a great drought?` → 未确
立。S（狐狸的 news）持有 Drought 断言、saidJump、
`InOrderTo{saidJump, Has{fox, water}}`；world 持有
`SameReferent{left: saidJump, right: fellIn}`（由 world 持有——指导第五
节 2；依据：叙述者同框两次得到-in）与 `ByChance{fellIn}`；类级不相容规则
（意外事件不为目的而做）写在 `Refutations.js`，使 Q5 答"否"而非"未确立"
（不是故事专用规则）。Q2 的"为了确保身边有水"以 S 中 InOrderTo 的 goal
保留（译文以 InOrderTo 动作约束取 saidJump 为值，目的在约束中）。
Unable[ResultsIn{fellIn}..Ends{goatJump}] + Enables{goatJump, escape}（r5：能力始于其手段到场，非始于其行使）。

### Story 12 — The Ass's Brains

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| What did the lion propose to the ass? | 两家结盟 | `Entity(an alliance between their two families)` | Says + HoldsIn(Proposes) |
| What did the lion forbid the fox to do? | 碰他的猎物 | `Touch(theme=Entity(the prey))` | Says + HoldsIn(Forbids.deed=answer) |
| What did the fox eat while the lion was away? | 驴的脑子 | `Entity(the brains of the Ass)` | Eat + Among + Occurs + Agent + Before×2 |
| What did the lion notice when he came back? | 脑子不见了 | `Missing(thing=Entity(the brains of the Ass))` | Notice.theme=answer + Next |
| Was the fox telling the truth when he said the ass had no brains? | 否 | `{result=no}` | Says + HoldsIn(HoldsWhen(Not(Has), t)) + AskWhether(when=t) |

对照：`Did the ass have brains when he came to the place of meeting?` →
是（Has[Initially..Ends{takeBrains}]，at assCame 成立）；`Who advised the
lion to send the message?` → `Entity(the Fox)`（Advise + Agent）。
"while" 译为事件位于走与回之间（Before 对）；狮子外出 = `Away` 状态
[GoAway..ComeBack]（While 锚点见回归）。"finding that his master did not
return" = 狐狸的 `Notice{theme: Not{Occurs{lionBack}}}`——感知内容，非
world 持有的否定（区间内的否定，不是永远不回来）。Q5：狐狸回答语境
持有 `HoldsWhen{Not(Has), lionPounce}`——"it had none" 关于落入圈套之时
（依据 "or it would never have fallen into your trap"，指导第三节 5），
问题从言语语境同时读出所说内容与其所关于的时间（见 Phase 2r3）。

### Story 13 — The Fox, the Cock, and the Dog

| 题 | 语义 | 机器 | 主要关系 |
|---|---|---|---|
| What did the fox say King Lion had declared? | 一场普遍休战 | `Entity(a universal truce)` | Says + HoldsIn(Occurs(Declare)) + HoldsIn(Agent(kingLion)) |
| According to the fox's news, may a beast hurt a bird? | 否（其语境中） | `{result=no}` | AskWhether(context: S, Not(Forbids(Hurt{beast, bird}))) |
| Could the fox reach the cock? | 否 | `{result=no}` | AskWhether(Not(Unable)) |
| What did the fox do as soon as he heard that the dog was coming? | 开始转身离开 | `TurnAway()` | Next{听到〔描述：所听言语持有 SameReferent(·, dog)〕, answer} |
| What reason did the fox give for not staying to congratulate the dog? | 他担心狗可能还没听说狮王的命令 | `Fears(content=Context(the dog may not have heard of King Lion's decree),fearer=Entity(the Fox))` | Says + HoldsIn(Motivates{answer → Not(Occurs(Congratulate(dog)))}) |

对照：`Was there really a universal truce?` → 未确立；`According to the
fox's news, shall all dwell together in brotherly friendship?` → 是
（Mandates 在 S 中）。S 的内部时间线：`Declare`（Occurs-in-S + Agent
KingLion）→ `ResultsIn{declare, Forbids{Hurt{bird}}}` 与
`ResultsIn{declare, Mandates{Dwell}}`（"henceforth" = 自宣告起，语境内
锚定）。公鸡两次所见（"some one coming"/"master's Dog"）是 C1/C2 言语内
容，C2 持有 `SameReferent{someone, dog}`；叙述者不确认（world 无狗到来事
件）。Q5：嵌套态度 FS(言语) ⊃ Fears ⊃ F(担忧语境) ⊃ `Not{HeardOf{dog,
truce}}`；回答取 FS 持有的 Fears 命题整体。Q4："as soon as" =
`Next{heardNews, turnAway}`；"heard that the dog was coming" 的听件 =
公鸡的指认言语（译文判断：news 即该言语内容）。"beyond his reach" →
`Unable{fox, GetAt{cock}}`（未锚定=全程）。

## P6 词汇蕴含记录（触发原文短语）

| 故事 | 原文短语 | 持有的认知 |
|---|---|---|
| 4 | "was **never** seen more" | `NoEvent{See{meat}, from: dropMeat}` |
| 5 | "found it was **only** a Mask" | B2 持有 `Not{SameReferent{mask, face}}` |
| 6 | "a **robber** … dug up … and decamped" | `Steal extends Get`（ robber ⇒ 偷取） |
| 6 | "found **nothing but** the empty hole" | `Empty{hole}` 自 robSteal 起（穷尽+empty） |
| 8 | "It **is sure to cry** soon"（狼语）+ "that noise" | 威胁前件 = 哭（noise=哭的同一） |
| 9 | "found **great difficulty** in getting at" | `Unable{wolf, GetAt{sheep}}` [.. foundSkin] |
| 9 | "for some time he **succeeded in deceiving**" | `Deceives{wolf, sheep}` + `Lasted{…, some time}` |
| 10 | "tried the **same trick**" / "**fooled** twice before" | world `Deceives{boy, villagers}` [cry1..cry3)；`Not{Present{wolf}}` [.. wolfCome] |
| 10 | "a Wolf **actually** did come" | `Present{wolf}` 自 wolfCome 起（前两次无狼） |
| 11 | "**By** an **unlucky chance**" | `ByChance{fellIn}`（类级不相容规则用） |
| 12 | "Woe betide you **if** you touch my prey" | 言语语境 Forbids（威胁读作禁令，见下） |

另记两处翻译判断（非词汇蕴含但指导要求记录）：story-8 威胁的"禁令/条件"
取 Conditional（原文是条件威胁）而 story-12 狮子命令取 Forbids（原文是
命令式禁令）；story-6 "Nay" 的内容 = 邻居问句命题的 NoEvent 否定。

## 旧三篇 expected 变化汇总

| 题 | 变化 | 理由 |
|---|---|---|
| S1Q1–Q5 | 无 | 迁移仅为 Unable/时间锚定，投影不变 |
| S2Q1,Q2,Q4,Q5 | 无 | — |
| S2Q3 | 无（机制迁移） | Believes→语境 + HoldsIn 取同一 claim 命题，投影同形 |
| S3Q1,Q2,Q4,Q5 | 无 | — |
| S3Q3 | `Tickled(at=Entity(the mouse's offer),…)` → `Tickled(at=Believes(…,Context(the Mouse being able to help him)),…)` | offer 名义化改为 idea 语境（指导第七节授权；见上） |

## 每篇的复用与新增

| 故事 | 复用 | 新增（类） | 被迫修改已有语义 |
|---|---|---|---|
| 4 | Fall/Causes/Goal/InOrderTo/Get开放类/Agent/Next | SameReferent、Carrying、SnapAt、Cross、See、NoEvent(用时)、LocatedAt 锚定 | 无 |
| 5 | Says/Agent | Believes 区间、Fears 之外：LookClosely、Enter、Frightened、Has、Not(言语内) | 无 |
| 6 | Agent/Next | Habitual、Instance、Hide、DigUp、Gloat、Find、Steal(extends Get)、Take、Empty、OnlyDid、NoEvent(语境) | 无 |
| 7 | Causes/Fall/Next | Plans、Buy、Sell、Lay、Toss、Jealous、Carrying | 无 |
| 8 | Says/Agent | Conditional、Crouch、Wait、Shut、CallForHelp、RushOut、GallopAway、ComeTo、Cry、Throw、Hear | 无 |
| 9 | ResultsIn/Eat | Deceives、Wears、BelongsTo、PutOn.over、Follow、Lead、Stroll、GetAt、Unable、Missing 无（不用）、Lasted、SomeTime 值 | PutOn 增 over 字段（注释级） |
| 10 | Says/Agent/Next | CryOut、ComeToHelp、ComeOut、Worry、Present、Not(锚定)、Plans(复用)、Lonely、ThinkUp(复用)、Nth | 无 |
| 11 | Fall/PassBy/Put/Says | ByChance、SameReferent(world 持有)、Unable 区间、GetOut 开放、JumpDown/JumpOn/JumpUp、Drought、Approves、Has(目标) | 无 |
| 12 | Says/Agent/Next | Proposes、Forbids、Advise、Declare 无（13 引入）、Pounce、Touch、Worry(10)、Hunt、GoAway、ComeBack、Away、Overjoyed、Take、Missing、HeardOf 无 | 无 |
| 13 | Says/Agent/Next | Declare、Forbids(复用)、Mandates、Dwell、Hurt、Prowl、HeardOf、Fears、TurnAway、GetAt(复用)、Unable(全程) | 无 |

新增类型数随故事推进：4 篇 8 类 → 5 篇 5 → 6 篇 8（否定机制集中）→
7 篇 6 → 8 篇 9 → 9 篇 9 → 10 篇 6 → 11 篇 7 → 12 篇 10 → 13 篇 7。
story-12 略高（言语/禁令/区间一次到位），未出现"每篇仍需大量新类型"的
失控；词汇按语义域组织（Motion/Moves/Contact/Encounter/Errands/
Perception/Possession/Trade/Weather/Emotions/Conditions/Relations/
Attitudes/Correspondence/Norms/Negation/Time/Habits/Asking/Chance/
Dialogue/Objects/Actions/Deeds + 求解器 Support/Search/Match/Shapes/
Temporal/Anchors/Covering/Refutations/Verdicts/Reading/QuerySolver/
Assertion/Outcomes/Project/Speech），不按故事拆分；space/ 文件全部
≤160 行；space/ 不含任何故事、答案或故事专用规则（类级规则三处：
LocatedAt 互斥、Empty 容器、ByChance×SameReferent 不相容，均在
space/）。

## 回归与变异验证

回归 68 项 = r4 的 42 项（其中两项按指导第八节改写：回复边界→27、字节
一致性→26 且扩展到 Interface 两文件）+ 新增 26 项（语境 5、时间 6、否定
与是非 7、言语信念欺骗 6、twins 汇总 1、持有/引入 1）。全部通过。

变异验证（`node mutation.mjs`；每项记录恰好击穿哪些回归、65 题剩多少；
`foundation: byte-identical` 在每个变异下必然失败，属预期哨兵，不计入
"被抓"）：

| 变异 | 回归 | 65 题 | 被击穿的语义回归 |
|---|---|---|---|
| inertia-off（Ends/类级结束失效） | 60/68 | 62 | 位置唯一、惯性、信念修正、无能力≠未发生、四结果、同内容异时、twins |
| noevent-window-ignored（否定存在全域生效） | 64/68 | 65 | NoEvent 窗口、穷尽范围、twins（65 题全过——只有回归能抓住） |
| context-fallback-to-world（HoldsIn 泄漏 world） | 65/68 | 64 | Reply 读命题（言语≠持有）、持有/引入分开 |
| question-shapes-off（内容匹配退回恒等） | 60/68 | 54 | NoEvent 窗口、无能力、语境内否定、四结果、预设/内容、同内容异时、twins |
| ends-negation-off（结束后只是未断言） | 66/68 | 65 | 无能力≠未发生（65 题全过——只有回归能抓住） |
| ordinal-off（序数退化为首个匹配） | 63/68 | 63 | NoEvent 窗口、四结果、预设/内容、同内容异时 |

三处"只有回归能抓住"的缺陷已在表中标出（noevent-window、ends-negation
两变异不破任何题目）。twins 汇总回归覆盖第六节全部 21 道对照题（19 个
TwinQuestions + 各篇引导的成对正反例）。

## 停止条件

未触发。无题不可忠实翻译；未出现需要改动既有语义的场合（PutOn 加
over 字段为字段级扩充，非语义变更）；Foundation 全程零修改。

## Phase 2r2：外部审核修订（2026-10-03）

一轮外部审核在 65/65 + 68/68 全绿的表面下指出 8 条求解器缺陷、若干
"答对但理由不对"的题目与超出原文的 fixture 断言，以及测试墙的缺口。
本节逐条记录修订；**冻结题面与语义期望全部未动，65 题期望答案无一
改变**——变化的只是求出的理由与求解器的健全性。修订后：
`node regression.mjs` → 81/81；`node run.mjs` → 81/81 + 65/65；
`node mutation.mjs` → 14 条变异每条至少破坏一条语义回归。

### 1. 求解器缺陷（审核 S1–S8 + 两条附带）

| # | 缺陷 | 修订 | 修订前 → 后 |
|---|---|---|---|
| S1 | `Refutations.js` 用 `fieldValue` 未导入，带 theme 的 OnlyDid 一触即崩 | 导入；theme 检查与"列出与否"都从 join 绑定出发 | ReferenceError → S6Q5 忠实形式答 no |
| S2 | 否定侧拿空 Map，绑定变量被套到别的个体 | 正负两侧都从 scope 过滤后的 join 绑定出发 | 山羊变量问 Unable@末尾 no → 未确立（与常量形式一致） |
| S3 | 正向侧带着跨语境绑定按身份匹配，"说的是真话吗"永远答不出是 | Verdicts 按求值 scope 过滤绑定：变量保留、scope 内对应物保留、跨语境对应物放开改按内容匹配 | 经 HoldsIn 取出的内容 world 求值 未确立 → 是 |
| S4 | Agent 内容无正向分支，被当无锚定状态，任意时刻都"成立" | Positives.js：Agent 内容 = 发生性问题——须持有 Agent 关系、事件确已发生、且落在锚点窗口内 | "护士在哭之前呼救了吗" yes → 未确立 |
| S5 | While 窗口返回 null 等于问全程；Nth 窗口是"从第 n 次起" | While → 各状态区间的 during 窗口；Nth → 第 n 次开启、第 n+1 次闭合的 until 窗口 | "离开期间扑了吗"（扑在离开前）yes → 未确立；"第 2 次时"发生在第 4 次的事 yes → 未确立 |
| S6 | before 窗口只查 from ≤ E，不要求 from 为空 | before 窗口要求否定从起点覆盖并越过界 | "肉在掉落前被看见过吗" no → 未确立（"never seen more" 从掉落起算） |
| S7 | After/PriorTo 对状态取存在量化，区间内变化即 conflict | After 读"锚点落在状态区间内"（与 endNegatesAt 互补），After(E)+PriorTo(F) 合起来表区间 | "山羊下来后狐狸能出来吗" conflict → no（无冲突） |
| S8 | 类规则结束的 LocatedAt 只算结束不算否定 | refutingProps 与 Not-正向都改经 `endOf` 推导（显式 Ends 与类规则统一） | "结尾时肉在狗嘴里吗" 未确立 → no |
| X1 | HoldsIn 只读直接断言，与 AskWhether 指定 context 的 Timeline 路径不一致 | `contextHolds`：断言 ∪ ResultsIn 携带 ∪ Initially ∪ 已发生事件——与 Timeline 同源 | 语境内 ResultsIn 携带的内容两条路径一致可读 |
| X2 | ByChance×SameReferent 借 S2 的空 Map 对任意变量动作生效 | named() 从绑定出发，只经问题自己的对应触发（守卫回归用同构不同节点的对应验证） | 指向别处的对应不再产生 no |

### 2. 题目修订（答对但理由不对）

- **S6Q5**：按题面忠实补上施事（Agent 内容形式），"Nay"改为带 actor 的
  NoEvent；不再丢 "you"，也不再有靠类名巧合的答案。twin 1 同样补施事。
- **S7Q1**：去掉夹带的 `from = Farmer Brown`；fixture 以 `Enables`
  表示两笔资金（牛奶钱买家禽、蛋钱买衣裳），问题按"用卖牛奶的钱"的
  资金约束判别——去掉资金约束即 Ambiguous（回归可查）。
- **S8Q3 / S8 twin / S7 twin / S9 twin**：平凡是（Among+预断言 Occurs
  内容）改为 Agent 机制提问——"是"必须经过发生性检查。
- **S8Q4**：去掉译者补的 `when = childCried`；fixture 的穷尽陈述按
  原句自身的全程范围（去掉 from）。
- **S9Q4**：问题改为命名所问内容（狼=其母的 SameReferent 断言于信念
  语境内）；无信念 → constraints=[Believes]（期望串不变），无关信念
  不再误答是（回归"presupposition"验证）。
- **S10Q1**："first" 显式编码为序数（第二次哭之前的哭）。
- **S10Q2/Q4**：三次哭各携带 claim 语境（"a wolf is coming"），
  问题经 HoldsIn 取出 claim、在 world 按该次哭求值——同一句话第二次
  否、第三次是，走的是真实言语内容；回归同名测试同构重建。
- **S10Q3**："the third time" 编码为 NoEvent 的 Nth 窗口（Search 的
  Nth 解析扩展到 from/until 字段）。
- **S10Q5**：补上 "villager" 施事，Agent 形式；窗口化否定给出干净的 no
  （原 Occurs 形式在忠实翻译下会 conflict）。
- **S12Q5**：去掉译者挑的 `when = lionPounce`；无锚点下按持续性世界
  记录答 no（"它有脑子，取出才结束"），说话时刻则答是（探针可查）。
- **S13Q5**：fixture 补 `Motivates{feared → foxExcuse}`；问题读借口
  行为的驱动者，"for not staying" 不再缺表示。

### 3. fixture 修订（P6 / P2 / 原文忠实）

- **story-1**：Unable 的终点从水位上升改为投完几颗石子（原文顺序
  waterRise → castMore → 才 "was able to"）。
- **story-3**：`tickled at the idea` 的 Believes 改为仅提及（想法语境的
  提及者、Tickled 的宾语），世界不再持有该信念（P6）；Asleep 补
  `Ends{wake}`——"this soon wakened the Lion"（"结尾还睡着吗"探针
  yes → no）。
- **story-4**：`carryHome`（到达式）删去，改 Carrying 状态（初始成立、
  止于掉落）；"as he crossed… saw" 用新的 `Overlaps` 表示同时。
- **story-5**：恐惧的 `Ends{lookClose}` 删去——原文未说他不再害怕
  （"细看后还害怕吗"探针 no → yes）。
- **story-6**：robber 的事件忠实为 notice→dig（取出）→steal（携走；
  词义依据 "a robber… decamped with it"）；`miserVisit` 从 Gloat 改为
  ComeTo，gloat 是其 InOrderTo 目标而不再断言发生；"nothing but the
  empty hole" 补 `NoEvent{Find(gold), from: miserVisit}`；"Nay" 补
  actor。
- **story-7**：`going` 改用新的非终结性 `HeadTo`（"was going to
  market"，到达未蕴含）；计划语境统一表示为 AssertOccurs 的想象事件
  + 语境内 Next 链 + 持有命题（habit/Jealous/Enables）；"as she spoke
  she tossed" 用 `Overlaps`。
- **story-8**："as this was said" 用 `Overlaps`（beQuiet 与 passing）；
  穷尽陈述去掉 from。
- **story-9**："great difficulty" 的 Unable 保留（词义依据已录），但删去
  原文未说的 `Ends{foundSkin}`——Q5 的 no 现在仅由锚定的初始状态给出。
- **story-11**：山羊的 Believes 改为 Assert（指南 Q3 语义即"她认为"，
  存在≠成立的反面修正）；偶然跌落的 Fall 不再断言 Agent。
- **story-13**：见 S13Q5。

回归期望串变化仅一处："time: a habit…的实例"从
`Gloat(theme=…)` 改为 `ComeTo(destination=…)`（原因如上）。

### 4. 测试墙补强

新增回归 13 条（81 项总计）：绑定一致性（S2）、是方向言语 twin（S3）、
Agent 时间性（S4）、While / Nth 窗口（S5）、before 覆盖（S6）、单侧性
（S7）、类规则否定（S8）、带 theme 与施事的穷尽（S1）、语境想象事件
可读（X1）、chance 仅经对应（X2）、Promise 正例（story-3）、预设对照
（S9Q4）、言语真值随时间（重建）。新增变异 8 条
（verdict-scope-off / agent-window-off / nth-window-unbounded /
before-window-covered-anyway / class-end-not-refuting /
chance-any-correspondence / while-window-ignored /
context-events-unread），矩阵：每条至少破坏一条语义回归；原 6 条中
noevent-window-ignored 现被新窗口守卫额外抓住。

## Phase 2r3：r2 修订的复查与再修订（2026-10-03）

对 r2 的复查发现其中几处修订本身引入了新问题，或以新的方式"答对但
理由不对"。本节逐条记录；冻结题面与 65 题期望答案仍无一改变。修订后：
`node regression.mjs` → 88/88；`node run.mjs` → 88/88 + 65/65；
`node mutation.mjs` → 17 条变异每条至少破坏一条语义回归。r2 中下列
条目以本节为准：S7Q1、S8Q3、S8Q4、S12Q5、S13Q5、PriorTo 读法。

### 1. 求解器

| # | r2 的问题 | 再修订 | 前 → 后（探针） |
|---|---|---|---|
| T1 | 无锚点状态问题两侧不对称：正向"某时成立"，否定侧从不计结束 | Verdicts 对无锚点状态问题逐时刻（开始、每个事件、结尾）判定，两侧都取"某时"；同一时刻两侧成立才是冲突 | "驴有脑子吗"是 / "驴没脑子吗"否 → 是 / 是 |
| T2 | PriorTo 仍是"窗口内某时"（头注释却说"恰在之前"） | holdsAt(PriorTo) 改为恰在 E 之前：起于 E 之前、未在 E 之前结束 | "第三次喊之前有狼吗" conflict → 是 |
| T3 | `Overlaps` 把事件摘出 Next 链，但时间线不读它——S4/S7/S8 的同时事件与其余事件失去先后（护士的警告不早于孩子的哭） | 新 `Order.js`：Overlaps 两端共一时刻，次序对二者同时成立；`Before` 支持与时间线共用此次序 | Before(警告, 哭) 无支持 → 支持 |
| T4 | AskWhether 的 `when` 只能是固定锚点 | `when` 可为 Variable 或描述，取 join 绑定的事件（言语所关于的时间；威胁所附条件的那次哭） | — |
| T5 | 否定结论丢弃 join 的其余变量 | No 元组保留 scope 过滤后的绑定 | — |

### 2. 题目与 fixture

- **S8（OnlyDid）**：r2 为让 Q4 去掉 when 而把 "all the Nurse did" 改为
  覆盖全程，结果护士开头的 "Be quiet" 也被否定（"护士说过话吗" →
  conflict）。恢复为自孩子哭起（"till at last the child began to cry …
  But all the Nurse did"）。Q4 问的是威胁是否兑现；威胁自身的条件
  （"If you make that noise again"）决定其时间：问题以描述找到警告之后
  孩子的那次哭作 when，不再直接点名故事事件。此为翻译判断，r4 随题面
  修改简化为"孩子开始哭的那次"；已确认（见 r6 第 4 节）。
- **S8Q3**：r2 仍用 Among 预设一个对应的哭，发生不成立时只能"未确立"。
  改为纯形状内容 + After(警告)（"again"）；构造"孩子没哭且被否定"的
  世界即答 no。对照 "Did the nurse call for help?" 同样去掉 Among；对照
  "Did anyone promise the wolf the child?" 改为形状（原先直接引用威胁
  语境节点）。
- **S12Q5**：r2 去掉 when 后靠 T1 的偏向答 no。改为在 fixture 中表示
  "it had none" 所关于的时间：回答语境持有
  `HoldsWhen{Not(Has(ass, brains)), lionPounce}`；问题经 HoldsIn 同时读出
  内容与时间变量，在 world 于该时间求值。回归以同一回答改指说话时刻
  验证答案随之变为是。
- **S13Q5**：r2 在 world 断言 `Motivates{feared → foxExcuse}`，等于叙述者
  确认狐狸真的担忧（这是托词，P1/P6）。删去；理由放进狐狸的言语语境：
  `Motivates{feared → Not(Occurs(Congratulate(dog)))}`（"I would gladly
  do so, but I fear…"）。问题读"他所说的、使他不去祝贺的理由"，不再需要
  `Next(cockTease)` 挑语境。新增词汇 `Congratulate`（Errands.js）。
- **S7Q1**：r2 以名为 "the money for the milk" 的实体作形状匹配——靠
  表层字符串区分两笔钱。改为以出售事件表示资金：计划语境持有
  `Sell(milk)`，`Enables{Sell(milk) → 买家禽}`、`Enables{Sell(eggs) →
  买衣帽}`；问题按"卖牛奶"的出售区分。r2 记录的"去掉资金约束即
  Ambiguous（回归可查）"并无对应回归，本轮补上。
- **S9Q4**：母羊描述去掉名字串，只靠 `BelongsTo{lamb}`；被问内容的左项由
  任意 Entity 形状改为狼本身（原先"小羊以为牧羊人是母亲"也会答是）。

### 3. 测试墙

r2 的 "presupposition: an unrelated belief…" 回归的断言接受 `yes`，且其
世界中没有母羊——不测任何东西。改为在真实 story-9 上加一份小羊信念：
无关信念 → 未确立；"牧羊人是母亲" → 未确立；"狼是母亲" → 是。

新增回归 7 条（88 项）：护士穷尽陈述的范围（真实 fixture）、无锚点
两侧对称、PriorTo 恰在之前、言语按所关于的时间求值、Overlaps 共时
次序、所给理由≠world 动机、出售区分资金。新增变异 3 条
（prior-to-stretch / unanchored-one-sided / overlap-ignored），各自被
对应回归抓住；overlap-ignored 另破 S8Q3/Q4。

### 4. 仍未处理（记录）

- S10Q2/Q4 "a wolf" 仍直接引用故事中的那只狼（存在问被译成个体问）；
- S11 After 点语义下 "After the goat came down, could the fox get out?"
  答否（紧随其后仍未出井）；自然读法可能是"能"，属语义选择，待定；
- S10Q1 "first" 以"第二次之前的那次"表达，而非 `Nth index=1`；
- 原审查中 S12 劝告/送信次序、S13Q2 丢 "beast"、S13Q4 "as soon as"、
  S11Q1/Q2 绕道言语、S6Q4 "next"、S5Q4 以 Causes 表"方式"、S4Q1 多余
  Carrying 约束——r2 与本轮均未处理。

## Phase 2r4：歧义题面与剩余翻译问题（2026-10-03）

授权：对可能造成明显歧义的问答可适当修改，以不偏离 Phase 2 目标为限。
（r6：本轮的题面修改与 S8 时间定位均已获明确确认，见 r6 第 4 节。）
本轮改了一道题面，其余均为翻译与 fixture 的修订；65 题的语义 expected
与机器 expected 无一改变。修订后 `node regression.mjs` → 91/91；
`node run.mjs` → 91/91 + 65/65；`node mutation.mjs` → 18 条变异各至少
破坏一条语义回归。

### 1. 题面修改（1 道）

| 题 | 原题面 | 新题面 | 理由 |
|---|---|---|---|
| S8Q4 | Did the nurse throw the child to the wolf? | When the child began to cry, did the nurse throw it to the wolf? | 原题无时间；"all the Nurse did" 回答的是孩子哭起那一刻（"till at last the child began to cry … But all the Nurse did"）。无时间的问法要么需要译者补锚点（r1–r3 的问题），要么把穷尽陈述扩到全程（r2 的问题，否定了护士开头的话）。新题面点明时刻，仍测 N5 穷尽推出的否定。 |

考虑过但未改的：S12Q5（"telling the truth when he said…"）表面上可读作
说话时刻，但原句 "or it would never have fallen into your trap" 自己给出
所关于的时间，fixture 已表示（r3），不改；S10Q2/Q4 的 "a wolf" 无歧义，
问题在表示（见第 3 节）。

### 2. 翻译与 fixture 修订

- **S5Q4**：新增 `Means{event, means}`（Chance.js）。"by some means" 是方式
  未写，不是原因未写；改用 Means 后 "How…" 答 Unknown，"Why did the fox
  get into the store-room?" 答未确立（原先 Causes 会让 why 也答 Unknown）。
- **S9Q5 / fixture**："great difficulty in getting at" 改持有
  `Unable{wolf, GetAt{sheep, manner: easily}}`——不能轻易够到，而非完全
  够不到。求解器：无能力的 deed 是**精确形状**（Shapes/Match 的 exact），
  故事中更窄的无能力不回答更宽的问题；"之前能不能够到羊"答未确立，
  "能不能轻易够到"答否。
- **S6Q4**："next came to gloat" 由直接点名 `miserVisit` 改为描述：吝啬鬼
  的一次到来、是每周习惯的实例（Instance）、目的为 gloat（InOrderTo）；
  去掉 world 的 Instance 即未确立（回归）。对照 "Was the gold in the hole
  when the miser next came?" 同样用此描述，并去掉被问内容上多余的持有。
- **S11Q2 / fixture**：狐狸的言语语境原先只持有"跳下是为了有水"，不持有
  "我跳下了"本身。补上 `Occurs(saidJump)` 与 `Agent(saidJump, fox)`；
  Q2 读"他所说的、由他做的发生"，不再借用题面没有的目的关系；Q1 经
  同一 helper 读出所说的跳下，再经 world 的 SameReferent 找到真实事件
  （"really" 预设一个不真实的说法，故保留这一路径）。
- **S12**：Next 链由 message→advice 改为 advice→message（"on the advice
  of the Fox, sent a message"）；Advise 补 `to: lion`、`advised: message`。
  对照 "Who advised the lion to send the message?" 要求劝告的对象与内容，
  不再是"谁劝过"。
- **S13Q2**：新闻中的禁令补上施事种类（`Hurt{doer: a beast, theme: a
  bird}`）；问题点名二者（语境单例），原先形状为空的 `Hurt{}`。
- **S13Q4**："heard that the dog was coming" 由直接点名 `heardNews` 改为
  描述：狐狸听到一段言语，其内容持有把来者认作狗的 SameReferent；
  "as soon as" 为 Next（紧接的下一件事）。
- **S13 newsOf**："the fox's news" 由 `Next(cockAsk)` 定位改为按内容
  描述（宣告了一次 Declare 的那段言语）。
- **S4Q1**：删去题面没有的 Carrying 约束（见 Story 4 投影判断）。

### 3. 仍未处理（记录）

三项均已在 Phase 2r5 处理（见下）。

## Phase 2r5：存在、序数与能力的语义完备化（2026-10-03）

r4 记录的三项未处理问题，按语义与逻辑完备性（而非实现成本）处理。三者的
共同根源都是**用更窄、更具体的命题替代了原文的命题**：个体在场替代存在、
"第二次之前"替代"第一次"、"做到了"替代"能够"。在固定的 fixture 上它们
答案相同，因而测试抓不到。题面与 65 题期望均未变。修订后
`node regression.mjs` → 95/95；`node run.mjs` → 95/95 + 65/65；
`node mutation.mjs` → 22 条变异各至少破坏一条语义回归（原记为 23 条，
系计数笔误：18 + 4 = 22；r6 更正）。

### 1. 存在（S10）

- 原文的否定是存在的："the same trick"、"a Wolf **actually** did come" 蕴含
  前两次 ¬∃x(狼(x) ∧ 在场(x))。原表示 ¬在场(那只狼) 对后来才出林的那只狼
  几乎平凡，且没有说出原文所说。男孩的 "Wolf, Wolf" 同样是存在的：
  ∃x(狼(x) ∧ 在场(x))。指南 N2 的定义本就是"没有匹配某描述的事件**或
  个体**"——原实现只覆盖了事件一半。
- **种类**：新增 `Kind`（Kinds.js）；Entity 可带 `kind` 字段（刚性的种）。
  种类是常量，按身份匹配。
- **状态的否定存在**：新增 `NoneSuch{some, pattern, from, until}`——窗口内
  不存在使 pattern 成立的 `some`（显式列出被量化的个体）。只有被量化的个体
  是开放形状，模式中其余节点（种类、故事个体）按身份——否则"没有狼在场"
  会连"有羊在场"一起否定（探针验证后改为显式量化）。它驳倒被涵盖、且时刻
  落在窗口内的状态问题，也正向支持 "Was there no wolf?"。
- **语境局部对象作为存在变量**：问题经 HoldsIn 绑定到另一语境（非 world
  链）里的节点后，在求值语境中该节点作为**替身**按其自身内容匹配，其语境
  的节点作形状；world 的个体始终按身份（各语境本可直接提及它们）。r2 的
  "跨语境对应物放开、按问题形状的内容匹配"在问题形状为空时会匹配任意对象，
  此规则取代之。
- **名字不参与匹配**：Entity 的 `name` 是表层文本，两侧都不进入匹配
  （Match.js 的 SURFACE）。全部现有描述已清查：S9Q4 的母羊名字 r4 已去掉，
  其余无依赖名字的描述。言语的引语（`CryOut.call`、`Says.text`）是言语行为
  本身的属性，保留为可匹配字段。
- S10 fixture：world 持有 `NoneSuch{some: [x 狼], Present{x}, until: wolfCome}`；
  claim 语境持有 `Present{一只狼〔claim 局部、kind=狼〕}`。Q2 译为 world 中的
  存在问（原先借道 claim，而 Q2 并不问 claim）；Q4 与其对照题共用
  "第 n 次喊所言为真吗"的构造。探针：另放一只自始在场的狼 → Q2 冲突
  （fixture 自相矛盾）；问其他种类在场 → 未确立；"那只狼在吗" → 否
  （由无狼推出）。

### 2. 序数（S10Q1）

- "第一次" = 没有更早的同类事件（最小元）；"第二次之前那次"只在至少两次
  且全序时与之重合——只喊一次时前者成立、后者无解。
- `Nth` 原以 `before` 排序取下标，遇不可比事件比较器返回 0，非合法全序，
  结果依赖 Input 顺序（违反"Input 顺序不是时间"）；引入 Overlaps 后已可发生。
  改为：匹配事件不全序时序数无定义（未确立），不任取。
- 序数可出现在约束的任意事件位（原只限 earlier/later/from/until）。S10Q1
  译为 `InOrderTo{action: Nth{cry, 1}}`。

### 3. 能力（S11、S1）

- After 的点语义（参照时间，紧接 E 之后）不变，它与 PriorTo 对称、承担区间
  组合。问题在 fixture：S11 的无能力止于逃出，把"能够"等同于"做到了"，
  混同指南要求区分的 N3 与 N1。
- 原则：**能力的起点由其条件/手段决定，不由其被行使的时刻决定**。S11 中
  "by putting his foot on her long horns managed to jump up" 明说手段是山羊：
  无能力止于山羊下来（goatJump），另持有 `Enables{goatJump, escape}`。之后
  "山羊下来之前能出来吗" → 否（S11Q4 不变），"之后" → 是，均不依赖逃出。
- 按同一原则复查：S1 乌鸦的无能力止于再投石子（"after casting in a few more
  pebbles he was able"），符合；但其 deed 原为实际发生的 TryToDrink 事件
  （"不能做那次已做的尝试"），改为未发生的形状 `GetAt{water}`（"could not
  reach far enough down to get at it"）。S9、S13 的无能力未锚定结束，无需改。

### 4. 测试墙

新增回归 4 条（95 项）：能力始于手段、序数只在全序上有定义、存在量化、
名字不参与匹配；扩充 2 条：言语真值（另一种类在场不使 claim 为真——替身
规则的区分样例）、PriorTo（E 之前已结束的状态）。"一侧性"回归改用 S12
（扑倒之后驴仍有脑子）。新增变异 4 条（names-match / stand-in-ignored /
existence-opens-constants / ordinal-on-partial-order），并修复两条因代码
变化失去锚点的旧变异（verdict-scope-off / ordinal-off）。

## Phase 2r6：嵌套序数未参与约束（2026-10-03）

复查发现 S10Q3 仍属"答对但理由不对"，且回归与变异均未抓到。冻结题面与
65 题期望均未变。修订后 `node regression.mjs` → 96/96；`node run.mjs` →
96/96 + 65/65；`node mutation.mjs` → 23 条变异各至少破坏一条语义回归。

### 1. 缺陷

- S10Q3 的译文构造了带窗口的 `NoEvent{pattern: ComeToHelp(boy), from:
  Nth{cry, 3}, until: TheEnd}`，但它只被 push、未被任何约束引用；
  `Causes.effect` 实际指向另一个**无窗口**的 NoEvent 形状。按"未断言的
  Node 不构成约束"，"the third time" 在问题中没有任何效力。
- 根源：`resolveNthAnchors` 只解析约束**顶层**字段上的 Nth。Nth 嵌在
  `Causes.effect`（按内容匹配的 asked 命题）内部时不被解析，与 world 的
  `from: cry3` 按身份比较必然失败——原译文的注释"its nested anchor cannot
  resolve there"即此限制，译文因而绕开了它。
- 探针（修订前）：把 Nth 下标改为 1、2、4，答案仍为"村民以为他又在骗
  他们"——前两次村民确实来了，第四次喊叫不存在。

### 2. 修订

- 求解器：序数解析从 Search.js 移到新文件 `Ordinals.js`（Search.js 已
  逼近 160 行），并沿**按内容匹配的 asked 命题**递归：路径上的节点逐个
  复制为同类真实实例，原约束不变；描述（Among 点名）与形状按身份绑定，
  不进入、不复制。任一嵌套序数无定义时整个约束无支持。
- S10Q3：删去无窗口的 NoEvent 形状，`Causes.effect` 直接指向带
  "the third time" 窗口的 NoEvent。
- 修订后探针：下标 3 → 村民的信念；1、2、4 →
  `{constraints=[Causes],level=instance,result=not-established}`。

### 3. 测试墙

新增回归 1 条（96 项）："ordinals: an ordinal nested in a content-matched
effect binds"（真实 story-10，第 3 次得答案，第 1/2/4 次未确立）。新增
变异 1 条 nested-ordinal-off（嵌套命题不进入序数解析）：击穿该回归与
S10Q3；ordinal-off 现另破 S10Q3 与该回归。

### 4. 待确认事项的结论（用户确认）

- **S8Q4 题面修改（r4）**：已明确允许。原题面无时间，有歧义；
  "When the child began to cry, did the nurse throw it to the wolf?" 是
  当前的冻结题面。
- **S8Q4 以描述定位"那次哭"作 when（r3/r4）**：已明确允许。asked 中的
  `Cry` 描述（Among world、发生、施事为孩子）绑定到故事中孩子的那次哭，
  作为问题的时间；"began to cry" 读作该次哭事件本身。
- **S4Q1**：接受现状，确认指导有误。语义 expected 由"另一只狗,叼着另一块
  肉"更正为"另一只狗"（`cases/story-4/questions.mjs` 的 `semantic` 同步
  更正）；机器 expected `Entity(another dog)` 不变。题目没有问另一只狗在
  做什么。
