# Konsupu Aesop Phase 1r4 → Phase 2r6 — Foundation 使用体验观察

前半为 Phase 1r4 的观察，基于 2026-10-02 修订之前的 Foundation；Phase 2
各节基于修订后的版本。Phase 2r6 没有新的 Foundation 观察，Foundation 仍然
零修改。

本轮第一次使用多 root Input（dialogue / story）、子 Situation 细化
（asked）、跨 root 的 `ref` 取值、Situation 的显式提及（Asks）、以及
结构化结果值（Unknown / Ambiguous / NotEstablished；审查后由
PresuppositionFailed 改名重设计，见 RESULTS）。按 r3 的
分类记录：**A** 领域设计问题、**B** API ergonomics、**C** 语义缺陷。
结论先行：**未发现 C 类问题，无 Foundation change candidate**。

## 1. 三层 Situation 与 ref 跨 root 取值

- 结构表达自然。`Situation(parent)` 一参数即可建立细化关系；story 与
  dialogue 无共同祖先即两个 root，`CanImport` 的"无关树可导入"规则让
  `ref(asked, answer)` 从 dialogue 取值完全合法，无需任何特殊通道。
- **交错布局是结构推出的，不是文档明说的**（A/B 之间，偏 B 的可发现性
  问题）：Analyze 只豁免 Input 第一个 Situation 的 semantic mention，
  而引用又必须指向更早出现——两者合谋要求"dialogue Situation 最前、
  dialogue 成员最后"。这个不变量在 InputContract 的条目里分开可推
  （"situations"/"mention"/"order"三条），但没有一处直接陈述多 root
  时的合成结果。本轮靠读源码（Analyze.slice(1) + CheckReference）确证；
  一个把"多 root 布局"写进 contract 文本的补充能让领域作者少走一步。
  这是文档/契约可发现性问题，不是语义缺陷。
- `ref(asked, answer)` 作为 Says.content 与 Query 项都工作良好；对话层
  的 re-export Query 被 PlanQueries 自动判空、QueryLoop 跳过——"列 ref
  即重导出"的既有设计在本轮被第一次真实使用，零成本、零意外。
- Situation 的显式提及（Asks 的普通字段指向 story/asked）是合法通道：
  CheckReference 对 Situation 引用豁免跨 Situation 规则，IndexMentions
  把 ReportReferences 报告的 Situation 记为 mentioned。机制干净；唯一
  注意点是提及必须由类型**显式报告**（ReportDataMembers 恰好做到），
  纯结构引用（不写 ReportReferences）不计——这与文档一致。

## 2. Nodes() 与 Bindings() 的范围不一致（指导 §八点名观察）

- 事实：`Perspective.Nodes()` 默认只返回当前 Situation 的成员；
  `Bindings()` 与 `Ancestors()` 看整条祖先链。r3 的 solver 因此在 asked
  下看不到故事事实——本轮 `heldAbove` 显式遍历 `view.Ancestors()` 并对
  每个 Situation 调 `Nodes(situation)`。
- 判断（B，轻微且可辩护）：两者范围不同是**有语义理由的**——Nodes 是
  "这个 Situation 自己声明了什么"（约束、成员），Bindings 是"谁提到了这
  个引用"（索引按可见性过滤）。求解器恰好需要这两个不同的问题。但
  "给我整条链上持有的命题"这类最常见询问没有便捷形态，领域要自己写
  三行遍历。可考虑的 ergonomics（不需要现在做）：一个
  `HeldAbove()`/`ChainNodes()` 便捷方法。本轮选择在 Support.js 固化为
  领域机械层，不构成 Foundation 缺陷。

## 3. "Query 列出的每个变量都必须求解" × 辅助变量 Ambiguous

- QueryLoop 的进度语义（每轮必须完成非空子集、直到 remaining 清空）
  与"辅助变量允许 Ambiguous"配合良好：Ambiguous 是一个普通值，赋给
  helper Variable 即算"已求解"。S2Q5 的未知事件、S1Q1 的描述对应都是
  helper，被问变量唯一即可回答。
- 唯一要注意的（B，已由结构化结果自然消解）：变量"完全无约束"时不能
  留空，必须显式赋 `Unknown`——这正是"resolved ≠ known"的体现，语义
  上正确，写法上要求 resolver 覆盖 remaining 的全部变量（本 solver 天然
  如此）。
- `CheckVariableValue` 对冻结 plain object 值直接放行（只禁裸 Variable
  与坏 ref），结构化结果作为值无需任何包装类型——这是本轮最顺手的
  Foundation 行为之一。

## 4. 描述 Node 与对应关系 vs 身份语义边界

- 描述 + `Among` 完全落在既有身份语义之内：两个 Node 永不合并（描述
  与故事事件是不同对象），指称同一性由显式认知（Among）表达且只在求解
  时确定。`matchValue` 的角色分派（`Among` 点名者＝描述并绑定对应者、
  asked 命题＝内容匹配、其余＝常量）是纯领域规则，Foundation 无需知情。
  首版以"asked 坐落即描述"分派，属 A 类领域缺陷，已修正（见 RESULTS
  审查后修正）。
- 未出现需要"描述 Node 指称等价"进入 Input 结构（如把描述当 ref 目标）
  的场景；`Among` 作为普通 Proposition 参与持有/支持语义已经足够。
  若未来需要给"同一指称"建模多个方向的等价（description ↔ description），
  那将是新的领域命题类，不是 Foundation 改动。

## 5. 其余观察

- `InputStructureError`（"Cross-Situation cognition requires ref"——
  2026-10-02 修订后分为 "Cross-Situation Variable requires ref" 与
  "Cross-Situation Node must not carry a Variable"、
  "Duplicate Node occurrence"、"Situation lacks semantic mention"）在
  本轮 fixture 构造错误时全部给出可定位信息——结构边界回归把第一个
  错误文案直接用作结构边界断言。
- 运行时以 fs 逐字节比对 Foundation 副本与 `src/foundation`（最后一项
  回归）比外部 diff 更早报警，建议后续轮次保留。
- 本轮再次零修改 Foundation；上述可发现性/便捷性建议均属 B 类记录，
  不构成 change candidate。

---

## Phase 2 观察（2026-10-02 修订后的 Foundation；A 领域设计 / B API
## ergonomics / C 语义缺陷）

### A. 领域设计

- **A1 语境 root 的可行性成立**。10 篇故事共 20+ 个语境 root（信念、言语、
  想象、威胁、规范、问句、idea），全部只用：root Situation + 引入命题
  （Believes/Fears/Plans/Says.content）+ 自持 Assertion。没有出现需要
  "语境嵌套为子 Situation"的场景——嵌套态度（言语 ⊃ 担忧 ⊃ 否定）用
  三个 root 的引用链表达即自然（story-13 Q5）。
- **A2 持有/引入分离的代价可控**。分语境持有同一命题对象只出现一处
  （story-2 的 claimVoice），`Assert(input, p, holder)` 默认值 + `Hold`
  辅助使调用点必须写出持有者；错误会在 Analyze（Duplicate/缺提及）或求解
  （支持的语境不对）显式暴露，回归 28 锁定。写错的实际风险：忘记 push
  语境引入的 Node（story-3 首版漏 push Unable，Analyze 的"引用须指向更早
  出现"当场抓住）。
- **A3 类级规则三处足够**：LocatedAt 互斥、Empty 容器、ByChance×
  SameReferent 不相容。均为通用世界知识，无一按故事写。

### B. API ergonomics

- **B1 常量跨 Situation 直引很好用**（修订后）：信念语境直接提及 world
  的影子/奶酪，world 的目标直接提及信念专有对象，不需要人为共同祖先。
  全程未遇到 `Cross-Situation Node must not carry a Variable`——领域内
  唯一跨 Situation 携带 Variable 的地方是回复链路的 `ref(asked, answer)`，
  而它本来就是 ref。**将来重议 Node 级 ref 的依据**：本轮没有出现需要
  它的压力样本；字段值里装 ref 的需求（若将来出现"语境持有带洞的命题"）
  是唯一可设想的场景。
- **B2 Situation 作为 Variable 的值顺手**：`Believes{content: b}` 绑定
  b=Situation，HoldsIn/AskWhether 的 context 字段接受该绑定；join 语义
  照常工作（story-5 Q3 靠 join+区间在两份信念中挑一）。投影用语境
  title（`Context(<title>)`），title 是领域侧表层（等同 Entity.name），
  Foundation 的 Situation 无需命名机制——但如果 Foundation 未来统一
  "表层命名"，Situation.title 是现成样例。
- **B3 `Nodes()` 不限范围 + `Bindings()` 只看祖先链** 的组合对本域恰好：
  问 world 的问题天然看不到语境（P1 由结构保证），问语境的问题经约束点名
  后用 `Nodes(context)` 读它的 Assertion。没有出现需要"列出全部 Situation
  再过滤"的求解路径（候选池=可见认知引入的语境）。
- **B4 值层面约定未被触及**：含 Variable 的 Node 作为值只在其 Situation
  及后代中读取——本轮所有跨 Situation 字段值都是常量或 Situation 本身。
- **B5 每个语境需要提及 + 交错布局的负担**：语境多时（story-13 有 5 个
  root）布局仍是机械的"被引用者在前"，BuildStory 一次成型；但约束在
  于 Node 须先 push 再被引用——问题侧的模式节点（HoldsIn 的 P、PriorTo
  锚点）也必须显式 push，首版漏 push 是本轮最高频的 fixture 错误
  （5 次，全部被 Analyze 立即拒绝）。若 Foundation 提供"字段内联节点视同
  出现"的宽松模式会破坏"每个实际 Node 恰好出现一次"的不变式，不建议；
  更好的方向是一个 fixture 辅助（领域侧已可做）。
- **B6 草案 §2.6 用于是非问自然**：`AskWhether{content, verdict}` 把
  真实性关联到 verdict Variable，Query 照常解析；四种结构化结果都是普通
  冻结值，经 Reply/TextOutput 机械投影。唯一摩擦：verdict 的求值需要
  其余约束 join 完成后进行（语境/内容 Variable 先绑定），求解器为此把
  AskWhether 排在 join 之后单独判定——这是领域求解策略，Foundation 无需
  支持"约束间依赖"。

### C. 语义缺陷

- **C1（无）**：本轮未发现需要修改 Foundation 的语义问题。跨 Situation
  引用规则、Perspective、Query/Imperative 分工在时间/否定/语境三类现象
  下均未出现最小反例。
- 备忘两点非缺陷的观察：(1) `Analyze` 对"Situation 缺语义提及"的报错
  指向第一个缺提及的 Situation，多语境时定位要靠二分——便利性问题，
  不改语义；(2) 语境 title 走的是"领域给 Foundation 对象挂表层字段"
  （Situation 实例的普通属性），Foundation 的引用扫描
  （CarriesVariable/WalkReferences）不进 Situation 内部，因此 title 不
  参与任何结构判定——这层"领域可挂表层、结构不读"的默契值得在规范里
  明示。

### Phase 2r2 补充观察（B7–B8）

- **B7（Object.create 与 Final/Brand 类）**：对领域 Node 实例做
  `Object.create(instance)` 式"轻拷贝"，其结果**不满足
  `instanceof 该类`**——Final/Brand 的构造路径只在真实构造时生效。
  r4 的 Nth 解析拷贝长期依赖这种拷贝并在重入分派时悄悄走错分支
  （Next 碰巧因默认池可用而无症状；Before 一类无持有实例的类直接
  失去支持）。教训：需要 instanceof 语义的拷贝必须 `new
  constraint.constructor(situated)` 再抄写字段；凡"结构上等价的轻量
  代理"在 Final 类族里都要重新验证。
- **B8（绑定与 scope）**：一次提问的 join 绑定跨语境携带时，"变量
  与对应物一律按身份保持"和"跨语境同构节点按内容匹配"是一对必须
  显式调和的规则（本轮以 scope 过滤解决）。Foundation 的
  CheckVariableValue 允许结构化结果，但结构相等的判定始终停在
  sameValue 的递归相等上；领域若需要"跨语境同构视为可匹配"，应像
  本轮一样在领域求解层显式表达，而不是改动 Node 的相等语义。

## 附：Foundation 副本同步（2026-10-04）

`src/foundation` 增加了 `RequireInput(condition, reason)`、一次性的领域入口
`ValidateInput`，并把自检主体移到 `Test/Suite.js`（`FoundationSuite()`），见
`doc/Konsupu_Foundation_规范备忘.md` 第 16、17 节。本空间的 Foundation 副本已
同步，字节一致性回归通过。Aesop 领域本身没有语义 lint，`Memory/ValidateInput.js`
使用 Foundation 的默认实现（不做任何检查）。同步后回归 96/96，题目 65/65，
23 个变异仍各被至少一条语义回归发现。

**已知问题（同步前即存在）。** 用 Runtime 的 `konsupu test --space` 检查本空间时，
源码检查拒绝了它：格式化后 `Interface/Aesop.js` 为 179 行、
`Memory/Aesop/Verdicts.js` 为 170 行，超过 160 行上限；另有 24 个文件不是
格式化后的形态。此前"所有文件 ≤160 行"统计的是未格式化的原始行数，本空间
从未经过 Runtime 的源码检查。原型将被 Commons 取代，本次未修复。

**再次同步（同日）。** Foundation 的两条顺序规则的原因改为写明位置与改法
（备忘第 18 节）：新增 `Memory/Foundation/Placement.js`，修改 `ScanContent.js`、
`Analyze.js`，新增自检 `Test/Order.js` 并接入 `Test/Suite.js`。本空间副本已同步，
与 `src/foundation` 逐字节一致。同步后回归 96/96，题目 65/65，23 个变异仍各被
至少一条语义回归发现。
