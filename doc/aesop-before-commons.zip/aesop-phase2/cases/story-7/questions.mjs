// Frozen question texts and semantic expectations for "The Milkmaid and
// Her Pail" (guide section 6.3, Story 7). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did Patty plan to buy with the money from the milk?",
    semantic: "值:一些家禽(from Farmer Brown)",
    tests: "计划语境",
  },
  {
    text: "Who did Patty imagine would be jealous of her?",
    semantic: "值:Polly Shaw",
    tests: "想象语境内的态度",
  },
  {
    text: "Did Patty buy any fowls?",
    semantic: "未确立(想象不泄漏到 world;也不能答'否')",
    tests: "想象语境隔离",
  },
  {
    text: "What did Patty do just before the pail fell off her head?",
    semantic: "值:向后甩头(实际发生的那一次)",
    tests: "world 时序;想象中的甩头不进入 world 的 Next 链",
  },
  {
    text: "Where was the pail before Patty tossed her head back?",
    semantic: "值:她头上",
    tests: "时间锚定的状态",
  },
];

export const Twins = [
  {
    text: "Did Patty toss her head?",
    semantic: "是(实际的甩头确实发生了)",
  },
  {
    text: "In Patty's plan, what would the fowls do each morning?",
    semantic: "下蛋",
  },
];

// The five questions. The plan is a context: an attitude constraint finds
// it and HoldsIn reads its content; nothing there supports a world
// question either way, so "did she buy" is not established. The world's
// own chain answers the sequencing and anchored-state questions; the
// imagined toss never enters that chain.
import {
  Agent,
  Among,
  Assert,
  AskWhether,
  Buy,
  Enables,
  Fall,
  Habitual,
  HoldsIn,
  HoldsWhen,
  Jealous,
  LocatedAt,
  Next,
  Occurs,
  Plans,
  PriorTo,
  Sell,
  Toss,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(some fowls)",
    build(input, asked, world, answer) {
      const p = planOf(input, asked, world);
      const buying = new Buy(asked);
      buying.buyer = world.patty;
      buying.what = answer;
      input.push(buying);
      // "With the money from the milk": the buying is funded by the
      // milk's sale (the text's own discriminator, not the seller).
      const sale = new Sell(asked);
      sale.what = world.milk;
      input.push(sale);
      const funded = new Enables(asked);
      funded.enabler = sale;
      funded.enabled = buying;
      input.push(funded);
      const held = new HoldsIn(asked);
      held.context = p;
      held.proposition = funded;
      Assert(input, held);
      return [p];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "Entity(Polly Shaw)",
    build(input, asked, world, answer) {
      const p = planOf(input, asked, world);
      const jealous = new Jealous(asked);
      jealous.subject = answer;
      input.push(jealous);
      const held = new HoldsIn(asked);
      held.context = p;
      held.proposition = jealous;
      Assert(input, held);
      return [p];
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const d = new Buy(asked);
      d.buyer = world.patty;
      d.what = world.fowls;
      input.push(d);
      const happened = new Occurs(asked);
      happened.event = d;
      input.push(happened);
      const asked1 = new AskWhether(asked);
      asked1.content = happened;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Toss(manner=back,theme=Entity(her head))",
    build(input, asked, world, answer) {
      const when = new Next(asked);
      when.earlier = answer;
      when.later = world.pailFell;
      Assert(input, when);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "Entity(her head)",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked);
      where.entity = world.pail;
      where.place = answer;
      Assert(input, where);
      const before = new PriorTo(asked);
      before.event = world.tossHead;
      input.push(before);
      const when = new HoldsWhen(asked);
      when.state = where;
      when.when = before;
      Assert(input, when);
    },
  },
];

// The asked Plans constraint binding the plan context.
function planOf(input, asked, world) {
  const p = new Variable(asked);
  input.push(p);
  const plan = new Plans(asked);
  plan.planner = world.patty;
  plan.content = p;
  Assert(input, plan);
  return p;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      // Asked through the agent machinery: the doing must have
      // happened, not been pre-asserted by the question.
      const d = new Toss(asked);
      d.theme = world.head;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.patty;
      input.push(who);
      const asked1 = new AskWhether(asked);
      asked1.content = who;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "Lay(theme=Entity(eggs))",
    build(input, asked, world, answer) {
      const p = planOf(input, asked, world);
      const habit = new Habitual(asked);
      habit.doer = world.fowls;
      habit.deed = answer;
      input.push(habit);
      const held = new HoldsIn(asked);
      held.context = p;
      held.proposition = habit;
      Assert(input, held);
      return [p];
    },
  },
];
