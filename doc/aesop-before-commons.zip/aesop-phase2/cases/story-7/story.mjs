// BuildStory for "The Milkmaid and Her Pail". Patty's calculating is one
// plan context, spoken aloud as she goes: it holds her intended buyings,
// the fowls' imagined habit, Polly's imagined jealousy, and an imagined
// head-toss of its own — none of which the world holds or hosts in its
// Next chain. The real toss, the pail's fall, and the spilt milk are
// world events; the pail's two locations are anchored (on her head from
// the start, on the ground from the fall). Nothing in the plan leaks
// into the world: no buying ever occurred.
import {
  Agent,
  Assert,
  HeadTo,
  AssertOccurs,
  Buy,
  Carrying,
  Causes,
  ComeTo,
  context,
  Entity,
  Fall,
  Enables,
  Habitual,
  Initially,
  Overlaps,
  Jealous,
  LocatedAt,
  Lay,
  Next,
  Occurs,
  Plans,
  ResultsIn,
  Sell,
  Says,
  Toss,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later, holder = root) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation, holder);
}

export function BuildStory(input, root) {
  const patty = entity(root, "Patty the Milkmaid");
  const milk = entity(root, "her milk");
  const pail = entity(root, "the Pail");
  const market = entity(root, "the market");
  const head = entity(root, "her head");
  const ground = entity(root, "the ground");
  const home = entity(root, "home");
  const mother = entity(root, "her mother");
  input.push(patty, milk, pail, market, head, ground, home, mother);

  // The plan context: everything Patty worked out for the money.
  const plan = context(
    new Situation(),
    "what she would do with the money for the milk",
  );
  input.push(plan);
  const fowls = entity(plan, "some fowls");
  const farmerBrown = entity(plan, "Farmer Brown");
  const eggs = entity(plan, "eggs");
  const eachMorning = entity(plan, "each morning");
  const parsonsWife = entity(plan, "the parson's wife");
  const frock = entity(plan, "a new dimity frock");
  const hat = entity(plan, "a chip hat");
  const polly = entity(plan, "Polly Shaw");
  const youngMen = entity(plan, "all the young men");
  input.push(
    fowls, farmerBrown, eggs, eachMorning, parsonsWife, frock, hat, polly,
    youngMen,
  );

  // "The money she would get for the milk": the milk's sale, which the
  // plan presupposes. Each purchase is funded by a sale, so the money is
  // told apart by what was sold, never by a surface name.
  const sellMilk = new Sell(plan);
  sellMilk.seller = patty;
  sellMilk.what = milk;
  input.push(sellMilk);
  AssertOccurs(input, sellMilk, plan);
  agent(plan, input, sellMilk, patty);

  const buyFowls = new Buy(plan);
  buyFowls.buyer = patty;
  buyFowls.what = fowls;
  buyFowls.from = farmerBrown;
  input.push(buyFowls);
  AssertOccurs(input, buyFowls, plan);
  agent(plan, input, buyFowls, patty);

  const layEggs = new Lay(plan);
  layEggs.theme = eggs;
  input.push(layEggs);
  const layingHabit = new Habitual(plan);
  layingHabit.doer = fowls;
  layingHabit.deed = layEggs;
  layingHabit.frequency = eachMorning;
  Assert(input, layingHabit, plan);

  const sellEggs = new Sell(plan);
  sellEggs.seller = patty;
  sellEggs.what = eggs;
  sellEggs.to = parsonsWife;
  input.push(sellEggs);
  AssertOccurs(input, sellEggs, plan);
  agent(plan, input, sellEggs, patty);

  const buyClothes = new Buy(plan);
  buyClothes.buyer = patty;
  buyClothes.what = [frock, hat];
  input.push(buyClothes);
  AssertOccurs(input, buyClothes, plan);
  agent(plan, input, buyClothes, patty);

  // The two fundings: the fowls with the milk's sale, the clothes with
  // the eggs' — "I'll buy some fowls … with the money that I get from
  // the sale of these eggs I'll buy myself …".
  const fowlsFunded = new Enables(plan);
  fowlsFunded.enabler = sellMilk;
  fowlsFunded.enabled = buyFowls;
  Assert(input, fowlsFunded, plan);
  const clothesFunded = new Enables(plan);
  clothesFunded.enabler = sellEggs;
  clothesFunded.enabled = buyClothes;
  Assert(input, clothesFunded, plan);

  const menComeUp = new ComeTo(plan);
  menComeUp.destination = patty;
  input.push(menComeUp);
  AssertOccurs(input, menComeUp, plan);
  agent(plan, input, menComeUp, youngMen);

  const jealousPolly = new Jealous(plan);
  jealousPolly.subject = polly;
  Assert(input, jealousPolly, plan);

  // The toss inside the plan — never in the world's chain.
  const plannedToss = new Toss(plan);
  plannedToss.theme = head;
  plannedToss.manner = "like this";
  input.push(plannedToss);
  AssertOccurs(input, plannedToss, plan);
  agent(plan, input, plannedToss, patty);

  // The imagined future, one chain: the milk sold, buy, sell, buy, the
  // men come up, the toss. Nothing here ever enters the world's chain.
  const imagined = [sellMilk, buyFowls, sellEggs, buyClothes, menComeUp, plannedToss];
  for (let index = 0; index + 1 < imagined.length; index += 1) {
    next(root, input, imagined[index], imagined[index + 1], plan);
  }

  const planning = new Plans(root);
  planning.planner = patty;
  planning.content = plan;
  input.push(planning);

  // "Was going to market": atelic — on the way, arrival never implied.
  const going = new HeadTo(root);
  going.destination = market;
  const planSay = new Says(root);
  planSay.text =
    "I'll buy some fowls from Farmer Brown, and they will lay eggs each morning, which I will sell to the parson's wife...";
  planSay.content = plan;
  const tossHead = new Toss(root);
  tossHead.theme = head;
  tossHead.manner = "back";
  const pailFell = new Fall(root);
  pailFell.theme = pail;
  pailFell.destination = ground;
  const milkFell = new Fall(root);
  milkFell.theme = milk;
  milkFell.destination = ground;
  const wentHome = new ComeTo(root);
  wentHome.destination = home;
  const toldMother = new Says(root);
  toldMother.to = mother;
  toldMother.text = "what had occurred";
  const happened = [
    going,
    planSay,
    tossHead,
    pailFell,
    milkFell,
    wentHome,
    toldMother,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, going, patty);
  agent(root, input, planSay, patty);
  agent(root, input, tossHead, patty);
  agent(root, input, wentHome, patty);
  agent(root, input, toldMother, patty);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    if (happened[index] === planSay && happened[index + 1] === tossHead) {
      continue;
    }
    next(root, input, happened[index], happened[index + 1]);
  }

  // "As she spoke she tossed her head back": the toss is inside the
  // speaking's frame, not after it.
  const whileSpeaking = new Overlaps(root);
  whileSpeaking.first = planSay;
  whileSpeaking.second = tossHead;
  Assert(input, whileSpeaking);

  const carrying = new Carrying(root);
  carrying.carrier = patty;
  carrying.theme = pail;
  Assert(input, carrying);
  const pailOnHead = new LocatedAt(root);
  pailOnHead.entity = pail;
  pailOnHead.place = head;
  input.push(pailOnHead);
  const onHeadAtFirst = new Initially(root);
  onHeadAtFirst.state = pailOnHead;
  Assert(input, onHeadAtFirst);
  const pailOnGround = new LocatedAt(root);
  pailOnGround.entity = pail;
  pailOnGround.place = ground;
  input.push(pailOnGround);
  const fellResult = new ResultsIn(root);
  fellResult.event = pailFell;
  fellResult.proposition = pailOnGround;
  Assert(input, fellResult);

  const tossingDropped = new Causes(root);
  tossingDropped.cause = tossHead;
  tossingDropped.effect = pailFell;
  Assert(input, tossingDropped);

  const calcBegan = new ResultsIn(root);
  calcBegan.event = going;
  calcBegan.proposition = planning;
  Assert(input, calcBegan);

  return {
    root,
    patty,
    milk,
    pail,
    head,
    ground,
    plan,
    fowls,
    farmerBrown,
    tossHead,
    pailFell,
  };
}
