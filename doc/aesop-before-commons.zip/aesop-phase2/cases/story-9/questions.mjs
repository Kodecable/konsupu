// Frozen question texts and semantic expectations for "The Wolf in
// Sheep's Clothing" (guide section 6.3, Story 9). The English text never
// changes; `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Whose skin was the wolf wearing?",
    semantic: "值:那只被剥了皮的羊(小羊的母亲)",
    tests: "关系个体",
  },
  {
    text: "How did the wolf deceive the sheep?",
    semantic: "值:把羊皮披在自己的皮毛外面",
    tests: "非言语欺骗的手段",
  },
  {
    text: "For how long did the wolf succeed in deceiving the sheep?",
    semantic: "值:for some time(模糊时长,不是 Unknown)",
    tests: "时长",
  },
  {
    text: "Did the lamb think the wolf was its mother?",
    semantic: "未确立(P6:不从行为推断信念)",
    tests: "心理状态只取文本依据",
  },
  {
    text: "Before he found the sheep's skin, could the wolf get at the sheep easily?",
    semantic: "否",
    tests: "时间锚定的困难('great difficulty')",
  },
];

export const Twins = [
  {
    text: "Did the lamb follow the wolf?",
    semantic: "是",
  },
  {
    text: "Whom did the wolf deceive?",
    semantic: "the sheep",
  },
];

// The five questions. The wearing reads a state plus its possession; the
// means of the deceiving is the event whose result starts it; the
// duration is a stated value; the lamb has no belief anywhere to consult;
// "could" asks the complement of an anchored inability.
import {
  Agent,
  Among,
  Assert,
  AskWhether,
  Believes,
  BelongsTo,
  Entity,
  Deceives,
  Follow,
  GetAt,
  Lasted,
  Not,
  PriorTo,
  PutOn,
  ResultsIn,
  SameReferent,
  Unable,
  Wears,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(the sheep that had been flayed)",
    build(input, asked, world, answer) {
      const c = new Variable(asked);
      input.push(c);
      const wearing = new Wears(asked);
      wearing.wearer = world.wolf;
      wearing.clothing = c;
      Assert(input, wearing);
      const owned = new BelongsTo(asked);
      owned.possession = c;
      owned.owner = answer;
      Assert(input, owned);
      return [c];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "PutOn(over=Entity(its own pelt),theme=Entity(the skin of a sheep))",
    build(input, asked, world, answer) {
      const deceiving = new Deceives(asked);
      deceiving.deceiver = world.wolf;
      deceiving.victim = world.sheep;
      input.push(deceiving);
      const how = new ResultsIn(asked);
      how.event = answer;
      how.proposition = deceiving;
      Assert(input, how);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "Entity(some time)",
    build(input, asked, world, answer) {
      const deceiving = new Deceives(asked);
      deceiving.deceiver = world.wolf;
      deceiving.victim = world.sheep;
      input.push(deceiving);
      const lasted = new Lasted(asked);
      lasted.state = deceiving;
      lasted.duration = answer;
      Assert(input, lasted);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected:
      "{constraints=[Believes],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      // The question names the content it asks about — the wolf
      // identified with the lamb's dam — and asks whether the lamb
      // holds a belief of that shape. With no belief at all the
      // Believes constraint itself fails; an unrelated belief fails the
      // content question inside it.
      // "Its mother": described by the relation, not by a surface name.
      const dam = new Entity(asked);
      input.push(dam);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = dam;
      Assert(input, h);
      const owned = new BelongsTo(asked);
      owned.possession = world.lamb;
      owned.owner = dam;
      Assert(input, owned);
      const b = new Variable(asked);
      input.push(b);
      const belief = new Believes(asked);
      belief.believer = world.lamb;
      belief.content = b;
      Assert(input, belief);
      const claim = new SameReferent(asked);
      claim.left = world.wolf;
      claim.right = dam;
      input.push(claim);
      const asked1 = new AskWhether(asked);
      asked1.content = claim;
      asked1.context = b;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [b];
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const deed = new GetAt(asked);
      deed.theme = world.sheep;
      deed.manner = "easily";
      input.push(deed);
      const strained = new Unable(asked);
      strained.actor = world.wolf;
      strained.deed = deed;
      input.push(strained);
      const could = new Not(asked);
      could.proposition = strained;
      input.push(could);
      const before = new PriorTo(asked);
      before.event = world.foundSkin;
      input.push(before);
      const asked1 = new AskWhether(asked);
      asked1.content = could;
      asked1.when = before;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const d = new Follow(asked);
      d.theme = world.wolf;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.lamb;
      input.push(who);
      const asked1 = new AskWhether(asked);
      asked1.content = who;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "Entity(the sheep)",
    build(input, asked, world, answer) {
      const deceived = new Deceives(asked);
      deceived.deceiver = world.wolf;
      deceived.victim = answer;
      Assert(input, deceived);
    },
  },
];
