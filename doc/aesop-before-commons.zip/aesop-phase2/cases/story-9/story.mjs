// BuildStory for "The Wolf in Sheep's Clothing". The deceiving is a
// state that starts at the disguising and succeeds "for some time" — a
// stated vague duration, never an Unknown. The wolf never speaks: the
// deception is the wearing, non-verbal by construction. Nothing says what
// the lamb believed (P6): no belief of its own exists anywhere. The
// difficulty before the skin is an anchored inability ("found great
// difficulty" is the lexical basis, see RESULTS); the skin's owner and
// the lamb's dam are explicit possessions.
import {
  Agent,
  Assert,
  AssertOccurs,
  BelongsTo,
  context,
  Deceives,
  Eat,
  Ends,
  Entity,
  Find,
  Follow,
  GetAt,
  Initially,
  Lasted,
  Lead,
  LocatedAt,
  Next,
  PutOn,
  ResultsIn,
  Stroll,
  Unable,
  Wears,
} from "../../space/Interface/Aesop.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const wolf = entity(root, "the Wolf");
  const shepherd = entity(root, "the shepherd");
  const dogs = entity(root, "his dogs");
  const sheep = entity(root, "the sheep");
  const lamb = entity(root, "the Lamb");
  const flayedSheep = entity(root, "the sheep that had been flayed");
  const skin = entity(root, "the skin of a sheep");
  const pelt = entity(root, "its own pelt");
  const someTime = entity(root, "some time");
  input.push(
    wolf, shepherd, dogs, sheep, lamb, flayedSheep, skin, pelt, someTime,
  );

  // "Found great difficulty in getting at the sheep": he could not get
  // at them easily — an inability of the easy way only, never of getting
  // at them at all. It holds from the start; the text marks no ending of
  // it, so none is asserted (P2 cuts both ways).
  const gettingAt = new GetAt(root);
  gettingAt.theme = sheep;
  gettingAt.manner = "easily";
  input.push(gettingAt);
  const strained = new Unable(root);
  strained.actor = wolf;
  strained.deed = gettingAt;
  input.push(strained);
  const strainedAtFirst = new Initially(root);
  strainedAtFirst.state = strained;
  Assert(input, strainedAtFirst);

  const foundSkin = new Find(root);
  foundSkin.theme = skin;
  const putOn = new PutOn(root);
  putOn.theme = skin;
  putOn.over = pelt;
  const strolled = new Stroll(root);
  const lambFollowed = new Follow(root);
  lambFollowed.theme = wolf;
  const ledApart = new Lead(root);
  ledApart.theme = lamb;
  const madeMeal = new Eat(root);
  madeMeal.theme = lamb;
  const happened = [foundSkin, putOn, strolled, lambFollowed, ledApart, madeMeal];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, foundSkin, wolf);
  agent(root, input, putOn, wolf);
  agent(root, input, strolled, wolf);
  agent(root, input, lambFollowed, lamb);
  agent(root, input, ledApart, wolf);
  agent(root, input, madeMeal, wolf);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  const wearing = new Wears(root);
  wearing.wearer = wolf;
  wearing.clothing = skin;
  input.push(wearing);
  const dressed = new ResultsIn(root);
  dressed.event = putOn;
  dressed.proposition = wearing;
  Assert(input, dressed);

  const deceiving = new Deceives(root);
  deceiving.deceiver = wolf;
  deceiving.victim = sheep;
  input.push(deceiving);
  const began = new ResultsIn(root);
  began.event = putOn;
  began.proposition = deceiving;
  Assert(input, began);
  const lasted = new Lasted(root);
  lasted.state = deceiving;
  lasted.duration = someTime;
  Assert(input, lasted);

  const skinsOwner = new BelongsTo(root);
  skinsOwner.possession = skin;
  skinsOwner.owner = flayedSheep;
  Assert(input, skinsOwner);
  const lambsDam = new BelongsTo(root);
  lambsDam.possession = lamb;
  lambsDam.owner = flayedSheep;
  Assert(input, lambsDam);

  return {
    root,
    wolf,
    sheep,
    lamb,
    flayedSheep,
    skin,
    foundSkin,
    putOn,
    madeMeal,
    deceiving,
    strained,
  };
}
