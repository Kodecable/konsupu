// BuildStory for "The Ass's Brains". The message, the lion's orders, and
// the fox's reply are three speech contexts: the proposal lives in the
// message, the prohibition in the orders, the negated possession in the
// reply — the world holds none of them. The world does hold the ass's
// brains from the start until the fox takes them out, so the reply's
// claim is false at the time it is about (the trap-time), and the lion's
// noticing reads the absence that starts at the taking. "Finding that his
// master did not return" is the fox's perception of a negated happening
// within the interval — its content is perception content, not a
// world-held negation. The lion's away-ness is an anchored state the
// eating lies inside.
import {
  Agent,
  Assert,
  AssertOccurs,
  Away,
  ComeBack,
  ComeTo,
  context,
  Eat,
  Ends,
  Entity,
  Forbids,
  Has,
  HoldsWhen,
  Hunt,
  Initially,
  Missing,
  Motivates,
  Next,
  Notice,
  Not,
  Occurs,
  Overjoyed,
  Proposes,
  Pounce,
  ResultsIn,
  Says,
  Take,
  Touch,
  Wait,
  GoAway,
  Advise,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const lion = entity(root, "the Lion");
  const fox = entity(root, "the Fox");
  const ass = entity(root, "the Ass");
  const brains = entity(root, "the brains of the Ass");
  const prey = entity(root, "the prey");
  const meetingPlace = entity(root, "the place of meeting");
  input.push(lion, fox, ass, brains, prey, meetingPlace);

  // The message: an alliance proposed.
  const messageCtx = context(new Situation(), "the message to the Ass");
  input.push(messageCtx);
  const alliance = entity(messageCtx, "an alliance between their two families");
  input.push(alliance);
  const proposed = new Proposes(messageCtx);
  proposed.proposer = lion;
  proposed.to = ass;
  proposed.proposal = alliance;
  Assert(input, proposed, messageCtx);

  // The lion's orders: watch, nap, and the prohibition.
  const ordersCtx = context(new Situation(), "the Lion's orders to the Fox");
  input.push(ordersCtx);
  const touchPrey = new Touch(ordersCtx);
  touchPrey.theme = prey;
  input.push(touchPrey);
  const forbidden = new Forbids(ordersCtx);
  forbidden.deed = touchPrey;
  Assert(input, forbidden, ordersCtx);

  // The fox's reply: the ass had no brains — "or it would never have
  // fallen into your trap", so what he says is about the trap-time, the
  // pounce. The reply holds the claim anchored there; a saying is judged
  // at the time it is about, which the speech itself fixes.
  const replyCtx = context(new Situation(), "the Fox's reply");
  input.push(replyCtx);
  const lacked = new Has(replyCtx);
  lacked.owner = ass;
  lacked.possession = brains;
  input.push(lacked);
  const noBrains = new Not(replyCtx);
  noBrains.proposition = lacked;
  input.push(noBrains);

  // The ass had its brains from the start, until they were taken out.
  const hadBrains = new Has(root);
  hadBrains.owner = ass;
  hadBrains.possession = brains;
  input.push(hadBrains);
  const hadAtFirst = new Initially(root);
  hadAtFirst.state = hadBrains;
  Assert(input, hadAtFirst);

  const wentHunting = new Hunt(root);
  const message = new Says(root);
  message.to = ass;
  message.text = "proposing to make an alliance between their two families";
  message.content = messageCtx;
  // "On the advice of the Fox": advising the lion to send that message,
  // before he sent it.
  const advice = new Advise(root);
  advice.to = lion;
  advice.advised = message;
  const assCame = new ComeTo(root);
  assCame.destination = meetingPlace;
  const lionPounce = new Pounce(root);
  lionPounce.theme = ass;
  const lionSay = new Says(root);
  lionSay.to = fox;
  lionSay.text =
    "Here is our dinner for to-day. Watch you here while I go and have a nap. Woe betide you if you touch my prey.";
  lionSay.content = ordersCtx;
  const lionAway = new GoAway(root);
  const foxWaited = new Wait(root);
  // "Finding that his master did not return": the fox's perception of a
  // negated happening, its content never world-held.
  const lionBack = new ComeBack(root);
  input.push(lionBack);
  const masterBack = new Occurs(root);
  masterBack.event = lionBack;
  input.push(masterBack);
  const notReturning = new Not(root);
  notReturning.proposition = masterBack;
  input.push(notReturning);
  const foxFinding = new Notice(root);
  foxFinding.theme = notReturning;
  const takeBrains = new Take(root);
  takeBrains.theme = brains;
  takeBrains.source = ass;
  const ateBrains = new Eat(root);
  ateBrains.theme = brains;
  const missing = new Missing(root);
  missing.thing = brains;
  input.push(missing);
  const lionNotice = new Notice(root);
  lionNotice.theme = missing;
  const lionAsk = new Says(root);
  lionAsk.to = fox;
  lionAsk.text = "What have you done with the brains?";
  const foxReply = new Says(root);
  foxReply.text = "Brains, your Majesty! it had none, or it would never have fallen into your trap.";
  foxReply.content = replyCtx;
  const happened = [
    wentHunting,
    advice,
    message,
    assCame,
    lionPounce,
    lionSay,
    lionAway,
    foxWaited,
    foxFinding,
    takeBrains,
    ateBrains,
    lionNotice,
    lionAsk,
    foxReply,
  ];
  // The advice names the message, so the message occurs first in the
  // Input; Input order is never time — the chain above is.
  input.push(message, ...happened.filter((event) => event !== message));
  AssertOccurs(input, lionBack);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, wentHunting, lion);
  agent(root, input, wentHunting, fox);
  agent(root, input, advice, fox);
  agent(root, input, message, lion);
  agent(root, input, assCame, ass);
  agent(root, input, lionPounce, lion);
  agent(root, input, lionSay, lion);
  agent(root, input, lionAway, lion);
  agent(root, input, foxWaited, fox);
  agent(root, input, foxFinding, fox);
  agent(root, input, takeBrains, fox);
  agent(root, input, ateBrains, fox);
  agent(root, input, lionBack, lion);
  agent(root, input, lionNotice, lion);
  agent(root, input, lionAsk, lion);
  agent(root, input, foxReply, fox);

  // The reply's claim, at the time it is about.
  const atTrap = new HoldsWhen(replyCtx);
  atTrap.state = noBrains;
  atTrap.when = lionPounce;
  Assert(input, atTrap, replyCtx);

  const chain = [...happened.slice(0, 11), lionBack, ...happened.slice(11)];
  for (let index = 0; index + 1 < chain.length; index += 1) {
    next(root, input, chain[index], chain[index + 1]);
  }

  const glad = new Overjoyed(root);
  glad.subject = ass;
  input.push(glad);
  const gladAt = new ResultsIn(root);
  gladAt.event = assCame;
  gladAt.proposition = glad;
  Assert(input, gladAt);

  const gone = new Away(root);
  gone.subject = lion;
  input.push(gone);
  const leftAt = new ResultsIn(root);
  leftAt.event = lionAway;
  leftAt.proposition = gone;
  Assert(input, leftAt);
  const backEnded = new Ends(root);
  backEnded.event = lionBack;
  backEnded.state = gone;
  Assert(input, backEnded);

  const brainsGone = new ResultsIn(root);
  brainsGone.event = takeBrains;
  brainsGone.proposition = missing;
  Assert(input, brainsGone);
  const hadEnded = new Ends(root);
  hadEnded.event = takeBrains;
  hadEnded.state = hadBrains;
  Assert(input, hadEnded);

  const findingMoved = new Motivates(root);
  findingMoved.driver = foxFinding;
  findingMoved.action = takeBrains;
  Assert(input, findingMoved);

  return {
    root,
    lion,
    fox,
    ass,
    brains,
    meetingPlace,
    message,
    messageCtx,
    ordersCtx,
    replyCtx,
    foxReply,
    noBrains,
    assCame,
    lionPounce,
    lionAway,
    lionBack,
    takeBrains,
    hadBrains,
    gone,
  };
}
