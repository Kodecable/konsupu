// Frozen question texts and semantic expectations for "The Ass's Brains"
// (guide section 6.3, Story 12). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the lion propose to the ass?",
    semantic: "值:两家结盟",
    tests: "言语内容",
  },
  {
    text: "What did the lion forbid the fox to do?",
    semantic: "值:碰他的猎物",
    tests: "禁令(否定的祈使内容)",
  },
  {
    text: "What did the fox eat while the lion was away?",
    semantic: "值:驴的脑子",
    tests: "'while' 区间",
  },
  {
    text: "What did the lion notice when he came back?",
    semantic: "值:脑子不见了",
    tests: "N6 缺失被感知",
  },
  {
    text: "Was the fox telling the truth when he said the ass had no brains?",
    semantic: "否",
    tests: "所说内容关于更早的时间;被持续性推出的状态否定",
  },
];

export const Twins = [
  {
    text: "Did the ass have brains when he came to the place of meeting?",
    semantic: "是(脑子一直在,直到狐狸取出)",
  },
  {
    text: "Who advised the lion to send the message?",
    semantic: "the fox",
  },
];

// The five questions. The message and the orders are read inside their
// speech contexts; the while-eating is pinned by the going and the
// coming-back around it; the noticing reads the absence that starts at
// the taking; the reply's claim is evaluated in the world at the time it
// is about (the trap-time), where the held possession refutes it.
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Before,
  Eat,
  Forbids,
  Has,
  HoldsIn,
  HoldsWhen,
  Next,
  Not,
  Notice,
  Occurs,
  Proposes,
  Says,
  Advise,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(an alliance between their two families)",
    build(input, asked, world, answer) {
      const s = speechBy(input, asked, world, world.lion, world.ass);
      const proposed = new Proposes(asked);
      proposed.proposer = world.lion;
      proposed.proposal = answer;
      input.push(proposed);
      const held = new HoldsIn(asked);
      held.context = s;
      held.proposition = proposed;
      Assert(input, held);
      return [s];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "Touch(theme=Entity(the prey))",
    build(input, asked, world, answer) {
      const s = speechBy(input, asked, world, world.lion, world.fox);
      const forbidden = new Forbids(asked);
      forbidden.deed = answer;
      input.push(forbidden);
      const held = new HoldsIn(asked);
      held.context = s;
      held.proposition = forbidden;
      Assert(input, held);
      return [s];
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "Entity(the brains of the Ass)",
    build(input, asked, world, answer) {
      const d = new Eat(asked);
      d.theme = answer;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      // "While the lion was away": the eating lies between the going
      // and the coming-back.
      const after = new Before(asked);
      after.earlier = world.lionAway;
      after.later = d;
      Assert(input, after);
      const before = new Before(asked);
      before.earlier = d;
      before.later = world.lionBack;
      Assert(input, before);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Missing(thing=Entity(the brains of the Ass))",
    build(input, asked, world, answer) {
      const d = new Notice(asked);
      d.theme = answer;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.lion;
      Assert(input, who);
      const when = new Next(asked);
      when.earlier = world.lionBack;
      when.later = d;
      Assert(input, when);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const r = new Variable(asked);
      input.push(r);
      const d = new Says(asked);
      d.content = r;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      const claimed = new Not(asked);
      const lacked = new Has(asked);
      lacked.owner = world.ass;
      lacked.possession = world.brains;
      input.push(lacked);
      claimed.proposition = lacked;
      input.push(claimed);
      // What he said, at the time his saying is about: the reply holds
      // the claim anchored, and the question reads both from it.
      const t = new Variable(asked);
      input.push(t);
      const claimAt = new HoldsWhen(asked);
      claimAt.state = claimed;
      claimAt.when = t;
      input.push(claimAt);
      const said = new HoldsIn(asked);
      said.context = r;
      said.proposition = claimAt;
      Assert(input, said);
      const asked1 = new AskWhether(asked);
      asked1.content = claimed;
      asked1.when = t;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [r, t];
    },
  },
];

// A speech by one speaker to one addressee, bound through its Says.
function speechBy(input, asked, world, speaker, addressee) {
  const s = new Variable(asked);
  input.push(s);
  const d = new Says(asked);
  d.content = s;
  d.to = addressee;
  input.push(d);
  const h = new Among(asked);
  h.situation = world.root;
  h.node = d;
  Assert(input, h);
  AssertOccurs(input, d);
  const who = new Agent(asked);
  who.action = d;
  who.actor = speaker;
  Assert(input, who);
  return s;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const had = new Has(asked);
      had.owner = world.ass;
      had.possession = world.brains;
      Assert(input, had);
      const asked1 = new AskWhether(asked);
      asked1.content = had;
      asked1.when = world.assCame;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "Entity(the Fox)",
    build(input, asked, world, answer) {
      // "Advised the lion to send the message": the message is the one
      // saying to the ass; the advising names it and the lion.
      const sent = new Says(asked);
      sent.to = world.ass;
      input.push(sent);
      const known = new Among(asked);
      known.situation = world.root;
      known.node = sent;
      Assert(input, known);
      const d = new Advise(asked);
      d.to = world.lion;
      d.advised = sent;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = answer;
      Assert(input, who);
    },
  },
];
