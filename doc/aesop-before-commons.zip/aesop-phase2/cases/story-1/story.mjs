// BuildStory for "The Crow and the Pitcher". Every narration event —
// including the non-agentive Rise — occurs; the crow is the agent of its
// doings through reified Agent propositions; changeable states are
// time-anchored: thirst holds from the story's start and the drinking
// ends it, the inability to get at the water begins when the crow finds
// it (putting its beak in) and the casting of a few more pebbles
// ends it, as the text orders. The chain asserts
// the adjacent Next of narration events (Before is what the chain
// entails, never enumerated), the risen water enables the drinking, and
// the pebble's resting place is the result of the drop. The six "took a
// pebble and dropped it" sentences are the first Drop plus one Drop of
// the other pebbles; the water rises from the Series of both, not from
// any single pebble ("little by little"), and the crow casts in a few
// more pebbles after the rise and before drinking, as the text says.
// "Had once been full of water" is a state before the story began and is
// deliberately not represented. The story holds no question cognition of
// any kind.
import {
  Agent,
  Assert,
  AssertOccurs,
  Causes,
  Drop,
  Enables,
  Ends,
  Entity,
  Failed,
  FlyOff,
  GetAt,
  Goal,
  InOrderTo,
  Initially,
  Series,
  LocatedAt,
  Next,
  Put,
  Quench,
  ResultsIn,
  Rise,
  Save,
  Thirsty,
  ThinkUp,
  TryToDrink,
  Unable,
  ComeUpon,
} from "../../space/Interface/Aesop.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const crow = entity(root, "the crow");
  const pitcher = entity(root, "the pitcher");
  const water = entity(root, "the water");
  const pebble = entity(root, "a pebble");
  const otherPebbles = entity(root, "the other pebbles");
  const morePebbles = entity(root, "a few more pebbles");
  const beak = entity(root, "its beak");
  const thirst = entity(root, "its thirst");
  const life = entity(root, "its life");
  input.push(
    crow,
    pitcher,
    water,
    pebble,
    otherPebbles,
    morePebbles,
    beak,
    thirst,
    life,
  );

  const thirsty = new Thirsty(root);
  thirsty.subject = crow;
  input.push(thirsty);
  const thirstyAtFirst = new Initially(root);
  thirstyAtFirst.state = thirsty;
  Assert(input, thirstyAtFirst);

  const comeUpon = new ComeUpon(root);
  comeUpon.theme = pitcher;
  const putBeak = new Put(root);
  putBeak.theme = beak;
  putBeak.destination = pitcher;
  const tryDrink = new TryToDrink(root);
  tryDrink.theme = water;
  const think = new ThinkUp(root);
  const dropFirst = new Drop(root);
  dropFirst.theme = pebble;
  dropFirst.destination = pitcher;
  const dropOthers = new Drop(root);
  dropOthers.theme = otherPebbles;
  dropOthers.destination = pitcher;
  const waterRise = new Rise(root);
  waterRise.theme = water;
  const castMore = new Drop(root);
  castMore.theme = morePebbles;
  castMore.destination = pitcher;
  const drink = new Quench(root);
  drink.theme = thirst;
  const saveLife = new Save(root);
  saveLife.theme = life;
  const happened = [
    comeUpon,
    putBeak,
    tryDrink,
    think,
    dropFirst,
    dropOthers,
    waterRise,
    castMore,
    drink,
    saveLife,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  // "He could not reach far enough down to get at it", found when the
  // beak went in, ended only after the few more pebbles ("after casting
  // in a few more pebbles he was able to") — not at the rise itself.
  // The deed is a shape of getting at the water — not the trying that
  // occurred (being unable to do what one did is no inability at all).
  const gettingAt = new GetAt(root);
  gettingAt.theme = water;
  input.push(gettingAt);
  const unable = new Unable(root);
  unable.actor = crow;
  unable.deed = gettingAt;
  input.push(unable);
  const foundUnable = new ResultsIn(root);
  foundUnable.event = putBeak;
  foundUnable.proposition = unable;
  Assert(input, foundUnable);
  const ableAgain = new Ends(root);
  ableAgain.event = castMore;
  ableAgain.state = unable;
  Assert(input, ableAgain);
  const thirstEnded = new Ends(root);
  thirstEnded.event = drink;
  thirstEnded.state = thirsty;
  Assert(input, thirstEnded);

  agent(root, input, comeUpon, crow);
  agent(root, input, putBeak, crow);
  agent(root, input, tryDrink, crow);
  agent(root, input, think, crow);
  agent(root, input, dropFirst, crow);
  agent(root, input, dropOthers, crow);
  agent(root, input, castMore, crow);
  agent(root, input, drink, crow);
  agent(root, input, saveLife, crow);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  const failed = new Failed(root);
  failed.action = tryDrink;
  Assert(input, failed);
  // The droppings together, one after another, made the water rise.
  const dropping = new Series(root);
  dropping.parts = [dropFirst, dropOthers];
  input.push(dropping);
  AssertOccurs(input, dropping);
  agent(root, input, dropping, crow);
  const pebbleDropped = new Causes(root);
  pebbleDropped.cause = dropping;
  pebbleDropped.effect = waterRise;
  Assert(input, pebbleDropped);
  const riseLetDrink = new Causes(root);
  riseLetDrink.cause = waterRise;
  riseLetDrink.effect = drink;
  Assert(input, riseLetDrink);
  const drinkSaved = new Causes(root);
  drinkSaved.cause = drink;
  drinkSaved.effect = saveLife;
  Assert(input, drinkSaved);

  const pebbleRests = new LocatedAt(root);
  pebbleRests.entity = pebble;
  pebbleRests.place = pitcher;
  input.push(pebbleRests);
  const pebbleResult = new ResultsIn(root);
  pebbleResult.event = dropFirst;
  pebbleResult.proposition = pebbleRests;
  Assert(input, pebbleResult);

  const goal = new Goal(root);
  goal.actor = crow;
  goal.objective = drink;
  Assert(input, goal);
  const dropAimed = new InOrderTo(root);
  dropAimed.action = dropping;
  dropAimed.goal = waterRise;
  Assert(input, dropAimed);
  // The risen water is what made the drinking possible: "was then able to".
  const riseAble = new Enables(root);
  riseAble.enabler = waterRise;
  riseAble.enabled = drink;
  Assert(input, riseAble);

  return {
    root,
    crow,
    water,
    pitcher,
    pebble,
    putBeak,
    tryDrink,
    dropFirst,
    dropOthers,
    castMore,
    dropping,
    waterRise,
    drink,
  };
}
