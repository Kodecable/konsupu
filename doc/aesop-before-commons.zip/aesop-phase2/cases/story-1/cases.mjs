// Builds the complete Input for one question as three Situations: the
// dialogue root comes first (it is the initial Situation and needs no
// mention), the world root holds only fable facts, and the asked child of
// the world holds the question's constraints and its Query. The dialogue's
// member nodes come last, after everything they reference: an Asks naming
// world and asked (their semantic mention), a re-exporting Query, the
// reply Reply over ref(asked, answer), and the Konsupu Imperative. A fresh
// graph is constructed per call; nothing is shared between questions.
import {
  Imperative,
  KonsupuIdentity,
  Query,
  Situation,
  Variable,
  ref,
} from "../../space/Interface/Nodes.js";
import { Asks, Reply } from "../../space/Interface/Aesop.js";
import { BuildStory } from "./story.mjs";
import { Questions } from "./questions.mjs";

export { Questions };

export function BuildCase(question) {
  const dialogue = new Situation();
  const story = new Situation();
  const input = [dialogue, story];
  const world = BuildStory(input, story);
  const asked = new Situation(story);
  input.push(asked);
  const answer = new Variable(asked);
  input.push(answer);
  const extra = question.build(input, asked, world, answer) ?? [];
  input.push(new Query(asked, [answer, ...extra]));
  const asks = new Asks(dialogue);
  asks.story = story;
  asks.asked = asked;
  input.push(asks);
  input.push(new Query(dialogue, [ref(asked, answer)]));
  const reply = new Reply(dialogue);
  reply.content = ref(asked, answer);
  input.push(reply);
  input.push(new Imperative(dialogue, KonsupuIdentity.Ref(), reply));
  return input;
}
