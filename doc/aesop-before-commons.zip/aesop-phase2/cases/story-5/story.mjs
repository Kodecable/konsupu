// BuildStory for "The Fox and the Mask". The fox's two beliefs are two
// contexts on different intervals: the mask is a glaring face until the
// closer look, only a mask from then on — the correction holds the
// negated identification ("only a Mask", lexical). The fright is caused
// by the first believing, not by the mask: emotion follows belief. The
// fox's remark is a speech context holding the negated possession ("you
// have not got any brains"); the world never holds it. How the fox got
// into the store-room is stated as an event with no stated way at all.
import {
  Agent,
  Assert,
  AssertOccurs,
  Believes,
  Causes,
  context,
  Ends,
  Entity,
  Enter,
  Frightened,
  Has,
  LocatedAt,
  LookClosely,
  Means,
  Next,
  Not,
  ResultsIn,
  SameReferent,
  See,
  Says,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const fox = entity(root, "the fox");
  const mask = entity(root, "the Mask");
  const storeRoom = entity(root, "the store-room of a theatre");
  input.push(fox, mask, storeRoom);

  // The earlier mistaken belief: the observed thing is a face glaring
  // down. The face exists only in this belief.
  const firstBeliefCtx = context(
    new Situation(),
    "a face was glaring down on him",
  );
  input.push(firstBeliefCtx);
  const face = entity(firstBeliefCtx, "a face glaring down on him");
  input.push(face);
  const tookAsFace = new SameReferent(firstBeliefCtx);
  tookAsFace.left = mask;
  tookAsFace.right = face;
  Assert(input, tookAsFace, firstBeliefCtx);

  // The corrected belief: "only a Mask" — not a face (lexical "only").
  const secondBeliefCtx = context(
    new Situation(),
    "it was only a Mask such as actors use",
  );
  input.push(secondBeliefCtx);
  const notFace = new Not(secondBeliefCtx);
  notFace.proposition = tookAsFace;
  Assert(input, notFace, secondBeliefCtx);

  const believedFace = new Believes(root);
  believedFace.believer = fox;
  believedFace.content = firstBeliefCtx;
  input.push(believedFace);
  const believedMask = new Believes(root);
  believedMask.believer = fox;
  believedMask.content = secondBeliefCtx;
  input.push(believedMask);

  // The fox's remark: a speech context holding the negated possession.
  const remarkCtx = context(new Situation(), "the fox's remark on the mask");
  input.push(remarkCtx);
  const brains = entity(remarkCtx, "brains");
  input.push(brains);
  const noBrains = new Not(remarkCtx);
  const lacks = new Has(remarkCtx);
  lacks.owner = mask;
  lacks.possession = brains;
  input.push(lacks);
  noBrains.proposition = lacks;
  Assert(input, noBrains, remarkCtx);

  const enterStore = new Enter(root);
  enterStore.place = storeRoom;
  const observe = new See(root);
  observe.theme = mask;
  const lookClose = new LookClosely(root);
  lookClose.theme = mask;
  const remark = new Says(root);
  remark.text = "Ah, you look very fine; it is a pity you have not got any brains.";
  remark.content = remarkCtx;
  const happened = [enterStore, observe, lookClose, remark];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);
  agent(root, input, enterStore, fox);
  agent(root, input, observe, fox);
  agent(root, input, lookClose, fox);
  agent(root, input, remark, fox);
  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  // "Began to be very frightened" at the observation. The text never
  // says the fright ended, so no ending is asserted (P2 cuts both
  // ways); only the first belief is bounded by the closer look.
  const frightened = new Frightened(root);
  frightened.subject = fox;
  input.push(frightened);
  const scareBegan = new ResultsIn(root);
  scareBegan.event = observe;
  scareBegan.proposition = frightened;
  Assert(input, scareBegan);

  const faceBeliefBegan = new ResultsIn(root);
  faceBeliefBegan.event = observe;
  faceBeliefBegan.proposition = believedFace;
  Assert(input, faceBeliefBegan);
  const faceBeliefEnded = new Ends(root);
  faceBeliefEnded.event = lookClose;
  faceBeliefEnded.state = believedFace;
  Assert(input, faceBeliefEnded);
  const maskBeliefBegan = new ResultsIn(root);
  maskBeliefBegan.event = lookClose;
  maskBeliefBegan.proposition = believedMask;
  Assert(input, maskBeliefBegan);

  // "By some means": the entering had a way, which the text leaves
  // unstated — an Unknown means, not an unsupported question, and no
  // cause at all (a "why" stays unanswered).
  const someMeans = new Means(root);
  someMeans.event = enterStore;
  Assert(input, someMeans);

  // The fright is caused by the believing, not by the mask itself.
  const fearCaused = new Causes(root);
  fearCaused.cause = believedFace;
  fearCaused.effect = frightened;
  Assert(input, fearCaused);

  return {
    root,
    fox,
    mask,
    storeRoom,
    enterStore,
    observe,
    lookClose,
    remark,
    firstBeliefCtx,
    face,
    secondBeliefCtx,
    believedFace,
    brains,
  };
}
