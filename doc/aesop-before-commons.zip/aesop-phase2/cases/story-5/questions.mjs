// Frozen question texts and semantic expectations for "The Fox and the
// Mask" (guide section 6.3, Story 5). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the fox at first take the mask to be?",
    semantic: "值:一张正俯视着瞪着他的脸",
    tests: "较早的信念",
  },
  {
    text: "Why was the fox frightened?",
    semantic: "值:他以为有一张脸在瞪着他(这份误认/信念,不是面具本身)",
    tests: "情绪的原因是信念",
  },
  {
    text: "After looking more closely, did the fox still think a face was glaring down on him?",
    semantic: "否",
    tests: "信念修正;'only a Mask'",
  },
  {
    text: "How did the fox get into the store-room?",
    semantic: "未知('by some means')",
    tests: "事件发生、方式未写",
  },
  {
    text: "What did the fox say the mask did not have?",
    semantic: "值:brains",
    tests: "N4 言语内容中的否定",
  },
];

export const Twins = [
  {
    text: "When the fox first observed it, did he think a face was glaring down on him?",
    semantic: "是",
  },
];

// The five questions. Belief revision is two belief contexts on
// different intervals: a HoldsWhen over the asked Believes pattern picks
// the one alive at the anchor. Emotion's cause is the believing, read as
// a Causes whose cause-side answer resolves to the Believes node. The
// unstated way (Means) into the store-room resolves to Unknown, distinct
// from any stated vague value. The remark's negated possession is read inside its
// speech context.
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Believes,
  Causes,
  Enter,
  Frightened,
  Has,
  HoldsIn,
  HoldsWhen,
  Means,
  Not,
  PriorTo,
  SameReferent,
  Says,
  After,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(a face glaring down on him)",
    build(input, asked, world, answer) {
      const b = beliefAt(input, asked, world, beforeEvent(input, asked, world.lookClose));
      const identification = new SameReferent(asked);
      identification.left = world.mask;
      identification.right = answer;
      input.push(identification);
      const held = new HoldsIn(asked);
      held.context = b;
      held.proposition = identification;
      Assert(input, held);
      return [b];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected:
      "Believes(believer=Entity(the fox),content=Context(a face was glaring down on him))",
    build(input, asked, world, answer) {
      const scared = new Frightened(asked);
      scared.subject = world.fox;
      Assert(input, scared);
      const why = new Causes(asked);
      why.cause = answer;
      why.effect = scared;
      Assert(input, why);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const b = beliefAt(input, asked, world, afterEvent(input, asked, world.lookClose));
      const stillFace = new SameReferent(asked);
      stillFace.left = world.mask;
      stillFace.right = world.face;
      input.push(stillFace);
      const asked1 = new AskWhether(asked);
      asked1.content = stillFace;
      asked1.context = b;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [b];
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "{result=unknown}",
    build(input, asked, world, answer) {
      const d = new Enter(asked);
      d.place = world.storeRoom;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      const how = new Means(asked);
      how.event = d;
      how.means = answer;
      Assert(input, how);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "Entity(brains)",
    build(input, asked, world, answer) {
      const s = new Variable(asked);
      input.push(s);
      const d = new Says(asked);
      d.content = s;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      const lacking = new Has(asked);
      lacking.owner = world.mask;
      lacking.possession = answer;
      input.push(lacking);
      const denied = new Not(asked);
      denied.proposition = lacking;
      input.push(denied);
      const held = new HoldsIn(asked);
      held.context = s;
      held.proposition = denied;
      Assert(input, held);
      return [s];
    },
  },
];

// The asked Believes pattern plus the HoldsWhen that time-picks which of
// the believer's contexts is alive at the anchor.
function beliefAt(input, asked, world, anchor) {
  const b = new Variable(asked);
  input.push(b);
  const belief = new Believes(asked);
  belief.believer = world.fox;
  belief.content = b;
  Assert(input, belief);
  const when = new HoldsWhen(asked);
  when.state = belief;
  when.when = anchor;
  Assert(input, when);
  return b;
}

function beforeEvent(input, asked, event) {
  const anchor = new PriorTo(asked);
  anchor.event = event;
  input.push(anchor);
  return anchor;
}

function afterEvent(input, asked, event) {
  const anchor = new After(asked);
  anchor.event = event;
  input.push(anchor);
  return anchor;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const b = beliefAt(input, asked, world, world.observe);
      const stillFace = new SameReferent(asked);
      stillFace.left = world.mask;
      stillFace.right = world.face;
      input.push(stillFace);
      const asked1 = new AskWhether(asked);
      asked1.content = stillFace;
      asked1.context = b;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [b];
    },
  },
];
