// BuildStory for "The Shepherd's Boy". Three ordered cries, two real
// comings-to-help, one wolf. The wolf's presence is an anchored state:
// its negation holds from the start until the wolf actually comes out
// ("actually did come", "the same trick", "fooled twice before" are the
// lexical basis, see RESULTS), so the same question — was there a wolf —
// answers differently at the second and the third cry. Nobody coming the
// third time is a negated existence over that window alone, and its
// cause is the villagers' false belief that the boy was again deceiving
// them. The boy's plan is a context; the world's InOrderTo ties the
// first cry to the getting it planned. The wise man's closing line stays
// contentless speech: generalizations are out of scope this round.
import {
  Agent,
  Assert,
  AssertOccurs,
  Believes,
  Causes,
  ComeOut,
  ComeToHelp,
  context,
  CryOut,
  Deceives,
  Eat,
  Ends,
  Entity,
  Get,
  Goal,
  Initially,
  Kind,
  InOrderTo,
  Lonely,
  Motivates,
  Next,
  NoneSuch,
  NoEvent,
  Not,
  Plans,
  Present,
  ResultsIn,
  Says,
  ThinkUp,
  TheEnd,
  Worry,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const boy = entity(root, "the Shepherd Boy");
  const flock = entity(root, "the boy's flock");
  const villagers = entity(root, "the villagers");
  const forest = entity(root, "the dark forest");
  // The sort the boy's cry and the narrator's denial both quantify over.
  const wolfKind = new Kind(root);
  wolfKind.name = "wolf";
  input.push(wolfKind);
  const wolf = entity(root, "the Wolf");
  wolf.kind = wolfKind;
  const wiseMan = entity(root, "the wise man of the village");
  input.push(boy, flock, villagers, forest, wolf, wiseMan);

  // The plan: getting a little company and some excitement.
  const plan = context(
    new Situation(),
    "a plan to get a little company and some excitement",
  );
  input.push(plan);
  const company = entity(plan, "a little company");
  const excitement = entity(plan, "some excitement");
  input.push(company, excitement);
  const wanted = new Get(plan);
  wanted.theme = [company, excitement];
  input.push(wanted);
  const aimed = new Goal(plan);
  aimed.actor = boy;
  aimed.objective = wanted;
  Assert(input, aimed, plan);
  const planning = new Plans(root);
  planning.planner = boy;
  planning.content = plan;
  input.push(planning);

  // The villagers' false belief at the third cry.
  const suspicion = context(
    new Situation(),
    "the boy was again deceiving them",
  );
  input.push(suspicion);
  const deceiving = new Deceives(suspicion);
  deceiving.deceiver = boy;
  deceiving.victim = villagers;
  Assert(input, deceiving, suspicion);
  const believed = new Believes(root);
  believed.believer = villagers;
  believed.content = suspicion;
  input.push(believed);

  // What each cry says: a wolf is here — some wolf, not a known one. The
  // claim lives in its own context with its own indefinite; the world
  // never holds it, and the cries carry it as their content.
  const claim = context(new Situation(), "a wolf is coming");
  input.push(claim);
  const someWolf = entity(claim, "a wolf");
  someWolf.kind = wolfKind;
  input.push(someWolf);
  const wolfComing = new Present(claim);
  wolfComing.subject = someWolf;
  Assert(input, wolfComing, claim);

  const thinkUp = new ThinkUp(root);
  const cry1 = new CryOut(root);
  cry1.call = "Wolf, Wolf";
  cry1.content = claim;
  const help1 = new ComeToHelp(root);
  help1.theme = boy;
  const cry2 = new CryOut(root);
  cry2.call = "Wolf, Wolf";
  cry2.content = claim;
  const help2 = new ComeToHelp(root);
  help2.theme = boy;
  const wolfCome = new ComeOut(root);
  wolfCome.source = forest;
  const worryFlock = new Worry(root);
  worryFlock.theme = flock;
  const cry3 = new CryOut(root);
  cry3.call = "Wolf, Wolf";
  cry3.manner = "still louder than before";
  const eatFlock = new Eat(root);
  eatFlock.theme = flock;
  const complained = new Says(root);
  complained.text = "his complaint";
  const wiseSay = new Says(root);
  wiseSay.text = "A liar will not be believed, even when he speaks the truth.";
  const happened = [
    thinkUp,
    cry1,
    help1,
    cry2,
    help2,
    wolfCome,
    worryFlock,
    cry3,
    eatFlock,
    complained,
    wiseSay,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, thinkUp, boy);
  agent(root, input, cry1, boy);
  agent(root, input, help1, villagers);
  agent(root, input, cry2, boy);
  agent(root, input, help2, villagers);
  agent(root, input, wolfCome, wolf);
  agent(root, input, worryFlock, wolf);
  agent(root, input, cry3, boy);
  agent(root, input, eatFlock, wolf);
  agent(root, input, complained, boy);
  agent(root, input, wiseSay, wiseMan);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  const lonely = new Lonely(root);
  lonely.subject = boy;
  input.push(lonely);
  const lonelyAtFirst = new Initially(root);
  lonelyAtFirst.state = lonely;
  Assert(input, lonelyAtFirst);
  const lonelyMoved = new Motivates(root);
  lonelyMoved.driver = lonely;
  lonelyMoved.action = thinkUp;
  Assert(input, lonelyMoved);

  const plannedByThinking = new ResultsIn(root);
  plannedByThinking.event = thinkUp;
  plannedByThinking.proposition = planning;
  Assert(input, plannedByThinking);

  const present = new Present(root);
  present.subject = wolf;
  input.push(present);
  const appeared = new ResultsIn(root);
  appeared.event = wolfCome;
  appeared.proposition = present;
  Assert(input, appeared);
  // "The same trick", "a Wolf actually did come": until then there was
  // no wolf at all — a negated existence, not one wolf's absence.
  const anyWolf = new Entity(root);
  anyWolf.kind = wolfKind;
  input.push(anyWolf);
  const anyPresent = new Present(root);
  anyPresent.subject = anyWolf;
  input.push(anyPresent);
  const noWolf = new NoneSuch(root);
  noWolf.some = [anyWolf];
  noWolf.pattern = anyPresent;
  noWolf.until = wolfCome;
  Assert(input, noWolf);

  const suspected = new ResultsIn(root);
  suspected.event = cry3;
  suspected.proposition = believed;
  Assert(input, suspected);

  // "Tried the same trick", "fooled twice before": the boy did deceive
  // the villagers, from the first cry until the true one.
  const fooling = new Deceives(root);
  fooling.deceiver = boy;
  fooling.victim = villagers;
  input.push(fooling);
  const foolingBegan = new ResultsIn(root);
  foolingBegan.event = cry1;
  foolingBegan.proposition = fooling;
  Assert(input, foolingBegan);
  const foolingEnded = new Ends(root);
  foolingEnded.event = cry3;
  foolingEnded.state = fooling;
  Assert(input, foolingEnded);

  // The first cry served the plan's getting.
  const cryAimed = new InOrderTo(root);
  cryAimed.action = cry1;
  cryAimed.goal = wanted;
  Assert(input, cryAimed);

  // "Nobody stirred to come to his help" — this time only, and why.
  const comePattern = new ComeToHelp(root);
  comePattern.theme = boy;
  input.push(comePattern);
  const nobodyCame = new NoEvent(root);
  nobodyCame.pattern = comePattern;
  nobodyCame.from = cry3;
  nobodyCame.until = TheEnd;
  Assert(input, nobodyCame);
  const fearCaused = new Causes(root);
  fearCaused.cause = believed;
  fearCaused.effect = nobodyCame;
  Assert(input, fearCaused);

  return {
    root,
    boy,
    flock,
    villagers,
    wolf,
    wolfKind,
    cry1,
    cry2,
    cry3,
    help1,
    help2,
    wolfCome,
    eatFlock,
    believed,
    wanted,
    fooling,
    claim,
    wolfComing,
  };
}
