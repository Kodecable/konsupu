// Frozen question texts and semantic expectations for "The Shepherd's
// Boy" (guide section 6.3, Story 10). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Why did the boy first cry \"Wolf\"?",
    semantic: "值:为了得到一点陪伴和一些刺激",
    tests: "计划/目的;序数 'first'",
  },
  {
    text: "Was there a wolf when the boy cried \"Wolf\" the second time?",
    semantic: "否",
    tests: "序数;时间锚定的否定('actually'、'the same trick')",
  },
  {
    text: "Why did nobody come to help the boy the third time?",
    semantic: "值:村民以为他又在骗他们",
    tests: "错误信念作为原因",
  },
  {
    text: "Was the boy telling the truth when he cried \"Wolf\" the third time?",
    semantic: "是",
    tests: "同一内容的真值随时间不同",
  },
  {
    text: "Did any villager come to help the boy the third time?",
    semantic: "否",
    tests: "N2 时间窗口内的否定存在",
  },
];

export const Twins = [
  {
    text: "Did the villagers come to help the boy the second time?",
    semantic: "是",
  },
  {
    text: "Was the boy telling the truth the first time?",
    semantic: "否",
  },
];

// The five questions. Ordinals resolve matching events along the world
// chain; the wolf's presence and its negation are anchored states, so the
// same asked content answers differently at different cries; the
// nobody-coming is a negated existence whose cause-side answer is the
// villagers' believing.
import {
  Agent,
  Among,
  Assert,
  AskWhether,
  Causes,
  ComeToHelp,
  CryOut,
  Entity,
  HoldsIn,
  InOrderTo,
  Next,
  NoEvent,
  Nth,
  Present,
  TheEnd,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Get(theme=[Entity(a little company),Entity(some excitement)])",
    build(input, asked, world, answer) {
      // "First" is the ordinal 1: the matching cry with none before it.
      const first = new Nth(asked);
      first.pattern = cryPattern(input, asked, world);
      first.index = 1;
      input.push(first);
      const why = new InOrderTo(asked);
      why.action = first;
      why.goal = answer;
      Assert(input, why);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      // "Was there a wolf": whether any wolf was present at the second
      // cry — an existence question about the world, not about the cry.
      const cry = new CryOut(asked);
      cry.call = "Wolf, Wolf";
      input.push(cry);
      const nth = new Nth(asked);
      nth.pattern = cry;
      nth.index = 2;
      input.push(nth);
      const aWolf = new Entity(asked);
      aWolf.kind = world.wolfKind;
      input.push(aWolf);
      const there = new Present(asked);
      there.subject = aWolf;
      input.push(there);
      const asked1 = new AskWhether(asked);
      asked1.content = there;
      asked1.when = nth;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected:
      "Believes(believer=Entity(the villagers),content=Context(the boy was again deceiving them))",
    build(input, asked, world, answer) {
      const d = new ComeToHelp(asked);
      d.theme = world.boy;
      input.push(d);
      const cry = new CryOut(asked);
      cry.call = "Wolf, Wolf";
      input.push(cry);
      const third = new Nth(asked);
      third.pattern = cry;
      third.index = 3;
      input.push(third);
      // The effect is the windowed negated existence: "the third time"
      // is its window, resolved inside the Causes, so another cry's
      // window names a different (unheld) nobody-coming.
      const none = new NoEvent(asked);
      none.pattern = d;
      none.from = third;
      none.until = TheEnd;
      input.push(none);
      const why = new Causes(asked);
      why.cause = answer;
      why.effect = none;
      Assert(input, why);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      claimTruth(input, asked, world, answer, 3);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const d = new ComeToHelp(asked);
      d.theme = world.boy;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      const nth = new Nth(asked);
      nth.pattern = cryPattern(input, asked, world);
      nth.index = 3;
      input.push(nth);
      const did = new Agent(asked);
      did.action = d;
      did.actor = world.villagers;
      input.push(did);
      const asked1 = new AskWhether(asked);
      asked1.content = did;
      asked1.when = nth;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];

// "Was the boy telling the truth when he cried the n-th time": the claim
// the n-th cry carries — some wolf is here — read out of its context and
// judged against the world at that cry; its indefinite wolf is any wolf
// there.
function claimTruth(input, asked, world, answer, index) {
  const c = new Variable(asked);
  input.push(c);
  const d = new CryOut(asked);
  d.call = "Wolf, Wolf";
  d.content = c;
  input.push(d);
  const h = new Among(asked);
  h.situation = world.root;
  h.node = d;
  Assert(input, h);
  const nth = new Nth(asked);
  nth.pattern = d;
  nth.index = index;
  input.push(nth);
  const claimed = new Entity(asked);
  input.push(claimed);
  const claim = new Present(asked);
  claim.subject = claimed;
  input.push(claim);
  const held = new HoldsIn(asked);
  held.context = c;
  held.proposition = claim;
  Assert(input, held);
  const asked1 = new AskWhether(asked);
  asked1.content = claim;
  asked1.when = nth;
  asked1.verdict = answer;
  Assert(input, asked1);
}

function cryPattern(input, asked, world) {
  const d = new CryOut(asked);
  d.call = "Wolf, Wolf";
  input.push(d);
  return d;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const d = new ComeToHelp(asked);
      d.theme = world.boy;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      const nth = new Nth(asked);
      nth.pattern = cryPattern(input, asked, world);
      nth.index = 2;
      input.push(nth);
      const did = new Agent(asked);
      did.action = d;
      did.actor = world.villagers;
      input.push(did);
      const asked1 = new AskWhether(asked);
      asked1.content = did;
      asked1.when = nth;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      claimTruth(input, asked, world, answer, 1);
    },
  },
];
