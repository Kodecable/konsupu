// Frozen question texts and semantic expectations for "The Miser and His
// Gold" (guide section 6.3, Story 6). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Where did the miser use to hide his gold?",
    semantic: "值:花园里一棵树的树脚下",
    tests: "习惯性状态",
  },
  {
    text: "How often did the miser dig up his gold?",
    semantic: "值:每周",
    tests: "习惯的频率",
  },
  {
    text: "Who took the gold?",
    semantic: "值:the robber",
    tests: "单次事件(复用 Agent)",
  },
  {
    text: "What did the miser find when he next came to gloat over his treasures?",
    semantic: "值:那个空洞",
    tests: "习惯的下一次实例;N5 穷尽",
  },
  {
    text: "According to the miser, did he ever take any of the gold out?",
    semantic: "否(在吝啬鬼所说的语境中)",
    tests: "言语语境中的是非问;'Nay' 承接问句内容",
  },
];

export const Twins = [
  {
    text: "Did the miser ever take any of the gold out?",
    semantic: "未确立(world;只有他自己的说法)",
  },
  {
    text: "Was the gold in the hole when the miser next came?",
    semantic: "否",
  },
];

// The five questions. Habits are read through their deed shapes and
// frequency values; the taking through the open Get class; the finding
// through the immediate successor of the habit's next instance; the
// miser's own "Nay" through a yes-no question evaluated inside his speech
// context, where his NoEvent and OnlyDid negate the taking.
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  ComeTo,
  DigUp,
  Find,
  Get,
  Gloat,
  Hide,
  Habitual,
  InOrderTo,
  Instance,
  Next,
  Says,
  Take,
  LocatedAt,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(the foot of a tree in his garden)",
    build(input, asked, world, answer) {
      const deed = new Hide(asked);
      deed.theme = world.gold;
      deed.place = answer;
      input.push(deed);
      const habit = new Habitual(asked);
      habit.doer = world.miser;
      habit.deed = deed;
      Assert(input, habit);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "Entity(every week)",
    build(input, asked, world, answer) {
      const deed = new DigUp(asked);
      deed.theme = world.gold;
      input.push(deed);
      const habit = new Habitual(asked);
      habit.doer = world.miser;
      habit.deed = deed;
      habit.frequency = answer;
      Assert(input, habit);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "Entity(a robber)",
    build(input, asked, world, answer) {
      const d = new Get(asked);
      d.theme = world.gold;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = answer;
      Assert(input, who);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Entity(the empty hole)",
    build(input, asked, world, answer) {
      const d = new Find(asked);
      d.theme = answer;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const finder = new Agent(asked);
      finder.action = d;
      finder.actor = world.miser;
      Assert(input, finder);
      const when = new Next(asked);
      when.earlier = nextVisit(input, asked, world);
      when.later = d;
      Assert(input, when);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const m = new Variable(asked);
      input.push(m);
      const d = new Says(asked);
      d.content = m;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.miser;
      Assert(input, who);
      // "Did HE ever take any of it out": the actor is pinned, the
      // Nay is his ("I only came to look at it"), and the doing must
      // have happened for a yes.
      const taking = new Take(asked);
      taking.theme = world.gold;
      taking.source = world.hole;
      input.push(taking);
      const did = new Agent(asked);
      did.action = taking;
      did.actor = world.miser;
      input.push(did);
      const asked1 = new AskWhether(asked);
      asked1.content = did;
      asked1.context = m;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [m];
    },
  },
];

// "When he next came to gloat over his treasures": a coming of the
// miser's that is an instance of his weekly practice and was made in
// order to gloat over the gold — a description the solver binds, never
// a story event named by the question.
function nextVisit(input, asked, world) {
  const v = new ComeTo(asked);
  input.push(v);
  const known = new Among(asked);
  known.situation = world.root;
  known.node = v;
  Assert(input, known);
  AssertOccurs(input, v);
  const who = new Agent(asked);
  who.action = v;
  who.actor = world.miser;
  Assert(input, who);
  const practice = new Instance(asked);
  practice.habit = world.digHabit;
  practice.event = v;
  Assert(input, practice);
  const gloating = new Gloat(asked);
  gloating.theme = world.gold;
  input.push(gloating);
  const aimed = new Among(asked);
  aimed.situation = world.root;
  aimed.node = gloating;
  Assert(input, aimed);
  const purpose = new InOrderTo(asked);
  purpose.action = v;
  purpose.goal = gloating;
  Assert(input, purpose);
  return v;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const taking = new Take(asked);
      taking.theme = world.gold;
      taking.source = world.hole;
      input.push(taking);
      const did = new Agent(asked);
      did.action = taking;
      did.actor = world.miser;
      input.push(did);
      const asked1 = new AskWhether(asked);
      asked1.content = did;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked);
      where.entity = world.gold;
      where.place = world.hole;
      input.push(where);
      const asked1 = new AskWhether(asked);
      asked1.content = where;
      asked1.when = nextVisit(input, asked, world);
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];
