// BuildStory for "The Miser and His Gold". Two habits generalize the
// weekly practice without enumerating it; the "next coming" is one event
// tied to the habit by an explicit Instance. The robber's taking is a
// Steal (the word "robber"), which the open Get class matches. The
// miser's "Nay" and "I only came to look at it" live in his speech
// context: a NoEvent over any taking plus an OnlyDid exhausting his
// gold-concerned doings — the world holds neither. The hole's emptiness
// starts at the taking, so "was the gold in the hole" is refuted, not
// merely unstated.
import {
  Agent,
  Assert,
  AssertOccurs,
  ComeTo,
  context,
  CryOut,
  DigUp,
  Empty,
  Entity,
  Find,
  GoAway,
  Gloat,
  Hide,
  Habitual,
  InOrderTo,
  Initially,
  Instance,
  LocatedAt,
  Next,
  NoEvent,
  Notice,
  OnlyDid,
  ResultsIn,
  Says,
  See,
  Steal,
  Take,
  TheEnd,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const miser = entity(root, "the miser");
  const gold = entity(root, "his gold");
  const footOfTree = entity(root, "the foot of a tree in his garden");
  const hole = entity(root, "the empty hole");
  const robber = entity(root, "a robber");
  const neighbours = entity(root, "the neighbours");
  const week = entity(root, "every week");
  input.push(miser, gold, footOfTree, hole, robber, neighbours, week);

  // "Used to hide his gold at the foot of a tree; every week he used to
  // go and dig it up and gloat": two habits, no enumerated visits.
  const hideDeed = new Hide(root);
  hideDeed.theme = gold;
  hideDeed.place = footOfTree;
  input.push(hideDeed);
  const hideHabit = new Habitual(root);
  hideHabit.doer = miser;
  hideHabit.deed = hideDeed;
  Assert(input, hideHabit);
  const digDeed = new DigUp(root);
  digDeed.theme = gold;
  input.push(digDeed);
  const digHabit = new Habitual(root);
  digHabit.doer = miser;
  digHabit.deed = digDeed;
  digHabit.frequency = week;
  Assert(input, digHabit);

  const goldInHole = new LocatedAt(root);
  goldInHole.entity = gold;
  goldInHole.place = hole;
  input.push(goldInHole);
  const hiddenAtFirst = new Initially(root);
  hiddenAtFirst.state = goldInHole;
  Assert(input, hiddenAtFirst);

  // The neighbour's question introduces the taking pattern the "Nay"
  // answers.
  const questionCtx = context(new Situation(), "the neighbour's question");
  input.push(questionCtx);
  const takeOut = new Take(questionCtx);
  takeOut.theme = gold;
  takeOut.source = hole;
  input.push(takeOut);

  // The miser's answer: no taking ever, and all he did concerning the
  // gold was come to look.
  const miserCtx = context(new Situation(), "the miser's answer");
  input.push(miserCtx);
  const neverTook = new NoEvent(miserCtx);
  neverTook.pattern = takeOut;
  neverTook.actor = miser;
  Assert(input, neverTook, miserCtx);
  const lookDeed = new See(miserCtx);
  lookDeed.theme = gold;
  input.push(lookDeed);
  const onlyLooked = new OnlyDid(miserCtx);
  onlyLooked.actor = miser;
  onlyLooked.theme = gold;
  onlyLooked.deeds = [lookDeed];
  Assert(input, onlyLooked, miserCtx);

  const robNotice = new Notice(root);
  robNotice.theme = digHabit;
  const robDig = new DigUp(root);
  robDig.theme = gold;
  const robSteal = new Steal(root);
  robSteal.theme = gold;
  const miserVisit = new ComeTo(root);
  miserVisit.destination = footOfTree;
  const foundHole = new Find(root);
  foundHole.theme = hole;
  const outcry = new CryOut(root);
  outcry.call = "such an outcry";
  const neighboursCome = new ComeTo(root);
  neighboursCome.destination = miser;
  const toldThem = new Says(root);
  toldThem.text = "how he used to come and visit his gold";
  const neighbourAsk = new Says(root);
  neighbourAsk.to = miser;
  neighbourAsk.text = "Did you ever take any of it out?";
  neighbourAsk.content = questionCtx;
  const miserNay = new Says(root);
  miserNay.text = "Nay, I only came to look at it.";
  miserNay.content = miserCtx;
  const neighbourAdvice = new Says(root);
  neighbourAdvice.to = miser;
  neighbourAdvice.text = "Then come again and look at the hole; it will do you just as much good.";
  const happened = [
    robNotice,
    robDig,
    robSteal,
    miserVisit,
    foundHole,
    outcry,
    neighboursCome,
    toldThem,
    neighbourAsk,
    miserNay,
    neighbourAdvice,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, robNotice, robber);
  agent(root, input, robDig, robber);
  agent(root, input, robSteal, robber);
  agent(root, input, miserVisit, miser);
  agent(root, input, foundHole, miser);
  agent(root, input, outcry, miser);
  agent(root, input, neighboursCome, neighbours);
  agent(root, input, toldThem, miser);
  agent(root, input, neighbourAsk, neighbours);
  agent(root, input, miserNay, miser);
  agent(root, input, neighbourAdvice, neighbours);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  // "When the Miser next came to gloat": the coming happened; the
  // gloating is its purpose, never an occurred event. The visit is the
  // weekly practice's next single event.
  const gloatDeed = new Gloat(root);
  gloatDeed.theme = gold;
  input.push(gloatDeed);
  const visitAimed = new InOrderTo(root);
  visitAimed.action = miserVisit;
  visitAimed.goal = gloatDeed;
  Assert(input, visitAimed);
  const instance = new Instance(root);
  instance.habit = digHabit;
  instance.event = miserVisit;
  Assert(input, instance);

  // "Dug up the gold": out of the hole and into the robber's hands at
  // the digging; the decamping with it is the Steal ("a robber …
  // decamped with it" is its lexical basis).
  const holeEmpty = new Empty(root);
  holeEmpty.container = hole;
  input.push(holeEmpty);
  const emptied = new ResultsIn(root);
  emptied.event = robDig;
  emptied.proposition = holeEmpty;
  Assert(input, emptied);

  const goldGone = new LocatedAt(root);
  goldGone.entity = gold;
  goldGone.place = robber;
  input.push(goldGone);
  const stolen = new ResultsIn(root);
  stolen.event = robDig;
  stolen.proposition = goldGone;
  Assert(input, stolen);

  // "He found nothing but the empty hole": from the visit on, no
  // finding of the gold.
  const findGold = new Find(root);
  findGold.theme = gold;
  input.push(findGold);
  const neverFound = new NoEvent(root);
  neverFound.pattern = findGold;
  neverFound.from = miserVisit;
  neverFound.until = TheEnd;
  Assert(input, neverFound);

  return {
    root,
    miser,
    gold,
    footOfTree,
    hole,
    robber,
    digHabit,
    robSteal,
    miserVisit,
    foundHole,
    miserCtx,
    questionCtx,
    takeOut,
  };
}
