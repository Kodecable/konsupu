// Frozen question texts and semantic expectations for "The Dog and the
// Shadow" (guide section 6.3, Story 4). The English text never changes;
// `semantic` is binding. The machine `expected` is fixed at
// implementation and must agree with `semantic`; later changes need a
// per-question RESULTS note. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "What did the dog think his shadow was?",
    // Guide erratum (confirmed): the question asks what the shadow was
    // taken to be, not what that dog was doing; the carrying stays a
    // characterization held in the belief.
    semantic: "值:另一只狗(信念语境中影子的对应者)",
    tests: "信念语境;同一指称跨语境的不同刻画",
  },
  {
    text: "What did the dog really see in the water?",
    semantic: "值:他自己的影子",
    tests: "world 语境;Q1 的对照",
  },
  {
    text: "Where was the piece of meat before the dog snapped at the shadow?",
    semantic: "值:狗的嘴里",
    tests: "时间锚定的状态",
  },
  {
    text: "Where did the piece of meat end up?",
    semantic: "值:水里",
    tests: "终态;与 Q3 同一实体、不同时间,各自唯一",
  },
  {
    text: "Why did the dog snap at the shadow?",
    semantic: "值:想把另一块肉也弄到手(目标的对象只存在于信念中)",
    tests: "world 中的目标指向信念专有对象",
  },
];

export const Twins = [
  {
    text: "Did the dog get the other piece of meat?",
    semantic: "未确立",
  },
  {
    text: "Did anyone deceive the dog?",
    semantic: "未确立(误信不蕴含欺骗)",
  },
];

// The five questions. The belief is a context: an attitude constraint
// finds it, HoldsIn reads what it holds, and SameReferent carries the
// identification across contexts. The meat's locations are read through
// HoldsWhen anchors; the goal's object is the belief-specific "another
// piece of meat". For Q1 the value names the referent the shadow was
// identified with ("another dog"); its believed characterization —
// carrying the other meat — is the second identification constraint,
// held in the belief and in the asked translation alike (RESULTS).
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Believes,
  Get,
  HoldsIn,
  HoldsWhen,
  InOrderTo,
  LocatedAt,
  PriorTo,
  SameReferent,
  See,
  TheEnd,
  Deceives,
  Occurs,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(another dog)",
    build(input, asked, world, answer) {
      const b = new Variable(asked);
      input.push(b);
      const belief = new Believes(asked);
      belief.believer = world.dog;
      belief.content = b;
      Assert(input, belief);
      const identification = new SameReferent(asked);
      identification.left = world.shadow;
      identification.right = answer;
      input.push(identification);
      const identified = new HoldsIn(asked);
      identified.context = b;
      identified.proposition = identification;
      Assert(input, identified);
      // Only what the question asks: the belief's counterpart of the
      // shadow. Its carrying another piece of meat stays held in the
      // belief; the question does not ask for it as a constraint.
      return [b];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "Entity(his own shadow reflected in the water)",
    build(input, asked, world, answer) {
      const d = new See(asked);
      d.theme = answer;
      d.place = world.water;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.dog;
      Assert(input, who);
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "Entity(the dog's mouth)",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked);
      where.entity = world.meat;
      where.place = answer;
      Assert(input, where);
      const before = new PriorTo(asked);
      before.event = world.snapAt;
      input.push(before);
      const when = new HoldsWhen(asked);
      when.state = where;
      when.when = before;
      Assert(input, when);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "Entity(the water beneath)",
    build(input, asked, world, answer) {
      const where = new LocatedAt(asked);
      where.entity = world.meat;
      where.place = answer;
      Assert(input, where);
      const when = new HoldsWhen(asked);
      when.state = where;
      when.when = TheEnd;
      Assert(input, when);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "Get(theme=Entity(another piece of meat))",
    build(input, asked, world, answer) {
      const why = new InOrderTo(asked);
      why.action = world.snapAt;
      why.goal = answer;
      Assert(input, why);
    },
  },
];

// Guide twins, executable: the same machinery, opposite or different
// answers — a solver that answers "no" or "not established" to
// everything fails these.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const d = new Get(asked);
      d.theme = world.otherMeat;
      input.push(d);
      const happened = new Occurs(asked);
      happened.event = d;
      input.push(happened);
      const asked1 = new AskWhether(asked);
      asked1.content = happened;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const deceived = new Deceives(asked);
      deceived.victim = world.dog;
      input.push(deceived);
      const asked1 = new AskWhether(asked);
      asked1.content = deceived;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];
