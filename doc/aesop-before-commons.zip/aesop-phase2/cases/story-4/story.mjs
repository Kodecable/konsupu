// BuildStory for "The Dog and the Shadow". The dog's belief is a context
// of its own: it identifies the world's shadow with "another dog" and
// gives that dog "another piece of meat" — an object that exists only in
// the belief. The world can mention that belief-specific object (the
// dog's goal wants it) without corresponding it to anything real. The
// meat's two locations are anchored: in the mouth from the story's start
// (the class rule ends it when the water location starts at the drop),
// in the water from the drop on. "Never seen more" is a negated
// existence from the drop to the end. No one deceives the dog, and the
// story never says so.
import {
  Agent,
  Assert,
  AssertOccurs,
  Believes,
  Causes,
  context,
  Cross,
  Overlaps,
  Entity,
  Fall,
  Get,
  Goal,
  InOrderTo,
  Ends,
  Initially,
  LocatedAt,
  Next,
  NoEvent,
  ResultsIn,
  SameReferent,
  See,
  SnapAt,
  Carrying,
  TheEnd,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const dog = entity(root, "the dog");
  const meat = entity(root, "the piece of meat");
  const mouth = entity(root, "the dog's mouth");
  const plank = entity(root, "a plank lying across a running brook");
  const water = entity(root, "the water beneath");
  const shadow = entity(root, "his own shadow reflected in the water");
  const home = entity(root, "home");
  input.push(dog, meat, mouth, plank, water, shadow, home);

  // The dog's belief context: the shadow is another dog carrying another
  // piece of meat. Both objects exist only here.
  const belief = context(
    new Situation(),
    "it was another dog with another piece of meat",
  );
  input.push(belief);
  const otherDog = entity(belief, "another dog");
  const otherMeat = entity(belief, "another piece of meat");
  input.push(otherDog, otherMeat);
  const mistaken = new SameReferent(belief);
  mistaken.left = shadow;
  mistaken.right = otherDog;
  Assert(input, mistaken, belief);
  const otherCarries = new Carrying(belief);
  otherCarries.carrier = otherDog;
  otherCarries.theme = otherMeat;
  Assert(input, otherCarries, belief);

  // "He made up his mind to have that also": a world goal whose object
  // exists only in the belief. It never happened.
  const getOtherMeat = new Get(root);
  getOtherMeat.theme = otherMeat;
  input.push(getOtherMeat);

  const crossPlank = new Cross(root);
  crossPlank.what = plank;
  const seeShadow = new See(root);
  seeShadow.theme = shadow;
  seeShadow.place = water;
  const snapAt = new SnapAt(root);
  snapAt.theme = shadow;
  const dropMeat = new Fall(root);
  dropMeat.theme = meat;
  dropMeat.destination = water;
  const happened = [crossPlank, seeShadow, snapAt, dropMeat];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, crossPlank, dog);
  agent(root, input, seeShadow, dog);
  agent(root, input, snapAt, dog);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  const meatInMouth = new LocatedAt(root);
  meatInMouth.entity = meat;
  meatInMouth.place = mouth;
  input.push(meatInMouth);
  const mouthAtFirst = new Initially(root);
  mouthAtFirst.state = meatInMouth;
  Assert(input, mouthAtFirst);

  const meatInWater = new LocatedAt(root);
  meatInWater.entity = meat;
  meatInWater.place = water;
  input.push(meatInWater);
  const wetResult = new ResultsIn(root);
  wetResult.event = dropMeat;
  wetResult.proposition = meatInWater;
  Assert(input, wetResult);

  // "As he opened his mouth the piece of meat fell out": the snap and the
  // opening are one.
  const snapDropped = new Causes(root);
  snapDropped.cause = snapAt;
  snapDropped.effect = dropMeat;
  Assert(input, snapDropped);

  // "Was carrying it home in his mouth": a carrying state from the
  // story's start, ended by the drop — never an arrived-home event.
  const carrying = new Carrying(root);
  carrying.carrier = dog;
  carrying.theme = meat;
  input.push(carrying);
  const carriedAtFirst = new Initially(root);
  carriedAtFirst.state = carrying;
  Assert(input, carriedAtFirst);
  const carryEnded = new Ends(root);
  carryEnded.event = dropMeat;
  carryEnded.state = carrying;
  Assert(input, carryEnded);

  // "As he crossed, he looked in and saw": the seeing is inside the
  // crossing's frame, not after it.
  const whileCrossing = new Overlaps(root);
  whileCrossing.first = crossPlank;
  whileCrossing.second = seeShadow;
  Assert(input, whileCrossing);

  const believed = new Believes(root);
  believed.believer = dog;
  believed.content = belief;
  input.push(believed);
  const seeingLed = new ResultsIn(root);
  seeingLed.event = seeShadow;
  seeingLed.proposition = believed;
  Assert(input, seeingLed);

  const wanted = new Goal(root);
  wanted.actor = dog;
  wanted.objective = getOtherMeat;
  Assert(input, wanted);
  const snapAimed = new InOrderTo(root);
  snapAimed.action = snapAt;
  snapAimed.goal = getOtherMeat;
  Assert(input, snapAimed);

  // "And was never seen more": no seeing of the meat from the drop on.
  const seenPattern = new See(root);
  seenPattern.theme = meat;
  input.push(seenPattern);
  const neverSeen = new NoEvent(root);
  neverSeen.pattern = seenPattern;
  neverSeen.from = dropMeat;
  neverSeen.until = TheEnd;
  Assert(input, neverSeen);

  return {
    root,
    dog,
    meat,
    mouth,
    water,
    shadow,
    snapAt,
    dropMeat,
    belief,
    otherDog,
    otherMeat,
    getOtherMeat,
  };
}
