// Frozen question texts and semantic expectations for "The Fox and the
// Goat" (guide section 6.3, Story 11). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "How did the fox really get into the well?",
    semantic: "值:他(出于不幸的偶然)掉了进去",
    tests: "world 事件",
  },
  {
    text: "How did the fox say he got into the well?",
    semantic: "值:他自己跳了下来(为了确保身边有水)",
    tests: "言语语境;与 Q1 是同一事件的不同描述",
  },
  {
    text: "Why did the goat jump into the well?",
    semantic: "值:她认为狐狸的建议很好",
    tests: "被诱导的评价驱动行动",
  },
  {
    text: "Could the fox get out of the well before the goat came down?",
    semantic: "否",
    tests: "N3 无能力,时间锚定",
  },
  {
    text: "Was what the fox told the goat about why he was in the well true?",
    semantic: "否('by an unlucky chance' 与 'in order to' 不相容)",
    tests: "言语内容对照 world",
  },
];

export const Twins = [
  {
    text: "Did the fox get out of the well?",
    semantic: "是",
  },
  {
    text: "Was there going to be a great drought?",
    semantic: "未确立(只有狐狸的说法,故事既未确立也未否定)",
  },
];

// The five questions. The speech context supplies the said getting-in
// and its purpose; the world's SameReferent ties that saying to the
// actual fall; the chance incompatibility makes the told reason false;
// the goat's approving belief drives her jump; "could" asks the
// complement of an anchored inability.
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Believes,
  GetOut,
  HoldsIn,
  InOrderTo,
  Motivates,
  Not,
  Occurs,
  PriorTo,
  SameReferent,
  Says,
  Unable,
  Drought,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Fall(destination=Entity(a deep well),theme=Entity(the Fox))",
    build(input, asked, world, answer) {
      const j = saidGettingIn(input, asked, world);
      const same = new SameReferent(asked);
      same.left = j;
      same.right = answer;
      Assert(input, same);
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "JumpDown(destination=Entity(a deep well),theme=Entity(the Fox))",
    build(input, asked, world, answer) {
      // What his saying holds he did: a happening of his own in it.
      const s = newsOf(input, asked, world);
      saidDoing(input, asked, world, s, answer);
      return [s];
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected:
      "Believes(believer=Entity(the Goat),content=Context(the fox's advice was good))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked);
      why.driver = answer;
      why.action = world.goatJump;
      Assert(input, why);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const deed = new GetOut(asked);
      deed.from = world.well;
      input.push(deed);
      const trapped = new Unable(asked);
      trapped.actor = world.fox;
      trapped.deed = deed;
      input.push(trapped);
      const could = new Not(asked);
      could.proposition = trapped;
      input.push(could);
      const before = new PriorTo(asked);
      before.event = world.goatJump;
      input.push(before);
      const asked1 = new AskWhether(asked);
      asked1.content = could;
      asked1.when = before;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const s = newsOf(input, asked, world);
      const j = new Variable(asked);
      input.push(j);
      const h = new Variable(asked);
      input.push(h);
      const said = new InOrderTo(asked);
      said.action = j;
      said.goal = h;
      input.push(said);
      const held = new HoldsIn(asked);
      held.context = s;
      held.proposition = said;
      Assert(input, held);
      const asked1 = new AskWhether(asked);
      asked1.content = said;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [s, j, h];
    },
  },
];

// Bind the fox's news speech context through its Says.
function newsOf(input, asked, world) {
  const s = new Variable(asked);
  input.push(s);
  const d = new Says(asked);
  d.content = s;
  input.push(d);
  const h = new Among(asked);
  h.situation = world.root;
  h.node = d;
  Assert(input, h);
  AssertOccurs(input, d);
  const who = new Agent(asked);
  who.action = d;
  who.actor = world.fox;
  Assert(input, who);
  return s;
}

// The news holds that the fox did `doing`: it occurred, by him.
function saidDoing(input, asked, world, s, doing) {
  const happened = new Occurs(asked);
  happened.event = doing;
  input.push(happened);
  const saidHappened = new HoldsIn(asked);
  saidHappened.context = s;
  saidHappened.proposition = happened;
  Assert(input, saidHappened);
  const by = new Agent(asked);
  by.action = doing;
  by.actor = world.fox;
  input.push(by);
  const saidBy = new HoldsIn(asked);
  saidBy.context = s;
  saidBy.proposition = by;
  Assert(input, saidBy);
}

// Bind the said getting-in: the doing of his own his news tells.
function saidGettingIn(input, asked, world) {
  const s = newsOf(input, asked, world);
  const j = new Variable(asked);
  input.push(j);
  saidDoing(input, asked, world, s, j);
  return j;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const d = new GetOut(asked);
      d.from = world.well;
      input.push(d);
      const happened = new Occurs(asked);
      happened.event = d;
      input.push(happened);
      const asked1 = new AskWhether(asked);
      asked1.content = happened;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const coming = new Drought(asked);
      input.push(coming);
      const asked1 = new AskWhether(asked);
      asked1.content = coming;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];
