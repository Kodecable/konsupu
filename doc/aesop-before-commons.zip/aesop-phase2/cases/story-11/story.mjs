// BuildStory for "The Fox and the Goat". The fox's news is a speech
// context: the drought it claims, the jumping it claims, and the purpose
// it gives all live there — the world holds none of them. The world does
// hold the correspondence between the claimed jumping and the actual
// falling (the narrator frames the same getting-in both ways; see
// RESULTS), and that the falling happened by an unlucky chance — the
// class incompatibility (a chance happening serves no purpose) is what
// makes the told reason false rather than merely unestablished. The
// inability to get out starts at the fall and ends when its means
// arrives — the goat coming down — not when the escape is made: being
// able is not having done it.
import {
  Agent,
  Assert,
  AssertOccurs,
  Approves,
  Believes,
  ByChance,
  Causes,
  context,
  Drought,
  Enables,
  Ends,
  Entity,
  Fall,
  GetOut,
  Has,
  InOrderTo,
  JumpDown,
  JumpOn,
  JumpUp,
  LocatedAt,
  Motivates,
  Next,
  Occurs,
  PassBy,
  Put,
  ResultsIn,
  SameReferent,
  Says,
  Unable,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const fox = entity(root, "the Fox");
  const goat = entity(root, "the Goat");
  const well = entity(root, "a deep well");
  const water = entity(root, "water");
  const horns = entity(root, "her long horns");
  const edge = entity(root, "the edge of the well");
  const foot = entity(root, "his foot");
  const herBack = entity(root, "her back");
  input.push(fox, goat, well, water, horns, edge, foot, herBack);

  // The fox's news: a coming drought, his claimed jumping, the purpose.
  const news = context(
    new Situation(),
    "there is going to be a great drought, so I jumped down",
  );
  input.push(news);
  const drought = new Drought(news);
  Assert(input, drought, news);
  // "So I jumped down here": what he says happened, and who did it.
  const saidJump = new JumpDown(news);
  saidJump.theme = fox;
  saidJump.destination = well;
  input.push(saidJump);
  AssertOccurs(input, saidJump, news);
  const saidJumper = new Agent(news);
  saidJumper.action = saidJump;
  saidJumper.actor = fox;
  Assert(input, saidJumper, news);
  const waterNear = new Has(news);
  waterNear.owner = fox;
  waterNear.possession = water;
  input.push(waterNear);
  const saidWhy = new InOrderTo(news);
  saidWhy.action = saidJump;
  saidWhy.goal = waterNear;
  Assert(input, saidWhy, news);

  // The goat's approving belief of that advice, held by the world.
  const approval = context(new Situation(), "the fox's advice was good");
  input.push(approval);
  const thoughtWell = new Approves(approval);
  thoughtWell.approver = goat;
  thoughtWell.of = news;
  Assert(input, thoughtWell, approval);
  // "Only too taken in by the smooth cunning of the Fox" — the guide's
  // semantics for Q3 is that she believed; so the world holds it.
  const believed = new Believes(root);
  believed.believer = goat;
  believed.content = approval;
  Assert(input, believed);

  const fellIn = new Fall(root);
  fellIn.theme = fox;
  fellIn.destination = well;
  const goatPassed = new PassBy(root);
  const goatAsked = new Says(root);
  goatAsked.text = "What are you doing down there?";
  const foxNews = new Says(root);
  foxNews.text =
    "Oh, have you not heard? There is going to be a great drought, so I jumped down here in order to be sure to have water by me. Why don't you come down too?";
  foxNews.content = news;
  const goatJump = new JumpDown(root);
  goatJump.theme = goat;
  goatJump.destination = well;
  const foxOnBack = new JumpOn(root);
  foxOnBack.target = herBack;
  const footOnHorns = new Put(root);
  footOnHorns.theme = foot;
  footOnHorns.destination = horns;
  const escape = new JumpUp(root);
  escape.from = well;
  escape.to = edge;
  const foxBye = new Says(root);
  foxBye.text = "Good-bye, friend. Remember next time...";
  const happened = [
    fellIn,
    goatPassed,
    goatAsked,
    foxNews,
    goatJump,
    foxOnBack,
    footOnHorns,
    escape,
    foxBye,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  // The fall happened to him by unlucky chance: no agent of it.
  agent(root, input, goatPassed, goat);
  agent(root, input, goatAsked, goat);
  agent(root, input, foxNews, fox);
  agent(root, input, goatJump, goat);
  agent(root, input, foxOnBack, fox);
  agent(root, input, footOnHorns, fox);
  agent(root, input, escape, fox);
  agent(root, input, foxBye, fox);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  // "By an unlucky chance", and the world's identification of the said
  // jumping with the actual falling.
  const unlucky = new ByChance(root);
  unlucky.event = fellIn;
  Assert(input, unlucky);
  const sameGettingIn = new SameReferent(root);
  sameGettingIn.left = saidJump;
  sameGettingIn.right = fellIn;
  Assert(input, sameGettingIn);

  // Could not get out, from the fall until the goat came down: "by
  // putting his foot on her long horns [he] managed to jump up" names the
  // goat as the means, so her coming down is what made it possible; the
  // escape is the ability exercised, not its start.
  const gettingOut = new GetOut(root);
  gettingOut.from = well;
  input.push(gettingOut);
  const trapped = new Unable(root);
  trapped.actor = fox;
  trapped.deed = gettingOut;
  input.push(trapped);
  const trappedAt = new ResultsIn(root);
  trappedAt.event = fellIn;
  trappedAt.proposition = trapped;
  Assert(input, trappedAt);
  const freeAgain = new Ends(root);
  freeAgain.event = goatJump;
  freeAgain.state = trapped;
  Assert(input, freeAgain);
  const madePossible = new Enables(root);
  madePossible.enabler = goatJump;
  madePossible.enabled = escape;
  Assert(input, madePossible);

  const adviceMoved = new Motivates(root);
  adviceMoved.driver = believed;
  adviceMoved.action = goatJump;
  Assert(input, adviceMoved);

  return {
    root,
    fox,
    goat,
    well,
    fellIn,
    goatJump,
    escape,
    news,
    saidJump,
    waterNear,
    saidWhy,
  };
}
