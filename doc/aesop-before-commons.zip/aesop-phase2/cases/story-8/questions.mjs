// Frozen question texts and semantic expectations for "The Nurse and the
// Wolf" (guide section 6.3, Story 8). The English text never changes;
// `semantic` is binding. Guide twins are exercised in regression.
export const Frozen = [
  {
    text: "Who was the nurse speaking to when she mentioned the wolf?",
    semantic: "值:the child",
    tests: "受话人 ≠ 偷听者",
  },
  {
    text: "What did the wolf hope to eat?",
    semantic: "值:the child",
    tests: "狼的预期语境",
  },
  {
    text: "Did the child make the noise again?",
    semantic: "是",
    tests: "条件前件实现",
  },
  {
    // Phase 2r4 text change: the original "Did the nurse throw the child
    // to the wolf?" named no time, while "all the Nurse did" answers the
    // moment the child cried; the question now names that moment.
    text: "When the child began to cry, did the nurse throw it to the wolf?",
    semantic: "否(N5 穷尽陈述推出的否定)",
    tests: "穷尽",
  },
  {
    text: "Why did the wolf crouch down by the house and wait?",
    semantic: "值:他预期孩子很快会哭、会被扔给他(他自己的预期,不是谁的承诺)",
    tests: "误解形成的预期驱动行动('So he crouched')",
  },
];

export const Twins = [
  {
    text: "Did anyone promise the wolf the child?",
    semantic: "未确立(只有狼自己在结尾称之为 promise)",
  },
  {
    text: "Did the nurse call for help?",
    semantic: "是",
  },
];

// The five questions. The threat is read through its speech context; the
// wolf's hope through his expectation context; the renewed crying as a
// shape after the warning; the negated throwing through the exhaustive
// OnlyDid, at the crying the question names; the waiting's driver is the
// believing itself.
import {
  After,
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Believes,
  Conditional,
  Cry,
  Eat,
  Goal,
  HoldsIn,
  Motivates,
  Says,
  Throw,
  CallForHelp,
  Promise,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(the child)",
    build(input, asked, world, answer) {
      const s = new Variable(asked);
      input.push(s);
      const d = new Says(asked);
      d.to = answer;
      d.content = s;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.nurse;
      Assert(input, who);
      // The mentioning of the wolf: the threat's consequence.
      const thrown = new Throw(asked);
      thrown.to = world.wolf;
      input.push(thrown);
      const warning = new Conditional(asked);
      warning.consequent = thrown;
      input.push(warning);
      const held = new HoldsIn(asked);
      held.context = s;
      held.proposition = warning;
      Assert(input, held);
      return [s];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "Entity(the child)",
    build(input, asked, world, answer) {
      const w = new Variable(asked);
      input.push(w);
      const belief = new Believes(asked);
      belief.believer = world.wolf;
      belief.content = w;
      Assert(input, belief);
      const meal = new Eat(asked);
      meal.theme = answer;
      input.push(meal);
      const hope = new Goal(asked);
      hope.actor = world.wolf;
      hope.objective = meal;
      input.push(hope);
      const held = new HoldsIn(asked);
      held.context = w;
      held.proposition = hope;
      Assert(input, held);
      return [w];
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      // The asked content is a shape, never a presupposed correspondent:
      // "again" is after the nurse's warning, the noise is a crying
      // (the wolf's "It is sure to cry soon"). A yes means a crying by
      // the child occurred after the warning; a held negation could
      // answer no.
      const d = new Cry(asked);
      input.push(d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.child;
      input.push(who);
      const again = new After(asked);
      again.event = world.beQuiet;
      input.push(again);
      const asked1 = new AskWhether(asked);
      asked1.content = who;
      asked1.when = again;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const d = new Throw(asked);
      d.theme = world.child;
      d.to = world.wolf;
      input.push(d);
      const did = new Agent(asked);
      did.action = d;
      did.actor = world.nurse;
      input.push(did);
      // "When the child began to cry": a description the solver binds
      // to the world's crying by the child; it is the question's time.
      const cry = new Cry(asked);
      input.push(cry);
      const known = new Among(asked);
      known.situation = world.root;
      known.node = cry;
      Assert(input, known);
      AssertOccurs(input, cry);
      const crier = new Agent(asked);
      crier.action = cry;
      crier.actor = world.child;
      Assert(input, crier);
      const asked1 = new AskWhether(asked);
      asked1.content = did;
      asked1.when = cry;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected:
      "Believes(believer=Entity(the Wolf),content=Context(the child would soon cry and be thrown to him))",
    build(input, asked, world, answer) {
      const why = new Motivates(asked);
      why.driver = answer;
      why.action = world.waiting;
      Assert(input, why);
    },
  },
];

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      // A shape, not the threat's own node: any promise of the child
      // to the wolf, by anyone. The wolf's closing "promises" is his
      // gloss, never world-held promising.
      const giving = new Throw(asked);
      giving.theme = world.child;
      giving.to = world.wolf;
      input.push(giving);
      const promised = new Promise(asked);
      promised.deed = giving;
      input.push(promised);
      const asked1 = new AskWhether(asked);
      asked1.content = promised;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const d = new CallForHelp(asked);
      input.push(d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.nurse;
      input.push(who);
      const asked1 = new AskWhether(asked);
      asked1.content = who;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
];
