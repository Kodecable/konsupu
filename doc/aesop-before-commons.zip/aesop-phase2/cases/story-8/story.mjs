// BuildStory for "The Nurse and the Wolf". The nurse's threat is a
// conditional inside her speech context — content, never a promise. The
// wolf overhears it and forms his own expectation context, which holds
// that the child will cry and that very threatened throwing will happen;
// nothing in the world says it will. His crouching and waiting are driven
// by that believing. "All the Nurse did was to shut down the window and
// call for help" is an exhaustive listing the world holds from the
// child's crying on; the negation of the threatened throwing is derived
// from it, not handwritten.
import {
  Agent,
  Assert,
  AssertOccurs,
  Believes,
  CallForHelp,
  ComeTo,
  Conditional,
  context,
  Cry,
  Entity,
  Eat,
  GallopAway,
  Goal,
  Hear,
  Motivates,
  Next,
  Occurs,
  OnlyDid,
  Overlaps,
  PassBy,
  ResultsIn,
  RushOut,
  Says,
  Shut,
  TheEnd,
  Throw,
  Wait,
  Crouch,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const nurse = entity(root, "the old Nurse");
  const child = entity(root, "the child");
  const wolf = entity(root, "the Wolf");
  const dogs = entity(root, "the dogs of the house");
  const house = entity(root, "the side of the house");
  const window = entity(root, "the window");
  input.push(nurse, child, wolf, dogs, house, window);

  // The threat: her speech context holds the conditional. "That noise"
  // is the child's crying (the wolf's own "It is sure to cry soon" makes
  // the reading; see RESULTS).
  const threat = context(new Situation(), "the nurse's threat");
  input.push(threat);
  const throwChild = new Throw(threat);
  throwChild.theme = child;
  throwChild.to = wolf;
  input.push(throwChild);
  const noiseAgain = new Cry(threat);
  input.push(noiseAgain);
  const warned = new Conditional(threat);
  warned.antecedent = noiseAgain;
  warned.consequent = throwChild;
  Assert(input, warned, threat);

  // The wolf's expectation, formed on hearing the threat: the child will
  // cry soon, the threatened throwing will happen, and he will eat the
  // child.
  const expectation = context(
    new Situation(),
    "the child would soon cry and be thrown to him",
  );
  input.push(expectation);
  const crySoon = new Cry(expectation);
  input.push(crySoon);
  AssertOccurs(input, crySoon, expectation);
  agent(expectation, input, crySoon, child);
  const willBeThrown = new Occurs(expectation);
  willBeThrown.event = throwChild;
  Assert(input, willBeThrown, expectation);
  const eatChild = new Eat(expectation);
  eatChild.theme = child;
  input.push(eatChild);
  const wantedMeal = new Goal(expectation);
  wantedMeal.actor = wolf;
  wantedMeal.objective = eatChild;
  Assert(input, wantedMeal, expectation);

  const believed = new Believes(root);
  believed.believer = wolf;
  believed.content = expectation;
  input.push(believed);

  const beQuiet = new Says(root);
  beQuiet.to = child;
  beQuiet.text = "Be quiet now. If you make that noise again I will throw you to the Wolf.";
  beQuiet.content = threat;
  const passing = new PassBy(root);
  const heard = new Hear(root);
  heard.theme = beQuiet;
  const crouch = new Crouch(root);
  crouch.place = house;
  const waiting = new Wait(root);
  const childCried = new Cry(root);
  const cameForward = new ComeTo(root);
  cameForward.destination = window;
  const shutWindow = new Shut(root);
  shutWindow.theme = window;
  const callHelp = new CallForHelp(root);
  const dogsRush = new RushOut(root);
  const gallopAway = new GallopAway(root);
  const happened = [
    beQuiet,
    passing,
    heard,
    crouch,
    waiting,
    childCried,
    cameForward,
    shutWindow,
    callHelp,
    dogsRush,
    gallopAway,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, beQuiet, nurse);
  agent(root, input, passing, wolf);
  agent(root, input, heard, wolf);
  agent(root, input, crouch, wolf);
  agent(root, input, waiting, wolf);
  agent(root, input, childCried, child);
  agent(root, input, cameForward, wolf);
  agent(root, input, shutWindow, nurse);
  agent(root, input, callHelp, nurse);
  agent(root, input, dogsRush, dogs);
  agent(root, input, gallopAway, wolf);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    if (happened[index] === beQuiet && happened[index + 1] === passing) {
      continue;
    }
    next(root, input, happened[index], happened[index + 1]);
  }

  // "A Wolf was passing close under the window as this was said".
  const whileSaid = new Overlaps(root);
  whileSaid.first = beQuiet;
  whileSaid.second = passing;
  Assert(input, whileSaid);

  const formed = new ResultsIn(root);
  formed.event = heard;
  formed.proposition = believed;
  Assert(input, formed);
  const crouchMoved = new Motivates(root);
  crouchMoved.driver = believed;
  crouchMoved.action = crouch;
  Assert(input, crouchMoved);
  const waitMoved = new Motivates(root);
  waitMoved.driver = believed;
  waitMoved.action = waiting;
  Assert(input, waitMoved);

  // "Till at last the child began to cry, and the Wolf came forward …
  // But all the Nurse did was to shut down the window and call for
  // help": the listing answers that moment — from the crying on. Her
  // earlier "Be quiet" lies outside it and stays untouched; the solver
  // derives what did not happen inside the scope.
  const allSheDid = new OnlyDid(root);
  allSheDid.actor = nurse;
  allSheDid.deeds = [shutWindow, callHelp];
  allSheDid.from = childCried;
  allSheDid.until = TheEnd;
  Assert(input, allSheDid);

  return {
    root,
    nurse,
    child,
    wolf,
    threat,
    throwChild,
    expectation,
    believed,
    beQuiet,
    childCried,
    waiting,
  };
}
