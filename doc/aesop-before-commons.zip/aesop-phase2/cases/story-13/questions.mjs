// Frozen question texts and semantic expectations for "The Fox, the
// Cock, and the Dog" (guide section 6.3, Story 13). The English text
// never changes; `semantic` is binding. Guide twins are exercised in
// regression.
export const Frozen = [
  {
    text: "What did the fox say King Lion had declared?",
    semantic: "值:一场普遍休战",
    tests: "言语内容",
  },
  {
    text: "According to the fox's news, may a beast hurt a bird?",
    semantic: "否(在狐狸所说的语境中)",
    tests: "N4 规范否定;非 world 语境中的是非问",
  },
  {
    text: "Could the fox reach the cock?",
    semantic: "否('beyond his reach')",
    tests: "N3",
  },
  {
    text: "What did the fox do as soon as he heard that the dog was coming?",
    semantic: "值:开始转身离开",
    tests: "紧接",
  },
  {
    text: "What reason did the fox give for not staying to congratulate the dog?",
    semantic: "值:他担心狗可能还没听说狮王的命令",
    tests: "嵌套态度 + 否定",
  },
];

export const Twins = [
  {
    text: "Was there really a universal truce?",
    semantic: "未确立",
  },
  {
    text: "According to the fox's news, shall all dwell together in brotherly friendship?",
    semantic: "是",
  },
];

// The five questions. The declaring is read as the occurred doing inside
// the news context; permission asks the complement of the norm; reach
// asks the complement of the inability; "as soon as" is the immediate
// successor of the hearing; the given reason is the fearing the excuse
// speech holds, retrieved whole.
import {
  Agent,
  Among,
  Assert,
  AssertOccurs,
  AskWhether,
  Congratulate,
  Declare,
  Forbids,
  GetAt,
  Hear,
  HoldsIn,
  Hurt,
  Motivates,
  Next,
  Not,
  Occurs,
  SameReferent,
  Says,
  Unable,
  Dwell,
  Mandates,
} from "../../space/Interface/Aesop.js";
import { Variable } from "../../space/Interface/Nodes.js";

export const Questions = [
  {
    text: Frozen[0].text,
    semantic: Frozen[0].semantic,
    expected: "Entity(a universal truce)",
    build(input, asked, world, answer) {
      const s = new Variable(asked);
      input.push(s);
      const d = new Says(asked);
      d.content = s;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      const declared = new Declare(asked);
      declared.declaration = answer;
      input.push(declared);
      const happened = new Occurs(asked);
      happened.event = declared;
      input.push(happened);
      const byKing = new Agent(asked);
      byKing.action = declared;
      byKing.actor = world.kingLion;
      input.push(byKing);
      const saidHappened = new HoldsIn(asked);
      saidHappened.context = s;
      saidHappened.proposition = happened;
      Assert(input, saidHappened);
      const saidBy = new HoldsIn(asked);
      saidBy.context = s;
      saidBy.proposition = byKing;
      Assert(input, saidBy);
      return [s];
    },
  },
  {
    text: Frozen[1].text,
    semantic: Frozen[1].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const s = newsOf(input, asked, world);
      // "May a beast hurt a bird": the news's own beast and bird, its
      // only ones.
      const deed = new Hurt(asked);
      deed.doer = world.beast;
      deed.theme = world.bird;
      input.push(deed);
      const forbidden = new Forbids(asked);
      forbidden.deed = deed;
      input.push(forbidden);
      const mayNot = new Not(asked);
      mayNot.proposition = forbidden;
      input.push(mayNot);
      const asked1 = new AskWhether(asked);
      asked1.content = mayNot;
      asked1.context = s;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [s];
    },
  },
  {
    text: Frozen[2].text,
    semantic: Frozen[2].semantic,
    expected: "{result=no}",
    build(input, asked, world, answer) {
      const deed = new GetAt(asked);
      deed.theme = world.cock;
      input.push(deed);
      const beyond = new Unable(asked);
      beyond.actor = world.fox;
      beyond.deed = deed;
      input.push(beyond);
      const could = new Not(asked);
      could.proposition = beyond;
      input.push(could);
      const asked1 = new AskWhether(asked);
      asked1.content = could;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Frozen[3].text,
    semantic: Frozen[3].semantic,
    expected: "TurnAway()",
    build(input, asked, world, answer) {
      // "As soon as he heard that the dog was coming": the fox's hearing
      // of a saying whose content identifies the one coming as the dog;
      // "as soon as" is the very next thing he did (Next).
      const c = new Variable(asked);
      input.push(c);
      const told = new Says(asked);
      told.content = c;
      input.push(told);
      const toldKnown = new Among(asked);
      toldKnown.situation = world.root;
      toldKnown.node = told;
      Assert(input, toldKnown);
      const isDog = new SameReferent(asked);
      isDog.right = world.dog;
      input.push(isDog);
      const content = new HoldsIn(asked);
      content.context = c;
      content.proposition = isDog;
      Assert(input, content);
      const hearing = new Hear(asked);
      hearing.theme = told;
      input.push(hearing);
      const heardKnown = new Among(asked);
      heardKnown.situation = world.root;
      heardKnown.node = hearing;
      Assert(input, heardKnown);
      const hearer = new Agent(asked);
      hearer.action = hearing;
      hearer.actor = world.fox;
      Assert(input, hearer);
      const when = new Next(asked);
      when.earlier = hearing;
      when.later = answer;
      Assert(input, when);
      return [c];
    },
  },
  {
    text: Frozen[4].text,
    semantic: Frozen[4].semantic,
    expected:
      "Fears(content=Context(the dog may not have heard of King Lion's decree),fearer=Entity(the Fox))",
    build(input, asked, world, answer) {
      const e = new Variable(asked);
      input.push(e);
      const d = new Says(asked);
      d.content = e;
      input.push(d);
      const h = new Among(asked);
      h.situation = world.root;
      h.node = d;
      Assert(input, h);
      AssertOccurs(input, d);
      const who = new Agent(asked);
      who.action = d;
      who.actor = world.fox;
      Assert(input, who);
      // "The reason he gave for not staying to congratulate the dog":
      // what his saying holds as moving him not to congratulate — the
      // reason given, never a motive the world confirms.
      const congratulating = new Congratulate(asked);
      congratulating.theme = world.dog;
      input.push(congratulating);
      const happening = new Occurs(asked);
      happening.event = congratulating;
      input.push(happening);
      const notDoing = new Not(asked);
      notDoing.proposition = happening;
      input.push(notDoing);
      const why = new Motivates(asked);
      why.driver = answer;
      why.action = notDoing;
      input.push(why);
      const given = new HoldsIn(asked);
      given.context = e;
      given.proposition = why;
      Assert(input, given);
      return [e];
    },
  },
];

// The fox's news speech, bound through its Says by the fox.
function newsOf(input, asked, world) {
  const s = new Variable(asked);
  input.push(s);
  const d = new Says(asked);
  d.content = s;
  input.push(d);
  const h = new Among(asked);
  h.situation = world.root;
  h.node = d;
  Assert(input, h);
  AssertOccurs(input, d);
  const who = new Agent(asked);
  who.action = d;
  who.actor = world.fox;
  Assert(input, who);
  // "The fox's news" is the saying that announces a declaring — told
  // apart by what it says, not by where it falls in the talk.
  const declaring = new Declare(asked);
  input.push(declaring);
  const announced = new Occurs(asked);
  announced.event = declaring;
  input.push(announced);
  const tells = new HoldsIn(asked);
  tells.context = s;
  tells.proposition = announced;
  Assert(input, tells);
  return s;
}

// Guide twins, executable.
export const TwinQuestions = [
  {
    text: Twins[0].text,
    semantic: Twins[0].semantic,
    expected:
      "{constraints=[AskWhether],level=instance,result=not-established}",
    build(input, asked, world, answer) {
      const d = new Declare(asked);
      d.declaration = world.truce;
      input.push(d);
      const happened = new Occurs(asked);
      happened.event = d;
      input.push(happened);
      const asked1 = new AskWhether(asked);
      asked1.content = happened;
      asked1.verdict = answer;
      Assert(input, asked1);
    },
  },
  {
    text: Twins[1].text,
    semantic: Twins[1].semantic,
    expected: "{result=yes}",
    build(input, asked, world, answer) {
      const s = newsOf(input, asked, world);
      const dwell = new Dwell(asked);
      dwell.manner = "in brotherly friendship";
      input.push(dwell);
      const enjoined = new Mandates(asked);
      enjoined.content = dwell;
      input.push(enjoined);
      const asked1 = new AskWhether(asked);
      asked1.content = enjoined;
      asked1.context = s;
      asked1.verdict = answer;
      Assert(input, asked1);
      return [s];
    },
  },
];
