// BuildStory for "The Fox, the Cock, and the Dog". The fox's news is a
// speech context with its own inner timeline: King Lion's declaring
// (as claimed) starts the truce's norms "henceforth" — a prohibition and
// an enjoining, both negated and affirmed only inside that context. The
// cock's sightings are speech content the narrator never confirms; the
// fox's excuse nests a fearing around a negated having-heard. The cock
// stays beyond the fox's reach all along. Nothing here says what the dog
// or the fox believed about the truce.
import {
  Agent,
  Assert,
  AssertOccurs,
  Congratulate,
  context,
  Declare,
  Dwell,
  Entity,
  Forbids,
  Fears,
  GetAt,
  Hear,
  Hurt,
  Mandates,
  Motivates,
  Next,
  Not,
  Occurs,
  Prowl,
  ResultsIn,
  SameReferent,
  See,
  Says,
  TurnAway,
  Unable,
  HeardOf,
} from "../../space/Interface/Aesop.js";
import { Situation } from "../../space/Interface/Nodes.js";

function entity(root, name) {
  const value = new Entity(root);
  value.name = name;
  return value;
}

function agent(root, input, action, actor) {
  const relation = new Agent(root);
  relation.action = action;
  relation.actor = actor;
  Assert(input, relation);
}

function next(root, input, earlier, later) {
  const relation = new Next(root);
  relation.earlier = earlier;
  relation.later = later;
  Assert(input, relation);
}

export function BuildStory(input, root) {
  const fox = entity(root, "the Fox");
  const cock = entity(root, "the Cock");
  const dog = entity(root, "my master's Dog");
  const henCoop = entity(root, "a farmer's hen-coop");
  input.push(fox, cock, dog, henCoop);

  // The fox's news: King Lion's declaring and what it henceforth forbids
  // and enjoins — all inside the speech.
  const news = context(
    new Situation(),
    "King Lion has declared a universal truce",
  );
  input.push(news);
  const kingLion = entity(news, "King Lion");
  const truce = entity(news, "a universal truce");
  const bird = entity(news, "a bird");
  const beast = entity(news, "a beast");
  input.push(kingLion, truce, bird, beast);
  const declared = new Declare(news);
  declared.declaration = truce;
  input.push(declared);
  AssertOccurs(input, declared, news);
  agent(news, input, declared, kingLion);
  // "No beast may hurt a bird": the forbidden deed is a beast's.
  const hurtBird = new Hurt(news);
  hurtBird.doer = beast;
  hurtBird.theme = bird;
  input.push(hurtBird);
  const forbidden = new Forbids(news);
  forbidden.deed = hurtBird;
  input.push(forbidden);
  const normsBegan = new ResultsIn(news);
  normsBegan.event = declared;
  normsBegan.proposition = forbidden;
  Assert(input, normsBegan, news);
  const dwellTogether = new Dwell(news);
  dwellTogether.manner = "in brotherly friendship";
  input.push(dwellTogether);
  const enjoined = new Mandates(news);
  enjoined.content = dwellTogether;
  input.push(enjoined);
  const peaceBegan = new ResultsIn(news);
  peaceBegan.event = declared;
  peaceBegan.proposition = enjoined;
  Assert(input, peaceBegan, news);

  // The cock's sighting: some one coming — speech content, unconfirmed.
  const sightCtx = context(new Situation(), "the Cock's sighting");
  input.push(sightCtx);
  const someone = entity(sightCtx, "some one coming");
  input.push(someone);
  const sawSomeone = new See(sightCtx);
  sawSomeone.theme = someone;
  input.push(sawSomeone);
  AssertOccurs(input, sawSomeone, sightCtx);
  agent(sightCtx, input, sawSomeone, cock);

  // The identification: the coming one is the dog — the cock's claim.
  const claimCtx = context(new Situation(), "the Cock's identification");
  input.push(claimCtx);
  const isDog = new SameReferent(claimCtx);
  isDog.left = someone;
  isDog.right = dog;
  Assert(input, isDog, claimCtx);

  // The fox's excuse: a fearing of a negated having-heard.
  const fearCtx = context(
    new Situation(),
    "the dog may not have heard of King Lion's decree",
  );
  input.push(fearCtx);
  const notHeard = new Not(fearCtx);
  const heard = new HeardOf(fearCtx);
  heard.hearer = dog;
  heard.news = truce;
  input.push(heard);
  notHeard.proposition = heard;
  Assert(input, notHeard, fearCtx);
  // "I would gladly do so, but I fear …": the excuse holds the fearing
  // and gives it as the reason for not congratulating the dog. All of
  // it is what the fox said; the narrator never confirms the fear.
  const excuseCtx = context(new Situation(), "the fox's excuse");
  input.push(excuseCtx);
  const feared = new Fears(excuseCtx);
  feared.fearer = fox;
  feared.content = fearCtx;
  Assert(input, feared, excuseCtx);
  const congratulating = new Congratulate(excuseCtx);
  congratulating.theme = dog;
  input.push(congratulating);
  const happening = new Occurs(excuseCtx);
  happening.event = congratulating;
  input.push(happening);
  const notDoing = new Not(excuseCtx);
  notDoing.proposition = happening;
  input.push(notDoing);
  const reasonGiven = new Motivates(excuseCtx);
  reasonGiven.driver = feared;
  reasonGiven.action = notDoing;
  Assert(input, reasonGiven, excuseCtx);

  const prowl = new Prowl(root);
  const seeCock = new See(root);
  seeCock.theme = cock;
  const foxCry = new Says(root);
  foxCry.text = "Good news, good news!";
  const cockAsk = new Says(root);
  cockAsk.text = "Why, what is that?";
  const foxTell = new Says(root);
  foxTell.text =
    "King Lion has declared a universal truce. No beast may hurt a bird henceforth, but all shall dwell together in brotherly friendship.";
  foxTell.content = news;
  const cockSee = new Says(root);
  cockSee.text =
    "Why, that is good news; and there I see some one coming, with whom we can share the good tidings.";
  cockSee.content = sightCtx;
  const foxAsk = new Says(root);
  foxAsk.text = "What is it you see?";
  const cockTell = new Says(root);
  cockTell.text = "It is only my master's Dog that is coming towards us.";
  cockTell.content = claimCtx;
  const heardNews = new Hear(root);
  heardNews.theme = cockTell;
  const turnedAway = new TurnAway(root);
  const cockTease = new Says(root);
  cockTease.text =
    "What, going so soon? Will you not stop and congratulate the Dog on the reign of universal peace?";
  const foxExcuse = new Says(root);
  foxExcuse.text =
    "I would gladly do so, but I fear he may not have heard of King Lion's decree.";
  foxExcuse.content = excuseCtx;
  const happened = [
    prowl,
    seeCock,
    foxCry,
    cockAsk,
    foxTell,
    cockSee,
    foxAsk,
    cockTell,
    heardNews,
    turnedAway,
    cockTease,
    foxExcuse,
  ];
  input.push(...happened);
  for (const event of happened) AssertOccurs(input, event);

  agent(root, input, prowl, fox);
  agent(root, input, seeCock, fox);
  agent(root, input, foxCry, fox);
  agent(root, input, cockAsk, cock);
  agent(root, input, foxTell, fox);
  agent(root, input, cockSee, cock);
  agent(root, input, foxAsk, fox);
  agent(root, input, cockTell, cock);
  agent(root, input, heardNews, fox);
  agent(root, input, turnedAway, fox);
  agent(root, input, cockTease, cock);
  agent(root, input, foxExcuse, fox);

  for (let index = 0; index + 1 < happened.length; index += 1) {
    next(root, input, happened[index], happened[index + 1]);
  }

  // "Beyond his reach".
  const reaching = new GetAt(root);
  reaching.theme = cock;
  input.push(reaching);
  const beyond = new Unable(root);
  beyond.actor = fox;
  beyond.deed = reaching;
  Assert(input, beyond);

  return {
    root,
    fox,
    cock,
    dog,
    news,
    truce,
    kingLion,
    beast,
    bird,
    declared,
    forbidden,
    dwellTogether,
    cockAsk,
    cockTell,
    heardNews,
    turnedAway,
    cockTease,
    foxExcuse,
    excuseCtx,
    feared,
    fearCtx,
  };
}
