// Targeted mutation validation (guide section 8): each run copies the
// whole experiment to a scratch directory, applies one textual mutation
// to one semantic rule, and records exactly which regressions and how
// many of the 65 questions it breaks. A mutation that breaks nothing the
// regressions can see is a hole in the test wall. Run with
// `node mutation.mjs`.
import { cpSync, mkdirSync, rmSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const here = fileURLToPath(new URL(".", import.meta.url));

// Each mutation names the one rule it disables and the exact patch that
// disables it.
const Mutations = [
  {
    name: "inertia-off (Ends and class-derived endings ignored)",
    file: "space/Memory/Aesop/Temporal.js",
    find: "  endOf(node) {\n    let end = null;",
    replace: "  endOf(node) {\n    return null;\n    let end = null;",
  },
  {
    name: "noevent-window-ignored (negated existence refutes everywhere)",
    file: "space/Memory/Aesop/Covering.js",
    find: "function windowCovers(timeline, from, until, window) {",
    replace:
      "function windowCovers(timeline, from, until, window) {\n  return true;",
  },
  {
    name: "context-fallback-to-world (HoldsIn also reads world-held)",
    file: "space/Memory/Aesop/Reading.js",
    find: `    for (const proposition of contextHolds(view, target)) {
      const trial = new Map(base);
      if (matchValue(constraint.proposition, proposition, trial, shaped)) {
        tuples.push(trial);
      }
    }`,
    replace: `    for (const proposition of contextHolds(view, target)) {
      const trial = new Map(base);
      if (matchValue(constraint.proposition, proposition, trial, shaped)) {
        tuples.push(trial);
      }
    }
    for (const proposition of heldAbove(view, context.asked)) {
      const trial = new Map();
      if (matchValue(constraint.proposition, proposition, trial, shaped)) {
        tuples.push(trial);
      }
    }`,
  },
  {
    name: "question-shapes-off (content matching by identity again)",
    file: "space/Memory/Aesop/Shapes.js",
    find: "export function withQuestionShapes(context, ...patterns) {",
    replace:
      "export function withQuestionShapes(context, ...patterns) {\n  return context;",
  },
  {
    name: "ends-negation-off (an ended state is merely unstated after)",
    file: "space/Memory/Aesop/Covering.js",
    find: "function endNegatesAt(timeline, endEvent, when) {",
    replace:
      "function endNegatesAt(timeline, endEvent, when) {\n  return false;",
  },
  {
    name: "verdict-scope-off (all join bindings kept across contexts)",
    file: "space/Memory/Aesop/Verdicts.js",
    find: "      scope.has(value.situated) ||",
    replace: "      true ||",
  },
  {
    name: "agent-window-off (an agent question ignores time)",
    file: "space/Memory/Aesop/Positives.js",
    find: "      if (!inWindow(timeline, proposition.action, window)) continue;",
    replace: "      if (false && !inWindow(timeline, proposition.action, window)) continue;",
  },
  {
    name: "nth-window-unbounded (the n-th opens to the end)",
    file: "space/Memory/Aesop/Anchors.js",
    find: "    return { kind: \"until\", event, until: events[when.index] ?? null };",
    replace: "    return { kind: \"from\", event };",
  },
  {
    name: "before-window-covered-anyway (a late negation covers the past)",
    file: "space/Memory/Aesop/Covering.js",
    find: "    if (from != null) return false;",
    replace: "    if (from != null && false) return false;",
  },
  {
    name: "class-end-not-refuting (derived endings merely end)",
    file: "space/Memory/Aesop/Refutations.js",
    find: "    if (end !== null && endNegatesAt(timeline, end, when)) tuples.push(trial);",
    replace: "    if (false && end !== null && endNegatesAt(timeline, end, when)) {\n      tuples.push(trial);\n    }",
  },
  {
    name: "chance-any-correspondence (the chance rule rebinds)",
    file: "space/Memory/Aesop/Refutations.js",
    find: "        const named = (left, right) => {\n          const trial = new Map(base);",
    replace: "        const named = (left, right) => {\n          const trial = new Map();",
  },
  {
    name: "while-window-ignored (while asks about the whole line)",
    file: "space/Memory/Aesop/Anchors.js",
    find: "    return { kind: \"during\", intervals };",
    replace: "    return null;",
  },
  {
    name: "context-events-unread (a context holds only propositions)",
    file: "space/Memory/Aesop/Reading.js",
    find: "  for (const event of occurredSet(held)) pool.push(event);",
    replace: "  for (const event of []) pool.push(event);",
  },
  {
    name: "ordinal-off (the n-th match resolves to the first)",
    file: "space/Memory/Aesop/Anchors.js",
    find: "  return nthEvents(timeline, nth, context)?.[nth.index - 1] ?? null;",
    replace: "  return nthEvents(timeline, nth, context)?.[0] ?? null;",
  },
  {
    name: "prior-to-stretch (before E reads any time before E)",
    file: "space/Memory/Aesop/Anchors.js",
    find: "    // Just before the anchor: started before it, not ended before it.\n    const end = timeline.endOf(node);",
    replace: "    // Just before the anchor: started before it, not ended before it.\n    const end = null;",
  },
  {
    name: "unanchored-one-sided (an ending never answers an unanchored question)",
    file: "space/Memory/Aesop/Verdicts.js",
    find: "  const anchors = when === null && !occurrence ? moments(timeline) : [when];",
    replace: "  const anchors = [when];",
  },
  {
    name: "overlap-ignored (simultaneous events fall out of the order)",
    file: "space/Memory/Aesop/Order.js",
    find: "      } else if (proposition instanceof Overlaps) {",
    replace: "      } else if (proposition instanceof Overlaps && false) {",
  },
  {
    name: "inability-not-exact (a narrower inability answers the general one)",
    file: "space/Memory/Aesop/Match.js",
    find: "  if (context.exact?.has(pattern)) {",
    replace: "  if (false) {",
  },
  {
    name: "names-match (a surface name takes part in matching)",
    file: "space/Memory/Aesop/Match.js",
    find: "    if (SURFACE.has(key)) continue;",
    replace: "",
  },
  {
    name: "stand-in-ignored (another context's node matches by the question's empty shape)",
    file: "space/Memory/Aesop/Match.js",
    find: "  if (context.standIn?.has(pattern)) pattern = context.standIn.get(pattern);",
    replace: "",
  },
  {
    name: "existence-opens-constants (a negated existence covers any sort)",
    file: "space/Memory/Aesop/Covering.js",
    find: "  if (!open.has(pattern) && !(pattern instanceof Proposition)) return false;",
    replace: "",
  },
  {
    name: "ordinal-on-partial-order (the n-th is picked among unordered events)",
    file: "space/Memory/Aesop/Anchors.js",
    find: "      if (!timeline.before(left, right) && !timeline.before(right, left)) {\n        return null;\n      }",
    replace: "",
  },
  {
    name: "nested-ordinal-off (an ordinal inside a content-matched effect never resolves)",
    file: "space/Memory/Aesop/Ordinals.js",
    find: "function contentNested(value, context) {",
    replace: "function contentNested(value, context) {\n  return false;",
  },
];

function run(cmd, args, cwd) {
  try {
    const out = execFileSync(cmd, args, { cwd, encoding: "utf8" });
    return { ok: true, out };
  } catch (caught) {
    return { ok: false, out: caught.stdout ?? "" };
  }
}

function summarizeRegression(output) {
  const failed = [
    ...output.matchAll(/^FAIL  (.+)$/gm).map((match) => match[1]),
  ].filter((name) => !name.startsWith("foundation: the copied source"));
  const total = /regression tests: (\d+)\/(\d+)/.exec(output);
  return { failed, passed: total ? Number(total[1]) : 0, total: total ? Number(total[2]) : 0 };
}

function summarizeQuestions(output) {
  const failed = [...output.matchAll(/^FAIL  (.+)$/gm).map((match) => match[1])];
  const total = /Aesop questions: (\d+)\/(\d+)/.exec(output);
  return { failed, passed: total ? Number(total[1]) : 0, total: total ? Number(total[2]) : 0 };
}

const scratch = join(here, ".mutation-scratch");
rmSync(scratch, { recursive: true, force: true });

const report = [];
for (const mutation of Mutations) {
  mkdirSync(scratch, { recursive: true });
  cpSync(join(here, "space"), join(scratch, "space"), { recursive: true });
  cpSync(join(here, "cases"), join(scratch, "cases"), { recursive: true });
  cpSync(join(here, "regression.mjs"), join(scratch, "regression.mjs"));
  cpSync(join(here, "run.mjs"), join(scratch, "run.mjs"));
  const target = join(scratch, mutation.file);
  const source = readFileSync(target, "utf8");
  if (!source.includes(mutation.find)) {
    report.push({ mutation: mutation.name, error: "patch anchor not found" });
    continue;
  }
  writeFileSync(target, source.replace(mutation.find, mutation.replace));
  const regression = run("node", ["regression.mjs"], scratch);
  const questions = run("node", ["run.mjs"], scratch);
  report.push({
    mutation: mutation.name,
    regressions: summarizeRegression(regression.out),
    questions: summarizeQuestions(questions.out),
  });
  rmSync(scratch, { recursive: true, force: true });
}

for (const entry of report) {
  if (entry.error) {
    console.log(`## ${entry.mutation}\n  ERROR: ${entry.error}`);
    continue;
  }
  console.log(`## ${entry.mutation}`);
  console.log(
    `  regressions: ${entry.regressions.passed}/${entry.regressions.total}` +
      `  questions: ${entry.questions.passed}/${entry.questions.total}`,
  );
  for (const name of entry.regressions.failed) console.log(`  REG-FAIL ${name}`);
  const storyFails = entry.questions.failed.filter((name) =>
    name.startsWith("Story"),
  );
  for (const name of storyFails.slice(0, 12)) {
    console.log(`  Q-FAIL    ${name}`);
  }
  if (storyFails.length > 12) {
    console.log(`  Q-FAIL    ...and ${storyFails.length - 12} more`);
  }
}
